import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "bun:test";

import { ARTIFACT_DIR } from "./artifact/paths";
import { findModules, findVerifications, loadGraceArtifactIndex, resolveGovernedFile, resolveModule, resolveVerification } from "./query/core";
import { GraceCommandError } from "./query/errors";
import { buildModuleHealth } from "./query/health";
import {
  formatModuleFindTable,
  formatModuleHealthText,
  formatModuleText,
  formatVerificationText,
} from "./query/render";
import { createTempProject, GraceProjectBuilder } from "./test-support/fixtures";

function createProject() {
  const root = mkdtempSync(path.join(os.tmpdir(), "grace-query-"));
  return root;
}

function writeProjectFile(root: string, relativePath: string, contents: string) {
  const filePath = path.join(root, relativePath);
  mkdirSync(path.dirname(filePath), { recursive: true });
  writeFileSync(filePath, contents);
}

function writeProjectSkeleton(root: string) {
  writeProjectFile(root, `${ARTIFACT_DIR}/context/requirements.xml`, `<NgraceRequirements graceVersion="1.0"><Summary>Required.</Summary></NgraceRequirements>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/technology.xml`, `<NgraceTechnology graceVersion="1.0"><Runtime>Bun</Runtime></NgraceTechnology>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/principles.xml`, `<NgracePrinciples graceVersion="1.0"><Principle>Safe.</Principle></NgracePrinciples>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/deployment.xml`, `<NgraceDeployment graceVersion="1.0"><Applicability>applicable</Applicability></NgraceDeployment>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/ux-guidelines.xml`, `<NgraceUXGuidelines graceVersion="1.0"><Applicability>applicable</Applicability></NgraceUXGuidelines>`);
  mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "active"), { recursive: true });
  mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "archive"), { recursive: true });
}

function writeNgraceArtifacts(root: string) {
  writeProjectSkeleton(root);
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/index.xml`,
    `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-DB /><M-PROVIDER-PERSIST /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/main.xml`,
    `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-DB><Summary>Provide a shared database client.</Summary><Path>src/db</Path></M-DB><M-PROVIDER-PERSIST><Summary>Persist provider configuration records.</Summary><Path>src/provider</Path><M-DB /></M-PROVIDER-PERSIST></GD-MAIN></NgraceGraphDocument>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/index.xml`,
    `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-DB /><V-M-PROVIDER-PERSIST /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/main.xml`,
    `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-DB><Scenario>Database client is available.</Scenario></V-M-DB><V-M-PROVIDER-PERSIST><Priority>high</Priority><Command>bun test src/provider/config-repo.test.ts</Command><Scenario>Reads and writes provider config records.</Scenario><Marker>[ProviderConfigPersistence][getProviderConfig][BLOCK_GET_PROVIDER_CONFIG]</Marker></V-M-PROVIDER-PERSIST></VD-MAIN></NgraceVerificationDocument>`,
  );
}

function writeProviderRuntime(
  root: string,
  options: { declarations?: string; body?: string } = {},
) {
  const declarations = options.declarations ? `${options.declarations}\n` : "";
  const body = options.body ?? `  console.info("[ProviderConfigPersistence][getProviderConfig][BLOCK_GET_PROVIDER_CONFIG] read");
  // START_BLOCK_GET_PROVIDER_CONFIG
  return { ok: true };
  // END_BLOCK_GET_PROVIDER_CONFIG`;
  writeProjectFile(
    root,
    "src/provider/config-repo.ts",
    `// START_MODULE_CONTRACT
//   PURPOSE: Persist and retrieve provider configuration records
//   SCOPE: Read and write singleton provider config rows
//   DEPENDS: M-DB
//   LINKS: M-PROVIDER-PERSIST, M-DB
// END_MODULE_CONTRACT
//
// START_MODULE_MAP
//   getProviderConfig - Fetch provider configuration
//   providerConfigRepo - Repository API object
// END_MODULE_MAP
//
// START_CHANGE_SUMMARY
//   LAST_CHANGE: [v0.1.0 - Added provider config repository]
// END_CHANGE_SUMMARY
//
// START_CONTRACT: getProviderConfig
//   PURPOSE: Read provider configuration from storage
//   OUTPUTS: { Promise<object> }
// END_CONTRACT: getProviderConfig
${declarations}export async function getProviderConfig() {
${body}
}
//
// START_CONTRACT: providerConfigRepo
//   PURPOSE: Expose repository operations as a stable API surface
// END_CONTRACT: providerConfigRepo
export const providerConfigRepo = { getProviderConfig };
`,
  );
}

function writeGovernedFiles(root: string) {
  writeProjectFile(
    root,
    "src/db/index.ts",
    `// START_MODULE_CONTRACT
//   PURPOSE: Expose the shared database surface
//   SCOPE: Provide the shared db client singleton
//   DEPENDS: none
//   LINKS: M-DB
// END_MODULE_CONTRACT
//
// START_MODULE_MAP
//   db - Shared database client export
// END_MODULE_MAP
export const db = {};
`,
  );
  writeProviderRuntime(root);
  writeProjectFile(
    root,
    "src/provider/config-repo.test.ts",
    `// START_MODULE_CONTRACT
//   PURPOSE: Verify provider config repository behavior.
//   SCOPE: Deterministic repository tests and evidence checks.
//   DEPENDS: bun:test, M-PROVIDER-PERSIST
//   LINKS: M-PROVIDER-PERSIST
// END_MODULE_CONTRACT
//
// START_MODULE_MAP
//   provider config smoke - Confirms provider repository evidence marker.
// END_MODULE_MAP
import { expect, test } from "bun:test";

test("provider config evidence marker", () => {
  expect("[ProviderConfigPersistence][getProviderConfig][BLOCK_GET_PROVIDER_CONFIG]").toContain("BLOCK_GET_PROVIDER_CONFIG");
});
`,
  );
}

function createQueryProject() {
  const root = createProject();
  writeNgraceArtifacts(root);
  writeGovernedFiles(root);
  return root;
}

describe("grace query core", () => {
  it("loads .ngrace projections and file-local module context into one index", () => {
    const root = createQueryProject();
    const index = loadGraceArtifactIndex(root);

    const providerModule = resolveModule(index, "M-PROVIDER-PERSIST");
    expect(providerModule.graph.path).toBe("src/provider");
    expect(providerModule.verifications.map((entry) => entry.id)).toEqual(["V-M-PROVIDER-PERSIST"]);
    expect(providerModule.localFiles.map((file) => file.path)).toEqual([
      "src/provider/config-repo.test.ts",
      "src/provider/config-repo.ts",
    ]);
    expect(index.issues.filter((issue) => issue.severity === "error")).toHaveLength(0);
  });

  it("finds modules through projection fields, dependencies, verification ids, and file-local paths", () => {
    const root = createQueryProject();
    const index = loadGraceArtifactIndex(root);

    const pathMatches = findModules(index, { query: "src/provider/config-repo.ts" });
    expect(pathMatches[0]?.module.id).toBe("M-PROVIDER-PERSIST");

    const dependencyMatches = findModules(index, { dependsOn: "M-DB" });
    expect(dependencyMatches.map((match) => match.module.id)).toEqual(["M-PROVIDER-PERSIST"]);

    const verificationMatches = findModules(index, { query: "V-M-PROVIDER-PERSIST" });
    expect(verificationMatches[0]?.module.id).toBe("M-PROVIDER-PERSIST");
  });

  it("resolves module show targets by choosing the most specific owning module path", () => {
    const root = createQueryProject();
    const index = loadGraceArtifactIndex(root);

    const providerModule = resolveModule(index, "src/provider/config-repo.ts");
    expect(providerModule.id).toBe("M-PROVIDER-PERSIST");
  });

  it("parses file-local contracts and blocks for file show", () => {
    const root = createQueryProject();
    const index = loadGraceArtifactIndex(root);

    const fileRecord = resolveGovernedFile(index, "src/provider/config-repo.ts");
    expect(fileRecord.linkedModuleIds).toEqual(["M-PROVIDER-PERSIST", "M-DB"]);
    expect(fileRecord.moduleMap.map((item) => item.label)).toEqual([
      "getProviderConfig - Fetch provider configuration",
      "providerConfigRepo - Repository API object",
    ]);
    expect(fileRecord.contracts.map((contract) => contract.name)).toEqual(["getProviderConfig", "providerConfigRepo"]);
    expect(fileRecord.blocks.map((block) => block.name)).toEqual(["GET_PROVIDER_CONFIG"]);
  });

  it("finds verification entries and resolves them by id or module target", () => {
    const root = createQueryProject();
    const index = loadGraceArtifactIndex(root);

    expect(findVerifications(index, { query: "provider config" }).map((match) => match.verification.id)).toEqual(["V-M-PROVIDER-PERSIST"]);
    expect(findVerifications(index, { query: "bun test" }).map((match) => match.verification.id)).toEqual(["V-M-PROVIDER-PERSIST"]);
    expect(findVerifications(index, { query: "BLOCK_GET_PROVIDER_CONFIG" }).map((match) => match.verification.id)).toEqual(["V-M-PROVIDER-PERSIST"]);

    const resolved = resolveVerification(index, "M-PROVIDER-PERSIST");
    expect(resolved.verification.id).toBe("V-M-PROVIDER-PERSIST");
    expect(resolved.module?.id).toBe("M-PROVIDER-PERSIST");
  });

  it("prefers explicit TestFiles/File entries over command-derived test paths", () => {
    const root = createProject();
    writeProjectSkeleton(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      '<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>',
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      '<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example module.</Summary></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>',
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      '<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>',
    );
    // Explicit TestFiles are authoritative even when the command mentions another test path.
    writeProjectFile(root, "apps/web/src/module-explicit.test.ts", "test\n");
    writeProjectFile(root, "apps/web/src/module-additional.test.ts", "test\n");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      '<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE><Cwd>apps/web</Cwd><Command>bun test src/module.test.ts</Command><TestFiles><File>apps/web/src/module-explicit.test.ts</File><File>apps/web/src/module-additional.test.ts</File></TestFiles><Scenario>example works</Scenario><Marker>[Example]</Marker></V-M-EXAMPLE></VD-MAIN></NgraceVerificationDocument>',
    );

    const index = loadGraceArtifactIndex(root);
    const resolved = resolveVerification(index, "V-M-EXAMPLE");
    expect(resolved.verification.cwd).toBe("apps/web");
    expect(resolved.verification.testFiles).not.toContain("apps/web/src/module.test.ts");
    expect(resolved.verification.testFiles).toContain("apps/web/src/module-explicit.test.ts");
    expect(resolved.verification.testFiles).toContain("apps/web/src/module-additional.test.ts");
  });

  it("does not infer glob-shaped command arguments as literal test files", () => {
    const root = createQueryProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-DB><Scenario>Database client is available.</Scenario></V-M-DB><V-M-PROVIDER-PERSIST><Command>bun test src/provider/config-repo*.test.ts</Command><Scenario>Reads provider config.</Scenario><Marker>[ProviderConfigPersistence][getProviderConfig][BLOCK_GET_PROVIDER_CONFIG]</Marker></V-M-PROVIDER-PERSIST></VD-MAIN></NgraceVerificationDocument>`,
    );

    const index = loadGraceArtifactIndex(root);
    const verification = resolveVerification(index, "V-M-PROVIDER-PERSIST").verification;
    expect(verification.testFiles).toEqual([]);
    const health = buildModuleHealth(index, resolveModule(index, "M-PROVIDER-PERSIST"));
    expect(health.blockers.map((blocker) => blocker.code)).not.toContain("health.verification-test-file-missing-on-disk");
  });

  it("uses verification Cwd when checking monorepo test command references", () => {
    const root = createProject();
    writeProjectSkeleton(root);
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/index.xml`, '<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-WEB /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>');
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/main.xml`, '<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-WEB><Summary>Web workspace.</Summary></M-WEB></GD-MAIN></NgraceGraphDocument>');
    writeProjectFile(root, `${ARTIFACT_DIR}/verification/index.xml`, '<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-WEB /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>');
    writeProjectFile(root, `${ARTIFACT_DIR}/verification/main.xml`, '<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-WEB><Cwd>apps/web</Cwd><TestFiles><File>apps/web/src/web.test.ts</File></TestFiles><Command>bun test src/web.test.ts</Command><Scenario>web works</Scenario></V-M-WEB></VD-MAIN></NgraceVerificationDocument>');
    writeProjectFile(root, "apps/web/src/web.ts", '// START_MODULE_CONTRACT\n// PURPOSE: Web runtime.\n// LINKS: M-WEB\n// END_MODULE_CONTRACT\nexport const web = true;\n');
    writeProjectFile(root, "apps/web/src/web.test.ts", '// START_MODULE_CONTRACT\n// PURPOSE: Web tests.\n// LINKS: M-WEB\n// END_MODULE_CONTRACT\n');

    const index = loadGraceArtifactIndex(root);
    const health = buildModuleHealth(index, resolveModule(index, "M-WEB"));
    expect(health.warnings.map((warning) => warning.code)).not.toContain("health.verification-command-does-not-reference-test-file");
    expect(health.blockers.map((blocker) => blocker.code)).not.toContain("health.verification-test-file-missing-on-disk");
  });

  it("blocks UI_COMPONENT states without evidence and warns when states are undeclared", () => {
    const root = createProject();
    writeProjectSkeleton(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-UI-COVERED /><M-UI-BARE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN>
        <M-UI-COVERED><Summary>Covered UI</Summary><Path>src/covered.tsx</Path><Type>UI_COMPONENT</Type><States><ST-DEFAULT /><ST-ERROR /></States></M-UI-COVERED>
        <M-UI-BARE><Summary>Bare UI</Summary><Path>src/bare.tsx</Path><Type>UI_COMPONENT</Type></M-UI-BARE>
      </GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-UI-COVERED /><V-M-UI-BARE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN>
        <V-M-UI-COVERED><Command>bun test</Command><Scenario>default render</Scenario><TraceAssertion>render ok</TraceAssertion></V-M-UI-COVERED>
        <V-M-UI-BARE><Command>bun test</Command><Scenario>renders</Scenario><TraceAssertion>ok</TraceAssertion></V-M-UI-BARE>
      </VD-MAIN></NgraceVerificationDocument>`,
    );
    writeProjectFile(root, "src/covered.tsx", `// START_MODULE_CONTRACT\n// PURPOSE: UI.\n// LINKS: M-UI-COVERED\n// END_MODULE_CONTRACT\nexport const Covered = () => null;\n`);
    writeProjectFile(root, "src/bare.tsx", `// START_MODULE_CONTRACT\n// PURPOSE: UI.\n// LINKS: M-UI-BARE\n// END_MODULE_CONTRACT\nexport const Bare = () => null;\n`);
    writeProjectFile(root, `${ARTIFACT_DIR}/context/ux-guidelines.xml`, `<NgraceUXGuidelines graceVersion="1.0"><Applicability>applicable</Applicability></NgraceUXGuidelines>`);

    const index = loadGraceArtifactIndex(root);
    const uncovered = buildModuleHealth(index, resolveModule(index, "M-UI-COVERED"));
    expect(uncovered.blockers.map((b) => b.code)).toContain("health.ui-state-unverified");
    expect(uncovered.blockers.some((b) => b.message.includes("ST-ERROR"))).toBe(true);

    const bare = buildModuleHealth(index, resolveModule(index, "M-UI-BARE"));
    expect(bare.warnings.map((w) => w.code)).toContain("health.ui-states-undeclared");

    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN>
        <V-M-UI-COVERED><Command>bun test</Command><Scenario>default render</Scenario><Scenario>error banner</Scenario><AccessibilityCheck><Tool>axe</Tool><Command>bun run a11y</Command></AccessibilityCheck><TraceAssertion>ok</TraceAssertion></V-M-UI-COVERED>
        <V-M-UI-BARE><Command>bun test</Command><Scenario>renders</Scenario><TraceAssertion>ok</TraceAssertion></V-M-UI-BARE>
      </VD-MAIN></NgraceVerificationDocument>`,
    );
    const fixed = buildModuleHealth(loadGraceArtifactIndex(root), resolveModule(loadGraceArtifactIndex(root), "M-UI-COVERED"));
    expect(fixed.blockers.map((b) => b.code)).not.toContain("health.ui-state-unverified");

    // Only the artifact's own direct <Applicability> decides. Reading the first match at
    // any depth let a nested value flip the answer for every module in the project.
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/context/ux-guidelines.xml`,
      `<NgraceUXGuidelines graceVersion="1.0"><Notes><Applicability>applicable</Applicability></Notes><Applicability>not-applicable</Applicability><Reason>Headless service with no user interface surface.</Reason></NgraceUXGuidelines>`,
    );
    const notApplicable = loadGraceArtifactIndex(root);
    expect(buildModuleHealth(notApplicable, resolveModule(notApplicable, "M-UI-BARE")).warnings.map((w) => w.code)).not.toContain(
      "health.ui-states-undeclared",
    );
  });

  it("builds module health from projections and linked files", () => {
    const root = createQueryProject();
    const index = loadGraceArtifactIndex(root);

    const providerModule = resolveModule(index, "M-PROVIDER-PERSIST");
    const health = buildModuleHealth(index, providerModule);
    expect(health.state).toBe("ready");
    expect(health.implementationFiles).toEqual(["src/provider/config-repo.ts"]);
    expect(health.verificationTestFiles).toEqual(["src/provider/config-repo.test.ts"]);

    const dbHealth = buildModuleHealth(index, resolveModule(index, "M-DB"));
    expect(dbHealth.state).toBe("blocked");
    expect(dbHealth.blockers.map((blocker) => blocker.code)).toContain("health.verification-missing-commands");
  });

  it("treats TraceAssertion as module-health evidence without requiring runtime logging", () => {
    const root = createQueryProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-DB><Scenario>Database client is available.</Scenario></V-M-DB><V-M-PROVIDER-PERSIST><Command>bun test src/provider/config-repo.test.ts</Command><Scenario>Pure output is deterministic.</Scenario><TraceAssertion>The test proves deterministic output without runtime logging.</TraceAssertion></V-M-PROVIDER-PERSIST></VD-MAIN></NgraceVerificationDocument>`,
    );

    const index = loadGraceArtifactIndex(root);
    const verification = resolveVerification(index, "V-M-PROVIDER-PERSIST").verification;
    expect(verification.requiredTraceAssertions).toEqual(["The test proves deterministic output without runtime logging."]);
    const health = buildModuleHealth(index, resolveModule(index, "M-PROVIDER-PERSIST"));
    expect(health.warnings.map((warning) => warning.code)).not.toContain("health.verification-missing-evidence");
    expect(health.blockers.map((blocker) => blocker.code)).not.toContain("health.required-log-marker-not-found");
  });

  it("credits a required marker emitted through an identifier-safe constant inside nested blocks", () => {
    const root = createQueryProject();
    writeProviderRuntime(root, {
      declarations: 'const marker$ = "[ProviderConfigPersistence][getProviderConfig][BLOCK_GET_PROVIDER_CONFIG]";',
      body: `  console.info(marker$ + " read");
  // START_BLOCK_PROVIDER_OPERATION
  // START_BLOCK_GET_PROVIDER_CONFIG
  return { ok: true };
  // END_BLOCK_GET_PROVIDER_CONFIG
  // END_BLOCK_PROVIDER_OPERATION`,
    });

    const index = loadGraceArtifactIndex(root);
    const health = buildModuleHealth(index, resolveModule(index, "M-PROVIDER-PERSIST"));
    expect(health.blockers.map((blocker) => blocker.code)).not.toContain("health.required-log-marker-not-found");
    expect(health.blockers.map((blocker) => blocker.code)).not.toContain("health.required-log-marker-block-not-found");
  });

  it("does not credit a required marker when only a longer identifier is emitted", () => {
    const root = createQueryProject();
    writeProviderRuntime(root, {
      declarations: `const marker$ = "[ProviderConfigPersistence][getProviderConfig][BLOCK_GET_PROVIDER_CONFIG]";
const marker$Other = "[ProviderConfigPersistence][getProviderConfig][other]";`,
      body: `  console.info(marker$Other + " read");
  // START_BLOCK_GET_PROVIDER_CONFIG
  return { ok: true };
  // END_BLOCK_GET_PROVIDER_CONFIG`,
    });

    const index = loadGraceArtifactIndex(root);
    const health = buildModuleHealth(index, resolveModule(index, "M-PROVIDER-PERSIST"));
    expect(health.blockers.map((blocker) => blocker.code)).toContain("health.required-log-marker-not-found");
    expect(health.blockers.map((blocker) => blocker.code)).not.toContain("health.required-log-marker-block-not-found");
  });

  it("fails closed before returning records from invalid grammar or projections", () => {
    const wrongRoot = createQueryProject();
    writeProjectFile(wrongRoot, `${ARTIFACT_DIR}/graph/main.xml`, `<NgraceRequirements graceVersion="1.0"><GD-MAIN /></NgraceRequirements>`);
    expect(() => loadGraceArtifactIndex(wrongRoot)).toThrow(GraceCommandError);
    try {
      loadGraceArtifactIndex(wrongRoot);
    } catch (error) {
      expect((error as GraceCommandError).code).toBe("invalid-project");
      expect((error as GraceCommandError).issues).toContain("artifact.unexpected-root-tag");
    }

    const duplicateOwns = createQueryProject();
    writeProjectFile(
      duplicateOwns,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-DB /><M-DB /><M-PROVIDER-PERSIST /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    expect(() => loadGraceArtifactIndex(duplicateOwns)).toThrow(
      expect.objectContaining({ code: "invalid-project", issues: expect.arrayContaining(["projection.graph.duplicate-route"]) }),
    );
  });

  it("fails closed when active assertion or scope contracts are invalid", () => {
    const root = createQueryProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-INVALID/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><C-INVALID><Summary>Invalid operational contract.</Summary><Goals><Goal>Fail closed.</Goal></Goals><Constraints><Constraint>Do not navigate invalid state.</Constraint></Constraints><NonGoals><NonGoal>Unrelated work.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>Query fails.</Criterion></AcceptanceCriteria><AffectedAreas><M-DB /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></C-INVALID></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-INVALID/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-INVALID><IntentSummary>Invalid operational contract.</IntentSummary><BaselineAssertions><MustOwn><Owner>GD-MAIN</Owner></MustOwn></BaselineAssertions><TargetAssertions><MustVerify><Module>M-DB</Module></MustVerify></TargetAssertions><DurableScope><GraphAnchors><M-DB /></GraphAnchors></DurableScope><ObservedWriteScope><File>../escape.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Invalid task</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>Query fails.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></C-INVALID></NgraceChangePlan>`,
    );

    expect(() => loadGraceArtifactIndex(root)).toThrow(expect.objectContaining({
      code: "invalid-project",
      issues: expect.arrayContaining(["assertion.invalid-shape", "scope.invalid-path"]),
    }));
  });

  it("returns one structured JSON error and one concise text error without stack traces", () => {
    const root = createQueryProject();
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/main.xml`, `<NgraceRequirements graceVersion="1.0"><GD-MAIN /></NgraceRequirements>`);
    const repoRoot = path.resolve(import.meta.dir, "..");

    const jsonResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "module", "find", "provider", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(jsonResult.exitCode).not.toBe(0);
    const stdout = Buffer.from(jsonResult.stdout).toString("utf8").trim();
    const envelope = JSON.parse(stdout);
    expect(envelope).toEqual(expect.objectContaining({ schemaVersion: "1.0.0", ok: false }));
    expect(envelope.error.code).toBe("invalid-project");
    expect(stdout.split("\n")).toHaveLength(1);

    const textResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "file", "show", "src/provider/config-repo.ts", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(textResult.exitCode).not.toBe(0);
    const textError = Buffer.from(textResult.stderr).toString("utf8").trim();
    expect(textError).toContain("neo-grace artifacts are invalid");
    expect(textError).not.toContain("GraceCommandError");
    expect(textError).not.toMatch(/\n\s+at\s/);
  });

  it("uses nonzero typed failures for not-found and invalid-argument query commands", () => {
    const root = createQueryProject();
    const repoRoot = path.resolve(import.meta.dir, "..");
    const notFound = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "verification", "show", "V-M-MISSING", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(notFound.exitCode).not.toBe(0);
    expect(JSON.parse(Buffer.from(notFound.stdout).toString("utf8")).error.code).toBe("not-found");

    const invalidArguments = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "module", "show", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(invalidArguments.exitCode).not.toBe(0);
    expect(JSON.parse(Buffer.from(invalidArguments.stdout).toString("utf8")).error.code).toBe("invalid-arguments");
  });

  it("classifies tied path resolution as an ambiguous-target failure", () => {
    const index = loadGraceArtifactIndex(createQueryProject());
    const provider = resolveModule(index, "M-PROVIDER-PERSIST");
    index.modules.push({
      ...provider,
      id: "M-PROVIDER-DUPLICATE",
      graph: { ...provider.graph, id: "M-PROVIDER-DUPLICATE" },
      localFiles: [],
      verifications: [],
      verification: null,
    });

    expect(() => resolveModule(index, "src/provider/config-repo.ts")).toThrow(
      expect.objectContaining({ code: "ambiguous-target" }),
    );
  });

  it("wires module, verification, health, and file query commands through the CLI", () => {
    const root = createQueryProject();
    const repoRoot = path.resolve(import.meta.dir, "..");

    const moduleResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "module", "find", "provider", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(moduleResult.exitCode).toBe(0);
    expect(Buffer.from(moduleResult.stdout).toString("utf8")).toContain("M-PROVIDER-PERSIST");

    const moduleShowResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "module", "show", "M-PROVIDER-PERSIST", "--with", "verification", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(moduleShowResult.exitCode).toBe(0);
    const moduleShowOutput = Buffer.from(moduleShowResult.stdout).toString("utf8");
    expect(moduleShowOutput).toContain("Verification V-M-PROVIDER-PERSIST");
    expect(moduleShowOutput).toContain("bun test src/provider/config-repo.test.ts");

    const moduleShowJsonResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "module", "show", "src/provider/config-repo.ts", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(moduleShowJsonResult.exitCode).toBe(0);
    const moduleShowJson = JSON.parse(Buffer.from(moduleShowJsonResult.stdout).toString("utf8"));
    expect(moduleShowJson.id).toBe("M-PROVIDER-PERSIST");
    expect(moduleShowJson.verifications[0].id).toBe("V-M-PROVIDER-PERSIST");

    const fileResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "file", "show", "src/provider/config-repo.ts", "--path", root, "--contracts"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(fileResult.exitCode).toBe(0);
    expect(Buffer.from(fileResult.stdout).toString("utf8")).toContain("Contract getProviderConfig");

    const fileJsonResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "file", "show", "src/provider/config-repo.ts", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(fileJsonResult.exitCode).toBe(0);
    const fileJson = JSON.parse(Buffer.from(fileJsonResult.stdout).toString("utf8"));
    expect(fileJson.linkedModuleIds).toEqual(["M-PROVIDER-PERSIST", "M-DB"]);

    const verificationFindResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "verification", "find", "provider", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(verificationFindResult.exitCode).toBe(0);
    const verificationFindJson = JSON.parse(Buffer.from(verificationFindResult.stdout).toString("utf8"));
    expect(verificationFindJson[0].verification.id).toBe("V-M-PROVIDER-PERSIST");

    const priorityFindResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "verification", "find", "--priority", "high", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(priorityFindResult.exitCode).toBe(0);
    const priorityFindJson = JSON.parse(Buffer.from(priorityFindResult.stdout).toString("utf8"));
    expect(priorityFindJson.length).toBeGreaterThan(0);
    expect(priorityFindJson[0].verification.id).toBe("V-M-PROVIDER-PERSIST");

    const priorityMismatchResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "verification", "find", "--priority", "low", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(priorityMismatchResult.exitCode).toBe(0);
    const priorityMismatchJson = JSON.parse(Buffer.from(priorityMismatchResult.stdout).toString("utf8"));
    expect(priorityMismatchJson).toHaveLength(0);

    const verificationResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "verification", "show", "V-M-PROVIDER-PERSIST", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(verificationResult.exitCode).toBe(0);
    expect(Buffer.from(verificationResult.stdout).toString("utf8")).toContain("neo-grace Verification");

    const verificationShowByModuleResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "verification", "show", "M-PROVIDER-PERSIST", "--path", root, "--json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(verificationShowByModuleResult.exitCode).toBe(0);
    const verificationShowByModuleJson = JSON.parse(Buffer.from(verificationShowByModuleResult.stdout).toString("utf8"));
    expect(verificationShowByModuleJson.verification.id).toBe("V-M-PROVIDER-PERSIST");

    const healthResult = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "module", "health", "M-PROVIDER-PERSIST", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(healthResult.exitCode).toBe(0);
    expect(Buffer.from(healthResult.stdout).toString("utf8")).toContain("State: ready");
  });

  it("emits migration guidance for GRACE 3 roots instead of falling back to legacy docs", () => {
    const root = createProject();
    writeProjectFile(root, "docs/development-plan.xml", `<DevelopmentPlan />`);
    const repoRoot = path.resolve(import.meta.dir, "..");

    const result = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "module", "find", "provider", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });

    expect(result.exitCode).not.toBe(0);
    const combinedOutput = `${Buffer.from(result.stdout).toString("utf8")}\n${Buffer.from(result.stderr).toString("utf8")}`;
    expect(combinedOutput).toContain("Legacy GRACE 3 artifacts");
    expect(combinedOutput).toContain(".ngrace artifact model");
  });

  it("selects emission patterns by linked file language, not the union", async () => {
    // Pins that module health passes the linked file path into marker evidence.
    // `.Msg(` is a Go/zerolog shape with no DEFAULT counterpart, so a TypeScript
    // module must not credit it. If the path stopped being threaded through, the
    // union fallback would credit it and this module would go ready.
    const { GraceProjectBuilder, createTempProject } = await import("./test-support/fixtures");
    const root = new GraceProjectBuilder(createTempProject("grace-lang-select-"))
      .module({ id: "M-TS-ONLY", path: "src/tsonly.ts", summary: "TypeScript module." })
      .governedFile({
        path: "src/tsonly.ts",
        links: ["M-TS-ONLY"],
        role: "RUNTIME",
        mapMode: "EXPORTS",
        mapEntries: ["run - Run."],
        body: `export function run() {
  // START_BLOCK_RUN
  foo.Msg("[TsOnly][run][BLOCK_RUN]");
  // END_BLOCK_RUN
}
`,
      })
      .verification({
        moduleId: "M-TS-ONLY",
        commands: ["bun test src/tsonly.test.ts"],
        scenarios: ["Runs."],
        markers: ["[TsOnly][run][BLOCK_RUN]"],
      })
      .file("src/tsonly.test.ts", `import { expect, test } from "bun:test";\ntest("run", () => expect(1).toBe(1));\n`)
      .write();

    const index = loadGraceArtifactIndex(root);
    const health = buildModuleHealth(index, resolveModule(index, "M-TS-ONLY"));
    expect(health.blockers.map((blocker) => blocker.code)).toContain("health.required-log-marker-not-found");
  });

  it("credits polyglot marker evidence and still blocks comment-only Rust markers", async () => {
    const { polyglotFixture, GraceProjectBuilder, createTempProject } = await import("./test-support/fixtures");
    const root = polyglotFixture();
    const index = loadGraceArtifactIndex(root);

    for (const moduleId of ["M-LEDGER-CORE", "M-GATEWAY-ROUTER"]) {
      const health = buildModuleHealth(index, resolveModule(index, moduleId));
      expect(health.blockers.map((blocker) => blocker.code)).not.toContain("health.required-log-marker-not-found");
    }

    // Negative control: marker only in a comment still produces the blocker.
    const commentOnly = new GraceProjectBuilder(createTempProject("grace-rs-comment-"))
      .module({
        id: "M-LEDGER-CORE",
        path: "services/ledger/src/lib.rs",
        summary: "Ledger core.",
        type: "CORE_LOGIC",
      })
      .governedFile({
        path: "services/ledger/src/lib.rs",
        links: ["M-LEDGER-CORE"],
        role: "RUNTIME",
        mapMode: "EXPORTS",
        mapEntries: ["post - Post."],
        body: `pub fn post() {
    // START_BLOCK_VALIDATE_BALANCE
    // tracing::warn!("[LedgerCore][post][BLOCK_VALIDATE_BALANCE] unbalanced");
    // END_BLOCK_VALIDATE_BALANCE
}
`,
      })
      .verification({
        moduleId: "M-LEDGER-CORE",
        commands: ["cargo test --lib"],
        scenarios: ["Posts."],
        markers: ["[LedgerCore][post][BLOCK_VALIDATE_BALANCE]"],
      })
      .write();

    const commentIndex = loadGraceArtifactIndex(commentOnly);
    const commentHealth = buildModuleHealth(commentIndex, resolveModule(commentIndex, "M-LEDGER-CORE"));
    expect(commentHealth.blockers.map((blocker) => blocker.code)).toContain("health.required-log-marker-not-found");
  });

  it("infers cargo/go test targets and reports missing test files on disk (G-12)", async () => {
    const { unlinkSync } = await import("node:fs");
    const { GraceProjectBuilder, createTempProject } = await import("./test-support/fixtures");
    const root = new GraceProjectBuilder(createTempProject("grace-g12-"))
      .module({
        id: "M-LEDGER-CORE",
        path: "services/ledger/src/lib.rs",
        summary: "Ledger core.",
      })
      .module({
        id: "M-GATEWAY-ROUTER",
        path: "services/gateway/internal/router/router.go",
        summary: "Gateway router.",
      })
      .governedFile({
        path: "services/ledger/src/lib.rs",
        links: ["M-LEDGER-CORE"],
        role: "RUNTIME",
        mapMode: "EXPORTS",
        mapEntries: ["post - Post."],
        body: `pub fn post() {
    // START_BLOCK_VALIDATE_BALANCE
    tracing::warn!("[LedgerCore][post][BLOCK_VALIDATE_BALANCE] ok");
    // END_BLOCK_VALIDATE_BALANCE
}
`,
      })
      .governedFile({
        path: "services/gateway/internal/router/router.go",
        links: ["M-GATEWAY-ROUTER"],
        role: "RUNTIME",
        mapMode: "EXPORTS",
        mapEntries: ["Route - Route."],
        body: `func Route() error {
	// START_BLOCK_DISPATCH
	slog.Info("[GatewayRouter][Route][BLOCK_DISPATCH] ok")
	// END_BLOCK_DISPATCH
	return nil
}
`,
      })
      // TestFiles must exist when the projection is loaded (mode: existing).
      .file("services/gateway/internal/router/router_test.go", "package router\n")
      .verification({
        moduleId: "M-LEDGER-CORE",
        cwd: "services/ledger",
        commands: ["cargo test --lib"],
        scenarios: ["Ledger posts."],
        markers: ["[LedgerCore][post][BLOCK_VALIDATE_BALANCE]"],
        testFiles: ["services/ledger/src/lib.rs"],
      })
      .verification({
        moduleId: "M-GATEWAY-ROUTER",
        cwd: "services/gateway",
        commands: ["go test ./internal/router/..."],
        scenarios: ["Gateway routes."],
        markers: ["[GatewayRouter][Route][BLOCK_DISPATCH]"],
        testFiles: ["services/gateway/internal/router/router_test.go"],
      })
      .write();

    // Both files present: cargo --lib / go test package inference → no command warnings.
    const presentIndex = loadGraceArtifactIndex(root);
    const ledgerHealth = buildModuleHealth(presentIndex, resolveModule(presentIndex, "M-LEDGER-CORE"));
    expect(ledgerHealth.blockers.map((b) => b.code)).not.toContain("health.verification-test-file-missing-on-disk");
    expect(ledgerHealth.warnings.map((w) => w.code)).not.toContain("health.verification-command-does-not-reference-test-file");

    const gatewayPresent = buildModuleHealth(presentIndex, resolveModule(presentIndex, "M-GATEWAY-ROUTER"));
    expect(gatewayPresent.blockers.map((b) => b.code)).not.toContain("health.verification-test-file-missing-on-disk");
    expect(gatewayPresent.warnings.map((w) => w.code)).not.toContain("health.verification-command-does-not-reference-test-file");

    // Delete after load: health sees the path from the index but the file is gone.
    unlinkSync(path.join(root, "services/gateway/internal/router/router_test.go"));
    const gatewayMissing = buildModuleHealth(presentIndex, resolveModule(presentIndex, "M-GATEWAY-ROUTER"));
    expect(gatewayMissing.blockers.map((b) => b.code)).toContain("health.verification-test-file-missing-on-disk");
    // Inference still credits go test ./internal/router/... (no command warning).
    expect(gatewayMissing.warnings.map((w) => w.code)).not.toContain("health.verification-command-does-not-reference-test-file");
  });
});

/**
 * C-FLAG-HONESTY T-003 — F18.1, positionals counterweight, default-false working forms.
 * Uses the real CLI entry (src/grace.ts) against this repo root for module graph.
 */
const REPO_ROOT = path.resolve(import.meta.dir, "..");
const GRACE_BIN = path.join(REPO_ROOT, "src/grace.ts");

function runNgrace(args: string[]) {
  return Bun.spawnSync({
    cmd: ["bun", "run", GRACE_BIN, ...args],
    cwd: REPO_ROOT,
    stdout: "pipe",
    stderr: "pipe",
    env: process.env,
  });
}

describe("C-FLAG-HONESTY T-003 — F18.1 and positionals", () => {
  it("F18.1: module find --json true exits non-zero with space-form message (not empty search)", () => {
    const result = runNgrace(["module", "find", "--json", "true", "--path", REPO_ROOT]);
    expect(result.exitCode).not.toBe(0);
    const combined = `${result.stdout.toString()}\n${result.stderr.toString()}`;
    // Must not be the silent empty-result success shape.
    expect(combined.trim()).not.toBe("[]");
    expect(combined).toContain("--json=false");
    expect(combined).toContain("--json=true");
    expect(combined).toContain("--no-json");
  });

  it("F18.1: module find --json false also refuses (not a search for false)", () => {
    const result = runNgrace(["module", "find", "--json", "false", "--path", REPO_ROOT]);
    expect(result.exitCode).not.toBe(0);
    const combined = `${result.stdout.toString()}\n${result.stderr.toString()}`;
    expect(combined.trim()).not.toBe("[]");
    expect(combined).toMatch(/--json=false|--json=true/);
  });

  it("AC-LEGITIMATE-POSITIONALS: module find true treats true as search query, not boolean error", () => {
    const result = runNgrace(["module", "find", "true", "--path", REPO_ROOT]);
    // Empty-or-not is fine; must not raise the boolean space-form error.
    const combined = `${result.stdout.toString()}\n${result.stderr.toString()}`;
    expect(combined).not.toMatch(/does not accept a space-separated value/);
    // Pre-wiring measured exit 0 with "No modules found." — still a successful search shape.
    expect(result.exitCode).toBe(0);
  });

  it("AC-LEGITIMATE-POSITIONALS: bare false as module find query is not the space-form error", () => {
    const result = runNgrace(["module", "find", "false", "--path", REPO_ROOT]);
    const combined = `${result.stdout.toString()}\n${result.stderr.toString()}`;
    expect(combined).not.toMatch(/does not accept a space-separated value/);
    expect(result.exitCode).toBe(0);
  });

  it("AC-WORKING-FORMS default-false half: module --json equals and --no-json and bare --json", () => {
    // --json=true → JSON array (may be empty if query absent → still json shape)
    const eqTrue = runNgrace(["module", "find", "--json=true", "--path", REPO_ROOT]);
    expect(eqTrue.exitCode).toBe(0);
    expect(() => JSON.parse(eqTrue.stdout.toString())).not.toThrow();

    // --json=false → text table path, not rejected
    const eqFalse = runNgrace(["module", "find", "--json=false", "--path", REPO_ROOT]);
    expect(eqFalse.exitCode).toBe(0);
    expect(eqFalse.stdout.toString()).not.toMatch(/does not accept a space-separated value/);

    // --no-json → false behaviour
    const noJson = runNgrace(["module", "find", "--no-json", "--path", REPO_ROOT]);
    expect(noJson.exitCode).toBe(0);
    expect(noJson.stdout.toString()).not.toMatch(/does not accept a space-separated value/);

    // bare --json means true
    const bare = runNgrace(["module", "find", "--json", "--path", REPO_ROOT]);
    expect(bare.exitCode).toBe(0);
    expect(() => JSON.parse(bare.stdout.toString())).not.toThrow();
  });
});

function createFileExportsFixture() {
  return new GraceProjectBuilder(createTempProject("grace-file-exports-"))
    .module({ id: "M-EXACT", path: "src/exact.ts", summary: "Exact adapter exports." })
    .governedFile({
      path: "src/exact.ts",
      purpose: "Exact exports",
      links: ["M-EXACT"],
      mapMode: "EXPORTS",
      mapEntries: ["listedExport"],
      body: "export function listedExport() {}\nexport const otherExport = 1;\n",
    })
    .module({ id: "M-HEURISTIC", path: "src/heuristic.ts", summary: "Heuristic adapter exports." })
    .governedFile({
      path: "src/heuristic.ts",
      purpose: "Heuristic exports",
      links: ["M-HEURISTIC"],
      mapMode: "EXPORTS",
      mapEntries: ["reexported"],
      body: 'export * from "./exact";\n',
    })
    .module({ id: "M-NO-PATH", summary: "Module without Path." })
    .governedFile({
      path: "src/linked-only.ts",
      purpose: "Linked file that getModulePath would fall back to",
      links: ["M-NO-PATH"],
      mapMode: "EXPORTS",
      mapEntries: ["hiddenByFallback"],
      body: "export function hiddenByFallback() {}\n",
    })
    .module({ id: "M-MISSING-PATH", path: "src/does-not-exist.ts", summary: "Authored Path file missing on disk." })
    .module({ id: "M-PRIMARY", path: "src/primary.ts", summary: "Path file only, not every linked file." })
    .governedFile({
      path: "src/primary.ts",
      purpose: "Primary Path file",
      links: ["M-PRIMARY"],
      mapMode: "EXPORTS",
      mapEntries: ["alpha"],
      body: "export function alpha() {}\n",
    })
    .governedFile({
      path: "src/secondary.ts",
      purpose: "Linked sibling that Path form must not analyse",
      links: ["M-PRIMARY"],
      mapMode: "EXPORTS",
      mapEntries: ["beta"],
      body: "export function beta() {}\n",
    })
    .governedFile({
      path: "src/unlinked.ts",
      purpose: "Governed file linked to no module",
      links: [],
      mapMode: "EXPORTS",
      mapEntries: ["unlinkedExport"],
      body: "export function unlinkedExport() {}\n",
    })
    .file("src/unmarked.ts", "export function unmarkedExport() {}\n")
    .file("src/Main.java", "public class Main {}\n")
    .write();
}

function runFileExports(root: string, args: string[]) {
  return Bun.spawnSync({
    cmd: [process.execPath, "./src/grace.ts", "file", "exports", ...args],
    cwd: path.resolve(import.meta.dir, ".."),
    stdout: "pipe",
    stderr: "pipe",
  });
}

function fileExportsStdout(result: ReturnType<typeof runFileExports>) {
  return Buffer.from(result.stdout).toString("utf8");
}

function fileExportsStderr(result: ReturnType<typeof runFileExports>) {
  return Buffer.from(result.stderr).toString("utf8");
}

describe("file exports", () => {
  it("prints first-match adapter exports for a positional path", () => {
    const root = createFileExportsFixture();
    const before = readFileSync(path.join(root, "src/exact.ts"), "utf8");
    const result = runFileExports(root, ["src/exact.ts", "--path", root]);
    expect(result.exitCode).toBe(0);
    const stdout = fileExportsStdout(result);
    expect(stdout).toContain("js-ts");
    expect(stdout).toContain("exact");
    expect(stdout).toContain("listedExport");
    expect(stdout).toContain("otherExport");
    expect(readFileSync(path.join(root, "src/exact.ts"), "utf8")).toBe(before);
  });

  it("prints first-match adapter exports for argv token module using authored Path only", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["--module", "M-PRIMARY", "--path", root]);
    expect(result.exitCode).toBe(0);
    const stdout = fileExportsStdout(result);
    expect(stdout).toContain("js-ts");
    expect(stdout).toContain("alpha");
    expect(stdout).not.toContain("beta");
  });

  it("makes heuristic exportConfidence visible on the same view as the list", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["src/heuristic.ts", "--path", root]);
    expect(result.exitCode).toBe(0);
    expect(fileExportsStdout(result)).toContain("heuristic");
  });

  it("names Adapter none with an empty list and the consequence sentence", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["src/Main.java", "--path", root]);
    expect(result.exitCode).toBe(0);
    const stdout = fileExportsStdout(result);
    expect(stdout).toContain("Adapter none");
    expect(stdout).toContain("contracts and health work");
    expect(stdout).toContain("MODULE_MAP parity unverified");
    expect(stdout).not.toMatch(/Exports:\s*\S/);
  });

  it("prints Module none for an unmarked file and still analyses it", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["src/unmarked.ts", "--path", root]);
    expect(result.exitCode).toBe(0);
    const stdout = fileExportsStdout(result);
    expect(stdout).toContain("Module none");
    expect(stdout).toContain("js-ts");
    expect(stdout).toContain("unmarkedExport");
  });

  it("prints Module none for a governed file linked to no module and still analyses it", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["src/unlinked.ts", "--path", root]);
    expect(result.exitCode).toBe(0);
    const stdout = fileExportsStdout(result);
    expect(stdout).toContain("Module none");
    expect(stdout).toContain("unlinkedExport");
  });

  it("treats a resolved module with no Path as not-found without analysing a linked file", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["--module", "M-NO-PATH", "--path", root, "--json"]);
    expect(result.exitCode).not.toBe(0);
    const body = JSON.parse(fileExportsStdout(result));
    expect(body.ok).toBe(false);
    expect(body.error.code).toBe("not-found");
    expect(body.error.message).toMatch(/Path/i);
    expect(body.error.message).not.toMatch(/does-not-exist|not found on disk|missing on disk/i);
    expect(body.error.message).not.toContain("hiddenByFallback");
  });

  it("names a directory Path as its own cause, not as a missing file", () => {
    const root = createFileExportsFixture();
    mkdirSync(path.join(root, "src/adir"), { recursive: true });
    const result = runFileExports(root, ["src/adir", "--path", root, "--json"]);
    expect(result.exitCode).not.toBe(0);
    const body = JSON.parse(fileExportsStdout(result));
    expect(body.error.code).toBe("not-found");
    expect(body.error.message).toMatch(/directory/i);
    // The path exists; borrowing the missing-file sentence would be F40/F55's defect.
    expect(body.error.message).not.toMatch(/not found on disk/i);
  });

  it("treats a missing file as not-found with a different cause than a missing Path", () => {
    const root = createFileExportsFixture();
    const missingFile = runFileExports(root, ["src/absent.ts", "--path", root, "--json"]);
    const missingPath = runFileExports(root, ["--module", "M-MISSING-PATH", "--path", root, "--json"]);
    const noPath = runFileExports(root, ["--module", "M-NO-PATH", "--path", root, "--json"]);
    expect(missingFile.exitCode).not.toBe(0);
    expect(missingPath.exitCode).not.toBe(0);
    const missingFileBody = JSON.parse(fileExportsStdout(missingFile));
    const missingPathBody = JSON.parse(fileExportsStdout(missingPath));
    const noPathBody = JSON.parse(fileExportsStdout(noPath));
    expect(missingFileBody.error.code).toBe("not-found");
    expect(missingPathBody.error.code).toBe("not-found");
    expect(noPathBody.error.code).toBe("not-found");
    expect(missingFileBody.error.message).not.toBe(noPathBody.error.message);
    expect(missingPathBody.error.message).not.toBe(noPathBody.error.message);
    expect(missingFileBody.error.message).toMatch(/src\/absent\.ts|absent\.ts/);
    expect(missingPathBody.error.message).toMatch(/src\/does-not-exist\.ts|does-not-exist\.ts/);
  });

  it("rejects both selectors or neither as invalid-arguments", () => {
    const root = createFileExportsFixture();
    const neither = runFileExports(root, ["--path", root, "--json"]);
    const both = runFileExports(root, ["src/exact.ts", "--module", "M-EXACT", "--path", root, "--json"]);
    expect(neither.exitCode).not.toBe(0);
    expect(both.exitCode).not.toBe(0);
    expect(JSON.parse(fileExportsStdout(neither)).error.code).toBe("invalid-arguments");
    expect(JSON.parse(fileExportsStdout(both)).error.code).toBe("invalid-arguments");
  });

  it("emits the dedicated object for format json and the json boolean", () => {
    const root = createFileExportsFixture();
    const formatJson = runFileExports(root, ["src/exact.ts", "--path", root, "--format", "json"]);
    const jsonFlag = runFileExports(root, ["--module", "M-EXACT", "--path", root, "--json"]);
    expect(formatJson.exitCode).toBe(0);
    expect(jsonFlag.exitCode).toBe(0);
    const fromFormat = JSON.parse(fileExportsStdout(formatJson));
    const fromFlag = JSON.parse(fileExportsStdout(jsonFlag));
    expect(fromFormat).toEqual({
      path: "src/exact.ts",
      moduleId: "M-EXACT",
      adapterId: "js-ts",
      exportConfidence: "exact",
      exports: ["listedExport", "otherExport"],
    });
    expect(fromFlag).toEqual({
      path: "src/exact.ts",
      moduleId: "M-EXACT",
      adapterId: "js-ts",
      exportConfidence: "exact",
      exports: ["listedExport", "otherExport"],
    });
  });

  it("emits null moduleId, adapterId, and exportConfidence when none", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["src/Main.java", "--path", root, "--json"]);
    expect(result.exitCode).toBe(0);
    expect(JSON.parse(fileExportsStdout(result))).toEqual({
      path: "src/Main.java",
      moduleId: null,
      adapterId: null,
      exportConfidence: null,
      exports: [],
    });
  });
});

function createNoPathLinkedDisplayFixture() {
  return new GraceProjectBuilder(createTempProject("grace-no-path-display-"))
    .module({ id: "M-NO-PATH", summary: "Module without Path." })
    .governedFile({
      path: "src/linked-only.ts",
      purpose: "Linked file that getModulePath would fall back to",
      links: ["M-NO-PATH"],
      mapMode: "EXPORTS",
      mapEntries: ["hiddenByFallback"],
      body: "export function hiddenByFallback() {}\n",
    })
    .verification({
      moduleId: "M-NO-PATH",
      commands: ["bun test src/linked-only.test.ts"],
      scenarios: ["linked file exists"],
    })
    .write();
}

describe("authored Path only (AC-AUTHORED-PATH)", () => {
  it("a no-Path module with a linked file renders absence tokens, not the linked path", () => {
    const root = createNoPathLinkedDisplayFixture();
    const index = loadGraceArtifactIndex(root);
    const moduleRecord = resolveModule(index, "M-NO-PATH");
    const linkedPath = "src/linked-only.ts";

    const moduleText = formatModuleText(moduleRecord, { withVerification: false });
    expect(moduleText).toMatch(/^Graph Path: /m);
    const graphLine = moduleText.split("\n").find((line) => line.startsWith("Graph Path:"));
    expect(graphLine).toBe("Graph Path: n/a");
    expect(graphLine).not.toContain(linkedPath);

    const verification = resolveVerification(index, "V-M-NO-PATH");
    const verificationText = formatVerificationText(verification);
    expect(verificationText).toMatch(/^Module Path: /m);
    const modulePathLine = verificationText.split("\n").find((line) => line.startsWith("Module Path:"));
    expect(modulePathLine).toBe("Module Path: n/a");
    expect(modulePathLine).not.toContain(linkedPath);

    const findText = formatModuleFindTable(findModules(index, { query: "M-NO-PATH" }));
    const findRow = findText.split("\n").find((line) => line.startsWith("M-NO-PATH"));
    expect(findRow).toBeDefined();
    const pathCell = findRow!.trim().split(/\s{2,}/)[3];
    expect(pathCell).toBe("-");
    expect(pathCell).not.toContain(linkedPath);

    const health = buildModuleHealth(index, moduleRecord);
    expect(health.path).toBeUndefined();
    const healthText = formatModuleHealthText(health);
    const healthPathLine = healthText.split("\n").find((line) => line.startsWith("Path:"));
    expect(healthPathLine).toBe("Path: n/a");
    expect(healthPathLine).not.toContain(linkedPath);
  });

  it("file exports on that module still reports not-found naming Path and does not analyse the linked file", () => {
    const root = createFileExportsFixture();
    const result = runFileExports(root, ["--module", "M-NO-PATH", "--path", root, "--json"]);
    expect(result.exitCode).not.toBe(0);
    const body = JSON.parse(fileExportsStdout(result));
    expect(body.ok).toBe(false);
    expect(body.error.code).toBe("not-found");
    expect(body.error.message).toMatch(/Path/i);
    expect(body.error.message).not.toContain("hiddenByFallback");
  });
});
