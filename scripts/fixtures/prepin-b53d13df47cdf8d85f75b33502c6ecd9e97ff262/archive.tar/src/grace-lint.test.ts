import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "bun:test";

import { createHash } from "node:crypto";
import { existsSync } from "node:fs";

import { writeChangeBundleFixture } from "./artifact/test-fixtures";
import { CHANGE_STATUSES } from "./artifact/types";
import { ARTIFACT_DIR } from "./artifact/paths";
import { SCHEMA_SHAPE_REGISTRY, renderSchemaShape } from "./artifact/schema-reference";
import { lintCommand, lintGraceProject } from "./grace-lint";
import { advanceCursor } from "./grace-cursor";
import { getLintIssueGuide } from "./lint/catalog";
import { createTempProject, GraceProjectBuilder } from "./test-support/fixtures";

function createProject() {
  return mkdtempSync(path.join(os.tmpdir(), "grace-lint-"));
}

function writeProjectFile(root: string, relativePath: string, contents: string) {
  const filePath = path.join(root, relativePath);
  mkdirSync(path.dirname(filePath), { recursive: true });
  writeFileSync(filePath, contents);
}

function writeMinimalNgraceProject(root: string) {
  writeProjectFile(root, `${ARTIFACT_DIR}/context/requirements.xml`, `<NgraceRequirements graceVersion="1.0"><Summary>Required.</Summary></NgraceRequirements>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/technology.xml`, `<NgraceTechnology graceVersion="1.0"><Runtime>Bun</Runtime></NgraceTechnology>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/principles.xml`, `<NgracePrinciples graceVersion="1.0"><Principle>Safe.</Principle></NgracePrinciples>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/deployment.xml`, `<NgraceDeployment graceVersion="1.0"><Applicability>applicable</Applicability></NgraceDeployment>`);
  writeProjectFile(root, `${ARTIFACT_DIR}/context/ux-guidelines.xml`, `<NgraceUXGuidelines graceVersion="1.0"><Applicability>applicable</Applicability></NgraceUXGuidelines>`);
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/index.xml`,
    `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/main.xml`,
    `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example module.</Summary><Path>src/example.ts</Path></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/index.xml`,
    `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/main.xml`,
    `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE><Command>bun test src/example.test.ts</Command><Scenario>example works</Scenario><Marker>[Example][run][BLOCK_RUN]</Marker></V-M-EXAMPLE></VD-MAIN></NgraceVerificationDocument>`,
  );
  mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "active"), { recursive: true });
  mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "archive"), { recursive: true });
  writeProjectFile(
    root,
    "src/example.ts",
    `// START_MODULE_CONTRACT
//   PURPOSE: Example runtime.
//   SCOPE: Small fixture.
//   DEPENDS: none
//   LINKS: M-EXAMPLE
//   ROLE: RUNTIME
//   MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
//   run - Execute the example runtime.
// END_MODULE_MAP
export function run() {
  console.info("[Example][run][BLOCK_RUN] run");
  // START_BLOCK_RUN
  return "ok";
  // END_BLOCK_RUN
}
`,
  );
  writeProjectFile(root, "src/example.test.ts", `import { expect, test } from "bun:test";\ntest("example", () => expect(1).toBe(1));\n`);
}

function writeApprovedChange(
  root: string,
  changeId: string,
  baselineAssertions: string,
  targetAssertions: string,
  status: "draft" | "approved" = "approved",
) {
  const bundle = `${ARTIFACT_DIR}/changes/active/${changeId}`;
  writeProjectFile(
    root,
    `${bundle}/spec.xml`,
    `<NgraceChangeSpec graceVersion="1.0" status="approved"><${changeId}><Summary>Selected change.</Summary><Goals><Goal>Exercise assertions.</Goal></Goals><Constraints><Constraint>Preserve fixture validity.</Constraint></Constraints><NonGoals><NonGoal>Unrelated behavior.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>Assertions are evaluated.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></${changeId}></NgraceChangeSpec>`,
  );
  writeProjectFile(
    root,
    `${bundle}/plan.xml`,
    `<NgraceChangePlan graceVersion="1.0" status="${status}"><${changeId}><IntentSummary>Evaluate selected assertions.</IntentSummary><BaselineAssertions>${baselineAssertions}</BaselineAssertions><TargetAssertions>${targetAssertions}</TargetAssertions><DurableScope><GraphAnchors><M-EXAMPLE /></GraphAnchors></DurableScope><ObservedWriteScope><File>src/example.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Verify assertions</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>Assertions pass.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></${changeId}></NgraceChangePlan>`,
  );
}

describe("lintGraceProject", () => {
  it("passes a valid neo-grace .ngrace project", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);

    const result = lintGraceProject(root);

    expect(result.summary.errors).toBe(0);
    expect(result.tool).toBe("grace-lint");
    expect(result.schemaVersion).toBe("1.0.0");
    expect(result.generatedAt).toBeTruthy();
    expect(result.root).toBe(path.resolve(root));
    expect(result.xmlFilesChecked).toBeGreaterThan(0);
  });

  it("fails with migration guidance when only GRACE 3 docs are present", () => {
    const root = createProject();
    writeProjectFile(root, "docs/development-plan.xml", `<DevelopmentPlan />`);

    const result = lintGraceProject(root);

    expect(result.issues[0]?.code).toBe("project.grace3-detected");
    expect(result.issues[0]?.message).toContain("ngrace-migrate");
    expect(result.issues.map((issue) => issue.code)).toEqual(["project.grace3-detected"]);
  });

  it("fails with missing .ngrace guidance when no neo-grace artifacts exist", () => {
    const result = lintGraceProject(createProject());

    expect(result.issues[0]?.code).toBe("project.missing-grace");
    expect(result.issues[0]?.message).toContain("No .ngrace directory");
  });

  it("returns JSON-compatible output shape with issue counts", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(root, `${ARTIFACT_DIR}/context/requirements.xml`, `<NgraceRequirements><Summary>Missing version.</Summary></NgraceRequirements>`);

    const result = lintGraceProject(root);

    expect(JSON.parse(JSON.stringify(result)).tool).toBe("grace-lint");
    expect(result.summary.errors).toBeGreaterThan(0);
    expect(result.issues.map((issue) => issue.code)).toContain("artifact.missing-grace-version");
  });

  it("rejects wrong document roots, unindexed documents, and mismatched executable bundles", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/main.xml`, `<NgraceRequirements graceVersion="1.0"><GD-MAIN><M-EXAMPLE /></GD-MAIN></NgraceRequirements>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/unindexed.xml`, `<NgraceGraphDocument graceVersion="1.0"><GD-EXTRA><M-EXTRA /></GD-EXTRA></NgraceGraphDocument>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-FOLDER/spec.xml`, `<NgraceChangeSpec graceVersion="1.0" status="approved"><C-SPEC /></NgraceChangeSpec>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-FOLDER/plan.xml`, `<NgraceChangePlan graceVersion="1.0" status="approved"><C-PLAN /></NgraceChangePlan>`);

    const issueCodes = lintGraceProject(root).issues.map((issue) => issue.code);
    expect(issueCodes).toContain("artifact.unexpected-root-tag");
    expect(issueCodes).toContain("projection.graph.unindexed-document");
    expect(issueCodes).toContain("change.bundle-id-mismatch");
    expect(issueCodes).toContain("change.spec-plan-id-mismatch");
    expect(issueCodes).toContain("change.plan-missing-section");
  });

  it("G-05: errors when an approved plan DurableScope covers a different module than the spec AffectedAreas", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-MISMATCH/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><C-MISMATCH><Summary>Spec A.</Summary><Goals><Goal>Govern M-EXAMPLE.</Goal></Goals><Constraints><Constraint>Keep fixtures valid.</Constraint></Constraints><NonGoals><NonGoal>Unrelated work.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>Scope matches.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></C-MISMATCH></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-MISMATCH/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-MISMATCH><IntentSummary>Plan B for a different module.</IntentSummary><BaselineAssertions><MustExist><Value>M-OTHER</Value></MustExist></BaselineAssertions><TargetAssertions><MustVerify><Module>M-OTHER</Module></MustVerify></TargetAssertions><DurableScope><GraphAnchors><M-OTHER /></GraphAnchors></DurableScope><ObservedWriteScope><File>src/other.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Wrong scope</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>Done.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></C-MISMATCH></NgraceChangePlan>`,
    );

    const codes = lintGraceProject(root).issues.map((issue) => issue.code);
    expect(codes).toContain("change.scope-does-not-cover-spec");
    expect(codes).toContain("change.plan-scope-exceeds-spec");
  });

  it("accepts a well-formed AC-* / Satisfies change bundle", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-AC/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><C-AC><Summary>AC coverage.</Summary><Goals><Goal>Map criteria.</Goal></Goals><Constraints><Constraint>Keep fixtures valid.</Constraint></Constraints><NonGoals><NonGoal>Unrelated work.</NonGoal></NonGoals><AcceptanceCriteria><AC-KEYBOARD-NAV>Arrow keys move focus.</AC-KEYBOARD-NAV><AC-AXE-CLEAN>axe is clean.</AC-AXE-CLEAN></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></C-AC></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-AC/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-AC><IntentSummary>Implement criteria.</IntentSummary><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions><TargetAssertions><MustVerify><Module>M-EXAMPLE</Module></MustVerify></TargetAssertions><DurableScope><GraphAnchors><M-EXAMPLE /></GraphAnchors></DurableScope><ObservedWriteScope><File>src/example.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Wire both criteria</Title><DependsOn></DependsOn><Satisfies><AC-KEYBOARD-NAV /><AC-AXE-CLEAN /></Satisfies><AcceptanceCriteria><Criterion>Both pass.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></C-AC></NgraceChangePlan>`,
    );

    const result = lintGraceProject(root);
    expect(result.summary.errors).toBe(0);
    expect(result.issues.map((issue) => issue.code)).not.toContain("change.acceptance-criterion-unmapped");
    expect(result.issues.map((issue) => issue.code)).not.toContain("change.unknown-acceptance-criterion");
    expect(result.issues.map((issue) => issue.code)).not.toContain("change.scope-does-not-cover-spec");
  });

  it("projects without design-system.xml remain compatible after Phase 6", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const result = lintGraceProject(root);
    expect(result.summary.errors).toBe(0);
    expect(result.issues.map((i) => i.code).filter((c) => c.startsWith("design-system."))).toEqual([]);
  });

  it("reports unknown module Type as a warning, not an error", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example</Summary><Path>src/example.ts</Path><Type>NONSENSE</Type></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`,
    );
    const result = lintGraceProject(root);
    const issue = result.issues.find((i) => i.code === "graph.unknown-module-type");
    expect(issue?.severity).toBe("warning");
    expect(result.summary.errors).toBe(0);
  });

  it("keeps the shipped spec and plan templates mutually consistent under spec→plan coverage", () => {
    // String assertions in skill-contracts cannot catch the templates naming different
    // placeholder modules. Linting them as a real bundle can.
    const skills = path.resolve(import.meta.dir, "../skills/ngrace");
    const fill = (relativePath: string) =>
      readFileSync(path.join(skills, relativePath), "utf8")
        .replace(/C-CHANGE-ID/g, "C-TEMPLATE")
        .replace(/\$[A-Z_]+/g, "Placeholder prose.")
        .replace(/status="draft"/, `status="approved"`);

    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-TEMPLATE/spec.xml`, fill("ngrace-spec/references/change-spec-template.xml"));
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-TEMPLATE/plan.xml`, fill("ngrace-plan/references/change-plan-template.xml"));

    const codes = lintGraceProject(root).issues.map((issue) => issue.code);
    expect(codes).not.toContain("change.scope-does-not-cover-spec");
    expect(codes).not.toContain("change.plan-scope-exceeds-spec");
    expect(codes).not.toContain("change.unknown-acceptance-criterion");
    expect(codes).not.toContain("change.acceptance-criterion-unmapped");
  });

  it("documents neo-grace diagnostic prefixes and removes allow-missing-docs CLI exposure", () => {
    expect(getLintIssueGuide("projection.graph.wrapper-mismatch").title).toContain("Projection");
    expect(getLintIssueGuide("assertion.MustExist").title).toContain("Assertion");
    expect(getLintIssueGuide("scope.durable-overlap").title).toContain("Scope");

    const lintSource = readFileSync(path.resolve(import.meta.dir, "grace-lint.ts"), "utf8");
    expect(lintSource).not.toContain("allowMissingDocs");
    expect(lintSource).not.toContain("allow-missing-docs");
  });

  it("wires the lint command through the CLI", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const repoRoot = path.resolve(import.meta.dir, "..");

    const result = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });

    expect(result.exitCode).toBe(0);
    const parsed = JSON.parse(Buffer.from(result.stdout).toString("utf8"));
    expect(parsed.tool).toBe("grace-lint");
    expect(parsed.summary.errors).toBe(0);
  });

  it("returns structured JSON for invalid options and missing project paths without stack traces", () => {
    const repoRoot = path.resolve(import.meta.dir, "..");
    const invalid = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--profile", "unsupported", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(invalid.exitCode).not.toBe(0);
    expect(Buffer.from(invalid.stderr).toString("utf8")).toBe("");
    expect(JSON.parse(Buffer.from(invalid.stdout).toString("utf8"))).toEqual(expect.objectContaining({
      schemaVersion: "1.0.0",
      ok: false,
      error: expect.objectContaining({ code: "invalid-arguments" }),
    }));

    const missingRoot = path.join(os.tmpdir(), `grace-missing-${crypto.randomUUID()}`);
    const missing = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", missingRoot, "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(missing.exitCode).not.toBe(0);
    expect(Buffer.from(missing.stderr).toString("utf8")).toBe("");
    const missingResult = JSON.parse(Buffer.from(missing.stdout).toString("utf8"));
    expect(missingResult.tool).toBe("grace-lint");
    expect(missingResult.issues.map((issue: { code: string }) => issue.code)).toContain("project.missing-grace");
  });
  it("does not evaluate BaselineAssertions for archived plans", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    // Only create archived plan with BaselineAssertions
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-DONE/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="applied"><C-DONE><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions></C-DONE></NgraceChangePlan>`,
    );
    expect(lintGraceProject(root).issues.filter((issue) => issue.code === "assertion.MustExist")).toHaveLength(0);

    // Remove M-EXAMPLE from graph so the archived baseline would fail if evaluated
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns /></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN /></NgraceGraphDocument>`,
    );

    const after = lintGraceProject(root);
    expect(after.issues.filter((issue) => issue.code === "assertion.MustExist")).toHaveLength(0);
  });
  it("emits assertion.MustExist for active plans with stale BaselineAssertions but not for archived plans", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);

    // Create an active plan with a MustExist reference to a module that does not exist
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-REFACTOR/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-REFACTOR><BaselineAssertions><MustExist><Value>M-NONEXISTENT</Value></MustExist></BaselineAssertions></C-REFACTOR></NgraceChangePlan>`,
    );

    // Active plan should emit assertion.MustExist for nonexistent module
    const activeResult = lintGraceProject(root);
    expect(activeResult.issues.filter((issue) => issue.code === "assertion.MustExist")).toHaveLength(1);

    // Now also add an archived plan with the same stale baseline
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-DONE/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="applied"><C-DONE><BaselineAssertions><MustExist><Value>M-NONEXISTENT</Value></MustExist></BaselineAssertions></C-DONE></NgraceChangePlan>`,
    );

    // Archived plan should NOT emit additional assertion.MustExist
    const bothResult = lintGraceProject(root);
    const assertionIssues = bothResult.issues.filter((issue) => issue.code === "assertion.MustExist");
    // Only the active plan's assertion should fire
    expect(assertionIssues).toHaveLength(1);
  });

  it("does not evaluate TargetAssertions for active approved plans in general lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-TARGET/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-TARGET><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions><TargetAssertions><MustVerify><Module>M-MISSING</Module></MustVerify></TargetAssertions></C-TARGET></NgraceChangePlan>`,
    );
    const result = lintGraceProject(root);
    // TargetAssertion MustVerify for M-MISSING should NOT fire
    expect(result.issues.filter((issue) => issue.code === "assertion.MustVerify")).toHaveLength(0);
  });

  it("requires one approved identity-matched active change for selected assertion modes", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);

    expect(lintGraceProject(root, { assertionMode: "target" }).issues.map((issue) => issue.code)).toContain("assertion.change-required");
    expect(lintGraceProject(root, { assertionMode: "baseline", changeId: "not-a-change" }).issues.map((issue) => issue.code)).toContain("assertion.invalid-change-id");

    writeApprovedChange(
      root,
      "C-DRAFT",
      `<MustExist><Value>M-EXAMPLE</Value></MustExist>`,
      `<MustVerify><Module>M-EXAMPLE</Module></MustVerify>`,
      "draft",
    );
    expect(lintGraceProject(root, { assertionMode: "target", changeId: "C-DRAFT" }).issues.map((issue) => issue.code)).toContain("assertion.change-not-approved");
  });

  it("evaluates only the selected baseline or target section", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-SELECTED",
      `<MustExist><Value>M-EXAMPLE</Value></MustExist>`,
      `<MustVerify><Module>M-MISSING</Module></MustVerify>`,
    );

    const baseline = lintGraceProject(root, { assertionMode: "baseline", changeId: "C-SELECTED" });
    expect(baseline.issues.filter((issue) => issue.code === "assertion.MustVerify")).toHaveLength(0);
    expect(baseline.assertionMode).toBe("baseline");
    expect(baseline.changeId).toBe("C-SELECTED");

    const target = lintGraceProject(root, { assertionMode: "target", changeId: "C-SELECTED" });
    expect(target.issues.filter((issue) => issue.code === "assertion.MustVerify")).toHaveLength(1);
  });

  it("requires explicit command opt-in and exposes selected assertion CLI flags", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-COMMAND",
      `<MustPassCommand><Command>exit 99</Command></MustPassCommand>`,
      `<MustPassCommand><Command>${process.platform === "win32" ? "exit /b 0" : "exit 0"}</Command></MustPassCommand>`,
    );

    const current = lintGraceProject(root);
    expect(current.issues.map((issue) => issue.code)).not.toContain("assertion.command-not-evaluated");
    expect(current.issues.some((issue) => issue.message.includes("exit 99"))).toBe(false);

    const skipped = lintGraceProject(root, { assertionMode: "target", changeId: "C-COMMAND" });
    expect(skipped.issues.map((issue) => issue.code)).toContain("assertion.command-not-evaluated");
    // A6.2: durable fixture — issueClass via catalog route 2; not pinned to live C-ABSENCE-VALUE.
    const notEvaluated = skipped.issues.find((issue) => issue.code === "assertion.command-not-evaluated");
    expect(notEvaluated).toBeDefined();
    expect(notEvaluated!.issueClass).toBe("absence");
    // A7.3 §2: assert the discriminating non-absence issue exists, then its class.
    // Finalized issues always carry guides; inject a non-absence assertion.* through the same finalize path
    // by re-linting a fixture that fails MustExist (below). Here pin that no other issue is "absence".
    for (const issue of skipped.issues) {
      if (issue.code !== "assertion.command-not-evaluated") {
        expect(issue.issueClass).not.toBe("absence");
      }
    }

    advanceCursor(root, "C-COMMAND", {
      task: "T-001",
      openEpoch: true,
      worker: "w0",
      from: 1,
      to: 20,
    });
    const executed = lintGraceProject(root, { assertionMode: "target", changeId: "C-COMMAND", runCommands: true });
    expect(executed.issues.map((issue) => issue.code)).not.toContain("assertion.command-not-evaluated");
    expect(executed.commandsEnabled).toBe(true);

    const repoRoot = path.resolve(import.meta.dir, "..");
    const cli = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--change", "C-COMMAND", "--assertions", "target", "--run-commands", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(cli.exitCode).toBe(0);
    expect(JSON.parse(Buffer.from(cli.stdout).toString("utf8")).assertionMode).toBe("target");
  });

  it("treats selected target without --run-commands as a structural query", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-COMMAND",
      `<MustPassCommand><Command>exit 99</Command></MustPassCommand>`,
      `<MustPassCommand><Command>${process.platform === "win32" ? "exit /b 0" : "exit 0"}</Command></MustPassCommand>`,
    );

    const skipped = lintGraceProject(root, { assertionMode: "target", changeId: "C-COMMAND" });
    const errorCount = skipped.issues.filter((issue) => issue.severity === "error").length;
    expect(skipped.summary.errors).toBe(errorCount);
    expect(skipped.summary.errors).toBe(1);
    expect(skipped.issues.map((issue) => issue.code)).toContain("assertion.command-not-evaluated");
    const notEvaluated = skipped.issues.find((issue) => issue.code === "assertion.command-not-evaluated");
    expect(notEvaluated!.issueClass).toBe("absence");
    expect(notEvaluated!.severity).toBe("error");

    const repoRoot = path.resolve(import.meta.dir, "..");
    const structural = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--change", "C-COMMAND", "--assertions", "target", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(structural.exitCode).toBe(0);
    const structuralJson = JSON.parse(Buffer.from(structural.stdout).toString("utf8")) as {
      issues: Array<{ code: string; severity: string }>;
      summary: { errors: number };
    };
    expect(structuralJson.issues.map((issue) => issue.code)).toContain("assertion.command-not-evaluated");
    expect(structuralJson.summary.errors).toBe(1);

    const warnFail = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--change", "C-COMMAND", "--assertions", "target", "--fail-on", "warnings", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(warnFail.exitCode).not.toBe(0);

    const finalCli = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--change", "C-COMMAND", "--assertions", "final", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(finalCli.exitCode).not.toBe(0);
    const finalJson = JSON.parse(Buffer.from(finalCli.stdout).toString("utf8")) as {
      issues: Array<{ code: string }>;
      summary: { errors: number };
    };
    expect(finalJson.issues.map((issue) => issue.code)).toContain("assertion.command-not-evaluated");
    expect(finalJson.summary.errors).toBeGreaterThan(0);

    const currentCli = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(currentCli.exitCode).toBe(0);
    const currentJson = JSON.parse(Buffer.from(currentCli.stdout).toString("utf8")) as { issues: Array<{ code: string }> };
    expect(currentJson.issues.map((issue) => issue.code)).not.toContain("assertion.command-not-evaluated");
  });

  it("still fails a structural target query when a non-exempt error coexists", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-COMMAND-AND-EXIST",
      `<MustExist><Value>M-EXAMPLE</Value></MustExist>`,
      `<MustPassCommand><Command>${process.platform === "win32" ? "exit /b 0" : "exit 0"}</Command></MustPassCommand><MustExist><Value>M-MISSING</Value></MustExist>`,
    );

    const skipped = lintGraceProject(root, { assertionMode: "target", changeId: "C-COMMAND-AND-EXIST" });
    expect(skipped.issues.map((issue) => issue.code)).toContain("assertion.command-not-evaluated");
    expect(skipped.issues.map((issue) => issue.code)).toContain("assertion.MustExist");
    expect(skipped.summary.errors).toBe(skipped.issues.filter((issue) => issue.severity === "error").length);
    expect(skipped.summary.errors).toBeGreaterThan(1);

    const repoRoot = path.resolve(import.meta.dir, "..");
    const structural = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--change", "C-COMMAND-AND-EXIST", "--assertions", "target", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(structural.exitCode).not.toBe(0);
  });

  it("omitting --assertions still selects current and accepts only the four modes", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const omitted = spawnLintJson(root, []);
    expect(omitted.exitCode).toBe(0);
    const omittedJson = JSON.parse(Buffer.from(omitted.stdout).toString("utf8")) as { assertionMode?: string };
    expect(omittedJson.assertionMode).toBe("current");
    expect((lintCommand.args as { assertions?: { default?: string } }).assertions?.default).toBe("current");

    const fifth = spawnLintJson(root, ["--assertions", "phase"]);
    const envelope = parseEnvelope(fifth);
    expect(fifth.exitCode).not.toBe(0);
    expect(envelope.ok).toBe(false);
    expect(envelope.error?.code).toBe("invalid-arguments");
    expect(envelope.error?.message).toContain("current");
    expect(envelope.error?.message).toContain("baseline");
    expect(envelope.error?.message).toContain("target");
    expect(envelope.error?.message).toContain("final");
  });

  it("current-mode CLI spawn of a failing baseline still exits 1", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-STALE-CLI",
      `<MustExist><Value>M-NONEXISTENT</Value></MustExist>`,
      `<MustVerify><Module>M-EXAMPLE</Module></MustVerify>`,
    );

    const repoRoot = path.resolve(import.meta.dir, "..");
    const currentCli = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(currentCli.exitCode).not.toBe(0);
    const currentJson = JSON.parse(Buffer.from(currentCli.stdout).toString("utf8")) as { issues: Array<{ code: string }> };
    expect(currentJson.issues.map((issue) => issue.code)).toContain("assertion.MustExist");
  });

  it("rejects target command evidence that recursively invokes current baseline lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-PHASE-CONFLICT",
      `<MustExist><Value>M-EXAMPLE</Value></MustExist>`,
      `<MustPassCommand><Command>ngrace lint --path . --assertions current</Command></MustPassCommand>`,
    );

    const current = lintGraceProject(root);
    const issue = current.issues.find((item) => item.code === "assertion.phase-incompatible-command");
    expect(issue?.message).toContain("leaf project evidence");
    expect(issue?.title).toContain("Phase-Incompatible");
    expect(issue?.message).toContain("omitted --assertions");
    expect(issue?.message).toContain("this project root");

    const final = lintGraceProject(root, { assertionMode: "final", changeId: "C-PHASE-CONFLICT", runCommands: true });
    expect(final.issues.map((item) => item.code)).toContain("assertion.phase-incompatible-command");
    expect(final.issues.map((item) => item.code)).not.toContain("assertion.MustPassCommand");
  });

  it("does not apply new phase policy retroactively to archived plans", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-HISTORICAL/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="applied"><C-HISTORICAL><Summary>Historical change.</Summary><Goals><Goal>Preserve history.</Goal></Goals><Constraints><Constraint>Do not rewrite archives.</Constraint></Constraints><NonGoals><NonGoal>New behavior.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>History remains readable.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></C-HISTORICAL></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-HISTORICAL/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="applied"><C-HISTORICAL><IntentSummary>Historical plan.</IntentSummary><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions><TargetAssertions><MustPassCommand><Command>ngrace lint --path . --assertions current</Command></MustPassCommand></TargetAssertions><DurableScope><GraphAnchors><M-EXAMPLE /></GraphAnchors></DurableScope><ObservedWriteScope><File>src/example.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Historical task</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>Done.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></C-HISTORICAL></NgraceChangePlan>`,
    );

    expect(lintGraceProject(root).issues.map((item) => item.code)).not.toContain("assertion.phase-incompatible-command");
  });

  it("rejects implicit-current lint of this project root on default lintGraceProject", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-PHASE-IMPLICIT",
      `<MustExist><Value>M-EXAMPLE</Value></MustExist>`,
      `<MustPassCommand><Command>bun run ngrace lint --path .</Command></MustPassCommand>`,
    );

    const current = lintGraceProject(root);
    const issue = current.issues.find((item) => item.code === "assertion.phase-incompatible-command");
    expect(issue).toBeDefined();
    expect(issue?.message).toContain("leaf project evidence");
    expect(issue?.title).toContain("Phase-Incompatible");
    expect(issue?.message).toContain("omitted --assertions");
    expect(issue?.message).toContain("this project root");
  });

  it("does not apply implicit-current phase policy retroactively to archived plans", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-HISTORICAL-IMPLICIT/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="applied"><C-HISTORICAL-IMPLICIT><Summary>Historical change.</Summary><Goals><Goal>Preserve history.</Goal></Goals><Constraints><Constraint>Do not rewrite archives.</Constraint></Constraints><NonGoals><NonGoal>New behavior.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>History remains readable.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></C-HISTORICAL-IMPLICIT></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-HISTORICAL-IMPLICIT/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="applied"><C-HISTORICAL-IMPLICIT><IntentSummary>Historical plan.</IntentSummary><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions><TargetAssertions><MustPassCommand><Command>bun run ngrace lint --path .</Command></MustPassCommand></TargetAssertions><DurableScope><GraphAnchors><M-EXAMPLE /></GraphAnchors></DurableScope><ObservedWriteScope><File>src/example.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Historical task</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>Done.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></C-HISTORICAL-IMPLICIT></NgraceChangePlan>`,
    );

    expect(lintGraceProject(root).issues.map((item) => item.code)).not.toContain("assertion.phase-incompatible-command");
  });

  it("reserves blocking overlap diagnostics for explicit parallel preflight", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(root, "C-ONE", `<MustExist><Value>M-EXAMPLE</Value></MustExist>`, `<MustVerify><Module>M-EXAMPLE</Module></MustVerify>`);
    writeApprovedChange(root, "C-TWO", `<MustExist><Value>M-EXAMPLE</Value></MustExist>`, `<MustVerify><Module>M-EXAMPLE</Module></MustVerify>`);

    const ordinaryCodes = lintGraceProject(root).issues.map((issue) => issue.code);
    expect(ordinaryCodes).toContain("scope.durable-overlap");
    expect(ordinaryCodes).not.toContain("scope.parallel-durable-overlap");
    expect(ordinaryCodes).not.toContain("scope.observed-write-overlap");

    const preflightCodes = lintGraceProject(root, { parallelPreflight: true }).issues.map((issue) => issue.code);
    expect(preflightCodes).toContain("scope.parallel-durable-overlap");
    expect(preflightCodes).toContain("scope.observed-write-overlap");
  });

  it("does not evaluate BaselineAssertions for active draft plans", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-DRAFT/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="draft"><C-DRAFT><BaselineAssertions><MustExist><Value>M-NONEXISTENT</Value></MustExist></BaselineAssertions></C-DRAFT></NgraceChangePlan>`,
    );
    // Draft active plan should NOT fire assertion.MustExist
    const result = lintGraceProject(root);
    expect(result.issues.filter((issue) => issue.code === "assertion.MustExist")).toHaveLength(0);
  });

  it("fails active approved plans with failing BaselineAssertions", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-STALE/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-STALE><BaselineAssertions><MustExist><Value>M-NONEXISTENT</Value></MustExist></BaselineAssertions></C-STALE></NgraceChangePlan>`,
    );
    const result = lintGraceProject(root);
    expect(result.issues.filter((issue) => issue.code === "assertion.MustExist")).toHaveLength(1);
  });

  it("parses approved plan status through XML regardless of attribute quote style", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-SINGLE-QUOTE",
      `<MustExist><Value>M-MISSING</Value></MustExist>`,
      `<MustVerify><Module>M-EXAMPLE</Module></MustVerify>`,
    );
    const planFile = path.join(root, `${ARTIFACT_DIR}/changes/active/C-SINGLE-QUOTE/plan.xml`);
    writeFileSync(planFile, readFileSync(planFile, "utf8").replace('status="approved"', "status='approved'"));

    expect(lintGraceProject(root).issues.map((issue) => issue.code)).toContain("assertion.MustExist");
  });

  it("uses final assertion mode for full end-state validation without re-evaluating the selected baseline", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-CREATE",
      `<MustNotExist><Value>M-NEW</Value></MustNotExist>`,
      `<MustVerify><Module>M-NEW</Module></MustVerify>`,
    );
    expect(lintGraceProject(root).summary.errors).toBe(0);

    writeProjectFile(root, `${ARTIFACT_DIR}/graph/index.xml`, `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><M-NEW /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/main.xml`, `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example module.</Summary></M-EXAMPLE><M-NEW><Summary>New module.</Summary></M-NEW></GD-MAIN></NgraceGraphDocument>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/verification/index.xml`, `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /><V-M-NEW /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/verification/main.xml`, `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE><Scenario>Example works.</Scenario></V-M-EXAMPLE><V-M-NEW><Scenario>New module works.</Scenario></V-M-NEW></VD-MAIN></NgraceVerificationDocument>`);

    const current = lintGraceProject(root);
    expect(current.issues.map((issue) => issue.code)).toContain("assertion.MustNotExist");

    const final = lintGraceProject(root, { assertionMode: "final", changeId: "C-CREATE" });
    expect(final.summary.errors).toBe(0);
    expect(final.assertionMode).toBe("final");
  });

  it("keeps unrelated approved baselines active during selected final validation", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(root, "C-SELECTED-FINAL", `<MustExist><Value>M-EXAMPLE</Value></MustExist>`, `<MustVerify><Module>M-EXAMPLE</Module></MustVerify>`);
    writeApprovedChange(root, "C-UNRELATED-STALE", `<MustExist><Value>M-MISSING</Value></MustExist>`, `<MustVerify><Module>M-EXAMPLE</Module></MustVerify>`);

    const final = lintGraceProject(root, { assertionMode: "final", changeId: "C-SELECTED-FINAL" });
    expect(final.issues.map((issue) => issue.code)).toContain("assertion.MustExist");
  });

  it("accepts a bundle with design-context.xml", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-DESIGN/design-context.xml`,
      `<NgraceChangeDesignContext graceVersion="1.0"><Change>C-DESIGN</Change><Rationale>Test.</Rationale></NgraceChangeDesignContext>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-DESIGN/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><C-DESIGN><Summary>Change with design context.</Summary></C-DESIGN></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-DESIGN/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-DESIGN><DurableScope><GraphAnchors><M-EXAMPLE /></GraphAnchors></DurableScope></C-DESIGN></NgraceChangePlan>`,
    );
    const result = lintGraceProject(root);
    expect(result.issues.filter((issue) => issue.code.startsWith("design-context.") || issue.code === "artifact.invalid-root-tag" || issue.code === "change.invalid-root-tag")).toHaveLength(0);
  });

  it("reports analysis coverage for polyglot fixtures with Go and Rust adapter-backed", async () => {
    const { polyglotFixture, minimalTsFixture } = await import("./test-support/fixtures");
    const root = polyglotFixture();
    const result = lintGraceProject(root);
    // Phase 3: both .go and .rs are adapter-backed; no analysis.no-adapter on polyglot.
    expect(result.issues.filter((issue) => issue.code === "analysis.no-adapter")).toHaveLength(0);
    expect(result.summary.errors).toBe(0);
    expect(result.analysisCoverage.unverified).toEqual([]);
    expect(result.analysisCoverage.adapterBacked.some((entry) => entry.extension === ".tsx")).toBe(true);
    expect(result.analysisCoverage.adapterBacked.some((entry) => entry.extension === ".go" && entry.adapterId === "go")).toBe(true);
    expect(result.analysisCoverage.adapterBacked.some((entry) => entry.extension === ".rs" && entry.adapterId === "rust")).toBe(true);

    const tsOnly = lintGraceProject(minimalTsFixture());
    expect(tsOnly.issues.filter((issue) => issue.code === "analysis.no-adapter")).toHaveLength(0);
    expect(tsOnly.analysisCoverage.unverified).toEqual([]);
  });

  it("enforces Go MODULE_MAP parity and no longer emits analysis.no-adapter for .go", async () => {
    const { polyglotFixture } = await import("./test-support/fixtures");
    const root = polyglotFixture();

    // Matching map: no mismatch, no no-adapter for Go.
    const clean = lintGraceProject(root);
    const goIssues = clean.issues.filter((issue) => issue.file.endsWith(".go") || issue.file.includes("router.go"));
    expect(goIssues.map((issue) => issue.code)).not.toContain("analysis.no-adapter");
    expect(goIssues.map((issue) => issue.code)).not.toContain("markup.module-map-mismatch");

    // G-01 regression: fabricated symbol must error (was silence at 4.0.4 / Phase 1).
    writeProjectFile(
      root,
      "services/gateway/internal/router/router.go",
      `// START_MODULE_CONTRACT
// PURPOSE: Route gateway requests to ledger services.
// SCOPE: Dispatch inbound HTTP/gRPC traffic.
// DEPENDS: none
// LINKS: M-GATEWAY-ROUTER
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// TotallyFakeSymbol - Fabricated for G-01 regression.
// END_MODULE_MAP
func Route(path string) error {
	// START_BLOCK_DISPATCH
	slog.Info("[GatewayRouter][Route][BLOCK_DISPATCH] dispatch")
	// END_BLOCK_DISPATCH
	return nil
}
`,
    );
    const broken = lintGraceProject(root);
    const mismatch = broken.issues.filter(
      (issue) => issue.code === "markup.module-map-mismatch" && issue.file.includes("router.go"),
    );
    expect(mismatch.length).toBeGreaterThanOrEqual(1);
    expect(mismatch[0]?.severity).toBe("error");

    // Build-tag file reports heuristic confidence.
    writeProjectFile(
      root,
      "services/gateway/internal/router/linux_only.go",
      `//go:build linux

// START_MODULE_CONTRACT
// PURPOSE: Linux-only helper.
// SCOPE: Platform file.
// DEPENDS: none
// LINKS: M-GATEWAY-ROUTER
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// LinuxHelper - Platform helper.
// END_MODULE_MAP
package router

func LinuxHelper() {}
`,
    );
    const tagged = lintGraceProject(root);
    expect(
      tagged.issues.some(
        (issue) => issue.code === "analysis.heuristic-confidence" && issue.file.includes("linux_only.go"),
      ),
    ).toBe(true);
  });

  it("enforces Rust MODULE_MAP parity and no longer emits analysis.no-adapter for .rs", async () => {
    const { polyglotFixture } = await import("./test-support/fixtures");
    const root = polyglotFixture();

    const clean = lintGraceProject(root);
    const rustIssues = clean.issues.filter((issue) => issue.file.endsWith(".rs") || issue.file.includes("lib.rs"));
    expect(rustIssues.map((issue) => issue.code)).not.toContain("analysis.no-adapter");
    expect(rustIssues.map((issue) => issue.code)).not.toContain("markup.module-map-mismatch");

    // G-01 regression: fabricated Rust symbol must error.
    writeProjectFile(
      root,
      "services/ledger/src/lib.rs",
      `// START_MODULE_CONTRACT
// PURPOSE: Ledger core posting and balance validation.
// SCOPE: Post journal entries with balance checks.
// DEPENDS: none
// LINKS: M-LEDGER-CORE
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// TotallyFakeSymbol - Fabricated for G-01 regression.
// END_MODULE_MAP
pub fn post(amount: i64) -> Result<(), String> {
    // START_BLOCK_VALIDATE_BALANCE
    tracing::warn!("[LedgerCore][post][BLOCK_VALIDATE_BALANCE] unbalanced");
    // END_BLOCK_VALIDATE_BALANCE
    Ok(())
}
`,
    );
    const broken = lintGraceProject(root);
    const mismatch = broken.issues.filter(
      (issue) => issue.code === "markup.module-map-mismatch" && issue.file.includes("lib.rs"),
    );
    expect(mismatch.length).toBeGreaterThanOrEqual(1);
    expect(mismatch[0]?.severity).toBe("error");

    // pub(crate) listed as EXPORTS is a mismatch (not a crate-external export).
    writeProjectFile(
      root,
      "services/ledger/src/lib.rs",
      `// START_MODULE_CONTRACT
// PURPOSE: Ledger core.
// SCOPE: Internal.
// DEPENDS: none
// LINKS: M-LEDGER-CORE
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// internal - Not actually public.
// END_MODULE_MAP
pub(crate) fn internal() {}
`,
    );
    const restricted = lintGraceProject(root);
    expect(
      restricted.issues.some(
        (issue) => issue.code === "markup.module-map-mismatch" && issue.file.includes("lib.rs"),
      ),
    ).toBe(true);

    // include! reports heuristic confidence.
    writeProjectFile(
      root,
      "services/ledger/src/generated_wrap.rs",
      `// START_MODULE_CONTRACT
// PURPOSE: Generated wrapper.
// SCOPE: Include generated code.
// DEPENDS: none
// LINKS: M-LEDGER-CORE
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// wrap - Wrapper.
// END_MODULE_MAP
include!("generated.rs");
pub fn wrap() {}
`,
    );
    const included = lintGraceProject(root);
    expect(
      included.issues.some(
        (issue) => issue.code === "analysis.heuristic-confidence" && issue.file.includes("generated_wrap.rs"),
      ),
    ).toBe(true);
  });

  it("validates DEPENDS and LINKS anchors against the graph (G-10, G-11)", async () => {
    const { polyglotFixture } = await import("./test-support/fixtures");

    // Unmodified polyglot must stay clean of new reference issues.
    const polyglot = lintGraceProject(polyglotFixture());
    expect(polyglot.issues.filter((issue) => issue.code === "markup.unknown-dependency")).toHaveLength(0);
    expect(polyglot.issues.filter((issue) => issue.code === "markup.unknown-link")).toHaveLength(0);
    expect(polyglot.summary.errors).toBe(0);

    // Free-text DEPENDS (no M-*) are ignored.
    const freeRoot = createProject();
    writeMinimalNgraceProject(freeRoot);
    writeProjectFile(
      freeRoot,
      "src/example.ts",
      `// START_MODULE_CONTRACT
// PURPOSE: Example.
// SCOPE: Example.
// DEPENDS: postgres, redis
// LINKS: M-EXAMPLE
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// run - Run.
// END_MODULE_MAP
export function run() {
  console.info("[Example][run][BLOCK_RUN] run");
  // START_BLOCK_RUN
  return "ok";
  // END_BLOCK_RUN
}
`,
    );
    expect(lintGraceProject(freeRoot).issues.filter((i) => i.code.startsWith("markup.unknown-"))).toHaveLength(0);

    // G-10: phantom DEPENDS
    writeProjectFile(
      freeRoot,
      "src/example.ts",
      `// START_MODULE_CONTRACT
// PURPOSE: Example.
// SCOPE: Example.
// DEPENDS: M-DOES-NOT-EXIST, M-ALSO-FAKE
// LINKS: M-EXAMPLE
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// run - Run.
// END_MODULE_MAP
export function run() {
  console.info("[Example][run][BLOCK_RUN] run");
  // START_BLOCK_RUN
  return "ok";
  // END_BLOCK_RUN
}
`,
    );
    const dependsBroken = lintGraceProject(freeRoot);
    const depIssues = dependsBroken.issues.filter((i) => i.code === "markup.unknown-dependency");
    expect(depIssues.length).toBe(2);

    // G-11: phantom module link
    writeProjectFile(
      freeRoot,
      "src/example.ts",
      `// START_MODULE_CONTRACT
// PURPOSE: Example.
// SCOPE: Example.
// DEPENDS: none
// LINKS: M-NONEXISTENT
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// run - Run.
// END_MODULE_MAP
export function run() {
  console.info("[Example][run][BLOCK_RUN] run");
  // START_BLOCK_RUN
  return "ok";
  // END_BLOCK_RUN
}
`,
    );
    const linkBroken = lintGraceProject(freeRoot);
    expect(linkBroken.issues.some((i) => i.code === "markup.unknown-link" && i.message.includes("M-NONEXISTENT"))).toBe(true);

    // Phantom verification link
    writeProjectFile(
      freeRoot,
      "src/example.ts",
      `// START_MODULE_CONTRACT
// PURPOSE: Example.
// SCOPE: Example.
// DEPENDS: none
// LINKS: M-EXAMPLE, V-M-NONEXISTENT
// ROLE: RUNTIME
// MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
// run - Run.
// END_MODULE_MAP
export function run() {
  console.info("[Example][run][BLOCK_RUN] run");
  // START_BLOCK_RUN
  return "ok";
  // END_BLOCK_RUN
}
`,
    );
    const verifBroken = lintGraceProject(freeRoot);
    expect(verifBroken.issues.some((i) => i.code === "markup.unknown-link" && i.message.includes("V-M-NONEXISTENT"))).toBe(true);

    // Module with Path but no linking governed file → warning
    const orphanRoot = createProject();
    writeMinimalNgraceProject(orphanRoot);
    writeProjectFile(
      orphanRoot,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><M-ORPHAN /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      orphanRoot,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example.</Summary><Path>src/example.ts</Path></M-EXAMPLE><M-ORPHAN><Summary>Orphan.</Summary><Path>src/orphan.ts</Path></M-ORPHAN></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      orphanRoot,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /><V-M-ORPHAN /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      orphanRoot,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE><Command>echo ok</Command><Scenario>ok</Scenario></V-M-EXAMPLE><V-M-ORPHAN><Command>echo ok</Command><Scenario>ok</Scenario></V-M-ORPHAN></VD-MAIN></NgraceVerificationDocument>`,
    );
    const orphan = lintGraceProject(orphanRoot);
    const orphanWarn = orphan.issues.filter((i) => i.code === "graph.module-without-linked-files");
    expect(orphanWarn.length).toBeGreaterThanOrEqual(1);
    expect(orphanWarn.every((i) => i.severity === "warning")).toBe(true);
    expect(orphanWarn.some((i) => i.message.includes("M-ORPHAN"))).toBe(true);
  });

  it("does not treat a Summary mentioning Path or File as a declared module Path", () => {
    // The Path check reads the structured GraphAnchorRecord.path, not the
    // flattened projection text, where `<Summary>Path resolution helper.</Summary>`
    // is indistinguishable from a real `<Path>` element.
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><M-PROSE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example.</Summary><Path>src/example.ts</Path></M-EXAMPLE><M-PROSE><Summary>Path resolution and File loading helpers.</Summary></M-PROSE></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /><V-M-PROSE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE><Command>echo ok</Command><Scenario>ok</Scenario></V-M-EXAMPLE><V-M-PROSE><Command>echo ok</Command><Scenario>ok</Scenario></V-M-PROSE></VD-MAIN></NgraceVerificationDocument>`,
    );

    const result = lintGraceProject(root);
    const warnings = result.issues.filter((i) => i.code === "graph.module-without-linked-files");
    expect(warnings.some((i) => i.message.includes("M-PROSE"))).toBe(false);
  });

  it("Phase 7: IC-* Schema escape and missing Provider fire through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(root, "src/gateway.ts", "export const g = 1;\n");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><M-GATEWAY /><IC-BAD /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN>`
        + `<M-EXAMPLE><Summary>Example.</Summary><Path>src/example.ts</Path></M-EXAMPLE>`
        + `<M-GATEWAY><Summary>Gateway.</Summary><Path>src/gateway.ts</Path></M-GATEWAY>`
        + `<IC-BAD><Summary>Bad contract.</Summary><Schema>../../etc/passwd</Schema><Version>1.0.0</Version>`
        + `<Provider><M-DOES-NOT-EXIST /></Provider><Consumer><M-GATEWAY /></Consumer>`
        + `<BreakingChangePolicy>additive-only</BreakingChangePolicy></IC-BAD>`
        + `</GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /><V-M-GATEWAY /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN>`
        + `<V-M-EXAMPLE><Command>echo ok</Command><Scenario>ok</Scenario></V-M-EXAMPLE>`
        + `<V-M-GATEWAY><Command>echo ok</Command><Scenario>ok</Scenario></V-M-GATEWAY>`
        + `</VD-MAIN></NgraceVerificationDocument>`,
    );

    const result = lintGraceProject(root);
    expect(result.issues.map((i) => i.code)).toContain("projection.graph.invalid-interface-contract");
    expect(result.issues.some((i) => i.message.includes("contained project path") || i.message.includes("Provider"))).toBe(true);
    expect(getLintIssueGuide("projection.graph.invalid-interface-contract").title).toContain("Interface Contract");
  });

  it("Phase 7: ordered DF gap and flat DF compatibility through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(root, "src/gateway.ts", "export const g = 1;\n");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><M-GATEWAY /><DF-FLAT /><DF-GAP /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN>`
        + `<M-EXAMPLE><Summary>Example.</Summary><Path>src/example.ts</Path></M-EXAMPLE>`
        + `<M-GATEWAY><Summary>Gateway.</Summary><Path>src/gateway.ts</Path></M-GATEWAY>`
        + `<DF-FLAT><Summary>Legacy flat.</Summary><M-EXAMPLE /><M-GATEWAY /></DF-FLAT>`
        + `<DF-GAP><Summary>Gapped.</Summary><Step order="1"><M-EXAMPLE /></Step><Step order="3"><M-GATEWAY /></Step></DF-GAP>`
        + `</GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /><V-M-GATEWAY /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN>`
        + `<V-M-EXAMPLE><Command>echo ok</Command><Scenario>ok</Scenario></V-M-EXAMPLE>`
        + `<V-M-GATEWAY><Command>echo ok</Command><Scenario>ok</Scenario></V-M-GATEWAY>`
        + `</VD-MAIN></NgraceVerificationDocument>`,
    );

    const result = lintGraceProject(root);
    expect(result.issues.map((i) => i.code)).toContain("projection.graph.invalid-data-flow-step");
    expect(result.issues.some((i) => i.message.includes("DF-GAP") && i.message.includes("missing 2"))).toBe(true);
    // Flat form must not invent step errors for DF-FLAT.
    expect(result.issues.filter((i) => i.message.includes("DF-FLAT") && i.code === "projection.graph.invalid-data-flow-step")).toHaveLength(0);
  });

  it("Phase 7: project without invariants.xml gains no context.invariants codes", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const result = lintGraceProject(root);
    expect(result.issues.filter((i) => i.code.startsWith("context.invariants."))).toHaveLength(0);
    expect(result.summary.errors).toBe(0);
  });

  it("Phase 7: MustConform and MustPassBudget respect --run-commands opt-in", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(root, "proto/x.proto", "syntax = \"proto3\";\n");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><IC-X /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN>`
        + `<M-EXAMPLE><Summary>Example.</Summary><Path>src/example.ts</Path></M-EXAMPLE>`
        + `<IC-X><Summary>Contract.</Summary><Schema>proto/x.proto</Schema><Version>1.0.0</Version>`
        + `<Provider><M-EXAMPLE /></Provider><Consumer><M-EXAMPLE /></Consumer>`
        + `<BreakingChangePolicy>versioned</BreakingChangePolicy></IC-X>`
        + `</GD-MAIN></NgraceGraphDocument>`,
    );
    writeApprovedChange(
      root,
      "C-SYSTEMS",
      `<MustConform><Contract>IC-X</Contract><Module>M-EXAMPLE</Module><Command>exit 0</Command></MustConform>`,
      `<MustPassBudget><Command>${process.platform === "win32" ? "echo p99=42" : "printf 'p99=42\\n'"}</Command><Metric>p99</Metric><Operator>lt</Operator><Threshold>50</Threshold><Unit>ms</Unit></MustPassBudget>`,
    );

    const without = lintGraceProject(root, { assertionMode: "target", changeId: "C-SYSTEMS" });
    // MustPassBudget is command-gated; MustConform ref-only passes without execution.
    expect(without.issues.map((i) => i.code)).not.toContain("assertion.MustConform");
    // Target mode evaluates MustPassBudget → command-not-evaluated without --run-commands.
    expect(without.issues.map((i) => i.code)).toContain("assertion.command-not-evaluated");
    expect(without.summary.errors).toBe(without.issues.filter((i) => i.severity === "error").length);

    const repoRoot = path.resolve(import.meta.dir, "..");
    const structuralBudget = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--change", "C-SYSTEMS", "--assertions", "target", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(structuralBudget.exitCode).toBe(0);
    const budgetJson = JSON.parse(Buffer.from(structuralBudget.stdout).toString("utf8")) as { issues: Array<{ code: string }> };
    expect(budgetJson.issues.map((i) => i.code)).toContain("assertion.command-not-evaluated");

    advanceCursor(root, "C-SYSTEMS", {
      task: "T-001",
      openEpoch: true,
      worker: "w0",
      from: 1,
      to: 20,
    });
    const withCmds = lintGraceProject(root, {
      assertionMode: "target",
      changeId: "C-SYSTEMS",
      runCommands: true,
    });
    expect(withCmds.issues.map((i) => i.code)).not.toContain("assertion.MustConform");
    expect(withCmds.issues.map((i) => i.code)).not.toContain("assertion.MustPassBudget");
    expect(withCmds.issues.map((i) => i.code)).not.toContain("assertion.budget-no-match");
    expect(withCmds.issues.map((i) => i.code)).not.toContain("assertion.command-not-evaluated");
  });

  it("Phase 7: current lint skips unevaluated MustPassBudget on active baselines (pins lint/core.ts)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    // Put MustPassBudget in BaselineAssertions of an active approved plan.
    writeApprovedChange(
      root,
      "C-BUDGET-BASELINE",
      `<MustPassBudget><Command>exit 99</Command><Metric>p99</Metric><Operator>lt</Operator><Threshold>50</Threshold><Unit>ms</Unit></MustPassBudget>`,
      `<MustExist><Value>M-EXAMPLE</Value></MustExist>`,
    );

    const current = lintGraceProject(root);
    // Without the skipUnevaluatedCommands extension to MustPassBudget, current mode would
    // emit assertion.command-not-evaluated for every active plan that uses a budget gate.
    expect(current.issues.map((i) => i.code)).not.toContain("assertion.command-not-evaluated");
    expect(current.issues.map((i) => i.code)).not.toContain("assertion.budget-command-failed");
  });

  it("A8: near-miss markers warn without governing the file", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      "src/typo.ts",
      `// START_MODULE_CONTRACTX
export const x = 1;
`,
    );
    writeProjectFile(
      root,
      "src/block-typo.ts",
      `// START_BLOCK_foo
export const y = 2;
`,
    );

    const result = lintGraceProject(root);
    const nearMiss = result.issues.filter((issue) => issue.code === "markup.near-miss-marker");
    expect(nearMiss.length).toBeGreaterThanOrEqual(2);
    expect(nearMiss.every((issue) => issue.severity === "warning")).toBe(true);
    // File stays ungoverned — only the real example.ts from writeMinimalNgraceProject counts.
    expect(result.governedFiles).toBe(1);
    // No false markup errors from treating near-miss as governed (A7.1 table after-column).
    expect(result.issues.map((i) => i.code)).not.toContain("markup.missing-module-contract");
    expect(nearMiss.every((issue) => issue.issueClass !== "absence")).toBe(true);
  });
});

describe("Phase 3 run ledger / cursor integration (§0.2, A12.2)", () => {
  const LEDGER_CURSOR_CODES = [
    "ledger.invalid-root-tag",
    "ledger.invalid-change-id",
    "ledger.bundle-id-mismatch",
    "ledger.non-monotonic-epoch",
    "ledger.reordered-epoch",
    "ledger.event-outside-allocation",
    "ledger.range-hole",
    "ledger.range-unterminated",
    "cursor.invalid-root-tag",
    "cursor.invalid-change-id",
    "cursor.bundle-id-mismatch",
    "cursor.unknown-task",
  ] as const;

  function writeApprovedBundle(root: string, changeId: string) {
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/${changeId}/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><${changeId}><Summary>S.</Summary><Goals><Goal>G.</Goal></Goals><Constraints><Constraint>C.</Constraint></Constraints><NonGoals><NonGoal>N.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>A.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></${changeId}></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/${changeId}/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><${changeId}><IntentSummary>I.</IntentSummary><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions><TargetAssertions><MustVerify><Module>M-EXAMPLE</Module></MustVerify></TargetAssertions><DurableScope><GraphAnchors><M-EXAMPLE /></GraphAnchors></DurableScope><ObservedWriteScope><File>src/example.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>T</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>ok</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></${changeId}></NgraceChangePlan>`,
    );
  }

  function denseLedger(changeId: string, epochs: string) {
    return `<NgraceRunLedger graceVersion="1.0"><${changeId}>${epochs}</${changeId}></NgraceRunLedger>`;
  }

  it("clean project emits none of the twelve ledger.* / cursor.* codes", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-CLEAN");
    const codes = lintGraceProject(root).issues.map((i) => i.code);
    for (const code of LEDGER_CURSOR_CODES) {
      expect(codes).not.toContain(code);
    }
  });

  it("AC-CURSOR-CONDITIONAL: absent cursor is silent (integration)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-NOCURSOR");
    const codes = lintGraceProject(root).issues.map((i) => i.code).filter((c) => c.startsWith("cursor."));
    expect(codes).toEqual([]);
  });

  it("AC-CURSOR-CONDITIONAL: unknown task errors (integration)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-BADTASK");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-BADTASK/run.xml`,
      `<NgraceRunCursor graceVersion="1.0"><C-BADTASK><Task>T-999</Task><State>idle</State></C-BADTASK></NgraceRunCursor>`,
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("cursor.unknown-task");
  });

  it("AC-CURSOR-CONDITIONAL: consistent cursor is clean (integration)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-OKCURSOR");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-OKCURSOR/run.xml`,
      `<NgraceRunCursor graceVersion="1.0"><C-OKCURSOR><Task>T-001</Task><State>idle</State></C-OKCURSOR></NgraceRunCursor>`,
    );
    const codes = lintGraceProject(root).issues.map((i) => i.code).filter((c) => c.startsWith("cursor."));
    expect(codes).toEqual([]);
  });

  it("fires ledger.invalid-root-tag through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LROOT");
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-LROOT/run-ledger.xml`, `<NotLedger graceVersion="1.0"><C-LROOT/></NotLedger>`);
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.invalid-root-tag");
  });

  it("fires ledger.invalid-change-id through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LID");
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-LID/run-ledger.xml`, `<NgraceRunLedger graceVersion="1.0"></NgraceRunLedger>`);
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.invalid-change-id");
  });

  it("fires ledger.bundle-id-mismatch through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LMIS");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-LMIS/run-ledger.xml`,
      denseLedger("C-OTHER", `<Epoch-1><Allocation worker="w" from="1" to="10"/><Event id="1" task="T-001" kind="opened"/><Event id="2" task="T-001" kind="terminal"/></Epoch-1>`),
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.bundle-id-mismatch");
  });

  it("fires ledger.non-monotonic-epoch through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LMONO");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-LMONO/run-ledger.xml`,
      denseLedger(
        "C-LMONO",
        `<Epoch-1><Allocation worker="w" from="1" to="10"/><Event id="1" task="T-001" kind="opened"/><Event id="2" task="T-001" kind="terminal"/></Epoch-1>`
          + `<Epoch-1><Allocation worker="w" from="11" to="20"/><Event id="11" task="T-001" kind="opened"/><Event id="12" task="T-001" kind="terminal"/></Epoch-1>`,
      ),
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.non-monotonic-epoch");
  });

  it("fires ledger.reordered-epoch through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LORD");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-LORD/run-ledger.xml`,
      denseLedger(
        "C-LORD",
        `<Epoch-2><Allocation worker="w" from="1" to="10"/><Event id="1" task="T-001" kind="opened"/><Event id="2" task="T-001" kind="terminal"/></Epoch-2>`
          + `<Epoch-1><Allocation worker="w" from="11" to="20"/><Event id="11" task="T-001" kind="opened"/><Event id="12" task="T-001" kind="terminal"/></Epoch-1>`,
      ),
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.reordered-epoch");
  });

  it("fires ledger.event-outside-allocation through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LOUT");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-LOUT/run-ledger.xml`,
      denseLedger(
        "C-LOUT",
        `<Epoch-1><Allocation worker="w" from="1" to="10"/><Event id="1" task="T-001" kind="opened"/><Event id="50" task="T-001" kind="terminal"/></Epoch-1>`,
      ),
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.event-outside-allocation");
  });

  it("fires ledger.range-hole through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LHOLE");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-LHOLE/run-ledger.xml`,
      denseLedger(
        "C-LHOLE",
        `<Epoch-1><Allocation worker="w" from="1" to="10"/><Event id="1" task="T-001" kind="opened"/><Event id="3" task="T-001" kind="terminal"/></Epoch-1>`,
      ),
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.range-hole");
  });

  it("fires ledger.range-unterminated through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-LUNTERM");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-LUNTERM/run-ledger.xml`,
      denseLedger(
        "C-LUNTERM",
        `<Epoch-1><Allocation worker="w" from="1" to="10"/><Event id="1" task="T-001" kind="opened"/><Event id="2" task="T-001" kind="progress"/></Epoch-1>`,
      ),
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("ledger.range-unterminated");
  });

  it("fires cursor.invalid-root-tag through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-CROOT");
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-CROOT/run.xml`, `<Nope graceVersion="1.0"/>`);
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("cursor.invalid-root-tag");
  });

  it("fires cursor.invalid-change-id through ngrace lint", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-CID");
    writeProjectFile(root, `${ARTIFACT_DIR}/changes/active/C-CID/run.xml`, `<NgraceRunCursor graceVersion="1.0"></NgraceRunCursor>`);
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("cursor.invalid-change-id");
  });

  it("fires cursor.bundle-id-mismatch through ngrace lint (not unknown-task when task collides)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-A");
    writeApprovedBundle(root, "C-B");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-B/run.xml`,
      `<NgraceRunCursor graceVersion="1.0"><C-A><Task>T-001</Task><State>idle</State></C-A></NgraceRunCursor>`,
    );
    const codes = lintGraceProject(root).issues.filter((i) => i.file.includes("C-B")).map((i) => i.code);
    expect(codes).toContain("cursor.bundle-id-mismatch");
    expect(codes).not.toContain("cursor.unknown-task");
  });

  it("fourth cursor behaviour: unknown-task when cursor names a task and plan.xml is absent (A12.5)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-NOPLAN/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><C-NOPLAN><Summary>S.</Summary><Goals><Goal>G.</Goal></Goals><Constraints><Constraint>C.</Constraint></Constraints><NonGoals><NonGoal>N.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>A.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></C-NOPLAN></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-NOPLAN/run.xml`,
      `<NgraceRunCursor graceVersion="1.0"><C-NOPLAN><Task>T-001</Task><State>idle</State></C-NOPLAN></NgraceRunCursor>`,
    );
    expect(lintGraceProject(root).issues.map((i) => i.code)).toContain("cursor.unknown-task");
  });

  it("dense terminated ledger admitted by public lint with no ledger.* codes", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedBundle(root, "C-DENSE");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-DENSE/run-ledger.xml`,
      denseLedger(
        "C-DENSE",
        `<Epoch-1><Allocation worker="w" from="1" to="10"/><Event id="1" task="T-001" kind="opened"/><Event id="2" task="T-001" kind="terminal"/></Epoch-1>`,
      ),
    );
    const codes = lintGraceProject(root).issues.map((i) => i.code).filter((c) => c.startsWith("ledger."));
    expect(codes).toEqual([]);
  });
});

describe("change.graph-anchors-miss-write-scope (C-GRAPH-COVERAGE / A53)", () => {
  const CODE = "change.graph-anchors-miss-write-scope";

  function writePlanWithScope(
    root: string,
    changeId: string,
    location: "active" | "archive",
    graphAnchors: string,
    observedWriteFiles: string[],
  ) {
    const dir = `${ARTIFACT_DIR}/changes/${location}/${changeId}`;
    const ows = observedWriteFiles.map((f) => `<File>${f}</File>`).join("");
    writeProjectFile(
      root,
      `${dir}/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><${changeId}><Summary>S.</Summary><Goals><Goal>G.</Goal></Goals><Constraints><Constraint>C.</Constraint></Constraints><NonGoals><NonGoal>N.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>A.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></${changeId}></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${dir}/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><${changeId}><IntentSummary>I.</IntentSummary><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions><TargetAssertions><MustVerify><Module>M-EXAMPLE</Module></MustVerify></TargetAssertions><DurableScope><GraphAnchors>${graphAnchors}</GraphAnchors></DurableScope><ObservedWriteScope>${ows}</ObservedWriteScope><ImplementationPlan><T-001><Title>T</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>ok</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></${changeId}></NgraceChangePlan>`,
    );
  }

  it("silent when GraphAnchors module appears in the file's LINKS (axis: owns)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writePlanWithScope(root, "C-OWN", "active", "<M-EXAMPLE />", ["src/example.ts"]);
    const issues = lintGraceProject(root).issues.filter((i) => i.code === CODE);
    expect(issues).toEqual([]);
  });

  it("red when GraphAnchors do not intersect file LINKS (axis: miss)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example module.</Summary><Path>src/example.ts</Path></M-EXAMPLE><M-OTHER><Summary>Other.</Summary><Path>src/other.ts</Path></M-OTHER></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><M-OTHER /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      "src/other.ts",
      `// START_MODULE_CONTRACT
//   PURPOSE: Other module.
//   SCOPE: Fixture.
//   DEPENDS: none
//   LINKS: M-OTHER
//   ROLE: RUNTIME
//   MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
//   other
// END_MODULE_MAP
export function other() { return 1; }
`,
    );
    // Review-shaped: write example (links M-EXAMPLE) but only anchor M-OTHER
    writePlanWithScope(root, "C-MISS", "active", "<M-OTHER />", ["src/example.ts"]);
    const issues = lintGraceProject(root).issues.filter((i) => i.code === CODE);
    expect(issues.length).toBeGreaterThanOrEqual(1);
    expect(issues[0]!.severity).toBe("error");
    expect(issues[0]!.message).toContain("src/example.ts");
    expect(issues[0]!.message).toMatch(/LINKS|GraphAnchors/);
  });

  it("silent when ObservedWriteScope is only non-src paths (axis: non-ownable)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writePlanWithScope(root, "C-NONSRC", "active", "<M-EXAMPLE />", [
      "README.md",
      "package.json",
      "docs/plans/active/RM-X/plan.md",
      "skills/ngrace/ngrace-cli/SKILL.md",
    ]);
    const issues = lintGraceProject(root).issues.filter((i) => i.code === CODE);
    expect(issues).toEqual([]);
  });

  it("archived mismatch is not evaluated (axis: archive policy)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example module.</Summary><Path>src/example.ts</Path></M-EXAMPLE><M-OTHER><Summary>Other.</Summary><Path>src/other.ts</Path></M-OTHER></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><M-OTHER /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      "src/other.ts",
      `// START_MODULE_CONTRACT
//   PURPOSE: Other module.
//   SCOPE: Fixture.
//   DEPENDS: none
//   LINKS: M-OTHER
//   ROLE: RUNTIME
//   MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
// START_MODULE_MAP
//   other
// END_MODULE_MAP
export function other() { return 1; }
`,
    );
    writePlanWithScope(root, "C-ARCH", "archive", "<M-OTHER />", ["src/example.ts"]);
    const issues = lintGraceProject(root).issues.filter((i) => i.code === CODE);
    expect(issues).toEqual([]);
  });

  it("silent for test files under src/ even without LINKS ownership", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writePlanWithScope(root, "C-TEST", "active", "<M-EXAMPLE />", ["src/example.test.ts"]);
    const issues = lintGraceProject(root).issues.filter((i) => i.code === CODE);
    expect(issues).toEqual([]);
  });
});

describe("ngrace lint --explain CLI (Phase 11 / A76)", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");

  it("exits 0 for exact catalogue codes", () => {
    const result = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--explain", "ledger.invalid-root-tag"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(result.exitCode).toBe(0);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out).toContain("ledger.invalid-root-tag");
    expect(out).toContain("Classification: exact");
    expect(out).not.toMatch(/signals drift/i);
  });

  it("exits 0 for emittable review codes without claiming drift", () => {
    const result = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--explain", "review.scope-outside-write-scope"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(result.exitCode).toBe(0);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out).toContain("Classification: emittable-uncatalogued");
    expect(out).not.toMatch(/signals drift/i);
    expect(out).toContain("Changed File Outside ObservedWriteScope");
  });

  it("exits non-zero for unknown codes and never claims drift", () => {
    const result = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--explain", "not.a.real.code"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(result.exitCode).toBe(1);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out).toContain("Classification: unknown");
    expect(out).toMatch(/does not emit/i);
    expect(out).not.toMatch(/signals drift/i);
  });

  it("exits 0 for the registered-section exact guide", () => {
    const result = spawnLintExplain(["--explain", "change.unregistered-section"]);
    expect(result.exitCode).toBe(0);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out).toContain("change.unregistered-section");
    expect(out).toContain("Classification: exact");
    expect(out).toContain("registered section");
    expect(out).not.toMatch(/signals drift/i);
  });
});

describe("AC-POINTER-JSON CLI (C-EXPLAIN-COVERAGE)", () => {
  it("text lint stdout contains the pointer; --format json stdout of the same project does not", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-POINTER-JSON",
      `<MustNotExist><Value>src/example.ts</Value></MustNotExist>`,
      `<MustExist><Value>src/example.ts</Value></MustExist>`,
    );
    const repoRoot = path.resolve(import.meta.dir, "..");
    const pointerStem = "ngrace lint --explain";
    const pointer = `(${pointerStem} assertion.MustNotExist)`;

    const jsonRun = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    const jsonOut = Buffer.from(jsonRun.stdout).toString("utf8");
    const parsed = JSON.parse(jsonOut) as { tool: string; summary: { errors: number } };
    expect(parsed.tool).toBe("grace-lint");
    expect(parsed.summary.errors).toBeGreaterThanOrEqual(1);
    expect(jsonOut).not.toContain(pointerStem);

    const textRun = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    const textOut = Buffer.from(textRun.stdout).toString("utf8");
    expect(textOut).toContain(pointer);
  });
});

const SHAPE_HEADING_PREFIX = "Shape reference: ";

function spawnLintExplain(args: string[]) {
  const repoRoot = path.resolve(import.meta.dir, "..");
  return Bun.spawnSync({
    cmd: [process.execPath, "./src/grace.ts", "lint", ...args],
    cwd: repoRoot,
    stdout: "pipe",
    stderr: "pipe",
  });
}

describe("AC-EXPLAIN-SHAPES", () => {
  for (const shape of ["change-spec", "assertion"] as const) {
    it(`explains ${shape} as a shape reference with renderer body`, () => {
      const result = spawnLintExplain(["--explain", shape]);
      expect(result.exitCode).toBe(0);
      const out = Buffer.from(result.stdout).toString("utf8");
      const heading = `${SHAPE_HEADING_PREFIX}${shape}`;
      expect(out.split("\n")[0]).toBe(heading);
      expect(out).not.toContain("neo-grace Lint Issue Guide");
      expect(out.slice(heading.length + 1)).toBe(`${renderSchemaShape(shape)}\n`);
    });

    it(`explains ${shape} as JSON kind shape without classification`, () => {
      const result = spawnLintExplain(["--explain", shape, "--format", "json"]);
      expect(result.exitCode).toBe(0);
      const parsed = JSON.parse(Buffer.from(result.stdout).toString("utf8")) as Record<string, unknown>;
      expect(parsed.kind).toBe("shape");
      expect(parsed).not.toHaveProperty("classification");
      expect(parsed.body).toBe(renderSchemaShape(shape));
    });
  }
});

describe("AC-SHAPE-CODE-SPLIT", () => {
  it("explains an undotted unregistered token as unknown shape without Classification", () => {
    const result = spawnLintExplain(["--explain", "graph-module"]);
    expect(result.exitCode).toBe(1);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out).toContain("graph-module");
    expect(out).not.toMatch(/Classification/);
    expect(out).not.toContain("neo-grace Lint Issue Guide");
    for (const name of Object.keys(SCHEMA_SHAPE_REGISTRY)) {
      expect(out).toContain(name);
    }
  });

  it("explains an undotted unregistered token as JSON without classification", () => {
    const result = spawnLintExplain(["--explain", "module-contract", "--format", "json"]);
    expect(result.exitCode).toBe(1);
    const parsed = JSON.parse(Buffer.from(result.stdout).toString("utf8")) as Record<string, unknown>;
    expect(parsed).not.toHaveProperty("classification");
    expect(JSON.stringify(parsed)).toContain("module-contract");
    for (const name of Object.keys(SCHEMA_SHAPE_REGISTRY)) {
      expect(JSON.stringify(parsed)).toContain(name);
    }
  });

  it("keeps today's exact dotted issue-code explain", () => {
    const result = spawnLintExplain(["--explain", "ledger.invalid-root-tag"]);
    expect(result.exitCode).toBe(0);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out.split("\n")[0]).toBe("neo-grace Lint Issue Guide");
    expect(out).toContain("Classification: exact");
    expect(out).toContain("ledger.invalid-root-tag");
  });

  it("keeps today's unknown dotted issue-code explain", () => {
    const result = spawnLintExplain(["--explain", "not.a.real.code"]);
    expect(result.exitCode).toBe(1);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out.split("\n")[0]).toBe("neo-grace Lint Issue Guide");
    expect(out).toContain("Classification: unknown");
  });

  it("AC-EXPLAIN-FALLBACK: an undotted suffix of exactly one registered code names it", () => {
    const result = spawnLintExplain(["--explain", "close-evidence-and-satisfied"]);
    expect(result.exitCode).toBe(1);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out.split("\n")[0]).toBe(
      "Unknown code or shape: close-evidence-and-satisfied; did you mean change.close-evidence-and-satisfied?",
    );
    expect(out).toContain("Registered shapes:");
    expect(out).not.toMatch(/Classification/);
  });

  it("AC-EXPLAIN-FALLBACK: an undotted token with no candidate names neither universe", () => {
    const result = spawnLintExplain(["--explain", "graph-module"]);
    expect(result.exitCode).toBe(1);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out.split("\n")[0]).toBe("Unknown code or shape: graph-module");
    expect(out).not.toContain("did you mean");
    expect(out).not.toContain("candidates:");
  });

  it("AC-EXPLAIN-FALLBACK: an undotted token shared by two codes lists every candidate", () => {
    const result = spawnLintExplain(["--explain", "document-too-large"]);
    expect(result.exitCode).toBe(1);
    const out = Buffer.from(result.stdout).toString("utf8");
    expect(out.split("\n")[0]).toBe(
      "Unknown code or shape: document-too-large; candidates: graph.document-too-large, verification.document-too-large",
    );
  });

  it("AC-EXPLAIN-JSON: undotted-unknown JSON carries suggestedCodes and kind unknown-code-or-shape", () => {
    const one = JSON.parse(
      Buffer.from(spawnLintExplain(["--explain", "close-evidence-and-satisfied", "--format", "json"]).stdout).toString("utf8"),
    ) as Record<string, unknown>;
    expect(one.kind).toBe("unknown-code-or-shape");
    expect(one.suggestedCodes).toEqual(["change.close-evidence-and-satisfied"]);
    expect(one).not.toHaveProperty("classification");
    const none = JSON.parse(
      Buffer.from(spawnLintExplain(["--explain", "graph-module", "--format", "json"]).stdout).toString("utf8"),
    ) as Record<string, unknown>;
    expect(none.suggestedCodes).toEqual([]);
  });

  it("does not change lint-result JSON schemaVersion", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const result = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--format", "json"],
      cwd: path.resolve(import.meta.dir, ".."),
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(result.exitCode).toBe(0);
    const parsed = JSON.parse(Buffer.from(result.stdout).toString("utf8")) as { schemaVersion: string };
    expect(parsed.schemaVersion).toBe("1.0.0");
  });

  it("leaves docs markdown outside the lint artifact universe", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeProjectFile(root, "docs/schema-reference.md", "# not an xml artifact\n");
    const result = lintGraceProject(root);
    expect(result.issues.every((issue) => !issue.file.endsWith(".md"))).toBe(true);
    expect(result.summary.errors).toBe(0);
  });
});

function javaGovernedBody(mapMode: "EXPORTS" | "SUMMARY") {
  return new GraceProjectBuilder(createTempProject("grace-path-no-adapter-"))
    .module({ id: "M-JAVA", path: "src/Main.java", summary: "Unbacked java Path." })
    .governedFile({
      path: "src/Main.java",
      purpose: "Java fixture",
      links: ["M-JAVA"],
      mapMode,
      mapEntries: mapMode === "EXPORTS" ? ["Main"] : undefined,
      body: "public class Main {}\n",
    });
}

describe("graph.path-no-adapter", () => {
  it("Case A: EXPORTS+LINKS on an unbacked ext emits analysis.no-adapter and skips this code", () => {
    const root = javaGovernedBody("EXPORTS").write();
    const result = lintGraceProject(root);
    expect(result.issues.some((issue) => issue.code === "analysis.no-adapter")).toBe(true);
    expect(result.issues.filter((issue) => issue.code === "graph.path-no-adapter")).toHaveLength(0);
  });

  it("Case B: unmarked Path file emits this code and graph.module-without-linked-files", () => {
    const root = new GraceProjectBuilder(createTempProject("grace-path-no-adapter-"))
      .module({ id: "M-JAVA", path: "src/Main.java", summary: "Unmarked java Path." })
      .file("src/Main.java", "public class Main {}\n")
      .write();
    const result = lintGraceProject(root);
    const pathIssues = result.issues.filter((issue) => issue.code === "graph.path-no-adapter");
    expect(pathIssues).toHaveLength(1);
    expect(pathIssues[0]?.severity).toBe("warning");
    expect(pathIssues[0]?.file).toContain(`${ARTIFACT_DIR}/graph/main.xml`);
    expect(pathIssues[0]?.message).toContain("M-JAVA");
    expect(pathIssues[0]?.message).toContain("src/Main.java");
    expect(pathIssues[0]?.message).toContain(".java");
    expect(pathIssues[0]?.message).toContain("contracts and health work");
    expect(pathIssues[0]?.message).toContain("MODULE_MAP parity unverified");
    expect(result.issues.some((issue) => issue.code === "graph.module-without-linked-files")).toBe(true);
  });

  it("Case C: SUMMARY+LINKS unacknowledged emits this code and not analysis.no-adapter", () => {
    const root = javaGovernedBody("SUMMARY").write();
    const result = lintGraceProject(root);
    expect(result.issues.some((issue) => issue.code === "analysis.no-adapter")).toBe(false);
    const pathIssues = result.issues.filter((issue) => issue.code === "graph.path-no-adapter");
    expect(pathIssues).toHaveLength(1);
    expect(pathIssues[0]?.severity).toBe("warning");
    expect(pathIssues[0]?.file).toContain(`${ARTIFACT_DIR}/graph/main.xml`);
    expect(pathIssues[0]?.message).toContain("M-JAVA");
    expect(pathIssues[0]?.message).toContain("src/Main.java");
    expect(pathIssues[0]?.message).toContain(".java");
    expect(pathIssues[0]?.message).toContain("contracts and health work");
    expect(pathIssues[0]?.message).toContain("MODULE_MAP parity unverified");
  });

  it("Case D: missing Path file emits this code and graph.module-without-linked-files", () => {
    const root = new GraceProjectBuilder(createTempProject("grace-path-no-adapter-"))
      .module({ id: "M-JAVA", path: "src/Main.java", summary: "Missing java Path." })
      .write();
    const result = lintGraceProject(root);
    expect(result.issues.some((issue) => issue.code === "graph.path-no-adapter")).toBe(true);
    expect(result.issues.some((issue) => issue.code === "graph.module-without-linked-files")).toBe(true);
  });

  it("Case E: adapter-backed .ts Path emits neither code", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const result = lintGraceProject(root);
    expect(result.issues.some((issue) => issue.code === "analysis.no-adapter")).toBe(false);
    expect(result.issues.some((issue) => issue.code === "graph.path-no-adapter")).toBe(false);
  });

  it("unverifiedLanguages for the Path extension suppresses this code", () => {
    const root = javaGovernedBody("SUMMARY")
      .file(".ngrace-lint.json", `${JSON.stringify({ unverifiedLanguages: [".java"] })}\n`)
      .write();
    const result = lintGraceProject(root);
    expect(result.issues.some((issue) => issue.code === "analysis.no-adapter")).toBe(false);
    expect(result.issues.some((issue) => issue.code === "graph.path-no-adapter")).toBe(false);
  });

  it("skips this code when the module has no Path", () => {
    const root = new GraceProjectBuilder(createTempProject("grace-path-no-adapter-"))
      .module({ id: "M-NOPATH", summary: "No Path module." })
      .write();
    const result = lintGraceProject(root);
    expect(result.issues.some((issue) => issue.code === "graph.path-no-adapter")).toBe(false);
  });
});

function spawnLintJson(root: string, args: string[]) {
  const repoRoot = path.resolve(import.meta.dir, "..");
  return Bun.spawnSync({
    cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--format", "json", ...args],
    cwd: repoRoot,
    stdout: "pipe",
    stderr: "pipe",
  });
}

function parseEnvelope(result: ReturnType<typeof Bun.spawnSync>) {
  const stdout = Buffer.from(result.stdout ?? "").toString("utf8");
  return JSON.parse(stdout) as {
    ok?: boolean;
    error?: { code?: string; message?: string };
    tool?: string;
    assertionMode?: string;
  };
}

function writeSpecOnlyDraft(root: string, changeId: string) {
  writeMinimalNgraceProject(root);
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/changes/active/${changeId}/spec.xml`,
    `<NgraceChangeSpec graceVersion="1.0" status="draft"><${changeId}><Summary>Draft spec only.</Summary><Goals><Goal>Preview as-state.</Goal></Goals><Constraints><Constraint>Keep fixture valid.</Constraint></Constraints><NonGoals><NonGoal>Unrelated.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>Draft is selectable.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></${changeId}></NgraceChangeSpec>`,
  );
}

describe("argv token as vocabulary", () => {
  it("declares as as a string option on lintCommand", () => {
    expect(lintCommand.args).toHaveProperty("as");
    expect((lintCommand.args as { as?: { type?: string } }).as?.type).toBe("string");
  });

  it("refuses a LintAssertionMode token and names argv token assertions", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "target", "--change", "C-AS-VOCAB"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
    const assertionMessage = parsed.error?.message ?? "";
    expect(assertionMessage).toContain("assertions");
    expect(assertionMessage).toMatch(/target/);
  });

  it("refuses a live gate name and names the gate verb", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "approve", "--change", "C-AS-VOCAB"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
    expect(parsed.error?.message).toMatch(/gate/i);
    expect(parsed.error?.message).toMatch(/approve/);
  });

  it("refuses as without change", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "approved"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
    expect(parsed.error?.message).toMatch(/change/i);
  });

  it("refuses a non-canonical change id", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "approved", "--change", "not-a-change"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
  });

  it("refuses a missing bundle as not-found or invalid-arguments", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "approved", "--change", "C-MISSING"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(["not-found", "invalid-arguments"]).toContain(parsed.error?.code ?? "");
  });

  it("refuses as combined with runCommands", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "approved", "--change", "C-AS-VOCAB", "--run-commands"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
  });

  it("refuses as combined with explain", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "approved", "--change", "C-AS-VOCAB", "--explain", "change.missing-status"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
  });

  it("refuses as combined with assertions other than current", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "approved", "--change", "C-AS-VOCAB", "--assertions", "target"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
  });

  it("refuses an unknown status and names CHANGE_STATUSES members", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    const result = spawnLintJson(root, ["--as", "gobbledygook", "--change", "C-AS-VOCAB"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.error?.code).toBe("invalid-arguments");
    for (const status of CHANGE_STATUSES) {
      expect(parsed.error?.message).toContain(status);
    }
  });

  it("accepts each CHANGE_STATUSES member with a spec-only draft and does not refuse compose flags", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    for (const status of CHANGE_STATUSES) {
      const result = spawnLintJson(root, [
        "--as",
        status,
        "--change",
        "C-AS-VOCAB",
        "--fail-on",
        "never",
        "--remediate",
        "--parallel-preflight",
      ]);
      const parsed = parseEnvelope(result);
      expect(parsed.ok).not.toBe(false);
      expect(parsed.tool).toBe("grace-lint");
    }
  });

  it("selects a spec-only draft and an archived bundle", () => {
    const root = createProject();
    writeSpecOnlyDraft(root, "C-AS-VOCAB");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-ARCHIVED/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="applied"><C-ARCHIVED><Summary>Archived spec.</Summary><Goals><Goal>Stay archived.</Goal></Goals><Constraints><Constraint>Keep fixture valid.</Constraint></Constraints><NonGoals><NonGoal>Unrelated.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>Selectable.</Criterion></AcceptanceCriteria><AffectedAreas><M-EXAMPLE /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></C-ARCHIVED></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/archive/C-ARCHIVED/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="applied"><C-ARCHIVED><IntentSummary>Archived plan.</IntentSummary><BaselineAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></BaselineAssertions><TargetAssertions><MustExist><Value>M-EXAMPLE</Value></MustExist></TargetAssertions><DurableScope><GraphAnchors><M-EXAMPLE /></GraphAnchors></DurableScope><ObservedWriteScope><File>src/example.ts</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Done</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>Done.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></C-ARCHIVED></NgraceChangePlan>`,
    );
    const draft = spawnLintJson(root, ["--as", "approved", "--change", "C-AS-VOCAB", "--fail-on", "never"]);
    expect(parseEnvelope(draft).tool).toBe("grace-lint");
    expect(parseEnvelope(draft).ok).not.toBe(false);
    const archived = spawnLintJson(root, ["--as", "applied", "--change", "C-ARCHIVED", "--fail-on", "never"]);
    expect(parseEnvelope(archived).tool).toBe("grace-lint");
    expect(parseEnvelope(archived).ok).not.toBe(false);
  });
});

function digestIfPresent(filePath: string): string {
  if (!existsSync(filePath)) return "";
  return createHash("sha256").update(readFileSync(filePath)).digest("hex");
}

describe("as-state pure preview", () => {
  it("overlays superseded onto a draft spec and emits change.superseded-missing-replacement", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "draft",
    });
    const result = lintGraceProject(root, { asStatus: "superseded", changeId: "C-AS-PREV" });
    expect(result.issues.some((issue) => issue.code === "change.superseded-missing-replacement")).toBe(true);
  });

  it("overlays approved onto a draft spec+plan and drops change.plan-requires-approved-spec", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    const current = lintGraceProject(root);
    expect(current.issues.some((issue) => issue.code === "change.plan-requires-approved-spec")).toBe(true);
    const preview = lintGraceProject(root, { asStatus: "approved", changeId: "C-AS-PREV" });
    expect(preview.issues.some((issue) => issue.code === "change.plan-requires-approved-spec")).toBe(false);
  });

  it("surfaces evaluateApproveGate artifact issues at approved", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "draft",
    });
    const specPath = path.join(root, ARTIFACT_DIR, "changes", "active", "C-AS-PREV", "spec.xml");
    const spec = readFileSync(specPath, "utf8").replace(
      "</C-AS-PREV>",
      "<Clarifications><Clarification><IC-EXAMPLE /></Clarification></Clarifications></C-AS-PREV>",
    );
    writeFileSync(specPath, spec);
    const result = lintGraceProject(root, { asStatus: "approved", changeId: "C-AS-PREV" });
    const issue = result.issues.find((item) => item.code === "gate.approve.clarification-unresolved");
    expect(issue).toBeDefined();
    expect(issue?.file.replaceAll("\\", "/")).toContain(".ngrace/changes/active/C-AS-PREV/spec.xml");
  });

  it("surfaces apply artifact-pure plan-present at applied without calling the archive gate", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "draft",
    });
    const result = lintGraceProject(root, { asStatus: "applied", changeId: "C-AS-PREV" });
    expect(result.issues.some((issue) => issue.code === "gate.apply.no-plan")).toBe(true);
    expect(result.issues.some((issue) => issue.code.startsWith("gate.archive."))).toBe(false);
  });

  it("does not write spec, plan, or ledger bytes", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "active", "C-AS-PREV");
    const before = ["spec.xml", "plan.xml", "run-ledger.xml"].map((name) => digestIfPresent(path.join(bundle, name)));
    lintGraceProject(root, { asStatus: "approved", changeId: "C-AS-PREV" });
    const after = ["spec.xml", "plan.xml", "run-ledger.xml"].map((name) => digestIfPresent(path.join(bundle, name)));
    expect(after).toEqual(before);
  });

  it("emits change.applied-plan-missing at applied when plan.xml carries no previewable status", () => {
    // The overlay leaves an unparseable plan.xml rootless, so it carries no status into the
    // preview. grammar.ts:1319 fires on exactly that shape, so the preview must fire too.
    const real = createProject();
    writeMinimalNgraceProject(real);
    writeChangeBundleFixture(real, {
      changeId: "C-AS-PREV",
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    writeFileSync(
      path.join(real, ARTIFACT_DIR, "changes", "archive", "C-AS-PREV", "plan.xml"),
      '<NgraceChangePlan graceVersion="1.0" status="applied"><C-AS-PREV>',
    );
    expect(lintGraceProject(real).issues.some((issue) => issue.code === "change.applied-plan-missing")).toBe(true);

    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
    });
    writeFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", "C-AS-PREV", "plan.xml"),
      '<NgraceChangePlan graceVersion="1.0" status="approved"><C-AS-PREV>',
    );
    const preview = lintGraceProject(root, { asStatus: "applied", changeId: "C-AS-PREV" });
    expect(preview.issues.some((issue) => issue.code === "change.applied-plan-missing")).toBe(true);
  });

  it("stays silent on change.applied-plan-missing at applied when plan.xml is well formed", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
    });
    const preview = lintGraceProject(root, { asStatus: "applied", changeId: "C-AS-PREV" });
    expect(preview.issues.some((issue) => issue.code === "change.applied-plan-missing")).toBe(false);
  });

  it("does not give design-context a status", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-AS-PREV",
      location: "active",
      specStatus: "draft",
      designContext:
        '<NgraceChangeDesignContext graceVersion="1.0"><Change>C-AS-PREV</Change><Rationale>Fixture.</Rationale></NgraceChangeDesignContext>',
    });
    const result = lintGraceProject(root, { asStatus: "approved", changeId: "C-AS-PREV" });
    expect(result.issues.some((issue) => issue.code === "design-context.forbidden-status")).toBe(false);
  });
});

describe("undeclared flag tokens on lint", () => {
  it("lint with an undeclared flag is invalid-arguments, not a LintResult", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const result = spawnLintJson(root, ["--not-a-real-flag"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.tool).toBeUndefined();
    expect(parsed.error?.code).toBe("invalid-arguments");
    expect(parsed.error?.message).toContain("--not-a-real-flag");
    expect(parsed.error?.message).not.toMatch(/\u001B/);
  });

  it("lint with a transposed assertions token is invalid-arguments, not a LintResult", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const result = spawnLintJson(root, ["--assertionss", "current"]);
    const parsed = parseEnvelope(result);
    expect(result.exitCode).not.toBe(0);
    expect(parsed.ok).toBe(false);
    expect(parsed.tool).toBeUndefined();
    expect(parsed.error?.code).toBe("invalid-arguments");
    expect(parsed.error?.message).toContain("--assertionss");
    expect(parsed.assertionMode).toBeUndefined();
  });
});



describe("C-CI-LINT-AND-PLAN-SHAPE-1-3526D6F0 assertions-off mode", () => {
  it("accepts --assertions none and evaluates no active baseline", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeApprovedChange(
      root,
      "C-NONE-PROBE",
      `<MustNotExist><Value>src/example.ts</Value></MustNotExist>`,
      `<MustVerify><Module>M-MISSING</Module></MustVerify>`,
    );
    const current = lintGraceProject(root, { assertionMode: "current" });
    expect(current.issues.some((issue) => issue.code === "assertion.MustNotExist")).toBe(true);
    const none = lintGraceProject(root, { assertionMode: "none" });
    expect(none.issues.filter((issue) => issue.code.startsWith("assertion.") && issue.code !== "assertion.command-not-evaluated")).toHaveLength(0);
    expect(none.assertionMode).toBe("none");
  });

  it("catches a planted MODULE_MAP escape under --assertions none", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const file = path.join(root, "src/example.ts");
    writeFileSync(file, `${readFileSync(file, "utf8")}\nexport const escapeExport = 1;\n`);
    const none = lintGraceProject(root, { assertionMode: "none" });
    expect(none.issues.some((issue) => issue.code === "markup.module-map-mismatch")).toBe(true);
  });

  it("accepts --assertions none through the CLI and keeps current the default", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const repoRoot = path.resolve(import.meta.dir, "..");
    const cli = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--assertions", "none", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(cli.exitCode).toBe(0);
    expect(JSON.parse(Buffer.from(cli.stdout).toString("utf8")).assertionMode).toBe("none");
    expect(lintGraceProject(root).assertionMode).toBe("current");
  });

  it("refuses an unknown mode naming all five accepted modes", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const repoRoot = path.resolve(import.meta.dir, "..");
    const cli = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--assertions", "bogus", "--format", "json"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(cli.exitCode).not.toBe(0);
    const output = Buffer.from(cli.stderr).toString("utf8") + Buffer.from(cli.stdout).toString("utf8");
    for (const mode of ["current", "baseline", "target", "final", "none"]) {
      expect(output).toContain(mode);
    }
  });
});

describe("C-CI-LINT-AND-PLAN-SHAPE-1-3526D6F0 anchor-miss existence branch", () => {
  function writeAnchorProbe(root: string, changeId: string, anchor: string, file: string) {
    const bundle = `${ARTIFACT_DIR}/changes/active/${changeId}`;
    writeProjectFile(
      root,
      `${bundle}/spec.xml`,
      `<NgraceChangeSpec graceVersion="1.0" status="approved"><${changeId}><Summary>Anchor probe.</Summary><Goals><Goal>Exercise the anchor branch.</Goal></Goals><Constraints><Constraint>Preserve fixture validity.</Constraint></Constraints><NonGoals><NonGoal>Unrelated behavior.</NonGoal></NonGoals><AcceptanceCriteria><Criterion>Anchor ownership is checked.</Criterion></AcceptanceCriteria><AffectedAreas><${anchor} /></AffectedAreas><VerificationIntent><ExpectedCommand>bun test</ExpectedCommand></VerificationIntent></${changeId}></NgraceChangeSpec>`,
    );
    writeProjectFile(
      root,
      `${bundle}/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><${changeId}><IntentSummary>Exercise the anchor branch.</IntentSummary><BaselineAssertions><MustExist><Value>${anchor}</Value></MustExist></BaselineAssertions><TargetAssertions><MustExist><Value>${anchor}</Value></MustExist></TargetAssertions><DurableScope><GraphAnchors><${anchor} /></GraphAnchors></DurableScope><ObservedWriteScope><File>${file}</File></ObservedWriteScope><ImplementationPlan><T-001><Title>Anchor probe</Title><DependsOn></DependsOn><AcceptanceCriteria><Criterion>Anchor branch exercised.</Criterion></AcceptanceCriteria><Verification><Command>bun test</Command></Verification></T-001></ImplementationPlan></${changeId}></NgraceChangePlan>`,
    );
  }

  it("warns pending for a declared-but-absent path and errors only once the file exists unowned", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeAnchorProbe(root, "C-ABSENT", "M-EXAMPLE", "src/absent-module.ts");
    const absent = lintGraceProject(root, { assertionMode: "none" });
    expect(absent.issues.some((issue) => issue.code === "change.graph-anchors-pending-file" && issue.severity === "warning")).toBe(true);
    expect(absent.issues.some((issue) => issue.code === "change.graph-anchors-miss-write-scope")).toBe(false);

    const root2 = createProject();
    writeMinimalNgraceProject(root2);
    writeProjectFile(root2, "src/unowned-probe.ts", "export const unowned = 1;\n");
    writeAnchorProbe(root2, "C-UNOWNED", "M-EXAMPLE", "src/unowned-probe.ts");
    const unowned = lintGraceProject(root2, { assertionMode: "none" });
    expect(unowned.issues.some((issue) => issue.code === "change.graph-anchors-miss-write-scope" && issue.severity === "error")).toBe(true);
    expect(unowned.issues.some((issue) => issue.code === "change.graph-anchors-pending-file")).toBe(false);
  });

  it("drives both fail-on directions through the CLI for an absent declared path", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeAnchorProbe(root, "C-ABSENT", "M-EXAMPLE", "src/absent-module.ts");
    const repoRoot = path.resolve(import.meta.dir, "..");
    const run = (failOn: string) =>
      Bun.spawnSync({
        cmd: [process.execPath, "./src/grace.ts", "lint", "--path", root, "--assertions", "none", "--fail-on", failOn],
        cwd: repoRoot,
        stdout: "pipe",
        stderr: "pipe",
      });
    expect(run("errors").exitCode).toBe(0);
    expect(run("warnings").exitCode).not.toBe(0);
  });

  it("carries an exact guide for change.graph-anchors-pending-file", () => {
    const guide = getLintIssueGuide("change.graph-anchors-pending-file");
    expect(guide).toBeDefined();
    expect(guide!.title.length).toBeGreaterThan(0);
    expect(guide!.explanation).toContain("change.graph-anchors-miss-write-scope");
  });
});
