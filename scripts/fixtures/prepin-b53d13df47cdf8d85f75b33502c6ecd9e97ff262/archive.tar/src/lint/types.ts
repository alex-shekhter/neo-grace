// START_MODULE_CONTRACT
//   PURPOSE: Lint shared types
//   SCOPE: Lint result, issue, config, and analysis type surface
//   DEPENDS: none
//   LINKS: M-LINT-TYPES
//   ROLE: TYPES
//   MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
//
// START_MODULE_MAP
//   AS_STATE_PURITY_CLASSES
//   AnalysisCoverage
//   AnalysisCoverageEntry
//   AsStatePurityClass
//   DEFAULT_DOCUMENT_ANCHOR_LIMIT
//   DEFAULT_DOCUMENT_BYTE_LIMIT
//   GateFailOn
//   GraceLintConfig
//   IssueClass
//   LanguageAdapter
//   LanguageAnalysis
//   LanguageRuntimeMissingError
//   LintAssertionMode
//   LintIssue
//   LintOptions
//   LintProfile
//   LintResult
//   LintSeverity
//   MapMode
//   MarkupSection
//   ModuleContractInfo
//   ModuleMapItem
//   ModuleRole
// END_MODULE_MAP
/** Closed inventory of as-state purity classes. Classifier must assign every member. */
export const AS_STATE_PURITY_CLASSES = ["artifact", "ledger-dependent", "verification-runtime"] as const;

export type AsStatePurityClass = (typeof AS_STATE_PURITY_CLASSES)[number];

export type LintSeverity = "error" | "warning";

export type LintProfile = "standard";

/** Selected assertion section evaluated by ngrace lint. */
export type LintAssertionMode = "current" | "baseline" | "target" | "final" | "none";

export type ModuleRole = "RUNTIME" | "TEST" | "BARREL" | "CONFIG" | "TYPES" | "SCRIPT";
export type MapMode = "EXPORTS" | "LOCALS" | "SUMMARY" | "NONE";

/**
 * Classification of a lint issue. Absent field means defect (additive default).
 * Absence codes are those for which no answer was produced, with the reason in `code`.
 */
export type IssueClass = "defect" | "absence";

export type LintIssue = {
  severity: LintSeverity;
  code: string;
  file: string;
  line?: number;
  message: string;
  title?: string;
  explanation?: string;
  remediation?: string[];
  /** Optional; absent means defect. Attached from exact catalog entries (route 2). */
  issueClass?: IssueClass;
};

export type AnalysisCoverageEntry = {
  extension: string;
  files: number;
  adapterId?: string;
};

export type AnalysisCoverage = {
  adapterBacked: AnalysisCoverageEntry[];
  unverified: AnalysisCoverageEntry[];
  governedFiles: number;
};

export type LintResult = {
  schemaVersion: string;
  tool: "grace-lint";
  generatedAt: string;
  root: string;
  profile: LintProfile;
  assertionMode: LintAssertionMode;
  changeId?: string;
  commandsEnabled: boolean;
  filesChecked: number;
  governedFiles: number;
  xmlFilesChecked: number;
  issues: LintIssue[];
  summary: {
    issues: number;
    errors: number;
    warnings: number;
    asState?: {
      status: string;
      evaluatedRuleClasses: number;
      unevaluableRuleClasses: number;
      unevaluable: string[];
    };
  };
  analysisCoverage: AnalysisCoverage;
};

export type LintOptions = {
  profile?: LintProfile;
  assertionMode?: LintAssertionMode;
  changeId?: string;
  runCommands?: boolean;
  parallelPreflight?: boolean;
  asStatus?: string;
};

/** Project policy for whether host-capability-missing (and similar) blocks apply (D11 / A29.5). */
export type GateFailOn = "errors" | "warnings" | "never";

export type GraceLintConfig = {
  ignoredDirs?: string[];
  /** Extensions that deliberately skip analysis.no-adapter, e.g. [".rs", ".go"]. */
  unverifiedLanguages?: string[];
  /**
   * Additional extensions GRACE should govern, e.g. [".ex", ".exs"] for a language with
   * no built-in adapter. Additive to the built-in set; it cannot remove governance.
   * Governed-without-adapter files still emit `analysis.no-adapter` unless the extension
   * also appears in `unverifiedLanguages`.
   */
  codeExtensions?: string[];
  /** Max anchors per graph/verification document before warning (default 50). */
  documentAnchorLimit?: number;
  /** Max bytes per graph/verification document before warning (default 30720 = 30 KB). */
  documentByteLimit?: number;
  /**
   * Project declaration: whether a recorded host-capability-missing review verdict is fatal
   * at the apply gate (D11 / A29.5). Default when omitted: errors (strict).
   * Distinct from per-command --fail-on on lint/status.
   */
  gateFailOn?: GateFailOn;
  /**
   * Additive command-prefix escape for CloseEvidence discriminating shapes.
   * Each entry is a flattened command prefix. The list cannot remove a default.
   */
  closeEvidenceCommandShapes?: string[];
};

/** Defaults for document-size pressure warnings (Phase 8 / G-16). */
export const DEFAULT_DOCUMENT_ANCHOR_LIMIT = 50;
export const DEFAULT_DOCUMENT_BYTE_LIMIT = 30 * 1024;

export type MarkupSection = {
  content: string;
  startLine: number;
  endLine: number;
};

export type ModuleContractInfo = {
  fields: Record<string, string>;
  purpose?: string;
  scope?: string;
  depends?: string;
  links?: string;
  role?: ModuleRole;
  mapMode?: MapMode;
};

export type ModuleMapItem = {
  label: string;
  symbolName?: string;
  line: number;
};

export type LanguageAnalysis = {
  adapterId: string;
  exports: Set<string>;
  valueExports: Set<string>;
  typeExports: Set<string>;
  localSymbols: Set<string>;
  exportConfidence: "exact" | "heuristic";
  hasDefaultExport: boolean;
  hasWildcardReExport: boolean;
  hasMainEntrypoint: boolean;
  directReExportCount: number;
  localExportCount: number;
  localImplementationCount: number;
  usesTestFramework: boolean;
};

export type LanguageAdapter = {
  id: string;
  supports(filePath: string): boolean;
  analyze(filePath: string, text: string): LanguageAnalysis;
};

/** Actionable failure raised when an optional language runtime is unavailable. */
export class LanguageRuntimeMissingError extends Error {
  readonly adapterId: string;
  readonly runtimeCandidates: string[];

  constructor(adapterId: string, runtimeCandidates: string[], message: string) {
    super(message);
    this.name = "LanguageRuntimeMissingError";
    this.adapterId = adapterId;
    this.runtimeCandidates = runtimeCandidates;
  }
}
