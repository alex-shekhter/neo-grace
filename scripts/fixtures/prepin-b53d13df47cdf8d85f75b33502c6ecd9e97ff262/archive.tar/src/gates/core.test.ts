import { afterEach, describe, expect, it } from "bun:test";
import { createHash } from "node:crypto";
import { existsSync, lstatSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, readlinkSync, renameSync, rmSync, statSync, symlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

import { validateNgraceProject } from "../artifact/grammar";
import { ARTIFACT_DIR } from "../artifact/paths";
import { writeChangeBundleFixture, writeMinimalNgraceProject } from "../artifact/test-fixtures";
import { allGateCodes, GATE_CATALOG, isGateIssueCode } from "./catalog";
import {
  evaluateApproveGate,
  evaluateApplyGate,
  evaluateApplyGateArtifact,
  evaluateArchiveGate,
  evaluateAttemptGate,
  evaluateAttemptOnBundle,
  evaluateGate,
  evaluationToDecision,
  resolveProjectGateFailOn,
} from "./core";
import {
  listGateDecisions,
  listReviewVerdicts,
  readGateDecisions,
  readLatestReviewVerdict,
  readLedgerVerdictsSurface,
  readLedgerWrapper,
  readPermittingDecision,
  recordGateDecision,
  recordReviewVerdict,
  supersedeChangeBundle,
  stampApproveArtifact,
  applyChangeBundle,
  computeVerdictSnapshotDigest,
  readAmendmentInstrument,
  type ReviewVerdictRecord,
} from "./ledger";
import { GraceCommandError } from "../query/errors";
import { advanceCursor, appendCommandRunEvent, discardAndFoldEpoch, foldEpoch, listLedgerEvents, listLooseEvents, pauseCursor, recordAttempt, recordCalibrationRestatement, recordVerificationUnavailable, recoverCursor, regenerateCursor, resumeCursor, showCursor, withCandidateLock } from "../grace-cursor";
import { mintResolvedBundle, pauseCandidatePublicationForTests, resolveSpecMint, type ResolvedSpecMint } from "../grace-generate";
import { formatGateEvaluation, gateCommand } from "./command";
import { runReview } from "../review/core";

const tempRoots: string[] = [];
const REPO_ROOT = path.resolve(import.meta.dir, "../..");
const GRACE_BIN = path.join(REPO_ROOT, "src/grace.ts");

function tempProject(): string {
  const root = mkdtempSync(path.join(os.tmpdir(), "ngrace-gate-"));
  tempRoots.push(root);
  writeMinimalNgraceProject(root);
  return root;
}

function libraryBoundPass(
  changeId: string,
  extra: Partial<Omit<ReviewVerdictRecord, "outcome">> = {},
): ReviewVerdictRecord {
  const findings = extra.findings ?? [];
  return {
    ...extra,
    outcome: "pass",
    findings,
    snapshotDigest: extra.snapshotDigest ?? computeVerdictSnapshotDigest(changeId, findings),
  };
}

function ackFindingCliArgs(root: string, changeId: string): string[] {
  return runReview(root, { changeId }).findings.flatMap((finding) => ["--ack-finding", finding.findingId]);
}

afterEach(() => {
  while (tempRoots.length > 0) {
    const root = tempRoots.pop()!;
    rmSync(root, { recursive: true, force: true });
  }
});

function activeBundle(root: string, changeId = "C-GATE") {
  writeChangeBundleFixture(root, {
    changeId,
    location: "active",
    specStatus: "approved",
    planStatus: "approved",
  });
  return path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
}

function runGateCli(args: string[], cwd = REPO_ROOT) {
  return spawnSync("bun", ["run", GRACE_BIN, "gate", ...args], {
    cwd,
    encoding: "utf8",
    env: process.env,
  });
}

describe("gate catalog (D14)", () => {
  it("every catalog code is gate.* and none is a bare lint path", () => {
    const codes = allGateCodes();
    expect(codes.length).toBeGreaterThan(0);
    for (const code of codes) {
      expect(isGateIssueCode(code)).toBe(true);
      expect(code.startsWith("gate.")).toBe(true);
    }
    expect(codes).toContain("gate.apply.invalid-verdict");
  });
});

describe("ledger Verdicts and Decisions (A30)", () => {
  it("records verdict and decision without creating run/ files", () => {
    const root = tempProject();
    activeBundle(root);
    recordReviewVerdict(root, "C-GATE", { outcome: "unable-to-determine", reason: "host-capability-missing" });
    recordGateDecision(root, "C-GATE", {
      gate: "apply",
      decision: "permit",
      requirements: [{ id: "review-verdict", required: true, present: true, blocking: false }],
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "active", "C-GATE");
    expect(existsSync(path.join(bundle, "run"))).toBe(false);
    expect(listLooseEvents(bundle)).toHaveLength(0);
    expect(listReviewVerdicts(root, "C-GATE")).toHaveLength(1);
    expect(listGateDecisions(root, "C-GATE")).toHaveLength(1);
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(ledger).toContain("<Verdicts>");
    expect(ledger).toContain("<Decisions>");
    expect(ledger).not.toContain("Epoch-");
  });

  it("Phase 10: stores scope and classification; unscoped never invents scope (corr 182)", () => {
    const root = tempProject();
    activeBundle(root);
    recordReviewVerdict(root, "C-GATE", {
      outcome: "fail",
      scope: "wave",
      wave: "1",
      classification: "plan",
      constituentTasksPassed: true,
    });
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const all = listReviewVerdicts(root, "C-GATE");
    expect(all[0]?.scope).toBe("wave");
    expect(all[0]?.classification).toBe("plan");
    expect(all[0]?.constituentTasksPassed).toBe(true);
    // Second verdict unscoped — must not gain a default scope on read.
    expect(all[1]?.scope).toBeUndefined();
    expect(all[1]?.outcome).toBe("pass");
    const ledger = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", "C-GATE", "run-ledger.xml"),
      "utf8",
    );
    expect(ledger).toContain('scope="wave"');
    expect(ledger).toContain('classification="plan"');
    // Unscoped entry has outcome only — no scope= invented (self-closing or open).
    expect(ledger).toMatch(/<Verdict outcome="pass"[ />]/);
    expect(ledger).not.toMatch(/<Verdict outcome="pass"[^>]*scope=/);
  });

  it("corr 184: constituentTasksPassed outside wave+fail is rejected, not dropped", () => {
    const root = tempProject();
    activeBundle(root);
    expect(() =>
      recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE", {
        scope: "task",
        task: "T-001",
        constituentTasksPassed: true,
      })),
    ).toThrow(/constituentTasksPassed applies only to wave-scoped fail verdicts/);
    // Silent path would have stored a pass with no ctp — ensure nothing was written.
    expect(listReviewVerdicts(root, "C-GATE")).toHaveLength(0);
  });

  it("corr 185: gates still fail closed on truncated ledger (no throw, no permit)", () => {
    const root = tempProject();
    activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const ledgerPath = path.join(root, ARTIFACT_DIR, "changes", "active", "C-GATE", "run-ledger.xml");
    const full = readFileSync(ledgerPath, "utf8");
    writeFileSync(ledgerPath, full.slice(0, Math.floor(full.length / 2)));

    // Must not throw — gate evaluates and refuses (fail closed).
    const evaluation = evaluateGate(root, "C-GATE", "apply");
    expect(evaluation.decision).toBe("refuse");
    expect(evaluation.requirements.some((r) => r.id === "review-verdict" && r.blocking)).toBe(true);
    // Honest classification: unreadable is invalid, not collapsed empty list.
    // listReviewVerdicts throws on invalid (existing contract); gate path stays refuse.
    expect(readLatestReviewVerdict(root, "C-GATE").state).toBe("invalid");
    expect(() => listReviewVerdicts(root, "C-GATE")).toThrow(/xml\.parse|unreadable|Invalid/i);
  });

  it("survives fold of a later epoch without losing sections (A30 probe)", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    recordGateDecision(root, "C-GATE", {
      gate: "approve",
      decision: "permit",
      requirements: [],
    });
    advanceCursor(root, "C-GATE", {
      task: "T-001",
      openEpoch: true,
      worker: "w0",
      from: 1,
      to: 10,
    });
    advanceCursor(root, "C-GATE", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-GATE");
    expect(listLooseEvents(bundle)).toHaveLength(0);
    expect(listReviewVerdicts(root, "C-GATE").map((v) => v.outcome)).toEqual(["pass"]);
    expect(listGateDecisions(root, "C-GATE").map((d) => d.gate)).toEqual(["approve"]);
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(ledger).toContain("<Epoch-1");
    expect(ledger).toContain("<Verdicts>");
    expect(ledger).toContain("<Decisions>");
  });

  it("absent Verdicts is not a pass — apply refuses (D5)", () => {
    const root = tempProject();
    activeBundle(root);
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.no-verdict")).toBe(true);
  });
});

describe("correction 62 — invocable verdict writer", () => {
  it("ngrace gate verdict records a Verdict the apply gate can consume", () => {
    const root = tempProject();
    activeBundle(root);
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("refuse");

    const recorded = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "pass", "--path", root, "--format", "json", ...ackFindingCliArgs(root, "C-GATE")],
      root,
    );
    expect(recorded.status).toBe(0);
    const body = JSON.parse(recorded.stdout);
    expect(body.ok).toBe(true);
    expect(body.verdict.outcome).toBe("pass");
    expect(listReviewVerdicts(root, "C-GATE")).toHaveLength(1);

    const applied = evaluateApplyGate(root, "C-GATE");
    expect(applied.decision).toBe("permit");
    expect(applied.verdict?.outcome).toBe("pass");
  });

  it("gate subCommands includes verdict (counterpart Writers surface)", () => {
    const keys = Object.keys(gateCommand.subCommands ?? {});
    expect(keys).toContain("verdict");
    expect(keys).toContain("approve");
    expect(keys).toContain("apply");
    expect(keys).toContain("archive");
  });
});

describe("correction 63 — malformed newest verdict does not promote older", () => {
  it("refuses when newest is outcome=failed after an older pass", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    let xml = readFileSync(ledgerPath, "utf8");
    // Exact A31 fixture: older valid + newer malformed.
    xml = xml.replace("</Verdicts>", `<Verdict outcome="failed" /></Verdicts>`);
    writeFileSync(ledgerPath, xml);

    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("invalid");
    if (latest.state === "invalid") {
      expect(latest.code).toBe("ledger.invalid-verdict");
      expect(latest.detail).toContain("failed");
    }

    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(true);
    expect(result.issues.some((i) => i.message.includes("ledger.invalid-verdict"))).toBe(true);
    // Must NOT report present=true on the older pass.
    const reviewReq = result.requirements.find((r) => r.id === "review-verdict");
    expect(reviewReq?.present).toBe(false);
    expect(result.verdict).toBeUndefined();
  });

  it("listReviewVerdicts throws rather than silently dropping invalid entries", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    let xml = readFileSync(ledgerPath, "utf8");
    xml = xml.replace("</Verdicts>", `<Verdict outcome="failed" /></Verdicts>`);
    writeFileSync(ledgerPath, xml);
    expect(() => listReviewVerdicts(root, "C-GATE")).toThrow(/ledger\.invalid-verdict/);
  });
});

describe("correction 68 — newest-governs at the section boundary (A32.1)", () => {
  it("duplicate Verdicts sections: refuse; do not permit on first section's pass", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    // A32 fixture: first section pass, second fail — first-wins would permit.
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE>`
        + `<Verdicts><Verdict outcome="pass" /></Verdicts>`
        + `<Verdicts><Verdict outcome="fail" /></Verdicts>`
        + `</C-GATE></NgraceRunLedger>`,
    );
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("invalid");
    if (latest.state === "invalid") {
      expect(latest.code).toBe("ledger.invalid-verdict");
      expect(latest.detail).toMatch(/duplicate/i);
    }
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(true);
    expect(result.verdict).toBeUndefined();
    const reviewReq = result.requirements.find((r) => r.id === "review-verdict");
    expect(reviewReq?.present).toBe(false);
  });

  it("stray non-Verdict child under Verdicts: refuse; do not filter to pass", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE>`
        + `<Verdicts><Verdict outcome="pass" /><Bogus /></Verdicts>`
        + `</C-GATE></NgraceRunLedger>`,
    );
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("invalid");
    if (latest.state === "invalid") {
      expect(latest.code).toBe("ledger.invalid-verdict");
      expect(latest.detail).toMatch(/Bogus/);
    }
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(true);
    expect(result.verdict).toBeUndefined();
  });

  it("silent direction: one well-formed section, newest of several entries governs", () => {
    const root = tempProject();
    activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    recordReviewVerdict(root, "C-GATE", { outcome: "fail" });
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("present");
    if (latest.state === "present") {
      expect(latest.verdict.outcome).toBe("fail");
    }
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("refuse");
    expect(evaluateApplyGate(root, "C-GATE").issues.some((issue) => issue.code === "gate.apply.outcome-fail")).toBe(true);
    expect(evaluateApplyGate(root, "C-GATE").verdict?.outcome).toBe("fail");
  });

  it("silent direction: no Verdicts section is absence, not invalid", () => {
    const root = tempProject();
    activeBundle(root);
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("absent");
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.no-verdict")).toBe(true);
    expect(result.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(false);
  });

  it("duplicate Decisions sections: not a permit; reason reaches readPermittingDecision", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE>`
        + `<Decisions><Decision gate="apply" decision="permit" /></Decisions>`
        + `<Decisions><Decision gate="apply" decision="refuse" /></Decisions>`
        + `</C-GATE></NgraceRunLedger>`,
    );
    const decisions = readGateDecisions(root, "C-GATE");
    expect(decisions.state).toBe("invalid");
    if (decisions.state === "invalid") {
      expect(decisions.code).toBe("ledger.invalid-decision");
      expect(decisions.detail).toMatch(/duplicate/i);
    }
    const permit = readPermittingDecision(root, "C-GATE", "apply");
    expect(permit.state).toBe("invalid");
    if (permit.state === "invalid") {
      expect(permit.code).toBe("ledger.invalid-decision");
      expect(permit.detail).toMatch(/duplicate/i);
    }
  });
});

describe("C-INSPECTION-SURFACE-1-2628AA2B T-001 — the Verdict reader carries the close-evidence tally", () => {
  const tallyA = { criterionId: "AC-CLOSE-LINT", exit: "0", result: "pass" };
  const tallyB = { criterionId: "AC-NO-OTHER-SRC", exit: "1", result: "fail" };

  function writeVerdict(root: string, verdictBody: string, changeId = "C-GATE") {
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
    mkdirSync(bundle, { recursive: true });
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><${changeId}>`
        + `<Verdicts>${verdictBody}</Verdicts>`
        + `</${changeId}></NgraceRunLedger>`,
    );
  }

  it("readLatestReviewVerdict carries Exit/Result for every complete AC-* criterion", () => {
    const root = tempProject();
    activeBundle(root);
    writeVerdict(
      root,
      `<Verdict outcome="fail">`
        + `<AC-CLOSE-LINT><Exit>0</Exit><Result>pass</Result></AC-CLOSE-LINT>`
        + `<AC-NO-OTHER-SRC><Exit>1</Exit><Result>fail</Result></AC-NO-OTHER-SRC>`
        + `</Verdict>`,
    );
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("present");
    if (latest.state === "present") {
      expect(latest.verdict.closeEvidence).toEqual([tallyA, tallyB]);
    }
  });

  it("readLedgerVerdictsSurface carries the same tally on every Verdict", () => {
    const root = tempProject();
    activeBundle(root);
    writeVerdict(
      root,
      `<Verdict outcome="pass"><AC-CLOSE-LINT><Exit>0</Exit><Result>pass</Result></AC-CLOSE-LINT></Verdict>`
        + `<Verdict outcome="fail"><AC-NO-OTHER-SRC><Exit>1</Exit><Result>fail</Result></AC-NO-OTHER-SRC></Verdict>`,
    );
    const surface = readLedgerVerdictsSurface(root, "C-GATE");
    expect(surface.state).toBe("ok");
    if (surface.state === "ok") {
      expect(surface.verdicts.map((v) => v.closeEvidence)).toEqual([[tallyA], [tallyB]]);
    }
  });

  it("an AC-* child missing Exit or Result is not carried as a recorded pass", () => {
    const root = tempProject();
    activeBundle(root);
    writeVerdict(
      root,
      `<Verdict outcome="pass">`
        + `<AC-COMPLETE><Exit>0</Exit><Result>pass</Result></AC-COMPLETE>`
        + `<AC-NO-EXIT><Result>pass</Result></AC-NO-EXIT>`
        + `<AC-EMPTY-EXIT><Exit></Exit><Result>pass</Result></AC-EMPTY-EXIT>`
        + `<AC-BAD-RESULT><Exit>0</Exit><Result>maybe</Result></AC-BAD-RESULT>`
        + `<Note>not a criterion</Note>`
        + `</Verdict>`,
    );
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("present");
    if (latest.state === "present") {
      expect(latest.verdict.closeEvidence).toEqual([
        { criterionId: "AC-COMPLETE", exit: "0", result: "pass" },
      ]);
    }
  });

  it("a Verdict with no complete AC-* child carries no tally at all — absent, never an empty array", () => {
    const root = tempProject();
    activeBundle(root);
    writeVerdict(root, `<Verdict outcome="pass"><AC-NO-EXIT><Result>pass</Result></AC-NO-EXIT></Verdict>`);
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(latest.state).toBe("present");
    if (latest.state === "present") {
      expect(latest.verdict.closeEvidence).toBeUndefined();
    }
  });
});

describe("correction 69 — absent Decisions is not applied-without-gate-record (A33.1)", () => {
  it("no Decisions section → absent, not no-permit", () => {
    const root = tempProject();
    activeBundle(root);
    // no run-ledger → no Decisions section
    const permit = readPermittingDecision(root, "C-GATE", "apply");
    expect(permit.state).toBe("absent");
    if (permit.state === "absent") {
      expect(permit.reason).toBe("no-decisions-section");
    }
  });

  it("Decisions section without apply permit → no-permit", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordGateDecision(root, "C-GATE", {
      gate: "approve",
      decision: "permit",
      requirements: [],
    });
    const permit = readPermittingDecision(root, "C-GATE", "apply");
    expect(permit.state).toBe("no-permit");
  });
});

describe("correction 64 — apply requires approved plan, not existsSync", () => {
  it("refuses status=draft plan even when plan.xml exists", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-DRAFT",
      location: "active",
      specStatus: "approved",
      planStatus: "draft",
    });
    recordReviewVerdict(root, "C-DRAFT", libraryBoundPass("C-DRAFT"));
    const result = evaluateApplyGate(root, "C-DRAFT");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.no-plan")).toBe(true);
    const planReq = result.requirements.find((r) => r.id === "plan-present");
    expect(planReq?.present).toBe(false);
    expect(planReq?.message).toMatch(/draft/);
  });
});

describe("evaluateApplyGateArtifact", () => {
  it("keeps plan-present and AC clarification and does not add review-verdict", () => {
    const root = tempProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-GATE",
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
    });
    const artifact = evaluateApplyGateArtifact(root, "C-GATE");
    expect(artifact.requirements.some((item) => item.id === "plan-present")).toBe(true);
    expect(artifact.requirements.some((item) => item.id === "no-unresolved-satisfied-ac-clarification")).toBe(true);
    expect(artifact.requirements.some((item) => item.id === "review-verdict")).toBe(false);
    const composed = evaluateApplyGate(root, "C-GATE");
    expect(composed.requirements.some((item) => item.id === "review-verdict")).toBe(true);
  });
});

describe("correction 65 — --format json is pure JSON", () => {
  it("archive --format json parses with JSON.parse (no trailing usage)", () => {
    const root = tempProject();
    activeBundle(root);
    const result = runGateCli(
      ["archive", "--change", "C-GATE", "--path", root, "--format", "json", "--record=false"],
      root,
    );
    expect(result.status).toBe(0);
    // Strict parse of entire stdout — fails if usage prose follows the object.
    const parsed = JSON.parse(result.stdout);
    expect(parsed.ok).toBe(true);
    expect(parsed.decision).toBe("permit");
    expect(result.stdout).not.toMatch(/Usage:/);
  });
});

describe("correction 66 — recorder validates before write and keeps the answer", () => {
  it("pre-existing invalid verdict: gate still answers; decision count does not grow", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    // Seed a clean pass verdict, then corrupt it in place so the tree is invalid.
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    let xml = readFileSync(ledgerPath, "utf8");
    xml = xml.replace('outcome="pass"', 'outcome="failed"');
    writeFileSync(ledgerPath, xml);
    const before = readFileSync(ledgerPath, "utf8");
    const decisionCountBefore = (before.match(/<Decision\b/g) ?? []).length;

    // Evaluate + attempt record: evaluation must survive recording failure (A31.5).
    const evaluation = evaluateGate(root, "C-GATE", "apply");
    expect(evaluation.decision).toBe("refuse");
    expect(evaluation.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(true);

    const decision = evaluationToDecision(evaluation)!;
    let recordingError: string | undefined;
    try {
      recordGateDecision(root, "C-GATE", decision);
    } catch (error) {
      recordingError = error instanceof Error ? error.message : String(error);
    }
    expect(recordingError).toBeDefined();
    expect(recordingError).toMatch(/ledger\.invalid-verdict|failed verification/);

    // Prior bytes restored / untouched — no new Decision appended.
    const after = readFileSync(ledgerPath, "utf8");
    const decisionCountAfter = (after.match(/<Decision\b/g) ?? []).length;
    expect(decisionCountAfter).toBe(decisionCountBefore);

    // formatGateEvaluation still surfaces the decision when recordingError is set.
    evaluation.recordingError = recordingError;
    const text = formatGateEvaluation(evaluation);
    expect(text).toContain("Decision: refuse");
    expect(text).toContain("Recording: failed");
  });

  it("CLI apply reports decision when recording fails", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    let xml = readFileSync(ledgerPath, "utf8");
    xml = xml.replace('outcome="pass"', 'outcome="bogus"');
    writeFileSync(ledgerPath, xml);

    const result = runGateCli(
      ["apply", "--change", "C-GATE", "--path", root, "--format", "json"],
      root,
    );
    // Evaluation is refused (invalid verdict) and recording may also fail — either way JSON has decision.
    expect(result.stdout.length).toBeGreaterThan(0);
    const parsed = JSON.parse(result.stdout);
    expect(parsed.decision).toBe("refuse");
    expect(parsed.ok).toBe(true);
    // Must not be the silent error envelope that loses the answer.
    expect(parsed.gate).toBe("apply");
  });
});

describe("correction 67 — no dead parseGate / void suppression", () => {
  it("command module has no parseGate and no void parseGate", () => {
    const source = readFileSync(path.join(import.meta.dir, "command.ts"), "utf8");
    expect(source).not.toMatch(/\bfunction parseGate\b/);
    expect(source).not.toMatch(/void parseGate/);
  });
});

describe("approve gate", () => {
  it("refuses unresolved IC/INV clarification; ASSUMPTION does not block", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    // Patch spec with Clarification + Assumption
    const specPath = path.join(bundle, "spec.xml");
    let spec = readFileSync(specPath, "utf8");
    spec = spec.replace(
      "</C-GATE>",
      `<Clarifications><Clarification><IC-EXAMPLE /></Clarification></Clarifications></C-GATE>`,
    );
    writeFileSync(specPath, spec);
    const refused = evaluateApproveGate(root, "C-GATE");
    expect(refused.decision).toBe("refuse");
    expect(refused.issues.some((i) => i.code === "gate.approve.clarification-unresolved")).toBe(true);

    // Resolve clarification
    spec = readFileSync(specPath, "utf8");
    spec = spec.replace(
      "<Clarification>",
      `<Clarification resolved="true">`,
    );
    writeFileSync(specPath, spec);
    const permitted = evaluateApproveGate(root, "C-GATE");
    expect(permitted.decision).toBe("permit");
  });

  it("clarification on non-satisfied AC does not block approve", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    const specPath = path.join(bundle, "spec.xml");
    let spec = readFileSync(specPath, "utf8");
    spec = spec.replace(
      "</C-GATE>",
      `<Clarifications><Clarification><AC-OTHER /></Clarification></Clarifications></C-GATE>`,
    );
    writeFileSync(specPath, spec);
    expect(evaluateApproveGate(root, "C-GATE").decision).toBe("permit");
  });
});

const CLARIFICATION_SHAPE_CODES = [
  "artifact.semantic-anchor-attribute",
  "change.invalid-clarification",
  "change.invalid-clarification-target",
] as const;

function plantChildFormClarification(bundle: string, inner: string): void {
  const specPath = path.join(bundle, "spec.xml");
  const spec = readFileSync(specPath, "utf8");
  writeFileSync(
    specPath,
    spec.replace("</C-GATE>", `<Clarifications>${inner}</Clarifications></C-GATE>`),
  );
}

function assertClarificationShapeClean(root: string): void {
  const codes = validateNgraceProject(root).issues.map((issue) => issue.code);
  for (const code of CLARIFICATION_SHAPE_CODES) {
    expect(codes).not.toContain(code);
  }
}

function approveClarificationRequirement(result: ReturnType<typeof evaluateApproveGate>) {
  return result.requirements.find((requirement) => requirement.id === "no-unresolved-ic-inv-clarification");
}

describe("C-GRAMMAR-SEAM T-002 approve gate on lint-clean child-form Clarification", () => {
  it("lint-clean unresolved IC-EXAMPLE refuses approve; resolved permits", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    plantChildFormClarification(
      bundle,
      "<Clarification><IC-EXAMPLE /></Clarification>",
    );
    assertClarificationShapeClean(root);

    const refused = evaluateApproveGate(root, "C-GATE");
    expect(refused.decision).toBe("refuse");
    expect(refused.issues.some((issue) => issue.code === "gate.approve.clarification-unresolved")).toBe(true);
    expect(approveClarificationRequirement(refused)?.present).toBe(false);

    const specPath = path.join(bundle, "spec.xml");
    writeFileSync(
      specPath,
      readFileSync(specPath, "utf8").replace("<Clarification>", `<Clarification resolved="true">`),
    );
    assertClarificationShapeClean(root);

    const permitted = evaluateApproveGate(root, "C-GATE");
    expect(permitted.decision).toBe("permit");
    expect(approveClarificationRequirement(permitted)?.present).toBe(true);
  });

  it("lint-clean unresolved INV-AUTH refuses approve; resolved permits", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    plantChildFormClarification(
      bundle,
      "<Clarification><INV-AUTH /></Clarification>",
    );
    assertClarificationShapeClean(root);

    const refused = evaluateApproveGate(root, "C-GATE");
    expect(refused.decision).toBe("refuse");
    expect(refused.issues.some((issue) => issue.code === "gate.approve.clarification-unresolved")).toBe(true);
    expect(approveClarificationRequirement(refused)?.present).toBe(false);

    const specPath = path.join(bundle, "spec.xml");
    writeFileSync(
      specPath,
      readFileSync(specPath, "utf8").replace("<Clarification>", `<Clarification resolved="true">`),
    );
    assertClarificationShapeClean(root);

    const permitted = evaluateApproveGate(root, "C-GATE");
    expect(permitted.decision).toBe("permit");
    expect(approveClarificationRequirement(permitted)?.present).toBe(true);
  });

  it("lint-clean unresolved AC-SAMPLE does not by itself refuse approve", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    plantChildFormClarification(
      bundle,
      "<Clarification><AC-SAMPLE /></Clarification>",
    );
    assertClarificationShapeClean(root);

    const result = evaluateApproveGate(root, "C-GATE");
    expect(result.decision).toBe("permit");
    expect(result.issues.some((issue) => issue.code === "gate.approve.clarification-unresolved")).toBe(false);
    expect(approveClarificationRequirement(result)?.present).toBe(true);
  });
});

function plantAcSampleCriterion(bundle: string): void {
  const specPath = path.join(bundle, "spec.xml");
  writeFileSync(
    specPath,
    readFileSync(specPath, "utf8").replace(
      "<AcceptanceCriteria><Criterion>The fixture remains valid.</Criterion></AcceptanceCriteria>",
      "<AcceptanceCriteria><AC-SAMPLE>Sample criterion.</AC-SAMPLE></AcceptanceCriteria>",
    ),
  );
}

function plantPlanSatisfiesAcSample(bundle: string): void {
  const planPath = path.join(bundle, "plan.xml");
  writeFileSync(
    planPath,
    readFileSync(planPath, "utf8").replace(
      "<DependsOn></DependsOn>",
      "<DependsOn></DependsOn><Satisfies><AC-SAMPLE /></Satisfies>",
    ),
  );
}

function applySatisfiedAcRequirement(result: ReturnType<typeof evaluateApplyGate>) {
  return result.requirements.find((requirement) => requirement.id === "no-unresolved-satisfied-ac-clarification");
}

describe("C-GRAMMAR-SEAM T-002 apply gate on lint-clean Satisfied AC Clarification", () => {
  it("lint-clean unresolved Satisfied AC-SAMPLE refuses apply; resolved does not emit the code", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    plantAcSampleCriterion(bundle);
    plantPlanSatisfiesAcSample(bundle);
    plantChildFormClarification(
      bundle,
      "<Clarification><AC-SAMPLE /></Clarification>",
    );
    assertClarificationShapeClean(root);

    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const refused = evaluateApplyGate(root, "C-GATE");
    expect(refused.issues.some((issue) => issue.code === "gate.apply.clarification-unresolved")).toBe(true);
    expect(applySatisfiedAcRequirement(refused)?.present).toBe(false);

    const specPath = path.join(bundle, "spec.xml");
    writeFileSync(
      specPath,
      readFileSync(specPath, "utf8").replace("<Clarification>", `<Clarification resolved="true">`),
    );
    assertClarificationShapeClean(root);

    const resolved = evaluateApplyGate(root, "C-GATE");
    expect(resolved.issues.some((issue) => issue.code === "gate.apply.clarification-unresolved")).toBe(false);
    expect(applySatisfiedAcRequirement(resolved)?.present).toBe(true);
  });

  it("lint-clean unresolved AC that no task Satisfies does not emit apply clarification-unresolved", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    plantChildFormClarification(
      bundle,
      "<Clarification><AC-OTHER /></Clarification>",
    );
    assertClarificationShapeClean(root);

    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.issues.some((issue) => issue.code === "gate.apply.clarification-unresolved")).toBe(false);
    expect(applySatisfiedAcRequirement(result)?.present).toBe(true);
  });
});

describe("apply gate", () => {
  it("permits unable-to-determine; refuses no verdict (D11 pair)", () => {
    const root = tempProject();
    activeBundle(root);
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("refuse");
    recordReviewVerdict(root, "C-GATE", { outcome: "unable-to-determine", reason: "evidence gap" });
    const permitted = evaluateApplyGate(root, "C-GATE");
    expect(permitted.decision).toBe("permit");
    expect(permitted.verdict?.outcome).toBe("unable-to-determine");
  });

  it("host-capability-missing respects gateFailOn permissive vs strict", () => {
    const root = tempProject();
    activeBundle(root);
    recordReviewVerdict(root, "C-GATE", {
      outcome: "unable-to-determine",
      reason: "host-capability-missing",
    });
    // default gateFailOn = errors → refuse
    expect(resolveProjectGateFailOn(root)).toBe("errors");
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("refuse");

    writeFileSync(
      path.join(root, ".ngrace-lint.json"),
      JSON.stringify({ gateFailOn: "never" }),
    );
    expect(resolveProjectGateFailOn(root)).toBe("never");
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("permit");

    writeFileSync(
      path.join(root, ".ngrace-lint.json"),
      JSON.stringify({ gateFailOn: "errors" }),
    );
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("refuse");
  });

  it("refuses without a plan (A17.2)", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-NOPLAN",
      location: "active",
      specStatus: "approved",
      // planStatus omitted → no plan.xml
    });
    recordReviewVerdict(root, "C-NOPLAN", libraryBoundPass("C-NOPLAN"));
    const result = evaluateApplyGate(root, "C-NOPLAN");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.no-plan")).toBe(true);
  });
});

/**
 * C-REPORT-HONESTY T-005 / AC-APPLY-VERDICT-DIAGNOSTICS (P0.7).
 * Apply refuse on missing/unusable verdict must name path, count, and why newest failed —
 * not catalog title alone or bare "no Verdicts section entry".
 */
describe("C-REPORT-HONESTY T-005 apply verdict diagnostics (P0.7)", () => {
  function reviewVerdictReq(result: ReturnType<typeof evaluateApplyGate>) {
    return result.requirements.find((r) => r.id === "review-verdict");
  }
  function noVerdictIssue(result: ReturnType<typeof evaluateApplyGate>) {
    return result.issues.find((i) => i.code === "gate.apply.no-verdict");
  }
  function combinedDiagText(result: ReturnType<typeof evaluateApplyGate>): string {
    const req = reviewVerdictReq(result)?.message ?? "";
    const issue = noVerdictIssue(result)?.message ?? "";
    const invalid = result.issues.find((i) => i.code === "gate.apply.invalid-verdict")?.message ?? "";
    return `${req}\n${issue}\n${invalid}`;
  }

  it("no run-ledger.xml: refuse names missing ledger path and count 0", () => {
    const root = tempProject();
    activeBundle(root);
    // Fixture creates no ledger until a writer runs.
    expect(existsSync(path.join(root, ARTIFACT_DIR, "changes/active/C-GATE/run-ledger.xml"))).toBe(false);

    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(noVerdictIssue(result)).toBeDefined();
    const text = combinedDiagText(result);
    // Must not be catalog-title-only or bare "no Verdicts section entry".
    expect(text).not.toBe("Apply Requires A Recorded Review Verdict");
    expect(text.trim()).not.toBe("no Verdicts section entry");
    expect(text).toMatch(/run-ledger\.xml/);
    expect(text).toMatch(/missing|not found|absent/i);
    expect(text).toMatch(/count\s*=\s*0|0\s*Verdict|Verdict child count=0/i);
    // Path looked at (bundle ledger location).
    expect(text).toMatch(/C-GATE/);
  });

  it("ledger present, no Verdicts section: refuse names path and count 0", () => {
    const root = tempProject();
    activeBundle(root);
    // Create ledger without Verdicts (approve Decision only).
    recordGateDecision(root, "C-GATE", {
      gate: "approve",
      decision: "permit",
      requirements: [],
    });
    const ledger = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes/active/C-GATE/run-ledger.xml"),
      "utf8",
    );
    expect(ledger).not.toContain("<Verdicts");

    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(noVerdictIssue(result)).toBeDefined();
    const text = combinedDiagText(result);
    expect(text).not.toBe("Apply Requires A Recorded Review Verdict");
    expect(text.trim()).not.toBe("no Verdicts section entry");
    expect(text).toMatch(/run-ledger\.xml|looked at/i);
    expect(text).toMatch(/C-GATE/);
    expect(text).toMatch(/count\s*=\s*0|0\s*Verdict|Verdict child count=0/i);
  });

  it("Verdicts present but empty: refuse names path and count 0", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE><Verdicts></Verdicts></C-GATE></NgraceRunLedger>`,
    );

    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(noVerdictIssue(result)).toBeDefined();
    const text = combinedDiagText(result);
    expect(text).not.toBe("Apply Requires A Recorded Review Verdict");
    expect(text.trim()).not.toBe("no Verdicts section entry");
    expect(text).toMatch(/run-ledger\.xml|looked at/i);
    expect(text).toMatch(/C-GATE/);
    expect(text).toMatch(/count\s*=\s*0|0\s*Verdict|Verdict child count=0/i);
  });

  it("newest entry unreadable: refuse names path, code, and reason", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE><Verdicts><Verdict outcome="failed"/></Verdicts></C-GATE></NgraceRunLedger>`,
    );

    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(true);
    const text = combinedDiagText(result);
    expect(text).toMatch(/run-ledger\.xml|looked at/i);
    expect(text).toMatch(/C-GATE/);
    expect(text).toMatch(/ledger\.invalid-verdict/);
    expect(text).toMatch(/outcome=failed|unreadable|did not qualify|invalid/i);
  });

  it("unparseable ledger: invalid-verdict names path and reason; decision stays refuse", () => {
    // Honest classification: unreadable maps to invalid (not collapsed absent/no-verdict).
    // Decision remains refuse (AC-GATE-COMPAT). Count is undetermined — not 0.
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(path.join(bundle, "run-ledger.xml"), "not xml at all <<<");

    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(true);
    expect(noVerdictIssue(result)).toBeUndefined();
    const text = combinedDiagText(result);
    expect(text).toMatch(/run-ledger\.xml|looked at/i);
    expect(text).toMatch(/C-GATE/);
    expect(text).toMatch(/unreadable|xml\.parse|not expected|parse/i);
    // Must not assert a determined zero when nothing was counted.
    expect(text).not.toMatch(/Verdict child count=0/);
  });

  it("wrong change wrapper: invalid-verdict with ledger.bundle-id-mismatch; decision refuse", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-OTHER><Verdicts><Verdict outcome="pass"/></Verdicts></C-OTHER></NgraceRunLedger>`,
    );

    const surface = readLedgerVerdictsSurface(root, "C-GATE");
    const latest = readLatestReviewVerdict(root, "C-GATE");
    expect(surface).toEqual(
      expect.objectContaining({ state: "unreadable", code: "ledger.bundle-id-mismatch" }),
    );
    expect(latest).toEqual(
      expect.objectContaining({ state: "invalid", code: "ledger.bundle-id-mismatch" }),
    );

    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((i) => i.code === "gate.apply.invalid-verdict")).toBe(true);
    expect(noVerdictIssue(result)).toBeUndefined();
  });

  it("corrupt ledger: deliberate regression would permit or throw — refuse holds (AC-GATE-COMPAT)", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(path.join(bundle, "run-ledger.xml"), "not xml at all <<<");

    let threw = false;
    let result: ReturnType<typeof evaluateApplyGate> | undefined;
    try {
      result = evaluateApplyGate(root, "C-GATE");
    } catch {
      threw = true;
    }
    expect(threw).toBe(false);
    expect(result!.decision).toBe("refuse");
    // Not a silent pass / permit on unreadable content.
    expect(result!.decision).not.toBe("permit");
  });

  it("immediate evaluateApplyGate after recordReviewVerdict permits (no flush)", () => {
    const root = tempProject();
    activeBundle(root);
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("refuse");
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    // Immediate — no re-read loop, no delay, no flush.
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("permit");
    expect(result.verdict?.outcome).toBe("pass");
  });
});

describe("archive gate (A30.1 deadlock)", () => {
  it("permits with recorded apply decision and verdict when run/ empty", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    recordGateDecision(root, "C-GATE", {
      gate: "apply",
      decision: "permit",
      requirements: [],
    });
    expect(listLooseEvents(bundle)).toHaveLength(0);
    expect(evaluateArchiveGate(root, "C-GATE").decision).toBe("permit");
  });

  it("refuses when one loose run/ event exists", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    mkdirSync(path.join(bundle, "run"), { recursive: true });
    writeFileSync(
      path.join(bundle, "run", "1-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="progress"/>`,
    );
    expect(evaluateArchiveGate(root, "C-GATE").decision).toBe("refuse");
    expect(evaluateArchiveGate(root, "C-GATE").issues.some((i) => i.code === "gate.archive.open-epoch")).toBe(true);
  });

  /**
   * C-REPORT-HONESTY T-002: honest no-open-epoch detail over orphans (F14),
   * without weakening refuse on real foldable loose events.
   */
  it("AC-TOKEN-ORPHAN-TRIPLE (2): orphan-only run/ permits with message not 'run/ empty' and names orphan", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-ORPHAN",
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-ORPHAN");
    mkdirSync(path.join(bundle, "run"), { recursive: true });
    // Copy shape of live NaN orphan — tests never mutate archive/.
    const liveNan = path.join(
      REPO_ROOT,
      ARTIFACT_DIR,
      "changes/archive/C-TOKEN-INTEGRITY/run/NaN-T-001-opened.xml",
    );
    writeFileSync(path.join(bundle, "run", "NaN-T-001-opened.xml"), readFileSync(liveNan));
    expect(listLooseEvents(bundle)).toHaveLength(0);

    const result = evaluateArchiveGate(root, "C-ORPHAN");
    expect(result.decision).toBe("permit");
    const req = result.requirements.find((r) => r.id === "no-open-epoch");
    expect(req?.present).toBe(true);
    expect(req?.message).not.toBe("run/ empty");
    expect(req?.message).toMatch(/no foldable|foldable/i);
    expect(req?.message).toMatch(/NaN-T-001-opened\.xml/);
  });

  it("AC-ARCHIVE-STILL-REFUSES-LOOSE: ≥1 foldable loose event refuses no-open-epoch", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-LOOSE",
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-LOOSE");
    mkdirSync(path.join(bundle, "run"), { recursive: true });
    writeFileSync(
      path.join(bundle, "run", "3-T-002-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="3" task="T-002" kind="progress"/>`,
    );
    expect(listLooseEvents(bundle).length).toBeGreaterThanOrEqual(1);

    const result = evaluateArchiveGate(root, "C-LOOSE");
    expect(result.decision).toBe("refuse");
    const req = result.requirements.find((r) => r.id === "no-open-epoch");
    expect(req?.present).toBe(false);
    expect(result.issues.some((i) => i.code === "gate.archive.open-epoch")).toBe(true);
  });

  it("AC-MEMBERSHIP-ONE-DEFINITION: evaluateArchiveGate uses listLooseEvents / listRunOrphans from run-membership", () => {
    const coreSrc = readFileSync(path.join(REPO_ROOT, "src/gates/core.ts"), "utf8");
    // Prefer direct import from artifact host (D2 construction).
    expect(coreSrc).toMatch(/listLooseEvents/);
    expect(coreSrc).toMatch(/listRunOrphans/);
    expect(coreSrc).toMatch(/from\s+["']\.\.\/artifact\/run-membership["']/);
    // Predicate remains listLooseEvents length === 0 (message-only change on permit).
    const archiveFn = coreSrc.slice(coreSrc.indexOf("export function evaluateArchiveGate"));
    const body = archiveFn.slice(0, archiveFn.indexOf("\nexport function"));
    expect(body).toMatch(/listLooseEvents\s*\(/);
    expect(body).toMatch(/loose\.length\s*[!=]==?\s*0|loose\.length\s*>\s*0|!open/);
  });
});

describe("escalated attempt refusal", () => {
  it("evaluateAttemptGate refuses when task is escalated", () => {
    const result = evaluateAttemptGate("C-X", "T-001", ["T-001"]);
    expect(result.decision).toBe("refuse");
    expect(result.issues[0]?.code).toBe("gate.attempt.escalated");
  });

  it("recordAttempt throws when task is escalated", () => {
    const root = tempProject();
    activeBundle(root);
    advanceCursor(root, "C-GATE", { task: "T-001", openEpoch: true, from: 1, to: 20 });
    recordAttempt(root, "C-GATE", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "a" },
    });
    recordAttempt(root, "C-GATE", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "a" }, // R: same signature (C-ESCALATION-HONESTY)
    });
    const position = showCursor(root, "C-GATE");
    expect(position.escalatedTasks).toContain("T-001");
    expect(() =>
      recordAttempt(root, "C-GATE", {
        task: "T-001",
        outcome: "fail",
        signature: { kind: "test", key: "c" },
      }),
    ).toThrow(/gate\.attempt\.escalated/);
  });

  function tripCircuit(root: string, changeId = "C-GATE", task = "T-001") {
    advanceCursor(root, changeId, { task, openEpoch: true, from: 1, to: 20 });
    const sig = { kind: "test", key: "a" };
    recordAttempt(root, changeId, { task, outcome: "fail", signature: sig });
    recordAttempt(root, changeId, { task, outcome: "fail", signature: sig });
    resumeCursor(root, changeId, task, { reason: "replan: after first R" });
    recordAttempt(root, changeId, { task, outcome: "fail", signature: sig });
    const tripped = recordAttempt(root, changeId, { task, outcome: "fail", signature: sig });
    expect(tripped.circuit).toBe(true);
    expect(tripped.position.state).toBe("paused-pending-supersede");
    return tripped;
  }

  it("GATE_CATALOG registers gate.attempt.circuit-tripped; remediation names supersede not resume", () => {
    const guide = GATE_CATALOG["gate.attempt.circuit-tripped"];
    expect(guide).toBeDefined();
    expect(guide!.code).toBe("gate.attempt.circuit-tripped");
    expect(guide!.severity).toBe("error");
    const remediation = guide!.remediation.join(" ");
    expect(remediation).toMatch(/supersede/i);
    expect(remediation).not.toMatch(/resume/i);
  });

  it("evaluateAttemptGate refuses circuit-tripped before ordinary escalation", () => {
    const circuitOnly = evaluateAttemptGate("C-X", "T-001", [], ["T-001"]);
    expect(circuitOnly.decision).toBe("refuse");
    expect(circuitOnly.issues[0]?.code).toBe("gate.attempt.circuit-tripped");
    const both = evaluateAttemptGate("C-X", "T-001", ["T-001"], ["T-001"]);
    expect(both.decision).toBe("refuse");
    expect(both.issues[0]?.code).toBe("gate.attempt.circuit-tripped");
    expect(both.issues.some((issue) => issue.code === "gate.attempt.escalated")).toBe(false);
  });

  it("evaluateAttemptOnBundle and recordAttempt both refuse circuit-tripped tasks", () => {
    const root = tempProject();
    activeBundle(root);
    tripCircuit(root);
    const gate = evaluateAttemptOnBundle(root, "C-GATE", "T-001");
    expect(gate.decision).toBe("refuse");
    expect(gate.issues[0]?.code).toBe("gate.attempt.circuit-tripped");
    let caught: unknown;
    try {
      recordAttempt(root, "C-GATE", {
        task: "T-001",
        outcome: "fail",
        signature: { kind: "test", key: "c" },
      });
    } catch (error) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(GraceCommandError);
    expect((caught as GraceCommandError).code).toBe("invalid-arguments");
    expect((caught as GraceCommandError).message).toMatch(/gate\.attempt\.circuit-tripped/);
    expect((caught as GraceCommandError).message).toMatch(/paused-pending-supersede/);
    expect((caught as GraceCommandError).message).toMatch(/supersede/);
    expect((caught as GraceCommandError).message).not.toMatch(/resume/);
    expect((caught as GraceCommandError).issues).toEqual(["gate.attempt.circuit-tripped"]);
  });
});

/**
 * C-FLAG-HONESTY T-002 — F18 gate --record space form.
 * Temp fixtures only; never a live or archived bundle.
 */
function countDecisionElements(ledgerPath: string): number {
  if (!existsSync(ledgerPath)) return 0;
  return (readFileSync(ledgerPath, "utf8").match(/<Decision\b/g) ?? []).length;
}

function fixtureLedgerPath(root: string, changeId = "C-GATE"): string {
  return path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml");
}

describe("C-FLAG-HONESTY T-002 — gate --record space form (F18)", () => {
  it("AC-SPACE-FORM-FAILS-LOUD: --record false exits non-zero, names both working forms, Decision count unchanged", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    const ledgerPath = fixtureLedgerPath(root);
    // Seed one Decision so "unchanged" is a real equality, not absence→absence.
    recordGateDecision(root, "C-GATE", {
      gate: "approve",
      decision: "permit",
      requirements: [{ id: "no-unresolved-ic-inv-clarification", required: true, present: true, blocking: false }],
    });
    const before = countDecisionElements(ledgerPath);
    expect(before).toBe(1);

    for (const gate of ["approve", "apply", "archive"] as const) {
      const result = runGateCli(
        [gate, "--change", "C-GATE", "--path", root, "--record", "false"],
        root,
      );
      // Exit code is GraceCommandError.exitCode (default 1) via runGraceCommand — exact pin.
      expect(result.status).toBe(1);
      // C-LEGIBLE-FAILURE T-003: message is the single stderr line (not a stack).
      const lines = result.stderr.replace(/\n$/, "").split("\n");
      expect(lines.length).toBe(1);
      expect(lines[0]).toContain("--record=false");
      expect(lines[0]).toContain("--no-record");
      // Actual refuseBooleanSpaceForm wording (not a family of plausible paraphrases).
      expect(lines[0]).toContain("bare `--record` means true");
      expect(result.stderr).not.toMatch(/at refuseBooleanSpaceForm|at async runCommand/);
      expect(countDecisionElements(ledgerPath)).toBe(before);
    }
    // Bundle path still only the seeded Decision (no archive write, no second Decision).
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(true);
  });

  it("AC-CHANNEL-JSON-ENVELOPE: --format json + space-form → entire stdout is GraceCommandErrorEnvelope", () => {
    const root = tempProject();
    activeBundle(root);
    const ledgerPath = fixtureLedgerPath(root);
    expect(countDecisionElements(ledgerPath)).toBe(0);

    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record", "false", "--format", "json"],
      root,
    );
    expect(result.status).toBe(1);
    // Entire stdout must parse — no stack prefix/suffix.
    const body = JSON.parse(result.stdout);
    expect(body.schemaVersion).toBe("1.0.0");
    expect(body.ok).toBe(false);
    expect(body.error.code).toBe("invalid-arguments");
    expect(typeof body.error.message).toBe("string");
    expect(body.error.message).toContain("--record=false");
    expect(result.stdout).not.toMatch(/at refuseBooleanSpaceForm|GraceCommandError:/);
    // AC-CHANNEL-SIDE-EFFECT-HELD: no ledger created when none existed.
    expect(existsSync(ledgerPath)).toBe(false);
    expect(countDecisionElements(ledgerPath)).toBe(0);
  });

  it("AC-CHANNEL-SIDE-EFFECT-HELD: Decision count toBe before/after on space-form refuse", () => {
    const root = tempProject();
    activeBundle(root);
    const ledgerPath = fixtureLedgerPath(root);
    recordGateDecision(root, "C-GATE", {
      gate: "approve",
      decision: "permit",
      requirements: [{ id: "no-unresolved-ic-inv-clarification", required: true, present: true, blocking: false }],
    });
    const before = countDecisionElements(ledgerPath);
    expect(before).toBe(1);

    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record", "false"],
      root,
    );
    expect(result.status).toBe(1);
    expect(countDecisionElements(ledgerPath)).toBe(before);
  });

  it("AC-BARE-FLAG-STILL-TRUE: bare --record still records (means true)", () => {
    const root = tempProject();
    activeBundle(root);
    const ledgerPath = fixtureLedgerPath(root);
    expect(countDecisionElements(ledgerPath)).toBe(0);

    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record"],
      root,
    );
    expect(result.status).toBe(0);
    expect(countDecisionElements(ledgerPath)).toBe(1);
    expect(`${result.stdout}\n${result.stderr}`).not.toMatch(/does not accept a space-separated value/);
  });

  it("AC-WORKING-FORMS default-true half: --record=false writes no Decision", () => {
    const root = tempProject();
    activeBundle(root);
    const ledgerPath = fixtureLedgerPath(root);
    expect(countDecisionElements(ledgerPath)).toBe(0);

    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=false"],
      root,
    );
    // Counterweight: equals form must not be rejected as the space-form error.
    expect(result.status).toBe(0);
    expect(result.stdout).toMatch(/Decision:\s*permit|decision.*permit/i);
    expect(countDecisionElements(ledgerPath)).toBe(0);
  });

  it("AC-WORKING-FORMS default-true half: --record=true records a Decision", () => {
    const root = tempProject();
    activeBundle(root);
    const ledgerPath = fixtureLedgerPath(root);
    expect(countDecisionElements(ledgerPath)).toBe(0);

    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
      root,
    );
    expect(result.status).toBe(0);
    expect(countDecisionElements(ledgerPath)).toBe(1);
  });

  it("AC-WORKING-FORMS default-true half: --no-record writes no Decision", () => {
    const root = tempProject();
    activeBundle(root);
    const ledgerPath = fixtureLedgerPath(root);
    expect(countDecisionElements(ledgerPath)).toBe(0);

    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--no-record"],
      root,
    );
    expect(result.status).toBe(0);
    expect(countDecisionElements(ledgerPath)).toBe(0);
  });

  it("A31.4: gate approve|apply|archive|verdict still resolve under --record=false", () => {
    const root = tempProject();
    activeBundle(root);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));

    for (const gate of ["approve", "apply", "archive"] as const) {
      const result = runGateCli(
        [gate, "--change", "C-GATE", "--path", root, "--record=false", "--format", "json"],
        root,
      );
      expect(result.status).toBe(0);
      const body = JSON.parse(result.stdout);
      expect(body.ok).toBe(true);
      expect(body.gate).toBe(gate);
      // Must not be the bare parent usage text.
      expect(result.stdout).not.toMatch(/Usage:\s*ngrace gate/);
    }

    const verdict = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "pass", "--path", root, "--format", "json", ...ackFindingCliArgs(root, "C-GATE")],
      root,
    );
    expect(verdict.status).toBe(0);
    expect(JSON.parse(verdict.stdout).ok).toBe(true);
  });
});

describe("C-LEGIBLE-FAILURE T-002 — three exits and single classification", () => {
  it("construction: sole readLedgerWrapper export; former null-collapse helper absent from production source", async () => {
    const src = await Bun.file(path.join(import.meta.dir, "ledger.ts")).text();
    expect(src).not.toMatch(/\bwrapperFromLedger\b/);
    expect(src.match(/\bexport function readLedgerWrapper\b/g)?.length).toBe(1);
    // Shared prefix only — surface must not re-implement existsSync on the ledger path.
    const surfaceBody = src.slice(src.indexOf("export function readLedgerVerdictsSurface"));
    const untilNextExport = surfaceBody.slice(0, surfaceBody.indexOf("\nexport function", 1));
    expect(untilNextExport).toContain("readLedgerWrapper");
    expect(untilNextExport).not.toMatch(/existsSync\s*\(/);
  });

  it("AC-THREE-EXITS matrix: missing / unparseable / wrong-wrapper / clean", () => {
    // missing → absent-no-file
    {
      const root = tempProject();
      const bundle = activeBundle(root);
      expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
      const w = readLedgerWrapper(bundle, "C-GATE");
      expect(w).toEqual({ state: "absent-no-file" });
      expect(readLedgerVerdictsSurface(root, "C-GATE")).toEqual({ state: "absent-no-file" });
      expect(readLatestReviewVerdict(root, "C-GATE")).toEqual({ state: "absent" });
    }

    // unparseable → unreadable, not absent
    {
      const root = tempProject();
      const bundle = activeBundle(root);
      writeFileSync(path.join(bundle, "run-ledger.xml"), "not xml at all <<<");
      const w = readLedgerWrapper(bundle, "C-GATE");
      expect(w.state).toBe("unreadable");
      if (w.state === "unreadable") {
        // Exact code, not a parse-family regex: a drift to another parse code is a
        // contract change and must redden here (plan: "exact codes/details where stable").
        expect(w.code).toBe("xml.parse");
        expect(w.detail.length).toBeGreaterThan(0);
      }
      const surface = readLedgerVerdictsSurface(root, "C-GATE");
      expect(surface.state).toBe("unreadable");
      const latest = readLatestReviewVerdict(root, "C-GATE");
      expect(latest.state).toBe("invalid");
      // Discriminating: unreadable is not collapsed to absent.
      expect(latest.state).not.toBe("absent");
    }

    // wrong wrapper → unreadable ledger.bundle-id-mismatch, not absent
    {
      const root = tempProject();
      const bundle = activeBundle(root);
      writeFileSync(
        path.join(bundle, "run-ledger.xml"),
        `<NgraceRunLedger graceVersion="1.0"><C-OTHER><Verdicts><Verdict outcome="pass"/></Verdicts></C-OTHER></NgraceRunLedger>`,
      );
      const w = readLedgerWrapper(bundle, "C-GATE");
      expect(w).toEqual(
        expect.objectContaining({ state: "unreadable", code: "ledger.bundle-id-mismatch" }),
      );
      expect(readLedgerVerdictsSurface(root, "C-GATE")).toEqual(
        expect.objectContaining({ state: "unreadable", code: "ledger.bundle-id-mismatch" }),
      );
      expect(readLatestReviewVerdict(root, "C-GATE")).toEqual(
        expect.objectContaining({ state: "invalid", code: "ledger.bundle-id-mismatch" }),
      );
      const decisions = readGateDecisions(root, "C-GATE");
      expect(decisions).toEqual(
        expect.objectContaining({ state: "invalid", code: "ledger.bundle-id-mismatch" }),
      );
    }

    // clean → ok
    {
      const root = tempProject();
      const bundle = activeBundle(root);
      recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
      const w = readLedgerWrapper(bundle, "C-GATE");
      expect(w.state).toBe("ok");
      if (w.state === "ok") {
        expect(w.wrapper.tag).toBe("C-GATE");
      }
      expect(readLatestReviewVerdict(root, "C-GATE")).toEqual(
        expect.objectContaining({ state: "present" }),
      );
      expect(evaluateApplyGate(root, "C-GATE").decision).toBe("permit");
    }
  });

  it("AC-GATE-COMPAT: green fixture permit/refuse decisions are exact toBe pins", () => {
    const root = tempProject();
    activeBundle(root);
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("refuse");
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    expect(evaluateApplyGate(root, "C-GATE").decision).toBe("permit");
    expect(evaluateApproveGate(root, "C-GATE").decision).toBe("permit");
  });
});

function gitIn(root: string, args: string[]) {
  return spawnSync("git", args, { cwd: root, encoding: "utf8" });
}

function initGitWithCommit(root: string, message: string): string {
  const init = gitIn(root, ["init"]);
  if (init.status !== 0) throw new Error(init.stderr);
  gitIn(root, ["config", "user.email", "t@t"]);
  gitIn(root, ["config", "user.name", "t"]);
  gitIn(root, ["config", "commit.gpgsign", "false"]);
  gitIn(root, ["add", "-A"]);
  const committed = gitIn(root, ["commit", "-m", message]);
  if (committed.status !== 0) throw new Error(committed.stderr);
  return revParseHead(root);
}

function revParseHead(root: string): string {
  const parsed = gitIn(root, ["rev-parse", "HEAD"]);
  if (parsed.status !== 0) throw new Error(parsed.stderr);
  return parsed.stdout.trim();
}

function decisionOpenTags(ledgerXml: string): string[] {
  return [...ledgerXml.matchAll(/<Decision\b[^>]*>/g)].map((match) => match[0]);
}

describe("C-BUNDLE-BASE-REF T-001 record-base", () => {
  it("record-base: permitting recorded approve writes baseCommit equal to fixture HEAD", () => {
    const root = tempProject();
    activeBundle(root);
    const head = initGitWithCommit(root, "base");
    expect(head).toMatch(/^[0-9a-f]{40}$/);

    // CLI process cwd is this repository; --path is the fixture (gate path).
    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(result.status).toBe(0);

    const tags = decisionOpenTags(readFileSync(fixtureLedgerPath(root), "utf8"));
    expect(tags).toHaveLength(1);
    expect(tags[0]).toContain(`gate="approve"`);
    expect(tags[0]).toContain(`decision="permit"`);
    expect(tags[0]).toContain(`baseCommit="${head}"`);
  });
});

function decisionElements(ledgerXml: string): string[] {
  return [...ledgerXml.matchAll(/<Decision\b[\s\S]*?<\/Decision>/g)].map((match) => match[0]);
}

function twoRecordedApprovesWithMovedHead(): {
  root: string;
  commitA: string;
  commitB: string;
  firstDecisionBytes: string;
  ledgerAfterSecond: string;
} {
  const root = tempProject();
  activeBundle(root);
  const commitA = initGitWithCommit(root, "A");
  const first = runGateCli(
    ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
  );
  expect(first.status).toBe(0);
  const firstDecisionBytes = decisionElements(readFileSync(fixtureLedgerPath(root), "utf8"))[0]!;
  expect(firstDecisionBytes).toBeTruthy();

  writeFileSync(path.join(root, "moved-head.txt"), "B");
  gitIn(root, ["add", "moved-head.txt"]);
  const moved = gitIn(root, ["commit", "-m", "B"]);
  if (moved.status !== 0) throw new Error(moved.stderr);
  const commitB = revParseHead(root);
  expect(commitB).not.toBe(commitA);

  const second = runGateCli(
    ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
  );
  expect(second.status).toBe(0);
  return {
    root,
    commitA,
    commitB,
    firstDecisionBytes,
    ledgerAfterSecond: readFileSync(fixtureLedgerPath(root), "utf8"),
  };
}

function firstRecordedBaseCommit(root: string): string | undefined {
  const decisions = listGateDecisions(root, "C-GATE") as Array<{
    gate: string;
    decision: string;
    baseCommit?: string;
  }>;
  const found = decisions.find(
    (entry) =>
      entry.gate === "approve"
      && entry.decision === "permit"
      && Boolean(entry.baseCommit?.trim()),
  );
  return found?.baseCommit;
}

describe("C-BUNDLE-BASE-REF T-001 base-stable", () => {
  it("base-stable: reader returns A after second approve at B", () => {
    const { root, commitA } = twoRecordedApprovesWithMovedHead();
    expect(firstRecordedBaseCommit(root)).toBe(commitA);
  });

  it("base-stable: second Decision is not B", () => {
    const { commitB, ledgerAfterSecond } = twoRecordedApprovesWithMovedHead();
    const tags = decisionOpenTags(ledgerAfterSecond);
    expect(tags).toHaveLength(2);
    expect(tags[1]).not.toContain(`baseCommit="${commitB}"`);
  });

  it("base-stable: first Decision bytes are unchanged", () => {
    const { firstDecisionBytes, ledgerAfterSecond } = twoRecordedApprovesWithMovedHead();
    expect(decisionElements(ledgerAfterSecond)[0]).toBe(firstDecisionBytes);
  });
});

describe("C-BUNDLE-BASE-REF T-001 characterization", () => {
  it("record=false still writes no Decision", () => {
    const root = tempProject();
    activeBundle(root);
    initGitWithCommit(root, "base");
    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=false"],
    );
    expect(result.status).toBe(0);
    expect(existsSync(fixtureLedgerPath(root))).toBe(false);
  });

  it("refuse, apply, and archive omit baseCommit", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    initGitWithCommit(root, "base");
    const specPath = path.join(bundle, "spec.xml");
    writeFileSync(
      specPath,
      readFileSync(specPath, "utf8").replace(
        "</C-GATE>",
        `<Clarifications><Clarification><IC-EXAMPLE /></Clarification></Clarifications></C-GATE>`,
      ),
    );
    const refused = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(refused.status).toBe(1);
    recordReviewVerdict(root, "C-GATE", libraryBoundPass("C-GATE"));
    const applied = runGateCli(
      ["apply", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(applied.status).toBe(0);
    const archived = runGateCli(
      ["archive", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(archived.status).toBe(0);
    for (const tag of decisionOpenTags(readFileSync(fixtureLedgerPath(root), "utf8"))) {
      expect(tag).not.toContain("baseCommit=");
    }
  });

  it("unreadable HEAD at first observation omits the attribute", () => {
    const root = tempProject();
    activeBundle(root);
    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(result.status).toBe(0);
    const tag = decisionOpenTags(readFileSync(fixtureLedgerPath(root), "utf8"))[0]!;
    expect(tag).toContain(`decision="permit"`);
    expect(tag).not.toContain("baseCommit=");
    expect(tag).not.toContain('baseCommit=""');
  });

  it("planted baseCommit stays a valid permitting approve", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE>`
        + `<Decisions><Decision gate="approve" decision="permit" baseCommit="abc123def456" /></Decisions>`
        + `</C-GATE></NgraceRunLedger>`,
    );
    const listed = listGateDecisions(root, "C-GATE");
    expect(listed).toHaveLength(1);
    expect(listed[0]?.gate).toBe("approve");
    expect(listed[0]?.decision).toBe("permit");
    expect(listed[0]?.baseCommit).toBe("abc123def456");
    expect(readPermittingDecision(root, "C-GATE", "approve").state).toBe("permit");
  });

  it("evaluateApproveGate source does not spawn git", () => {
    const source = readFileSync(path.join(import.meta.dir, "core.ts"), "utf8");
    const fn = source.slice(source.indexOf("export function evaluateApproveGate"));
    const body = fn.slice(0, fn.indexOf("\nexport function", 1));
    expect(body).not.toMatch(/\bgit\b/);
    expect(body).not.toMatch(/spawnSync|Bun\.spawnSync|rev-parse/);
  });

  it("later permit may write the first observation when the first omitted it", () => {
    const root = tempProject();
    activeBundle(root);
    const first = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(first.status).toBe(0);
    expect(decisionOpenTags(readFileSync(fixtureLedgerPath(root), "utf8"))[0]).not.toContain("baseCommit=");
    const head = initGitWithCommit(root, "later");
    const second = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(second.status).toBe(0);
    const tags = decisionOpenTags(readFileSync(fixtureLedgerPath(root), "utf8"));
    expect(tags).toHaveLength(2);
    expect(tags[0]).not.toContain("baseCommit=");
    expect(tags[1]).toContain(`baseCommit="${head}"`);
    expect(firstRecordedBaseCommit(root)).toBe(head);
  });
});

function writeCloseEvidenceSpec(specPath: string, command: string): void {
  const spec = readFileSync(specPath, "utf8").replace(
    "<AcceptanceCriteria><Criterion>The fixture remains valid.</Criterion></AcceptanceCriteria>",
    `<AcceptanceCriteria><AC-CLOSE>Close bound.<CloseEvidence><Command>${command}</Command></CloseEvidence></AC-CLOSE></AcceptanceCriteria>`,
  );
  writeFileSync(specPath, spec);
}

/** Deterministic, byte-complete recursive path/type/SHA-256 snapshot; "" when absent. */
function recursiveBundleSnapshot(dir: string): string {
  if (!existsSync(dir)) return "";
  const lines: string[] = [];
  const walk = (abs: string, rel: string): void => {
    const stat = statSync(abs);
    if (stat.isDirectory()) {
      for (const name of readdirSync(abs).sort()) walk(path.join(abs, name), rel ? `${rel}/${name}` : name);
      return;
    }
    lines.push(`${rel}\tfile\t${createHash("sha256").update(readFileSync(abs)).digest("hex")}`);
  };
  walk(dir, "");
  return lines.sort().join("\n");
}

describe("CloseEvidence gate verdict evaluator", () => {
  it("evaluate-on-archive: applied archive records AC-* Exit 0 Result pass", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-GATE",
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-GATE");
    writeCloseEvidenceSpec(path.join(bundle, "spec.xml"), "true");
    const recorded = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "pass", "--path", root, "--format", "json", ...ackFindingCliArgs(root, "C-GATE")],
      root,
    );
    expect(recorded.status).toBe(0);
    const xml = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(xml).toMatch(/<AC-CLOSE>\s*<Exit>0<\/Exit>\s*<Result>pass<\/Result>\s*<\/AC-CLOSE>/);
  });

  it("refuse-pass-on-nonzero: outcome pass is refused and no Verdict is written", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-GATE",
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-GATE");
    writeCloseEvidenceSpec(path.join(bundle, "spec.xml"), "false");
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    const prior = existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null;
    const recorded = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "pass", "--path", root],
      root,
    );
    expect(recorded.status).not.toBe(0);
    if (prior === null) {
      expect(existsSync(ledgerPath)).toBe(false);
    } else {
      expect(readFileSync(ledgerPath, "utf8")).toBe(prior);
    }
  });

  it("records outcome fail after a non-zero CloseEvidence Command", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-GATE",
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-GATE");
    writeCloseEvidenceSpec(path.join(bundle, "spec.xml"), "false");
    const recorded = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "fail", "--path", root, "--format", "json"],
      root,
    );
    expect(recorded.status).toBe(0);
    const xml = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(xml).toMatch(/<AC-CLOSE>\s*<Exit>1<\/Exit>\s*<Result>fail<\/Result>\s*<\/AC-CLOSE>/);
  });

  it("skip-on-active: does not run CloseEvidence and writes empty children", () => {
    const root = tempProject();
    activeBundle(root);
    writeCloseEvidenceSpec(
      path.join(root, ARTIFACT_DIR, "changes", "active", "C-GATE", "spec.xml"),
      "false",
    );
    const recorded = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "pass", "--path", root, ...ackFindingCliArgs(root, "C-GATE")],
      root,
    );
    expect(recorded.status).toBe(0);
    const xml = readFileSync(path.join(root, ARTIFACT_DIR, "changes", "active", "C-GATE", "run-ledger.xml"), "utf8");
    expect(xml).toContain("<Verdict outcome=\"pass\"");
    expect(xml).not.toContain("<AC-CLOSE>");
  });

  it("applied spec still under active/ does not run CloseEvidence", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-GATE",
      location: "active",
      specStatus: "applied",
      planStatus: "applied",
    });
    writeCloseEvidenceSpec(
      path.join(root, ARTIFACT_DIR, "changes", "active", "C-GATE", "spec.xml"),
      "false",
    );
    const recorded = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "pass", "--path", root, ...ackFindingCliArgs(root, "C-GATE")],
      root,
    );
    expect(recorded.status).toBe(0);
    const xml = readFileSync(path.join(root, ARTIFACT_DIR, "changes", "active", "C-GATE", "run-ledger.xml"), "utf8");
    expect(xml).not.toContain("<AC-CLOSE>");
  });

  it("GATE_SUBCOMMANDS and gate lint review arg maps gain no new token", () => {
    const gateSrc = readFileSync(path.join(import.meta.dir, "command.ts"), "utf8");
    expect(gateSrc).toContain('const GATE_SUBCOMMANDS = new Set(["approve", "apply", "archive", "verdict"])');
    const keys = Object.keys(gateCommand.subCommands ?? {}).sort();
    expect(keys).toEqual(["apply", "approve", "archive", "verdict"]);
    const lintSrc = readFileSync(path.join(import.meta.dir, "../grace-lint.ts"), "utf8");
    expect(lintSrc).toMatch(/args:\s*\{/);
    expect(lintSrc).not.toMatch(/closeEvidence|close-evidence/);
    const reviewSrc = readFileSync(path.join(import.meta.dir, "../review/command.ts"), "utf8");
    expect(reviewSrc).not.toMatch(/closeEvidence|close-evidence/);
    expect(gateSrc).not.toMatch(/closeEvidence|close-evidence/);
  });
});

function sha256File(filePath: string): string {
  return createHash("sha256").update(readFileSync(filePath)).digest("hex");
}

function draftBundle(root: string, changeId = "C-GATE") {
  writeChangeBundleFixture(root, {
    changeId,
    location: "active",
    specStatus: "draft",
    planStatus: "draft",
  });
  return path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
}

describe("C-APPROVAL-FINGERPRINT T-001", () => {
  it("fingerprint-attr: permitting recorded approve of a draft spec writes fingerprint and artifact attributes", () => {
    const root = tempProject();
    const bundle = draftBundle(root);
    const specPath = path.join(bundle, "spec.xml");

    const result = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(result.status).toBe(0);

    const ledgerXml = readFileSync(fixtureLedgerPath(root), "utf8");
    const tag = decisionOpenTags(ledgerXml)[0]!;
    expect(tag).toContain(`gate="approve"`);
    expect(tag).toContain(`decision="permit"`);
    expect(tag).toContain(`fingerprint="${sha256File(specPath)}"`);
    expect(tag).toContain(`artifact="spec"`);
    const decisionXml = decisionElements(ledgerXml)[0]!;
    expect(decisionXml).not.toMatch(/<(fingerprint|artifact)[\s>]/);

    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE>`
        + `<Decisions><Decision gate="approve" decision="permit"><Fingerprint>abc</Fingerprint></Decision></Decisions>`
        + `</C-GATE></NgraceRunLedger>`,
    );
    const invalid = readGateDecisions(root, "C-GATE");
    expect(invalid.state).toBe("invalid");
    if (invalid.state === "invalid") {
      expect(invalid.code).toBe("ledger.invalid-decision");
    }

    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><C-GATE>`
        + `<Decisions><Decision gate="approve" decision="permit" /></Decisions>`
        + `</C-GATE></NgraceRunLedger>`,
    );
    const historical = listGateDecisions(root, "C-GATE");
    expect(historical).toHaveLength(1);
    expect(historical[0]?.gate).toBe("approve");
    expect(historical[0]?.decision).toBe("permit");

    const refuseRoot = tempProject();
    const refuseBundle = activeBundle(refuseRoot);
    writeFileSync(
      path.join(refuseBundle, "spec.xml"),
      readFileSync(path.join(refuseBundle, "spec.xml"), "utf8").replace(
        "</C-GATE>",
        `<Clarifications><Clarification><IC-EXAMPLE /></Clarification></Clarifications></C-GATE>`,
      ),
    );
    const refused = runGateCli(
      ["approve", "--change", "C-GATE", "--path", refuseRoot, "--record=true"],
    );
    expect(refused.status).toBe(1);
    for (const refuseTag of decisionOpenTags(readFileSync(fixtureLedgerPath(refuseRoot), "utf8"))) {
      expect(refuseTag).not.toContain("fingerprint=");
      expect(refuseTag).not.toContain("artifact=");
    }

    const applyRoot = tempProject();
    activeBundle(applyRoot);
    recordReviewVerdict(applyRoot, "C-GATE", libraryBoundPass("C-GATE"));
    const applied = runGateCli(
      ["apply", "--change", "C-GATE", "--path", applyRoot, "--record=true"],
    );
    expect(applied.status).toBe(0);
    for (const applyTag of decisionOpenTags(readFileSync(fixtureLedgerPath(applyRoot), "utf8"))) {
      expect(applyTag).not.toContain("fingerprint=");
      expect(applyTag).not.toContain("artifact=");
    }
  });

  it("per-decision: second approve stores its own plan fingerprint and does not copy the first", () => {
    const root = tempProject();
    const bundle = draftBundle(root);
    const specPath = path.join(bundle, "spec.xml");
    const planPath = path.join(bundle, "plan.xml");
    const head = initGitWithCommit(root, "A");

    const first = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(first.status).toBe(0);
    const ledgerAfterFirst = readFileSync(fixtureLedgerPath(root), "utf8");
    const firstDecisionBytes = decisionElements(ledgerAfterFirst)[0]!;
    const firstTags = decisionOpenTags(ledgerAfterFirst);
    expect(firstTags).toHaveLength(1);
    expect(firstTags[0]).toContain(`artifact="spec"`);
    expect(firstTags[0]).toContain(`fingerprint="${sha256File(specPath)}"`);
    expect(firstTags[0]).toContain(`baseCommit="${head}"`);

    const second = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(second.status).toBe(0);
    const ledgerAfterSecond = readFileSync(fixtureLedgerPath(root), "utf8");
    const decisions = decisionElements(ledgerAfterSecond);
    expect(decisions).toHaveLength(2);
    expect(decisions[0]).toBe(firstDecisionBytes);
    const secondTags = decisionOpenTags(ledgerAfterSecond);
    expect(secondTags[1]).toContain(`artifact="plan"`);
    expect(secondTags[1]).toContain(`fingerprint="${sha256File(planPath)}"`);
    expect(secondTags[1]).toContain(`baseCommit="${head}"`);
    expect(secondTags[1]).not.toContain(`fingerprint="${sha256File(specPath)}"`);
    expect(secondTags[0]).not.toBe(secondTags[1]);
  });

  it("status-write: draft root becomes approved with byte identity except that attribute", () => {
    const root = tempProject();
    const bundle = draftBundle(root);
    const specPath = path.join(bundle, "spec.xml");
    const planPath = path.join(bundle, "plan.xml");
    const specBefore = readFileSync(specPath, "utf8");
    const planBefore = readFileSync(planPath, "utf8");
    expect(specBefore).toContain('status="draft"');

    const recorded = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(recorded.status).toBe(0);
    const specAfter = readFileSync(specPath, "utf8");
    expect(specAfter).toBe(specBefore.replace('status="draft"', 'status="approved"'));
    expect(readFileSync(planPath, "utf8")).toBe(planBefore);

    const approvedRoot = tempProject();
    const approvedBundle = activeBundle(approvedRoot);
    const approvedSpecBefore = readFileSync(path.join(approvedBundle, "spec.xml"), "utf8");
    const approvedPlanBefore = readFileSync(path.join(approvedBundle, "plan.xml"), "utf8");
    expect(approvedSpecBefore).toContain('status="approved"');
    const reapprove = runGateCli(
      ["approve", "--change", "C-GATE", "--path", approvedRoot, "--record=true"],
    );
    expect(reapprove.status).toBe(0);
    expect(readFileSync(path.join(approvedBundle, "spec.xml"), "utf8")).toBe(approvedSpecBefore);
    expect(readFileSync(path.join(approvedBundle, "plan.xml"), "utf8")).toBe(approvedPlanBefore);

    const applyRoot = tempProject();
    const applyBundle = activeBundle(applyRoot);
    const applySpecBefore = readFileSync(path.join(applyBundle, "spec.xml"), "utf8");
    const applyPlanBefore = readFileSync(path.join(applyBundle, "plan.xml"), "utf8");
    recordReviewVerdict(applyRoot, "C-GATE", libraryBoundPass("C-GATE"));
    const applied = runGateCli(
      ["apply", "--change", "C-GATE", "--path", applyRoot, "--record=true"],
    );
    expect(applied.status).toBe(0);
    expect(readFileSync(path.join(applyBundle, "spec.xml"), "utf8")).toBe(applySpecBefore);
    expect(readFileSync(path.join(applyBundle, "plan.xml"), "utf8")).toBe(applyPlanBefore);
    const archived = runGateCli(
      ["archive", "--change", "C-GATE", "--path", applyRoot, "--record=true"],
    );
    expect(archived.status).toBe(0);
    expect(readFileSync(path.join(applyBundle, "spec.xml"), "utf8")).toBe(applySpecBefore);
    expect(readFileSync(path.join(applyBundle, "plan.xml"), "utf8")).toBe(applyPlanBefore);

    const dryRoot = tempProject();
    const dryBundle = draftBundle(dryRoot);
    const drySpecBefore = readFileSync(path.join(dryBundle, "spec.xml"), "utf8");
    const dryPlanBefore = readFileSync(path.join(dryBundle, "plan.xml"), "utf8");
    const dryRun = runGateCli(
      ["approve", "--change", "C-GATE", "--path", dryRoot, "--record=false"],
    );
    expect(dryRun.status).toBe(0);
    expect(readFileSync(path.join(dryBundle, "spec.xml"), "utf8")).toBe(drySpecBefore);
    expect(readFileSync(path.join(dryBundle, "plan.xml"), "utf8")).toBe(dryPlanBefore);
    expect(existsSync(fixtureLedgerPath(dryRoot))).toBe(false);
  });
});

function plantUnresolvedIc(specPath: string): void {
  writeFileSync(
    specPath,
    readFileSync(specPath, "utf8").replace(
      "</C-GATE>",
      `<Clarifications><Clarification><IC-EXAMPLE /></Clarification></Clarifications></C-GATE>`,
    ),
  );
}

describe("C-APPROVAL-FINGERPRINT T-002", () => {
  it("force-hatch: force plus reason records a forced permit, writes status, and fingerprints", () => {
    const root = tempProject();
    const bundle = draftBundle(root);
    const specPath = path.join(bundle, "spec.xml");
    plantUnresolvedIc(specPath);
    const specBefore = readFileSync(specPath, "utf8");
    expect(evaluateApproveGate(root, "C-GATE").decision).toBe("refuse");

    const forced = runGateCli([
      "approve",
      "--change",
      "C-GATE",
      "--path",
      root,
      "--force",
      "--reason",
      "operator override",
    ]);
    expect(forced.status).toBe(0);
    const specAfter = readFileSync(specPath, "utf8");
    expect(specAfter).toBe(specBefore.replace('status="draft"', 'status="approved"'));
    const ledgerXml = readFileSync(fixtureLedgerPath(root), "utf8");
    const tag = decisionOpenTags(ledgerXml)[0]!;
    expect(tag).toContain(`decision="permit"`);
    expect(tag).toContain(`forced="true"`);
    expect(tag).toContain(`reason="operator override"`);
    expect(tag).toContain(`fingerprint="${sha256File(specPath)}"`);
    expect(tag).toContain(`artifact="spec"`);
    const decisionXml = decisionElements(ledgerXml)[0]!;
    expect(decisionXml).toContain('id="no-unresolved-ic-inv-clarification"');
    expect(decisionXml).toContain('present="false"');

    const missingReasonRoot = tempProject();
    const missingReasonBundle = draftBundle(missingReasonRoot);
    plantUnresolvedIc(path.join(missingReasonBundle, "spec.xml"));
    const missingSpecBefore = readFileSync(path.join(missingReasonBundle, "spec.xml"), "utf8");
    const missing = runGateCli([
      "approve",
      "--change",
      "C-GATE",
      "--path",
      missingReasonRoot,
      "--force",
    ]);
    expect(missing.status).toBe(1);
    expect(readFileSync(path.join(missingReasonBundle, "spec.xml"), "utf8")).toBe(missingSpecBefore);
    expect(existsSync(fixtureLedgerPath(missingReasonRoot))).toBe(false);

    const emptyReason = runGateCli([
      "approve",
      "--change",
      "C-GATE",
      "--path",
      missingReasonRoot,
      "--force",
      "--reason",
      "",
    ]);
    expect(emptyReason.status).toBe(1);
    expect(readFileSync(path.join(missingReasonBundle, "spec.xml"), "utf8")).toBe(missingSpecBefore);
    expect(existsSync(fixtureLedgerPath(missingReasonRoot))).toBe(false);

    const cleanRoot = tempProject();
    draftBundle(cleanRoot);
    const clean = runGateCli([
      "approve",
      "--change",
      "C-GATE",
      "--path",
      cleanRoot,
      "--record=true",
    ]);
    expect(clean.status).toBe(0);
    const cleanTag = decisionOpenTags(readFileSync(fixtureLedgerPath(cleanRoot), "utf8"))[0]!;
    expect(cleanTag).toContain(`decision="permit"`);
    expect(cleanTag).not.toContain("forced=");
    expect(cleanTag).not.toContain("reason=");

    const spaceRoot = tempProject();
    draftBundle(spaceRoot);
    const space = runGateCli([
      "approve",
      "--change",
      "C-GATE",
      "--path",
      spaceRoot,
      "--force",
      "true",
      "--reason",
      "because",
    ]);
    expect(space.status).toBe(1);
    const spaceLines = space.stderr.replace(/\n$/, "").split("\n");
    expect(spaceLines.length).toBe(1);
    expect(spaceLines[0]).toContain("--force=true");
    expect(spaceLines[0]).toContain("--no-force");
    expect(spaceLines[0]).toContain("bare `--force` means true");
    expect(existsSync(fixtureLedgerPath(spaceRoot))).toBe(false);

    for (const status of ["applied", "superseded", "cancelled", "rejected"] as const) {
      const terminalRoot = tempProject();
      writeChangeBundleFixture(terminalRoot, {
        changeId: "C-GATE",
        location: "active",
        specStatus: status,
        planStatus: status,
      });
      const terminalSpec = path.join(
        terminalRoot,
        ARTIFACT_DIR,
        "changes",
        "active",
        "C-GATE",
        "spec.xml",
      );
      plantUnresolvedIc(terminalSpec);
      const terminalBefore = readFileSync(terminalSpec, "utf8");
      const terminal = runGateCli([
        "approve",
        "--change",
        "C-GATE",
        "--path",
        terminalRoot,
        "--force",
        "--reason",
        "because",
      ]);
      expect(terminal.status).toBe(0);
      expect(readFileSync(terminalSpec, "utf8")).toBe(terminalBefore);
    }

    const artifactRoot = tempProject();
    const artifactBundle = draftBundle(artifactRoot);
    const artifactSpec = path.join(artifactBundle, "spec.xml");
    const artifactPlan = path.join(artifactBundle, "plan.xml");
    const specBeforeOverride = readFileSync(artifactSpec, "utf8");
    const planBeforeOverride = readFileSync(artifactPlan, "utf8");
    const override = runGateCli([
      "approve",
      "--change",
      "C-GATE",
      "--path",
      artifactRoot,
      "--artifact",
      "plan",
    ]);
    expect(override.status).toBe(0);
    expect(readFileSync(artifactSpec, "utf8")).toBe(specBeforeOverride);
    expect(readFileSync(artifactPlan, "utf8")).toBe(
      planBeforeOverride.replace('status="draft"', 'status="approved"'),
    );
    expect(decisionOpenTags(readFileSync(fixtureLedgerPath(artifactRoot), "utf8"))[0]).toContain(
      `artifact="plan"`,
    );
  });

  it("evaluateApproveGate stays clarification-only and git-free", () => {
    const source = readFileSync(path.join(import.meta.dir, "core.ts"), "utf8");
    const fn = source.slice(source.indexOf("export function evaluateApproveGate"));
    const body = fn.slice(0, fn.indexOf("\nexport function", 1));
    expect(body).not.toMatch(/\bgit\b/);
    expect(body).not.toMatch(/spawnSync|Bun\.spawnSync|rev-parse/);
    expect(body).not.toMatch(/fingerprint|writeFileSync|createHash/);
  });
});

describe("C-SUPERSEDE-COMMAND T-001", () => {
  it("f114-single-quoted-write: single-quoted draft becomes approved preserving quote", () => {
    const root = tempProject();
    const bundle = draftBundle(root);
    const specPath = path.join(bundle, "spec.xml");
    const planPath = path.join(bundle, "plan.xml");
    const specBefore = readFileSync(specPath, "utf8").replace('status="draft"', "status='draft'");
    writeFileSync(specPath, specBefore);
    expect(specBefore).toContain("status='draft'");
    const planBefore = readFileSync(planPath, "utf8");

    const recorded = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(recorded.status).toBe(0);
    const specAfter = readFileSync(specPath, "utf8");
    expect(specAfter).toBe(specBefore.replace("status='draft'", "status='approved'"));
    expect(readFileSync(planPath, "utf8")).toBe(planBefore);
  });

  it("f114-throw-on-miss: grammar-parsed draft with unlocatable needle throws", () => {
    const root = tempProject();
    const bundle = draftBundle(root);
    const specPath = path.join(bundle, "spec.xml");
    const specBefore = readFileSync(specPath, "utf8").replace('status="draft"', 'status = "draft"');
    writeFileSync(specPath, specBefore);

    expect(() => stampApproveArtifact(root, "C-GATE")).toThrow(GraceCommandError);
    expect(existsSync(fixtureLedgerPath(root))).toBe(false);

    const recorded = runGateCli(
      ["approve", "--change", "C-GATE", "--path", root, "--record=true"],
    );
    expect(recorded.status).not.toBe(0);
    expect(existsSync(fixtureLedgerPath(root))).toBe(false);
    expect(recorded.stdout + recorded.stderr).not.toMatch(/fingerprint="/);
  });
});

function runSupersedeCli(args: string[]) {
  return spawnSync("bun", ["run", GRACE_BIN, "supersede", ...args], {
    cwd: REPO_ROOT,
    encoding: "utf8",
    env: process.env,
  });
}

function changeArtifactPath(root: string, changeId: string, fileName: string): string | undefined {
  for (const location of ["active", "archive"] as const) {
    const filePath = path.join(root, ARTIFACT_DIR, "changes", location, changeId, fileName);
    if (existsSync(filePath)) return filePath;
  }
  return undefined;
}

describe("C-SUPERSEDE-COMMAND T-004", () => {
  it("surgical-write: spec and plan status become superseded for both quote styles", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-OLD",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    writeChangeBundleFixture(root, {
      changeId: "C-OLD-2",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    runSupersedeCli(["--change", "C-OLD", "--replacement", "C-OLD-2", "--path", root]);
    const specAfter = readFileSync(changeArtifactPath(root, "C-OLD", "spec.xml")!, "utf8");
    expect(specAfter).toMatch(/\bstatus="superseded"/);
    const planAfter = readFileSync(changeArtifactPath(root, "C-OLD", "plan.xml")!, "utf8");
    expect(planAfter).toMatch(/\bstatus="superseded"/);

    const quoted = tempProject();
    writeChangeBundleFixture(quoted, {
      changeId: "C-OLD",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    writeChangeBundleFixture(quoted, {
      changeId: "C-OLD-2",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    const quotedSpecPath = path.join(quoted, ARTIFACT_DIR, "changes", "active", "C-OLD", "spec.xml");
    writeFileSync(
      quotedSpecPath,
      readFileSync(quotedSpecPath, "utf8").replace('status="draft"', "status='draft'"),
    );
    runSupersedeCli(["--change", "C-OLD", "--replacement", "C-OLD-2", "--path", quoted]);
    expect(readFileSync(changeArtifactPath(quoted, "C-OLD", "spec.xml")!, "utf8")).toMatch(
      /\bstatus='superseded'/,
    );

    const approved = tempProject();
    writeChangeBundleFixture(approved, {
      changeId: "C-OLD",
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
    });
    writeChangeBundleFixture(approved, {
      changeId: "C-OLD-2",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    runSupersedeCli(["--change", "C-OLD", "--replacement", "C-OLD-2", "--path", approved]);
    expect(readFileSync(changeArtifactPath(approved, "C-OLD", "spec.xml")!, "utf8")).toMatch(
      /\bstatus="superseded"/,
    );
  });
});

describe("C-SUPERSEDE-INTEGRATION-CLOSE-1-82073AAC T-003 gates transaction/refusal matrix", () => {
  const ACTIVE_DIR = path.join(ARTIFACT_DIR, "changes", "active");
  const ARCHIVE_DIR = path.join(ARTIFACT_DIR, "changes", "archive");

  /**
   * Union-key recursive path/type/symlink/byte snapshot of the whole disposable
   * project outside `.git`. Directory entries are recorded as markers so an added
   * empty directory cannot hide; symlinks record their target via lstat/readlink.
   */
  function snapshotProject(root: string): Map<string, string> {
    const out = new Map<string, string>();
    const walk = (abs: string, rel: string): void => {
      for (const entry of readdirSync(abs, { withFileTypes: true })) {
        if (entry.name === ".git") continue;
        const childAbs = path.join(abs, entry.name);
        const childRel = rel ? `${rel}/${entry.name}` : entry.name;
        const stat = lstatSync(childAbs);
        if (stat.isSymbolicLink()) out.set(childRel, `SYMLINK:${readlinkSync(childAbs)}`);
        else if (stat.isDirectory()) { out.set(childRel, "DIR"); walk(childAbs, childRel); }
        else out.set(childRel, `FILE:${createHash("sha256").update(readFileSync(childAbs)).digest("hex")}`);
      }
    };
    walk(root, "");
    return out;
  }
  /** Compare two snapshots over the union of keys: additions, deletions, and changes all surface. */
  function projectDelta(before: Map<string, string>, after: Map<string, string>): string[] {
    const keys = [...new Set([...before.keys(), ...after.keys()])].sort();
    const delta: string[] = [];
    for (const key of keys) {
      const prior = before.get(key);
      const next = after.get(key);
      if (prior === next) continue;
      delta.push(prior === undefined ? `ADDED ${key}` : next === undefined ? `DELETED ${key}` : `CHANGED ${key}`);
    }
    return delta;
  }

  it("positive: the gates transaction archives a predecessor with one discarded and never cleans an explicit replacement", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, { changeId: "C-GT-OLD", location: "active", specStatus: "draft", planStatus: "draft" });
    writeChangeBundleFixture(root, { changeId: "C-GT-OLD-2", location: "active", specStatus: "draft", planStatus: "draft" });
    const bundle = path.join(root, ACTIVE_DIR, "C-GT-OLD");
    advanceCursor(root, "C-GT-OLD", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    advanceCursor(root, "C-GT-OLD", { task: "T-001", kind: "progress" });
    supersedeChangeBundle(root, "C-GT-OLD", { kind: "explicit", id: "C-GT-OLD-2" });
    const archived = path.join(root, ARCHIVE_DIR, "C-GT-OLD");
    expect(existsSync(bundle)).toBe(false);
    expect(existsSync(archived)).toBe(true);
    expect(readFileSync(path.join(archived, "spec.xml"), "utf8")).toMatch(/\bstatus="superseded"/);
    expect(readFileSync(path.join(archived, "spec.xml"), "utf8")).toContain("<Replacement>C-GT-OLD-2</Replacement>");
    expect(readFileSync(path.join(archived, "plan.xml"), "utf8")).toMatch(/\bstatus="superseded"/);
    expect(readFileSync(path.join(archived, "plan.xml"), "utf8")).toContain("<Replacement>C-GT-OLD-2</Replacement>");
    expect(listLedgerEvents(archived).map((event) => `${event.id}:${event.kind}`)).toEqual(["1:opened", "2:progress", "3:discarded"]);
    expect(readdirSync(path.join(archived, "run"))).toEqual([]);
    // The explicit replacement is never cleaned: it stays active and unarchived.
    expect(existsSync(path.join(root, ACTIVE_DIR, "C-GT-OLD-2"))).toBe(true);
    expect(existsSync(path.join(root, ARCHIVE_DIR, "C-GT-OLD-2"))).toBe(false);
  });

  it("negative: a missing explicit replacement refuses before any write with a byte-identical project tree", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, { changeId: "C-GT-REF", location: "active", specStatus: "draft", planStatus: "draft" });
    const before = snapshotProject(root);
    expect(() => supersedeChangeBundle(root, "C-GT-REF", { kind: "explicit", id: "C-GT-REF-2" }))
      .toThrow(/missing as a directory/);
    expect(projectDelta(before, snapshotProject(root))).toEqual([]);
  });

  it("negative: an existing implicit successor refuses before any fold and leaves the competitor bytes intact", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, { changeId: "C-GT-IMP", location: "active", specStatus: "draft", planStatus: "draft" });
    const resolved = resolveSpecMint({ supersedes: "C-GT-IMP", timestamp: "2026-09-19T00:00:00Z", branch: "b" }, root);
    mkdirSync(path.join(root, ACTIVE_DIR, resolved.id), { recursive: true });
    writeFileSync(path.join(root, ACTIVE_DIR, resolved.id, "spec.xml"), "<competitor/>\n");
    const before = snapshotProject(root);
    expect(() =>
      supersedeChangeBundle(root, "C-GT-IMP", { kind: "mint", id: resolved.id, mint: () => mintResolvedBundle(root, resolved).acquired }),
    ).toThrow(/already exists/);
    expect(projectDelta(before, snapshotProject(root))).toEqual([]);
    expect(readFileSync(path.join(root, ACTIVE_DIR, resolved.id, "spec.xml"), "utf8")).toBe("<competitor/>\n");
  });

  it("negative: an archive-destination conflict refuses before any fold with a byte-identical project tree", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, { changeId: "C-GT-CONF", location: "active", specStatus: "draft", planStatus: "draft" });
    writeChangeBundleFixture(root, { changeId: "C-GT-CONF-2", location: "active", specStatus: "draft", planStatus: "draft" });
    writeChangeBundleFixture(root, { changeId: "C-GT-CONF", location: "archive", specStatus: "superseded", planStatus: "superseded" });
    const before = snapshotProject(root);
    expect(() => supersedeChangeBundle(root, "C-GT-CONF", { kind: "explicit", id: "C-GT-CONF-2" }))
      .toThrow(/Archive destination already exists/);
    expect(projectDelta(before, snapshotProject(root))).toEqual([]);
  });

  it("discrimination: the whole-project union-key snapshot reddens on empty-directory, symlink, and archive-side mutations", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, { changeId: "C-GT-MUT", location: "active", specStatus: "draft", planStatus: "draft" });
    // Green direction: a clean refusal leaves the whole project byte-identical.
    const before = snapshotProject(root);
    expect(() => supersedeChangeBundle(root, "C-GT-MUT", { kind: "explicit", id: "C-GT-MUT-2" }))
      .toThrow(/missing as a directory/);
    expect(projectDelta(before, snapshotProject(root))).toEqual([]);
    // A planted empty directory is invisible to a file-only walk that skips directory entries.
    mkdirSync(path.join(root, "planted-empty-dir"), { recursive: true });
    expect(projectDelta(before, snapshotProject(root)), "an added empty directory is visible").toEqual(["ADDED planted-empty-dir"]);
    rmSync(path.join(root, "planted-empty-dir"), { recursive: true, force: true });
    // A planted symlink is only visible when identity and target come from lstat/readlink.
    symlinkSync("src/example.ts", path.join(root, "planted-link"));
    expect(projectDelta(before, snapshotProject(root)), "an added symlink records its target").toEqual(["ADDED planted-link"]);
    rmSync(path.join(root, "planted-link"), { force: true });
    // An archive-side write is invisible to a snapshot scoped to active/ alone.
    mkdirSync(path.join(root, ARCHIVE_DIR), { recursive: true });
    writeFileSync(path.join(root, ARCHIVE_DIR, "planted-archive.txt"), "planted\n");
    expect(projectDelta(before, snapshotProject(root)), "an archive-side write is visible").toEqual([
      `ADDED ${ARCHIVE_DIR}/planted-archive.txt`,
    ]);
  });
});

describe("C-BOUND-VERDICT T-001 persist digest", () => {
  it("persist-unbound: pass with no snapshotDigest throws and writes nothing", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    expect(() => recordReviewVerdict(root, "C-GATE", { outcome: "pass" })).toThrow(GraceCommandError);
    expect(existsSync(ledgerPath)).toBe(false);
  });

  it("persist-unbound: empty finding set still refuses pass without snapshotDigest", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    expect(() =>
      recordReviewVerdict(root, "C-GATE", { outcome: "pass", findings: [] } as ReviewVerdictRecord),
    ).toThrow(GraceCommandError);
    expect(existsSync(ledgerPath)).toBe(false);
  });

  it("identity-stale-digest: pass with Finding children and a non-canonical digest throws and writes nothing", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    const findings = [
      {
        code: "review.scope-outside-write-scope",
        file: "src/example.ts",
        findingId: "aaaaaaaaaaaaaaaa",
        severity: "error",
        ruleId: "scope-outside-write-scope",
        anchorOrHunkKey: "src/example.ts",
        message: "outside ObservedWriteScope",
      },
    ];
    expect(() =>
      recordReviewVerdict(root, "C-GATE", {
        outcome: "pass",
        snapshotDigest: "0".repeat(64),
        findings,
      } as ReviewVerdictRecord),
    ).toThrow(GraceCommandError);
    expect(existsSync(ledgerPath)).toBe(false);
  });

  it("cli-invokes-review: gate verdict pass records snapshotDigest of runReview displayed findings", () => {
    const root = tempProject();
    activeBundle(root);
    const recorded = runGateCli(
      ["verdict", "--change", "C-GATE", "--outcome", "pass", "--path", root, "--format", "json", ...ackFindingCliArgs(root, "C-GATE")],
      root,
    );
    expect(recorded.status).toBe(0);
    const stored = listReviewVerdicts(root, "C-GATE")[0] as { snapshotDigest?: string } | undefined;
    expect(stored?.snapshotDigest).toBeDefined();
    const displayed = runReview(root, { changeId: "C-GATE" }).findings;
    const canonical = createHash("sha256")
      .update(
        JSON.stringify({
          changeId: "C-GATE",
          findings: [...displayed]
            .sort(
              (a, b) =>
                a.code.localeCompare(b.code)
                || a.file.localeCompare(b.file)
                || a.findingId.localeCompare(b.findingId),
            )
            .map((f) => ({ code: f.code, file: f.file, findingId: f.findingId })),
        }),
      )
      .digest("hex");
    expect(stored?.snapshotDigest).toBe(canonical);
  });
});

describe("C-BOUND-VERDICT T-002 Ack matching", () => {
  it("persist-ack-mismatch: extra, missing, or unknown Ack findingIds throw and write nothing", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    const findings = [
      {
        code: "review.scope-outside-write-scope",
        file: "src/example.ts",
        findingId: "aaaaaaaaaaaaaaaa",
        severity: "error",
        ruleId: "scope-outside-write-scope",
        anchorOrHunkKey: "src/example.ts",
        message: "outside ObservedWriteScope",
      },
    ];
    const snapshotDigest = computeVerdictSnapshotDigest("C-GATE", findings);
    expect(() =>
      recordReviewVerdict(root, "C-GATE", {
        outcome: "pass",
        snapshotDigest,
        findings,
        acks: [],
      }),
    ).toThrow(GraceCommandError);
    expect(existsSync(ledgerPath)).toBe(false);

    expect(() =>
      recordReviewVerdict(root, "C-GATE", {
        outcome: "pass",
        snapshotDigest,
        findings,
        acks: [{ findingId: "bbbbbbbbbbbbbbbb", snapshotDigest }],
      }),
    ).toThrow(GraceCommandError);
    expect(existsSync(ledgerPath)).toBe(false);
  });

  it("persist-ack-mismatch: CLI ack-finding that does not match the displayed set one-for-one", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    const recorded = runGateCli(
      [
        "verdict",
        "--change",
        "C-GATE",
        "--outcome",
        "pass",
        "--path",
        root,
        "--ack-finding",
        "ffffffffffffffff",
      ],
      root,
    );
    expect(recorded.status).not.toBe(0);
    expect(`${recorded.stderr}${recorded.stdout}`).not.toMatch(/Unknown argument|Unrecognized argument/i);
    expect(existsSync(ledgerPath)).toBe(false);
  });

  it("identity-cross-change: findingId from another change's same code and file does not satisfy pass", () => {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId: "C-OTHER",
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
    });
    const bundle = activeBundle(root);
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    const findings = [
      {
        code: "review.scope-outside-write-scope",
        file: "src/example.ts",
        findingId: "cccccccccccccccc",
        severity: "error",
        ruleId: "scope-outside-write-scope",
        anchorOrHunkKey: "src/example.ts",
        message: "outside ObservedWriteScope",
      },
    ];
    const digestOther = computeVerdictSnapshotDigest("C-OTHER", findings);
    const digestHere = computeVerdictSnapshotDigest("C-GATE", findings);
    expect(() =>
      recordReviewVerdict(root, "C-GATE", {
        outcome: "pass",
        snapshotDigest: digestHere,
        findings,
        acks: [{ findingId: "cccccccccccccccc", snapshotDigest: digestOther }],
      }),
    ).toThrow(GraceCommandError);
    expect(existsSync(ledgerPath)).toBe(false);
  });
});

describe("C-BOUND-VERDICT T-003 apply binding", () => {
  function plantNewestVerdict(bundle: string, verdictXml: string): void {
    const ledgerPath = path.join(bundle, "run-ledger.xml");
    let xml = readFileSync(ledgerPath, "utf8");
    xml = xml.replace(/<Verdict\b[^>]*(?:\/>|>[\s\S]*?<\/Verdict>)/, verdictXml);
    writeFileSync(ledgerPath, xml);
  }

  it("apply-unbound: evaluateApplyGate refuses pass without snapshotDigest as gate.apply.unbound-pass", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", { outcome: "fail" });
    plantNewestVerdict(bundle, `<Verdict outcome="pass" />`);
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((issue) => issue.code === "gate.apply.unbound-pass")).toBe(true);
    expect(result.issues.some((issue) => issue.code === "gate.apply.no-verdict")).toBe(false);
  });

  it("apply-digest-mismatch: evaluateApplyGate refuses when snapshotDigest does not match Finding children", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", { outcome: "fail" });
    plantNewestVerdict(
      bundle,
      `<Verdict outcome="pass" snapshotDigest="${"0".repeat(64)}"><Finding code="review.scope-outside-write-scope" file="src/example.ts" findingId="aaaaaaaaaaaaaaaa" severity="error" ruleId="scope-outside-write-scope" anchorOrHunkKey="src/example.ts" message="outside" /></Verdict>`,
    );
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((issue) => issue.code === "gate.apply.digest-mismatch")).toBe(true);
  });

  it("apply-unacked: evaluateApplyGate refuses when Ack children are not the persisted findingId set", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    recordReviewVerdict(root, "C-GATE", { outcome: "fail" });
    const findings = [
      {
        code: "review.write-evidence-outside-scope",
        file: "src/example.ts",
        findingId: "dddddddddddddddd",
      },
    ];
    const snapshotDigest = computeVerdictSnapshotDigest("C-GATE", findings);
    plantNewestVerdict(
      bundle,
      `<Verdict outcome="pass" snapshotDigest="${snapshotDigest}"><Finding code="review.write-evidence-outside-scope" file="src/example.ts" findingId="dddddddddddddddd" severity="error" ruleId="write-evidence-outside-scope" anchorOrHunkKey="src/example.ts" message="undeclared write" /></Verdict>`,
    );
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((issue) => issue.code === "gate.apply.ack-mismatch")).toBe(true);
  });
});

describe("C-BOUND-VERDICT T-004 apply refuses fail", () => {
  it("apply-fail-refuses: evaluateApplyGate refuses newest outcome fail as gate.apply.outcome-fail", () => {
    const root = tempProject();
    activeBundle(root);
    recordReviewVerdict(root, "C-GATE", { outcome: "fail" });
    const result = evaluateApplyGate(root, "C-GATE");
    expect(result.decision).toBe("refuse");
    expect(result.issues.some((issue) => issue.code === "gate.apply.outcome-fail")).toBe(true);
  });
});

describe("C-AMENDMENT-COUNT T-001 readAmendmentInstrument", () => {
  function writeLedgerDecisions(root: string, changeId: string, inner: string) {
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
    mkdirSync(bundle, { recursive: true });
    writeFileSync(
      path.join(bundle, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><${changeId}><Decisions>${inner}</Decisions></${changeId}></NgraceRunLedger>`,
    );
  }

  function writeBundleSpec(
    root: string,
    changeId: string,
    location: "active" | "archive",
    inner: string,
  ) {
    writeChangeBundleFixture(root, {
      changeId,
      location,
      specStatus: location === "archive" ? "superseded" : "approved",
      planStatus: location === "archive" ? "superseded" : "approved",
    });
    const specPath = path.join(root, ARTIFACT_DIR, "changes", location, changeId, "spec.xml");
    const spec = readFileSync(specPath, "utf8");
    writeFileSync(specPath, spec.replace(`<${changeId}>`, `<${changeId}>${inner}`));
  }

  it("no-op re-approve of the same spec fingerprint is 0", () => {
    const root = tempProject();
    activeBundle(root);
    writeLedgerDecisions(
      root,
      "C-GATE",
      `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`,
    );
    expect(readAmendmentInstrument(root, "C-GATE")).toEqual({
      reRatificationCount: 0,
      supersedeChainDepth: 0,
    });
  });

  it("distinct spec fingerprints A then B is 1", () => {
    const root = tempProject();
    activeBundle(root);
    writeLedgerDecisions(
      root,
      "C-GATE",
      `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="bbb" artifact="spec"></Decision>`,
    );
    expect(readAmendmentInstrument(root, "C-GATE").reRatificationCount).toBe(1);
  });

  it("two unnamed unfingerprinted permits are 0, and a later named fingerprinted permit stays baseline 0", () => {
    const root = tempProject();
    activeBundle(root);
    writeLedgerDecisions(
      root,
      "C-GATE",
      `<Decision gate="approve" decision="permit"></Decision>`
      + `<Decision gate="approve" decision="permit"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`,
    );
    expect(readAmendmentInstrument(root, "C-GATE").reRatificationCount).toBe(0);
  });

  it("first spec approve plus first plan approve is 0", () => {
    const root = tempProject();
    activeBundle(root);
    writeLedgerDecisions(
      root,
      "C-GATE",
      `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="bbb" artifact="plan"></Decision>`,
    );
    expect(readAmendmentInstrument(root, "C-GATE").reRatificationCount).toBe(0);
  });

  it("three fingerprinted spec permits A, B, A is 2 not 1", () => {
    const root = tempProject();
    activeBundle(root);
    writeLedgerDecisions(
      root,
      "C-GATE",
      `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="bbb" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`,
    );
    expect(readAmendmentInstrument(root, "C-GATE").reRatificationCount).toBe(2);
  });

  it("unreadable Decisions reports reRatificationCount 0", () => {
    const root = tempProject();
    const bundle = activeBundle(root);
    writeFileSync(path.join(bundle, "run-ledger.xml"), "not xml at all <<<");
    expect(readAmendmentInstrument(root, "C-GATE").reRatificationCount).toBe(0);
  });

  it("refuse, apply, archive, empty fingerprint, and unnamed-artifact do not participate or reset", () => {
    const root = tempProject();
    activeBundle(root);
    writeLedgerDecisions(
      root,
      "C-GATE",
      `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="refuse" fingerprint="zzz" artifact="spec"></Decision>`
      + `<Decision gate="apply" decision="permit" fingerprint="zzz" artifact="spec"></Decision>`
      + `<Decision gate="archive" decision="permit" fingerprint="zzz" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="zzz"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="bbb" artifact="spec"></Decision>`,
    );
    expect(readAmendmentInstrument(root, "C-GATE").reRatificationCount).toBe(1);
  });

  it("forced permits participate when they carry artifact and fingerprint", () => {
    const root = tempProject();
    activeBundle(root);
    writeLedgerDecisions(
      root,
      "C-GATE",
      `<Decision gate="approve" decision="permit" fingerprint="aaa" artifact="spec"></Decision>`
      + `<Decision gate="approve" decision="permit" fingerprint="bbb" artifact="spec" forced="true" reason="operator"></Decision>`,
    );
    expect(readAmendmentInstrument(root, "C-GATE").reRatificationCount).toBe(1);
  });

  it("chain depth is 0 with no predecessor, 1 with one, and 2 on a two-step tip", () => {
    const root = tempProject();
    writeBundleSpec(root, "C-CHAIN-A", "archive", "<Replacement>C-CHAIN-B</Replacement>");
    writeBundleSpec(root, "C-CHAIN-B", "archive", "<Replacement>C-CHAIN-C</Replacement>");
    writeBundleSpec(root, "C-CHAIN-C", "active", "");
    expect(readAmendmentInstrument(root, "C-CHAIN-A").supersedeChainDepth).toBe(0);
    expect(readAmendmentInstrument(root, "C-CHAIN-B").supersedeChainDepth).toBe(1);
    expect(readAmendmentInstrument(root, "C-CHAIN-C").supersedeChainDepth).toBe(2);
  });

  it("cycle-guarded reverse walk terminates with depth 0 at the repeated node", () => {
    const root = tempProject();
    writeBundleSpec(root, "C-LOOP-A", "archive", "<Replacement>C-LOOP-B</Replacement>");
    writeBundleSpec(root, "C-LOOP-B", "archive", "<Replacement>C-LOOP-A</Replacement>");
    expect(readAmendmentInstrument(root, "C-LOOP-A").supersedeChainDepth).toBe(2);
    expect(readAmendmentInstrument(root, "C-LOOP-B").supersedeChainDepth).toBe(2);
  });

  it("spec Replacement wins when plan names a different successor", () => {
    const root = tempProject();
    writeBundleSpec(root, "C-SPEC-WIN", "archive", "<Replacement>C-FROM-SPEC</Replacement>");
    const planPath = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-SPEC-WIN", "plan.xml");
    const plan = readFileSync(planPath, "utf8");
    writeFileSync(
      planPath,
      plan.replace("<C-SPEC-WIN>", "<C-SPEC-WIN><Replacement>C-FROM-PLAN</Replacement>"),
    );
    writeBundleSpec(root, "C-FROM-SPEC", "active", "");
    writeBundleSpec(root, "C-FROM-PLAN", "active", "");
    expect(readAmendmentInstrument(root, "C-FROM-SPEC").supersedeChainDepth).toBe(1);
    expect(readAmendmentInstrument(root, "C-FROM-PLAN").supersedeChainDepth).toBe(0);
  });

  it("reads a child C-* tag as a predecessor pointer", () => {
    const root = tempProject();
    writeBundleSpec(root, "C-SHAPE-CHILD", "archive", "<C-SHAPE-TIP />");
    writeBundleSpec(root, "C-SHAPE-TIP", "active", "");
    expect(readAmendmentInstrument(root, "C-SHAPE-TIP").supersedeChainDepth).toBe(1);
  });

  it("reads ReplacementChange text as a predecessor pointer", () => {
    const root = tempProject();
    writeBundleSpec(root, "C-SHAPE-TEXT", "archive", "<ReplacementChange>C-SHAPE-TIP</ReplacementChange>");
    writeBundleSpec(root, "C-SHAPE-TIP", "active", "");
    expect(readAmendmentInstrument(root, "C-SHAPE-TIP").supersedeChainDepth).toBe(1);
  });
});


// ---------------------------------------------------------------------------
// C-TEST-TIME-BUDGET-2-3EC1F016 T-002 — predecessor-map memo: invalidation both
// ways. A stale cache is a false green; every mutation must invalidate.
// ---------------------------------------------------------------------------

import { __predecessorMemoStats, __resetPredecessorCache, __predecessorMapView } from "./ledger";

describe("C-TEST-TIME-BUDGET-2-3EC1F016 predecessor memo invalidation", () => {
  function writePredecessor(root: string, id: string, replaces: string): string {
    writeChangeBundleFixture(root, { changeId: id, location: "archive", specStatus: "superseded" });
    const specPath = path.join(root, ARTIFACT_DIR, "changes", "archive", id, "spec.xml");
    const spec = readFileSync(specPath, "utf8");
    writeFileSync(specPath, spec.replace(`<${id}>`, `<${id}><Replacement>${replaces}</Replacement>`));
    return path.join(root, ARTIFACT_DIR, "changes", "archive", id);
  }

  it("rebuilds once, then add/remove/rename/in-place each invalidate; view mutation is isolated", () => {
    const root = mkdtempSync(path.join(os.tmpdir(), "ngrace-memo-"));
    tempRoots.push(root);
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, { changeId: "C-TARGET", location: "archive", specStatus: "applied" });
    __resetPredecessorCache();
    const old = writePredecessor(root, "C-OLD", "C-TARGET");

    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(1);
    expect(__predecessorMemoStats.builds).toBe(1);
    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(1);
    expect(__predecessorMemoStats.builds).toBe(1);

    const view = __predecessorMapView(root);
    view.set("C-TARGET", ["C-HACK"]);
    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(1);
    expect(__predecessorMemoStats.builds).toBe(1);

    // add
    writePredecessor(root, "C-OLD-TWO", "C-OLD");
    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(2);
    expect(__predecessorMemoStats.builds).toBe(2);

    // edit in place (size changes, so the revision token moves)
    writeFileSync(
      path.join(old, "spec.xml"),
      `<NgraceChangeSpec graceVersion="1.0" status="superseded"><C-OLD><Replacement>C-SOMEWHERE-ELSE</Replacement></C-OLD></NgraceChangeSpec>`,
    );
    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(0);
    expect(__predecessorMemoStats.builds).toBe(3);

    // rename
    renameSync(
      path.join(root, ARTIFACT_DIR, "changes", "archive", "C-OLD-TWO"),
      path.join(root, ARTIFACT_DIR, "changes", "archive", "C-OLD-TWO-RENAMED"),
    );
    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(0);
    expect(__predecessorMemoStats.builds).toBe(4);

    // remove
    rmSync(path.join(root, ARTIFACT_DIR, "changes", "archive", "C-OLD-TWO-RENAMED"), { recursive: true, force: true });
    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(0);
    expect(__predecessorMemoStats.builds).toBe(5);

    __resetPredecessorCache();
    expect(readAmendmentInstrument(root, "C-TARGET").supersedeChainDepth).toBe(0);
    expect(__predecessorMemoStats.builds).toBe(1);
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-003: the three-phase review-verdict snapshot.
describe("review verdict three-phase", () => {
  function appliedArchive(changeId: string): { root: string; bundle: string; specPath: string; ledgerPath: string } {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId,
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "archive", changeId);
    return { root, bundle, specPath: path.join(bundle, "spec.xml"), ledgerPath: path.join(bundle, "run-ledger.xml") };
  }

  it("(a) a spec-byte mutation between snapshot and write refuses and preserves the mutated bytes", () => {
    const { root, specPath, ledgerPath } = appliedArchive("C-3PH-SPEC");
    writeCloseEvidenceSpec(specPath, `printf '\\n<!--spec-mutated-->' >> ${specPath}`);
    const ledgerBefore = existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null;
    const result = runGateCli(
      ["verdict", "--change", "C-3PH-SPEC", "--outcome", "pass", "--path", root, ...ackFindingCliArgs(root, "C-3PH-SPEC")],
      root,
    );
    expect(result.status).not.toBe(0);
    expect(`${result.stdout ?? ""}${result.stderr ?? ""}`).toMatch(/stale snapshot/i);
    expect(readFileSync(specPath, "utf8")).toContain("spec-mutated");
    expect(existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null).toBe(ledgerBefore);
  });

  it("(b) a ledger-byte mutation between snapshot and write refuses", () => {
    const { root, specPath, ledgerPath } = appliedArchive("C-3PH-LEDGER");
    writeCloseEvidenceSpec(specPath, `printf ' ' >> ${ledgerPath}`);
    const result = runGateCli(
      ["verdict", "--change", "C-3PH-LEDGER", "--outcome", "pass", "--path", root, ...ackFindingCliArgs(root, "C-3PH-LEDGER")],
      root,
    );
    expect(result.status).not.toBe(0);
    expect(`${result.stdout ?? ""}${result.stderr ?? ""}`).toMatch(/stale snapshot/i);
    expect(readFileSync(ledgerPath, "utf8").endsWith(" ")).toBe(true);
  });

  it("clean prerequisite: an unchanged applied archive records the verdict", () => {
    const { root, specPath, ledgerPath } = appliedArchive("C-3PH-CLEAN");
    writeCloseEvidenceSpec(specPath, "true");
    const result = runGateCli(
      ["verdict", "--change", "C-3PH-CLEAN", "--outcome", "pass", "--path", root, ...ackFindingCliArgs(root, "C-3PH-CLEAN")],
      root,
    );
    expect(result.status).toBe(0);
    expect(readFileSync(ledgerPath, "utf8")).toContain('outcome="pass"');
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-003: identity-only and location-only verdict cases.
describe("review verdict three-phase identity and location", () => {
  function appliedArchive(changeId: string): { root: string; bundle: string; specPath: string; ledgerPath: string } {
    const root = tempProject();
    writeChangeBundleFixture(root, {
      changeId,
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "archive", changeId);
    return { root, bundle, specPath: path.join(bundle, "spec.xml"), ledgerPath: path.join(bundle, "run-ledger.xml") };
  }

  it("(c) a same-path directory replacement with byte-identical prerequisites (identity-only) refuses and preserves the replacement with no ledger write", () => {
    const { root, bundle, specPath, ledgerPath } = appliedArchive("C-3PH-IDENT");
    const tmp = `${bundle}.swap`;
    writeCloseEvidenceSpec(specPath, `mv ${bundle} ${tmp}; cp -a ${tmp} ${bundle}; rm -rf ${tmp}`);
    const bytesBeforeCommand = recursiveBundleSnapshot(bundle);
    const inoBefore = statSync(bundle).ino;
    const ledgerBefore = existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null;
    const result = runGateCli(
      ["verdict", "--change", "C-3PH-IDENT", "--outcome", "pass", "--path", root, ...ackFindingCliArgs(root, "C-3PH-IDENT")],
      root,
    );
    expect(result.status).not.toBe(0);
    expect(`${result.stdout ?? ""}${result.stderr ?? ""}`).toMatch(/identity|stale snapshot/i);
    // The command's replacement is byte-identical but a distinct inode; it survives the refusal.
    expect(recursiveBundleSnapshot(bundle)).toBe(bytesBeforeCommand);
    const inoAfter = statSync(bundle).ino;
    expect(inoAfter).not.toBe(inoBefore);
    expect(statSync(bundle).ino).toBe(inoAfter);
    // The gate added no ledger bytes after detecting the stale snapshot.
    expect(existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null).toBe(ledgerBefore);
  });

  it("(d) an active/archive relocation (location-only) refuses, leaves the archive path absent, and preserves the active arrival with no ledger write", () => {
    const { root, bundle, specPath, ledgerPath } = appliedArchive("C-3PH-LOC");
    const active = path.join(root, ARTIFACT_DIR, "changes", "active", "C-3PH-LOC");
    mkdirSync(path.dirname(active), { recursive: true });
    writeCloseEvidenceSpec(specPath, `mv ${bundle} ${active}`);
    const bytesBeforeCommand = recursiveBundleSnapshot(bundle);
    const ledgerBefore = existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null;
    const result = runGateCli(
      ["verdict", "--change", "C-3PH-LOC", "--outcome", "pass", "--path", root, ...ackFindingCliArgs(root, "C-3PH-LOC")],
      root,
    );
    expect(result.status).not.toBe(0);
    expect(`${result.stdout ?? ""}${result.stderr ?? ""}`).toMatch(/location|stale snapshot/i);
    expect(existsSync(bundle), "the archive path stays absent").toBe(false);
    expect(recursiveBundleSnapshot(active), "the active arrival is the command's preserved tree").toBe(bytesBeforeCommand);
    const activeLedger = path.join(active, "run-ledger.xml");
    expect(existsSync(activeLedger) ? readFileSync(activeLedger, "utf8") : null, "no gate-added ledger bytes").toBe(ledgerBefore);
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-003: the covered outer-mutation-writer population.
describe("cooperating writer population", () => {
  const ACTIVE = path.join(ARTIFACT_DIR, "changes", "active");
  const REPO = path.resolve(import.meta.dir, "../..");
  const CURSOR_MODULE = path.join(REPO, "src", "grace-cursor.ts");

  function recursiveSnapshot(dir: string): string {
    if (!existsSync(dir)) return "";
    const lines: string[] = [];
    const walk = (abs: string, rel: string): void => {
      const stat = statSync(abs);
      if (stat.isDirectory()) {
        for (const name of readdirSync(abs).sort()) walk(path.join(abs, name), rel ? `${rel}/${name}` : name);
        return;
      }
      lines.push(`${rel}\t${readFileSync(abs, "utf8").length}\t${createHash("sha256").update(readFileSync(abs)).digest("hex")}`);
    };
    walk(dir, "");
    return lines.sort().join("\n");
  }

  function initGit(root: string): void {
    for (const args of [["init"], ["config", "user.email", "a@b.c"], ["config", "user.name", "T"], ["add", "."], ["commit", "-m", "baseline"]]) {
      const result = Bun.spawnSync({ cmd: ["git", ...args], cwd: root, stdout: "pipe", stderr: "pipe" });
      if (result.exitCode !== 0) throw new Error(Buffer.from(result.stderr).toString("utf8"));
    }
  }

  type LiveExpectation = { ok: true } | { ok: false; message: RegExp };
  type LiveRow = {
    /** Module that exports the writer, or the CLI for the `plan new` row. */
    module?: string;
    entry?: string;
    cliArgs?: (changeId: string) => string[];
    args?: (root: string, changeId: string) => unknown[];
    prepare?: (root: string, changeId: string) => void;
    expect: LiveExpectation;
  };
  type WriterRow = {
    name: string;
    specStatus?: string;
    planStatus?: string;
    prepare?: (root: string, bundle: string, changeId: string) => void;
    invoke: (root: string, changeId: string, bundle: string) => unknown;
    live: LiveRow;
  };

  const LEDGER_MODULE = path.join(REPO, "src", "gates", "ledger.ts");
  /** A writer runner used by the live-publisher rows, so a writer can block on the lock. */
  const WRITER_RUNNER = [
    'import { readFileSync, writeFileSync } from "node:fs";',
    'const s = JSON.parse(readFileSync(process.argv[2], "utf8"));',
    'try { const mod = await import(s.module); await mod[s.entry](...s.args); writeFileSync(s.result, JSON.stringify({ ok: true })); }',
    'catch (e) { writeFileSync(s.result, JSON.stringify({ ok: false, message: String((e && e.message) || e) })); }',
    "",
  ].join("\n");

  /** The lineage successor of a live-publisher candidate id. */
  function lineageSuccessor(changeId: string): string {
    return changeId.replace(/-1-([0-9A-F]{8})$/, "-2-$1");
  }

  const rows: WriterRow[] = [
    {
      name: "writePlanNew",
      invoke: (root, changeId) => {
        const result = Bun.spawnSync({ cmd: ["bun", "run", path.join(REPO, "src/grace.ts"), "plan", "new", changeId, "--path", root], cwd: REPO, stdout: "pipe", stderr: "pipe" });
        if (result.exitCode !== 0) {
          throw new GraceCommandError("invalid-arguments", Buffer.from(result.stderr).toString("utf8"));
        }
        return result;
      },
      live: { cliArgs: (changeId) => ["plan", "new", changeId], expect: { ok: false, message: /not approved/i } },
    },
    {
      name: "stampApproveArtifact",
      specStatus: "draft",
      invoke: (root, changeId) => stampApproveArtifact(root, changeId, "spec"),
      live: { module: LEDGER_MODULE, entry: "stampApproveArtifact", args: (root, changeId) => [root, changeId, "spec"], expect: { ok: true } },
    },
    {
      name: "regenerateCursor",
      prepare: (root) => initGit(root),
      invoke: (root, changeId) => regenerateCursor(root, changeId, { apply: true, allowDirty: true }),
      live: { module: CURSOR_MODULE, entry: "regenerateCursor", prepare: (root) => initGit(root), args: (root, changeId) => [root, changeId, { apply: true, allowDirty: true }], expect: { ok: true } },
    },
    { name: "advanceCursor", invoke: (root, changeId) => advanceCursor(root, changeId, { task: "T-001", openEpoch: true, from: 1, to: 10 }), live: { module: CURSOR_MODULE, entry: "advanceCursor", args: (root, changeId) => [root, changeId, { task: "T-001", openEpoch: true, from: 1, to: 10 }], expect: { ok: true } } },
    { name: "pauseCursor", invoke: (root, changeId) => pauseCursor(root, changeId, "T-001"), live: { module: CURSOR_MODULE, entry: "pauseCursor", args: (root, changeId) => [root, changeId, "T-001"], expect: { ok: true } } },
    { name: "resumeCursor", invoke: (root, changeId) => resumeCursor(root, changeId, "T-001"), live: { module: CURSOR_MODULE, entry: "resumeCursor", args: (root, changeId) => [root, changeId, "T-001"], expect: { ok: true } } },
    { name: "recordAttempt", invoke: (root, changeId) => recordAttempt(root, changeId, { task: "T-001", outcome: "pass" }), live: { module: CURSOR_MODULE, entry: "recordAttempt", args: (root, changeId) => [root, changeId, { task: "T-001", outcome: "pass" }], expect: { ok: true } } },
    { name: "recordVerificationUnavailable", invoke: (root, changeId) => recordVerificationUnavailable(root, changeId, { task: "T-001", absence: { verdict: "unable-to-determine", reason: "test" } }), live: { module: CURSOR_MODULE, entry: "recordVerificationUnavailable", args: (root, changeId) => [root, changeId, { task: "T-001", absence: { verdict: "unable-to-determine", reason: "test" } }], expect: { ok: true } } },
    { name: "foldEpoch", invoke: (root, changeId) => foldEpoch(root, changeId), live: { module: CURSOR_MODULE, entry: "foldEpoch", args: (root, changeId) => [root, changeId], expect: { ok: false, message: /No loose run\/ events to fold/ } } },
    { name: "recoverCursor", invoke: (root, changeId) => recoverCursor(root, changeId, { fix: true }), live: { module: CURSOR_MODULE, entry: "recoverCursor", args: (root, changeId) => [root, changeId, { fix: true }], expect: { ok: false, message: /no valid loose integer events/ } } },
    { name: "appendCommandRunEvent", invoke: (root, changeId) => appendCommandRunEvent(root, changeId, { command: "bun test", exitCode: 0, assertionPassed: true, assertionKind: "MustPassCommand", source: "test" }, { task: "T-001" }), live: { module: CURSOR_MODULE, entry: "appendCommandRunEvent", args: (root, changeId) => [root, changeId, { command: "bun test", exitCode: 0, assertionPassed: true, assertionKind: "MustPassCommand", source: "test" }, { task: "T-001" }], expect: { ok: false, message: /no declared task is in scope/ } } },
    { name: "recordReviewVerdict", invoke: (root, changeId) => recordReviewVerdict(root, changeId, { outcome: "fail", reason: "test" }), live: { module: LEDGER_MODULE, entry: "recordReviewVerdict", args: (root, changeId) => [root, changeId, { outcome: "fail", reason: "test" }], expect: { ok: true } } },
    { name: "recordGateDecision", invoke: (root, changeId) => recordGateDecision(root, changeId, { gate: "apply", decision: "refuse", requirements: [] }), live: { module: LEDGER_MODULE, entry: "recordGateDecision", args: (root, changeId) => [root, changeId, { gate: "apply", decision: "refuse", requirements: [] }], expect: { ok: true } } },
    { name: "discardAndFoldEpoch", invoke: (root, changeId) => discardAndFoldEpoch(root, changeId), live: { module: CURSOR_MODULE, entry: "discardAndFoldEpoch", args: (root, changeId) => [root, changeId], expect: { ok: true } } },
    { name: "recordCalibrationRestatement", invoke: (root, changeId) => recordCalibrationRestatement(root, changeId, { changeId, epoch: 1, adjudicatedAt: "backfill", reason: "test" }), live: { module: CURSOR_MODULE, entry: "recordCalibrationRestatement", args: (root, changeId) => [root, changeId, { changeId, epoch: 1, adjudicatedAt: "backfill", reason: "test" }], expect: { ok: false, message: /has no run-ledger\.xml/ } } },
    {
      name: "supersedeChangeBundle",
      prepare: (root, bundle, changeId) => {
        writeChangeBundleFixture(root, { changeId: "C-WRITER-SUCC-2-ABCDEF12", location: "active", specStatus: "draft", planStatus: "draft" });
        void bundle;
        void changeId;
      },
      invoke: (root, changeId) => supersedeChangeBundle(root, changeId, { kind: "explicit", id: "C-WRITER-SUCC-2-ABCDEF12" }),
      live: {
        module: LEDGER_MODULE,
        entry: "supersedeChangeBundle",
        prepare: (root, changeId) => {
          writeChangeBundleFixture(root, { changeId: lineageSuccessor(changeId), location: "active", specStatus: "draft", planStatus: "draft" });
        },
        args: (root, changeId) => [root, changeId, { kind: "explicit", id: lineageSuccessor(changeId) }],
        expect: { ok: true },
      },
    },
  ];
  const LIVE_IDS = rows.map((_, index) => `C-WLIVE-${String(index).padStart(2, "0")}-1-ABCDEF${String(index).padStart(2, "0")}`);

  for (const row of rows) {
    it(`AC-COOPERATING-WRITER-COVERAGE ${row.name}: crash-marker residue refuses before any write`, () => {
      const root = tempProject();
      const changeId = "C-WRITER-SUCC-1";
      writeChangeBundleFixture(root, { changeId, location: "active", specStatus: row.specStatus ?? "approved", planStatus: row.planStatus ?? "approved" });
      const bundle = path.join(root, ACTIVE, changeId);
      row.prepare?.(root, bundle, changeId);
      writeFileSync(path.join(bundle, ".ngrace-mint-owner"), "stale-token\n");
      const before = recursiveSnapshot(bundle);
      expect(() => row.invoke(root, changeId, bundle)).toThrow(/unpublished candidate/i);
      expect(recursiveSnapshot(bundle), "no write under a stale marker").toBe(before);
    });

    it(`AC-COOPERATING-WRITER-COVERAGE ${row.name}: bare candidate-lock primitive is respected by a distinct lock holder (not the live-publisher half)`, async () => {
      const root = tempProject();
      const changeId = "C-WRITER-SUCC-1";
      writeChangeBundleFixture(root, { changeId, location: "active", specStatus: row.specStatus ?? "approved", planStatus: row.planStatus ?? "approved" });
      const bundle = path.join(root, ACTIVE, changeId);
      row.prepare?.(root, bundle, changeId);
      const lockPath = path.join(root, ACTIVE, `.candidate-${changeId}.lock`);
      const body = `
        const mod = await import(${JSON.stringify(CURSOR_MODULE)});
        mod.withCandidateLock(${JSON.stringify(root)}, ${JSON.stringify(changeId)}, () => { Bun.sleepSync(400); });
      `;
      const holder = Bun.spawn({ cmd: [process.execPath, "-e", body], stdout: "pipe", stderr: "pipe" });
      for (let i = 0; i < 400 && !existsSync(lockPath); i += 1) await Bun.sleep(5);
      expect(existsSync(lockPath)).toBe(true);
      const started = Date.now();
      let caught: unknown;
      try {
        row.invoke(root, changeId, bundle);
      } catch (error) {
        caught = error;
      }
      const elapsed = Date.now() - started;
      await holder.exited;
      expect(elapsed, "the writer waited for the bare lock holder").toBeGreaterThanOrEqual(150);
      expect(String((caught as Error)?.message ?? ""), "never the unpublished-candidate refusal").not.toMatch(/unpublished candidate/i);
    });

    it(`AC-COOPERATING-WRITER-COVERAGE ${row.name}: waits for a real paused publisher, then ${row.live.expect.ok ? "proceeds" : "refuses on its own prerequisite"}`, async () => {
      const index = rows.indexOf(row);
      const changeId = LIVE_IDS[index]!;
      const root = tempProject();
      row.live.prepare?.(root, changeId);
      const bundle = path.join(root, ACTIVE, changeId);
      const payloadFile = path.join(root, "payload.json");
      const resultFile = path.join(root, "result.json");
      const runnerFile = path.join(root, "writer-runner.js");
      writeFileSync(runnerFile, WRITER_RUNNER);
      const resolved: ResolvedSpecMint = { id: changeId, slug: "WLIVE", lineage: 1, hash: "ABCDEF12", branch: "probe", timestamp: "2026-09-19T00:00:00.000Z" };
      let child: Bun.Subprocess | undefined;
      let markerSeen = false;
      let lockSeen = false;
      let pending = false;
      let invariant = false;
      const startedAt = Date.now();
      pauseCandidatePublicationForTests(() => {
        const before = recursiveSnapshot(bundle);
        markerSeen = existsSync(path.join(bundle, ".ngrace-mint-owner"));
        lockSeen = existsSync(path.join(root, ACTIVE, `.candidate-${changeId}.lock`));
        if (row.live.cliArgs) {
          child = Bun.spawn({ cmd: [process.execPath, GRACE_BIN, ...row.live.cliArgs(changeId), "--path", root], cwd: REPO_ROOT, stdout: "pipe", stderr: "pipe" });
        } else {
          writeFileSync(payloadFile, JSON.stringify({ module: row.live.module, entry: row.live.entry, args: row.live.args!(root, changeId), result: resultFile }));
          child = Bun.spawn({ cmd: [process.execPath, runnerFile, payloadFile], stdout: "pipe", stderr: "pipe" });
        }
        Bun.sleepSync(350);
        pending = child.exitCode === null;
        invariant = recursiveSnapshot(bundle) === before;
      });
      let publisherError: unknown;
      try {
        mintResolvedBundle(root, resolved);
      } catch (error) {
        publisherError = error;
      } finally {
        pauseCandidatePublicationForTests(null);
      }
      expect(publisherError, "the paused publisher's direct exit is success").toBeUndefined();
      expect(markerSeen, "the publisher reached the paused marker-bearing state").toBe(true);
      expect(lockSeen, "the publisher held the sibling candidate lock").toBe(true);
      expect(pending, "the contender is pending during the publication state").toBe(true);
      expect(invariant, "the contender is byte-invariant during the publication state").toBe(true);
      const code = await child!.exited;
      expect(Date.now() - startedAt, "the contender waited for the publisher").toBeGreaterThanOrEqual(150);
      if (row.live.cliArgs) {
        expect(code).toBe(row.live.expect.ok ? 0 : 1);
        if (!row.live.expect.ok) {
          const stderr = Buffer.from(await new Response(child!.stderr as ReadableStream).arrayBuffer()).toString("utf8");
          expect(stderr, `${row.name} refuses on its own prerequisite`).toMatch(row.live.expect.message);
        }
      } else {
        expect(existsSync(resultFile), "the writer reported an outcome").toBe(true);
        const reported = JSON.parse(readFileSync(resultFile, "utf8")) as { ok: boolean; message?: string };
        if (row.live.expect.ok) {
          expect(reported.ok, `${row.name} succeeds after the wait: ${reported.message ?? ""}`).toBe(true);
        } else {
          expect(reported.ok, `${row.name} refuses on its own prerequisite`).toBe(false);
          expect(reported.message ?? "", `${row.name} refuses on its own prerequisite`).toMatch(row.live.expect.message);
        }
        expect(code, "the writer process exits cleanly even when its function refuses").toBe(0);
      }
    });
  }

  it("AC-COOPERATING-WRITER-COVERAGE writeEventFile is the reentrant event fallback used by a public cursor path", () => {
    // Source pin: writeEventFile wraps its event write in the per-bundle event lock.
    const src = readFileSync(path.join(REPO, "src", "grace-cursor.ts"), "utf8");
    expect(src).toMatch(/function writeEventFile\([\s\S]*?withEventWriteLock\(bundlePath/);
    const root = tempProject();
    const changeId = "C-WRITER-EVENT-1";
    writeChangeBundleFixture(root, { changeId, location: "active", specStatus: "approved", planStatus: "approved" });
    const bundle = path.join(root, ACTIVE, changeId);
    // A wider transaction already holds the candidate lock; the public cursor path
    // reenters that boundary and still writes through writeEventFile's event lock.
    const position = withCandidateLock(root, changeId, () =>
      advanceCursor(root, changeId, { task: "T-001", openEpoch: true, from: 1, to: 10 }),
    );
    expect(position, "the reentrant public path completes").toBeDefined();
    const runDir = path.join(bundle, "run");
    expect(
      readdirSync(runDir).some((name) => name.includes("-T-001-opened")),
      "the event was written through writeEventFile while the wider transaction held the candidate lock",
    ).toBe(true);
    expect(existsSync(path.join(bundle, ".run-write.lock")), "the event lock is released").toBe(false);
  });

  it("AC-COOPERATING-WRITER-COVERAGE applyChangeBundle is unreachable for an unpublished candidate and reachable for a published closeable one", () => {
    const root = tempProject();
    // Unpublished candidate: ownership marker present, draft spec, no plan.xml.
    const unpublishedId = "C-WRITER-APPLY-1";
    const unpublished = path.join(root, ACTIVE, unpublishedId);
    mkdirSync(unpublished, { recursive: true });
    writeChangeBundleFixture(root, { changeId: unpublishedId, location: "active", specStatus: "draft" });
    writeFileSync(path.join(unpublished, ".ngrace-mint-owner"), "stale\n");
    const before = recursiveSnapshot(unpublished);
    expect(() => applyChangeBundle(root, unpublishedId)).toThrow(/plan\.xml is required/);
    expect(recursiveSnapshot(unpublished), "apply mutates nothing on an unpublished candidate").toBe(before);
    // Published closeable bundle: the next refusal is the apply permit prerequisite,
    // which proves the production path is reachable for a published, closeable state.
    const publishedId = "C-WRITER-APPLY-2";
    writeChangeBundleFixture(root, { changeId: publishedId, location: "active", specStatus: "approved", planStatus: "approved" });
    expect(() => applyChangeBundle(root, publishedId)).toThrow(/Apply permit missing/);
  });
});
