// START_MODULE_CONTRACT
//   PURPOSE: Transition gate surface
//   SCOPE: Approve, apply, archive evaluation and ledger decisions
//   DEPENDS: none
//   LINKS: M-GATES
//   ROLE: RUNTIME
//   MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
//
// START_MODULE_MAP
//   DecisionGateId
//   DecisionListResult
//   ApplyChangeBundleOptions
//   applyChangeBundle
//   validateApplyChangeBundle
//   GateDecisionRecord
//   GateDecisionValue
//   GateId
//   GateRequirementRecord
//   LEDGER_NON_EPOCH_SECTIONS
//   LatestReviewVerdict
//   LedgerVerdictsSurface
//   LedgerWrapperSurface
//   PermittingDecisionStatus
//   ResolutionClassification
//   ReviewVerdictOutcome
//   ReviewVerdictRecord
//   ReviewVerdictScope
//   VerdictAckRecord
//   VerdictFindingRecord
//   computeVerdictSnapshotDigest
//   hasPermittingDecision
//   classifyApprovedArtifact
//   stampApproveArtifact
//   supersedeChangeBundle
//   SupersedeReplacement
//   AmendmentInstrument
//   ApprovedArtifactClassification
//   ApprovedArtifactName
//   latestReviewVerdict
//   listGateDecisions
//   listReviewVerdicts
//   parseResolutionClassification
//   parseReviewVerdictScope
//   readAmendmentInstrument
//   readGateDecisions
//   readLatestReviewVerdict
//   readLedgerVerdictsSurface
//   readLedgerWrapper
//   readPermittingDecision
//   recordGateDecision
//   recordReviewVerdict
//   __predecessorMapView
//   __predecessorMemoStats
//   __resetPredecessorCache
// END_MODULE_MAP
/**
 * Bundle-scoped Verdicts and Decisions on run-ledger.xml (A30.2).
 * Siblings to Epoch-N; never loose run/ events (correction 61).
 * Write path: validate constructed tree, write, re-read, verify, restore on failure (A31.5).
 * Read path: newest entry governs; unreadable is absence with reason, never skip (A31.2).
 * Section boundary: duplicate or validator-rejected section is invalid, not first-wins (A32.1 / 68).
 */

import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync, rmdirSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import path from "node:path";

import { spawnShellCommand } from "../artifact/assertions";
import { collectCloseEvidenceEvaluations, isCloseBoundCriterion, validateRunLedgerArtifact } from "../artifact/grammar";
import { ARTIFACT_DIR } from "../artifact/paths";
import { ANCHOR_PATTERNS, ARTIFACT_TAG_PREFIX, nextBundleLineage, NGRACE_ARTIFACT_VERSION, parseBundleId } from "../artifact/types";
import { cloneXmlNode, parseGraceXmlArtifact, readGraceXmlArtifact, walkNodes, type GraceXmlNode } from "../artifact/xml";
import { serializeGraceXmlDocument } from "../artifact/xml-serialize";
import { assertCandidatePublished, discardAndFoldEpoch, resolveChangeBundle, withCandidateLock } from "../grace-cursor";
import { cleanupCandidate, type AcquiredCandidate } from "../grace-generate";
import { GraceCommandError } from "../query/errors";

export type ReviewVerdictOutcome = "pass" | "fail" | "unable-to-determine";

/**
 * D10 review scope, extended with `bundle` (A71 / corr 182).
 * Historical unscoped verdicts stay scope-not-recorded — never retro-labelled bundle.
 */
export type ReviewVerdictScope = "task" | "wave" | "bundle";

/** Stored at resolution (rule 13) — implementation vs plan defect (D10). */
export type ResolutionClassification = "implementation" | "plan";

export type VerdictFindingRecord = {
  code: string;
  file: string;
  findingId: string;
  severity: string;
  ruleId: string;
  anchorOrHunkKey: string;
  message: string;
};

export type VerdictAckRecord = {
  findingId: string;
  snapshotDigest: string;
};

export type ReviewVerdictRecord = {
  outcome: ReviewVerdictOutcome;
  /** D5 reason when outcome is an absence (e.g. host-capability-missing). */
  reason?: string;
  /** Optional free text. */
  note?: string;
  /**
   * Optional D10 scope. Absent means scope-not-recorded at report time —
   * never defaulted to task, wave, or bundle (D5 / rule 13 / corr 182).
   */
  scope?: ReviewVerdictScope;
  /** Task id when scope=task (optional label). */
  task?: string;
  /** Wave id when scope=wave (optional label; used for precondition join). */
  wave?: string;
  /**
   * Stored resolution classification (implementation | plan). Written at resolution
   * time; report reads this field, never re-derives as sole truth (P3 / rule 13).
   */
  classification?: ResolutionClassification;
  /**
   * Stored when scope=wave and outcome=fail: whether every constituent task passed
   * its own verification at record time. Absent + reason when unknown.
   */
  constituentTasksPassed?: boolean;
  /** D5 reason when constituentTasksPassed could not be determined. */
  constituentTasksPassedReason?: string;
  /** SHA-256 of changeId plus findings sorted by (code, file, findingId). Required on pass. */
  snapshotDigest?: string;
  /** Persisted displayed findings bound to snapshotDigest. */
  findings?: VerdictFindingRecord[];
  /** Pass-only acknowledgements of persisted findingIds. */
  acks?: VerdictAckRecord[];
  /**
   * Recorded close-evidence tally: one entry per close-bound `AC-*` child that
   * carries both `Exit` and a `pass`/`fail` `Result`. Absent when the Verdict
   * carries no complete criterion — never an empty array (F270). Read here,
   * through the shipped `collectCloseEvidenceEvaluations`, so no surface needs
   * a second reader of the ledger bytes.
   */
  closeEvidence?: Array<{ criterionId: string; exit: string; result: string }>;
};

/** Canonical snapshot digest: SHA-256 of changeId plus findings sorted by (code, file, findingId). */
export function computeVerdictSnapshotDigest(
  changeId: string,
  findings: Array<{ code: string; file: string; findingId: string }>,
): string {
  const sorted = [...findings].sort(
    (a, b) =>
      a.code.localeCompare(b.code)
      || a.file.localeCompare(b.file)
      || a.findingId.localeCompare(b.findingId),
  );
  return createHash("sha256")
    .update(
      JSON.stringify({
        changeId,
        findings: sorted.map((finding) => ({
          code: finding.code,
          file: finding.file,
          findingId: finding.findingId,
        })),
      }),
    )
    .digest("hex");
}

export type GateId = "approve" | "apply" | "archive";
/**
 * Decision-record gate vocabulary: the three evaluation gates plus the applied
 * close writer. The writer is not a gate subcommand (C-APPLY-VERB / D37); the
 * wider parse set names the command-path event that wrote the status.
 */
export type DecisionGateId = GateId | "applied";
export type GateDecisionValue = "permit" | "refuse";

export type GateRequirementRecord = {
  id: string;
  required: boolean;
  present: boolean;
  blocking: boolean;
  message?: string;
};

export type GateDecisionRecord = {
  gate: DecisionGateId;
  decision: GateDecisionValue;
  requirements: GateRequirementRecord[];
  /** First observed HEAD object name on a permitting approve. Omitted when never observed. */
  baseCommit?: string;
  /** SHA-256 lowercase hex of the targeted artifact bytes after the status write. */
  fingerprint?: string;
  /** Which artifact this permitting approve targeted. */
  artifact?: "spec" | "plan";
  /** Present and true only on a forced permit. Omit when unused; never store false. */
  forced?: boolean;
  /** Operator-supplied reason stored only with forced true. */
  reason?: string;
};

/** Newest-governs read of the Verdicts section (A31.2). Invalid is never skipped. */
export type LatestReviewVerdict =
  | { state: "absent" }
  | { state: "invalid"; code: string; detail: string }
  | { state: "present"; verdict: ReviewVerdictRecord };

/** Newest-governs scan of Decisions; any unreadable entry is invalid, never skipped (A31.2 / A32.1). */
export type DecisionListResult =
  | { state: "ok"; decisions: GateDecisionRecord[]; sectionPresent: boolean }
  | { state: "invalid"; code: string; detail: string };

/**
 * Permit lookup with reason (A32.1 / A33.1).
 * - absent: no Decisions section (pre-gate bundles; not a violation)
 * - no-permit: Decisions section exists but holds no permitting apply
 * - invalid: unreadable section
 */
export type PermittingDecisionStatus =
  | { state: "permit" }
  | { state: "absent"; reason: "no-decisions-section" }
  | { state: "no-permit" }
  | { state: "invalid"; code: string; detail: string };

const LEDGER_BUNDLE_SECTIONS = new Set(["Verdicts", "Decisions"]);

const VALID_OUTCOMES = new Set<string>(["pass", "fail", "unable-to-determine"]);
const VALID_SCOPES = new Set<string>(["task", "wave", "bundle"]);
const VALID_CLASSIFICATIONS = new Set<string>(["implementation", "plan"]);
const VALID_GATES = new Set<string>(["approve", "apply", "archive", "applied"]);
const VALID_DECISIONS = new Set<string>(["permit", "refuse"]);

export function parseReviewVerdictScope(value: string): ReviewVerdictScope {
  if (!VALID_SCOPES.has(value)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Unsupported verdict scope \`${value}\`. Use task, wave, or bundle.`,
    );
  }
  return value as ReviewVerdictScope;
}

export function parseResolutionClassification(value: string): ResolutionClassification {
  if (!VALID_CLASSIFICATIONS.has(value)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Unsupported resolution classification \`${value}\`. Use implementation or plan.`,
    );
  }
  return value as ResolutionClassification;
}

function emptyLedgerRoot(changeId: string): GraceXmlNode {
  return {
    tag: `${ARTIFACT_TAG_PREFIX}RunLedger`,
    attributes: { graceVersion: NGRACE_ARTIFACT_VERSION },
    children: [{ tag: changeId, attributes: {}, children: [], text: "" }],
    text: "",
  };
}

function loadOrCreateLedgerRoot(bundlePath: string, changeId: string): GraceXmlNode {
  const ledgerPath = path.join(bundlePath, "run-ledger.xml");
  if (!existsSync(ledgerPath)) {
    return emptyLedgerRoot(changeId);
  }
  const artifact = readGraceXmlArtifact(ledgerPath);
  if (!artifact.root) {
    throw new GraceCommandError("invalid-project", `Existing run-ledger.xml at ${ledgerPath} is unreadable.`);
  }
  return cloneXmlNode(artifact.root);
}

function ensureWrapper(root: GraceXmlNode, changeId: string): GraceXmlNode {
  let wrapper = root.children.find((child) => child.tag === changeId);
  if (!wrapper) {
    wrapper = { tag: changeId, attributes: {}, children: [], text: "" };
    root.children.push(wrapper);
  }
  return wrapper;
}

function ensureSection(wrapper: GraceXmlNode, sectionTag: "Verdicts" | "Decisions"): GraceXmlNode {
  const existing = wrapper.children.find((child) => child.tag === sectionTag);
  if (existing) return existing;
  const section: GraceXmlNode = { tag: sectionTag, attributes: {}, children: [], text: "" };
  // Append after any Epoch-N sections so fold's epoch walk stays contiguous at the front.
  wrapper.children.push(section);
  return section;
}

/**
 * A31.5 restore: prior ledger bytes back, or remove a ledger this run created.
 * The single unlinkSync call site in this module is this restore; shared by
 * post-write verification and by the applied writer's rollback.
 */
function restorePriorLedgerBytes(ledgerPath: string, priorBytes: Buffer | null): void {
  if (priorBytes !== null) {
    writeFileSync(ledgerPath, priorBytes);
  } else if (existsSync(ledgerPath)) {
    unlinkSync(ledgerPath);
  }
}

/**
 * Validate the constructed tree, write, re-read, verify; restore prior bytes on failure (A31.5).
 * Never leaves a failed write on disk. Does not delete a good prior file.
 */
function writeAndVerifyLedger(bundlePath: string, root: GraceXmlNode): void {
  const ledgerPath = path.join(bundlePath, "run-ledger.xml");
  const priorBytes = existsSync(ledgerPath) ? readFileSync(ledgerPath) : null;

  const preValidation = validateRunLedgerArtifact({
    file: ledgerPath,
    root,
    issues: [],
  });
  const preErrors = preValidation.issues.filter((issue) => issue.severity === "error");
  if (preErrors.length > 0) {
    throw new GraceCommandError(
      "invalid-project",
      `run-ledger.xml failed verification before write: ${preErrors.map((e) => e.code).join(", ")}`,
      { issues: preErrors.map((e) => e.code) },
    );
  }

  writeFileSync(ledgerPath, serializeGraceXmlDocument(root));

  const reRead = readGraceXmlArtifact(ledgerPath);
  const postValidation = validateRunLedgerArtifact(reRead);
  const postErrors = postValidation.issues.filter((issue) => issue.severity === "error");
  if (postErrors.length > 0) {
    restorePriorLedgerBytes(ledgerPath, priorBytes);
    throw new GraceCommandError(
      "invalid-project",
      `run-ledger.xml failed verification after write; prior content restored: ${postErrors.map((e) => e.code).join(", ")}`,
      { issues: postErrors.map((e) => e.code) },
    );
  }
}

/** Append a review verdict to the ledger Verdicts section (A30.2). Leaves run/ untouched. */
export function recordReviewVerdict(
  projectRoot: string,
  changeId: string,
  verdict: ReviewVerdictRecord,
): ReviewVerdictRecord {
  if (!VALID_OUTCOMES.has(verdict.outcome)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Unsupported verdict outcome \`${verdict.outcome}\`. Use pass, fail, or unable-to-determine.`,
    );
  }
  if (verdict.scope !== undefined && !VALID_SCOPES.has(verdict.scope)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Unsupported verdict scope \`${verdict.scope}\`. Use task, wave, or bundle.`,
    );
  }
  if (verdict.classification !== undefined && !VALID_CLASSIFICATIONS.has(verdict.classification)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Unsupported resolution classification \`${verdict.classification}\`. Use implementation or plan.`,
    );
  }
  // Corr 184: constituentTasksPassed applies only to wave-scoped fail — never silent drop.
  const ctpSupplied =
    verdict.constituentTasksPassed !== undefined ||
    Boolean(verdict.constituentTasksPassedReason?.trim());
  if (ctpSupplied && !(verdict.scope === "wave" && verdict.outcome === "fail")) {
    throw new GraceCommandError(
      "invalid-arguments",
      "constituentTasksPassed applies only to wave-scoped fail verdicts",
    );
  }

  const findings = verdict.findings ?? [];
  const digest = (verdict.snapshotDigest ?? "").trim();
  if (verdict.outcome === "pass" && !digest) {
    throw new GraceCommandError("invalid-arguments", "outcome pass requires snapshotDigest");
  }
  if (digest) {
    const expected = computeVerdictSnapshotDigest(changeId, findings);
    if (digest !== expected) {
      throw new GraceCommandError(
        "invalid-arguments",
        "snapshotDigest does not match the canonical digest of Finding children",
      );
    }
  }
  const acks = verdict.acks ?? [];
  if (verdict.outcome === "pass") {
    const findingIds = findings.map((finding) => finding.findingId);
    const ackIds = acks.map((ack) => ack.findingId);
    const findingSet = new Set(findingIds);
    const ackSet = new Set(ackIds);
    const oneForOne =
      ackIds.length === findingIds.length
      && ackSet.size === findingSet.size
      && findingIds.every((id) => ackSet.has(id));
    const digestAligned = acks.every((ack) => ack.snapshotDigest === digest);
    if (!oneForOne || !digestAligned) {
      throw new GraceCommandError(
        "invalid-arguments",
        "outcome pass requires Ack findingIds that match Finding children one-for-one with the Verdict snapshotDigest",
      );
    }
  }

  // Stored fields only — never invent scope or classification defaults (D5 / corr 182).
  const stored: ReviewVerdictRecord = {
    outcome: verdict.outcome,
    ...(verdict.reason ? { reason: verdict.reason } : {}),
    ...(verdict.note ? { note: verdict.note } : {}),
    ...(verdict.scope ? { scope: verdict.scope } : {}),
    ...(verdict.task ? { task: verdict.task } : {}),
    ...(verdict.wave ? { wave: verdict.wave } : {}),
    ...(verdict.classification ? { classification: verdict.classification } : {}),
    ...(digest ? { snapshotDigest: digest, findings } : {}),
    ...(verdict.acks && verdict.acks.length > 0 ? { acks: verdict.acks } : {}),
  };
  if (verdict.scope === "wave" && verdict.outcome === "fail") {
    if (verdict.constituentTasksPassed !== undefined) {
      stored.constituentTasksPassed = verdict.constituentTasksPassed;
      if (verdict.constituentTasksPassedReason) {
        stored.constituentTasksPassedReason = verdict.constituentTasksPassedReason;
      }
    } else if (verdict.constituentTasksPassedReason) {
      stored.constituentTasksPassedReason = verdict.constituentTasksPassedReason;
    }
  }

  const snapshot = withCandidateLock(projectRoot, changeId, () => {
    const bundlePath = resolveChangeBundle(projectRoot, changeId);
    assertCandidatePublished(bundlePath, changeId);
    const ledgerPath = path.join(bundlePath, "run-ledger.xml");
    const specPath = path.join(bundlePath, "spec.xml");
    const identity = statSync(bundlePath);
    return {
      bundlePath,
      dev: identity.dev,
      ino: identity.ino,
      specBytes: existsSync(specPath) ? readFileSync(specPath, "utf8") : null,
      ledgerBytes: existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null,
    };
  });
  const closeChildren = evaluateCloseEvidenceChildren(projectRoot, snapshot.bundlePath);
  if (
    verdict.outcome === "pass"
    && closeChildren.some((child) =>
      child.children.some((node) => node.tag === "Result" && node.text.trim() === "fail"))
  ) {
    throw new GraceCommandError(
      "invalid-arguments",
      "CloseEvidence Command exited non-zero; refuse to record outcome pass.",
    );
  }
  return withCandidateLock(projectRoot, changeId, () => {
  const bundlePath = resolveChangeBundle(projectRoot, changeId);
  assertCandidatePublished(bundlePath, changeId);
  const ledgerPath = path.join(bundlePath, "run-ledger.xml");
  const specPath = path.join(bundlePath, "spec.xml");
  const currentBytes = existsSync(ledgerPath) ? readFileSync(ledgerPath, "utf8") : null;
  const currentSpecBytes = existsSync(specPath) ? readFileSync(specPath, "utf8") : null;
  let currentIdentity: { dev: number; ino: number } | undefined;
  try {
    const stat = statSync(bundlePath);
    currentIdentity = { dev: stat.dev, ino: stat.ino };
  } catch {
    currentIdentity = undefined;
  }
  // Three-phase: refuse a verdict written against a stale location, directory
  // identity, spec bytes, or ledger bytes (AC-REVIEW-VERDICT-THREE-PHASE).
  if (
    bundlePath !== snapshot.bundlePath
    || currentBytes !== snapshot.ledgerBytes
    || currentSpecBytes !== snapshot.specBytes
    || currentIdentity === undefined
    || currentIdentity.dev !== snapshot.dev
    || currentIdentity.ino !== snapshot.ino
  ) {
    throw new GraceCommandError(
      "invalid-project",
      "bundle location, identity, spec.xml, or run-ledger.xml changed during verdict evaluation; refusing to record a verdict against a stale snapshot.",
    );
  }
  const root = loadOrCreateLedgerRoot(bundlePath, changeId);
  const wrapper = ensureWrapper(root, changeId);
  const section = ensureSection(wrapper, "Verdicts");
  const attributes: Record<string, string> = { outcome: stored.outcome };
  if (stored.reason) attributes.reason = stored.reason;
  if (stored.scope) attributes.scope = stored.scope;
  if (stored.task) attributes.task = stored.task;
  if (stored.wave) attributes.wave = stored.wave;
  if (stored.classification) attributes.classification = stored.classification;
  if (stored.constituentTasksPassed !== undefined) {
    attributes.constituentTasksPassed = stored.constituentTasksPassed ? "true" : "false";
  }
  if (stored.constituentTasksPassedReason) {
    attributes.constituentTasksPassedReason = stored.constituentTasksPassedReason;
  }
  if (stored.snapshotDigest) attributes.snapshotDigest = stored.snapshotDigest;
  const findingChildren: GraceXmlNode[] = (stored.findings ?? []).map((finding) => ({
    tag: "Finding",
    attributes: {
      code: finding.code,
      file: finding.file,
      findingId: finding.findingId,
      severity: finding.severity,
      ruleId: finding.ruleId,
      anchorOrHunkKey: finding.anchorOrHunkKey,
      message: finding.message,
    },
    children: [],
    text: "",
  }));
  const ackChildren: GraceXmlNode[] = (stored.acks ?? []).map((ack) => ({
    tag: "Ack",
    attributes: {
      findingId: ack.findingId,
      snapshotDigest: ack.snapshotDigest,
    },
    children: [],
    text: "",
  }));
  section.children.push({
    tag: "Verdict",
    attributes,
    children: [...findingChildren, ...ackChildren, ...closeChildren],
    text: stored.note ?? "",
  });
  writeAndVerifyLedger(bundlePath, root);
  return stored;
  });
}

function isAppliedArchiveBundle(bundlePath: string, specStatus: string | undefined): boolean {
  const archiveMarker = `${path.sep}changes${path.sep}archive${path.sep}`;
  return bundlePath.includes(archiveMarker) && specStatus === "applied";
}

function evaluateCloseEvidenceChildren(projectRoot: string, bundlePath: string): GraceXmlNode[] {
  const specPath = path.join(bundlePath, "spec.xml");
  if (!existsSync(specPath)) return [];
  const spec = readGraceXmlArtifact(specPath);
  if (!isAppliedArchiveBundle(bundlePath, spec.root?.attributes.status)) {
    return [];
  }
  const wrapper = spec.root?.children.find((child) => ANCHOR_PATTERNS.change.test(child.tag));
  if (!wrapper) return [];
  const children: GraceXmlNode[] = [];
  for (const section of wrapper.children.filter((child) => child.tag === "AcceptanceCriteria")) {
    for (const node of walkNodes(section)) {
      if (node === section || !isCloseBoundCriterion(node)) continue;
      const close = node.children.find((child) => child.tag === "CloseEvidence");
      if (!close) continue;
      let exitCode = 0;
      let result: "pass" | "fail" = "pass";
      for (const command of close.children.filter((child) => child.tag === "Command" && child.text.trim())) {
        const spawned = spawnShellCommand(command.text.trim(), projectRoot);
        const code = spawned.exitCode ?? 1;
        exitCode = code;
        if (code !== 0) {
          result = "fail";
          break;
        }
      }
      children.push({
        tag: node.tag,
        attributes: {},
        children: [
          { tag: "Exit", attributes: {}, children: [], text: String(exitCode) },
          { tag: "Result", attributes: {}, children: [], text: result },
        ],
        text: "",
      });
    }
  }
  return children;
}

/** Append a gate decision to the ledger Decisions section (A30.2). Leaves run/ untouched. */
export function recordGateDecision(
  projectRoot: string,
  changeId: string,
  decision: GateDecisionRecord,
): GateDecisionRecord {
  return withCandidateLock(projectRoot, changeId, () => {
  const bundlePath = resolveChangeBundle(projectRoot, changeId);
  assertCandidatePublished(bundlePath, changeId);
  const root = loadOrCreateLedgerRoot(bundlePath, changeId);
  const wrapper = ensureWrapper(root, changeId);
  const section = ensureSection(wrapper, "Decisions");
  const reqChildren: GraceXmlNode[] = decision.requirements.map((req) => ({
    tag: "Requirement",
    attributes: {
      id: req.id,
      required: req.required ? "true" : "false",
      present: req.present ? "true" : "false",
      blocking: req.blocking ? "true" : "false",
    },
    children: [],
    text: req.message ?? "",
  }));
  const attributes: Record<string, string> = {
    gate: decision.gate,
    decision: decision.decision,
  };
  if (decision.decision === "permit") {
    if (decision.gate === "approve") {
      const stored = firstStoredBaseCommit(section);
      const incoming = (decision.baseCommit ?? "").trim();
      const value = stored ?? (incoming || undefined);
      if (value) attributes.baseCommit = value;
    }
    // Fingerprints, artifact names, and forced permits persist on approve and
    // on applied (the write records); evaluation gates apply and archive never
    // carry them (C-APPROVAL-FINGERPRINT), and applied never stores baseCommit.
    if (decision.gate === "approve" || decision.gate === "applied") {
      if (decision.fingerprint) attributes.fingerprint = decision.fingerprint;
      if (decision.artifact) attributes.artifact = decision.artifact;
      if (decision.forced === true) {
        attributes.forced = "true";
        const reason = (decision.reason ?? "").trim();
        if (reason) attributes.reason = reason;
      }
    }
  }
  section.children.push({
    tag: "Decision",
    attributes,
    children: reqChildren,
    text: "",
  });
  writeAndVerifyLedger(bundlePath, root);
  return decision;
  });
}

/**
 * Sole three-exit classification for run-ledger.xml → change wrapper
 * (C-LEGIBLE-FAILURE / AC-SINGLE-CLASSIFICATION).
 *
 * exists → regular file → parses → correct root → wrapper for changeId.
 * No second production definition of this chain may exist.
 */
export type LedgerWrapperSurface =
  | { state: "absent-no-file" }
  | { state: "unreadable"; code: string; detail: string }
  | { state: "ok"; wrapper: GraceXmlNode };

/**
 * Classify ledger file presence and the change-id wrapper under the ledger root.
 * Callers map exits into their own result types; they must not re-implement this chain.
 */
export function readLedgerWrapper(bundlePath: string, changeId: string): LedgerWrapperSurface {
  const ledgerPath = path.join(bundlePath, "run-ledger.xml");
  if (!existsSync(ledgerPath)) {
    return { state: "absent-no-file" };
  }

  try {
    const st = statSync(ledgerPath);
    if (!st.isFile()) {
      return {
        state: "unreadable",
        code: "xml.parse",
        detail: `run-ledger.xml is not a regular file (${st.isDirectory() ? "directory" : "special"})`,
      };
    }
  } catch (error) {
    return {
      state: "unreadable",
      code: "xml.parse",
      detail: error instanceof Error ? error.message : String(error),
    };
  }

  let artifact: ReturnType<typeof readGraceXmlArtifact>;
  try {
    artifact = readGraceXmlArtifact(ledgerPath);
  } catch (error) {
    return {
      state: "unreadable",
      code: "xml.parse",
      detail: error instanceof Error ? error.message : String(error),
    };
  }

  if (!artifact.root) {
    const issue = artifact.issues[0];
    return {
      state: "unreadable",
      code: issue?.code ?? "xml.parse",
      detail: issue?.message ?? "run-ledger.xml could not be parsed",
    };
  }

  // Corr 187: a non-ledger root with a matching wrapper must not look like ok/empty.
  // Match lint code ledger.invalid-root-tag (grammar validateRunLedger).
  const expectedRoot = `${ARTIFACT_TAG_PREFIX}RunLedger`;
  if (artifact.root.tag !== expectedRoot) {
    return {
      state: "unreadable",
      code: "ledger.invalid-root-tag",
      detail: `Unsupported run ledger root tag '${artifact.root.tag}'. Expected ${expectedRoot}.`,
    };
  }

  const wrapper = artifact.root.children.find((child) => child.tag === changeId);
  if (!wrapper) {
    return {
      state: "unreadable",
      code: "ledger.bundle-id-mismatch",
      detail: `run-ledger.xml has no wrapper for ${changeId}`,
    };
  }

  return { state: "ok", wrapper };
}

/**
 * Distinguishes absent-no-file vs unreadable vs ok for plan-quality and other consumers
 * that must not shrink a corpus silently (corr 185–187 / A31.2 / D5).
 *
 * Shared prefix (exists → parse → wrapper) is readLedgerWrapper only. This function
 * continues with Verdicts section → children after ok(wrapper).
 */
export type LedgerVerdictsSurface =
  | { state: "absent-no-file" }
  | { state: "unreadable"; code: string; detail: string }
  | { state: "ok"; verdicts: ReviewVerdictRecord[] };

export function readLedgerVerdictsSurface(
  projectRoot: string,
  changeId: string,
): LedgerVerdictsSurface {
  let bundlePath: string;
  try {
    bundlePath = resolveChangeBundle(projectRoot, changeId);
  } catch {
    return { state: "absent-no-file" };
  }

  const classified = readLedgerWrapper(bundlePath, changeId);
  if (classified.state === "absent-no-file") {
    return { state: "absent-no-file" };
  }
  if (classified.state === "unreadable") {
    return { state: "unreadable", code: classified.code, detail: classified.detail };
  }

  const { wrapper } = classified;
  const selected = selectUniqueSection(wrapper, "Verdicts");
  if (selected.state === "absent") {
    return { state: "ok", verdicts: [] };
  }
  if (selected.state === "invalid") {
    return {
      state: "unreadable",
      code: "ledger.invalid-verdict",
      detail: selected.detail,
    };
  }

  const verdicts: ReviewVerdictRecord[] = [];
  for (const child of selected.section.children) {
    if (child.tag !== "Verdict") {
      return {
        state: "unreadable",
        code: "ledger.invalid-verdict",
        detail: `unexpected <${child.tag}> under Verdicts`,
      };
    }
    const parsed = parseVerdictNode(child);
    if ("invalid" in parsed) {
      return {
        state: "unreadable",
        code: "ledger.invalid-verdict",
        detail: parsed.invalid,
      };
    }
    verdicts.push(parsed);
  }
  return { state: "ok", verdicts };
}

function parseVerdictNode(child: GraceXmlNode): ReviewVerdictRecord | { invalid: string } {
  const outcome = child.attributes.outcome;
  if (!outcome || !VALID_OUTCOMES.has(outcome)) {
    return { invalid: `outcome=${outcome ?? "(missing)"}` };
  }
  const scopeRaw = (child.attributes.scope ?? "").trim();
  if (scopeRaw && !VALID_SCOPES.has(scopeRaw)) {
    return { invalid: `scope=${scopeRaw}` };
  }
  const classRaw = (child.attributes.classification ?? "").trim();
  if (classRaw && !VALID_CLASSIFICATIONS.has(classRaw)) {
    return { invalid: `classification=${classRaw}` };
  }
  const ctpRaw = (child.attributes.constituentTasksPassed ?? "").trim();
  if (ctpRaw && ctpRaw !== "true" && ctpRaw !== "false") {
    return { invalid: `constituentTasksPassed=${ctpRaw}` };
  }
  const record: ReviewVerdictRecord = {
    outcome: outcome as ReviewVerdictOutcome,
    reason: child.attributes.reason || undefined,
    note: child.text.trim() || undefined,
  };
  // Never invent scope when attribute is absent (corr 182 retro-label forbid).
  if (scopeRaw) record.scope = scopeRaw as ReviewVerdictScope;
  if (child.attributes.task?.trim()) record.task = child.attributes.task.trim();
  if (child.attributes.wave?.trim()) record.wave = child.attributes.wave.trim();
  if (classRaw) record.classification = classRaw as ResolutionClassification;
  if (ctpRaw === "true") record.constituentTasksPassed = true;
  if (ctpRaw === "false") record.constituentTasksPassed = false;
  if (child.attributes.constituentTasksPassedReason?.trim()) {
    record.constituentTasksPassedReason = child.attributes.constituentTasksPassedReason.trim();
  }
  if (child.attributes.snapshotDigest?.trim()) {
    record.snapshotDigest = child.attributes.snapshotDigest.trim();
  }
  const findings: VerdictFindingRecord[] = [];
  const acks: VerdictAckRecord[] = [];
  for (const node of child.children) {
    if (node.tag === "Finding") {
      findings.push({
        code: node.attributes.code ?? "",
        file: node.attributes.file ?? "",
        findingId: node.attributes.findingId ?? "",
        severity: node.attributes.severity ?? "",
        ruleId: node.attributes.ruleId ?? "",
        anchorOrHunkKey: node.attributes.anchorOrHunkKey ?? "",
        message: node.attributes.message ?? "",
      });
    } else if (node.tag === "Ack") {
      acks.push({
        findingId: node.attributes.findingId ?? "",
        snapshotDigest: node.attributes.snapshotDigest ?? "",
      });
    }
  }
  if (record.snapshotDigest) record.findings = findings;
  if (acks.length > 0) record.acks = acks;
  const closeEvidence = collectCloseEvidenceEvaluations(child);
  if (closeEvidence.length > 0) record.closeEvidence = closeEvidence;
  return record;
}

function parseDecisionNode(child: GraceXmlNode): GateDecisionRecord | { invalid: string } {
  const gate = child.attributes.gate;
  const decision = child.attributes.decision;
  if (!gate || !VALID_GATES.has(gate) || !decision || !VALID_DECISIONS.has(decision)) {
    return {
      invalid: `gate=${gate ?? "(missing)"} decision=${decision ?? "(missing)"}`,
    };
  }
  const requirements: GateRequirementRecord[] = [];
  for (const req of child.children) {
    if (req.tag !== "Requirement") {
      return { invalid: `non-Requirement child <${req.tag}> under Decision` };
    }
    if (!(req.attributes.id ?? "").trim()) {
      return { invalid: "Requirement missing id" };
    }
    requirements.push({
      id: req.attributes.id ?? "",
      required: req.attributes.required === "true",
      present: req.attributes.present === "true",
      blocking: req.attributes.blocking === "true",
      message: req.text.trim() || undefined,
    });
  }
  const record: GateDecisionRecord = {
    gate: gate as DecisionGateId,
    decision: decision as GateDecisionValue,
    requirements,
  };
  const baseCommit = (child.attributes.baseCommit ?? "").trim();
  if (baseCommit) record.baseCommit = baseCommit;
  const fingerprint = (child.attributes.fingerprint ?? "").trim();
  if (fingerprint) record.fingerprint = fingerprint;
  const artifact = (child.attributes.artifact ?? "").trim();
  if (artifact === "spec" || artifact === "plan") record.artifact = artifact;
  if ((child.attributes.forced ?? "").trim() === "true") record.forced = true;
  const reason = (child.attributes.reason ?? "").trim();
  if (reason) record.reason = reason;
  return record;
}

function firstStoredBaseCommit(section: GraceXmlNode): string | undefined {
  for (const child of section.children) {
    if (child.tag !== "Decision") continue;
    if (child.attributes.gate !== "approve") continue;
    if (child.attributes.decision !== "permit") continue;
    const value = (child.attributes.baseCommit ?? "").trim();
    if (value) return value;
  }
  return undefined;
}

/**
 * Select the unique named section under the change wrapper (A32.1 / correction 68).
 * Duplicate sections make "newest" undefined → invalid, never first-wins.
 */
function selectUniqueSection(
  wrapper: GraceXmlNode,
  tag: "Verdicts" | "Decisions",
):
  | { state: "absent" }
  | { state: "invalid"; detail: string }
  | { state: "ok"; section: GraceXmlNode } {
  const matches = wrapper.children.filter((child) => child.tag === tag);
  if (matches.length === 0) return { state: "absent" };
  if (matches.length > 1) {
    return {
      state: "invalid",
      detail: `duplicate ${tag} sections (${matches.length}); newest is undefined`,
    };
  }
  return { state: "ok", section: matches[0]! };
}

/**
 * Newest Verdict entry governs (A31.2). Section must be unique and every child
 * validator-clean (A32.1) — filter is not a read strategy.
 */
export function readLatestReviewVerdict(projectRoot: string, changeId: string): LatestReviewVerdict {
  const bundlePath = resolveChangeBundle(projectRoot, changeId);
  const classified = readLedgerWrapper(bundlePath, changeId);
  if (classified.state === "absent-no-file") return { state: "absent" };
  if (classified.state === "unreadable") {
    return {
      state: "invalid",
      code: classified.code,
      detail: classified.detail,
    };
  }
  const { wrapper } = classified;
  const selected = selectUniqueSection(wrapper, "Verdicts");
  if (selected.state === "absent") return { state: "absent" };
  if (selected.state === "invalid") {
    return {
      state: "invalid",
      code: "ledger.invalid-verdict",
      detail: selected.detail,
    };
  }
  const { section } = selected;
  if (section.children.length === 0) return { state: "absent" };

  // Every child must be a valid Verdict — no filter, no skip (A32.1 second facet).
  const parsedEntries: ReviewVerdictRecord[] = [];
  for (const child of section.children) {
    if (child.tag !== "Verdict") {
      return {
        state: "invalid",
        code: "ledger.invalid-verdict",
        detail: `unexpected <${child.tag}> under Verdicts`,
      };
    }
    const parsed = parseVerdictNode(child);
    if ("invalid" in parsed) {
      return {
        state: "invalid",
        code: "ledger.invalid-verdict",
        detail: parsed.invalid,
      };
    }
    parsedEntries.push(parsed);
  }
  return { state: "present", verdict: parsedEntries[parsedEntries.length - 1]! };
}

/**
 * All recorded review verdicts (oldest first). Throws when the section is duplicated
 * or any child is unreadable so callers cannot convert an absence into a shorter list.
 */
export function listReviewVerdicts(projectRoot: string, changeId: string): ReviewVerdictRecord[] {
  const read = readLatestReviewVerdict(projectRoot, changeId);
  if (read.state === "invalid") {
    throw new GraceCommandError(
      "invalid-project",
      `${read.code}: ${read.detail}`,
      { issues: [read.code] },
    );
  }
  if (read.state === "absent") return [];
  // Re-walk for the full list (section already known clean via readLatest).
  const bundlePath = resolveChangeBundle(projectRoot, changeId);
  const classified = readLedgerWrapper(bundlePath, changeId);
  if (classified.state !== "ok") return [];
  const selected = selectUniqueSection(classified.wrapper, "Verdicts");
  if (selected.state !== "ok") return [];
  return selected.section.children.map((child) => {
    const parsed = parseVerdictNode(child);
    if ("invalid" in parsed) {
      throw new GraceCommandError(
        "invalid-project",
        `ledger.invalid-verdict: ${parsed.invalid}`,
        { issues: ["ledger.invalid-verdict"] },
      );
    }
    return parsed;
  });
}

/** @deprecated Prefer readLatestReviewVerdict — this collapses invalid to undefined. */
export function latestReviewVerdict(
  projectRoot: string,
  changeId: string,
): ReviewVerdictRecord | undefined {
  const read = readLatestReviewVerdict(projectRoot, changeId);
  return read.state === "present" ? read.verdict : undefined;
}

/** All recorded gate decisions with no silent skip of unreadable entries (A31.2 / A32.1). */
export function readGateDecisions(projectRoot: string, changeId: string): DecisionListResult {
  const bundlePath = resolveChangeBundle(projectRoot, changeId);
  const classified = readLedgerWrapper(bundlePath, changeId);
  if (classified.state === "absent-no-file") {
    return { state: "ok", decisions: [], sectionPresent: false };
  }
  if (classified.state === "unreadable") {
    return {
      state: "invalid",
      code: classified.code,
      detail: classified.detail,
    };
  }
  const selected = selectUniqueSection(classified.wrapper, "Decisions");
  if (selected.state === "absent") return { state: "ok", decisions: [], sectionPresent: false };
  if (selected.state === "invalid") {
    return {
      state: "invalid",
      code: "ledger.invalid-decision",
      detail: selected.detail,
    };
  }
  const out: GateDecisionRecord[] = [];
  for (const child of selected.section.children) {
    if (child.tag !== "Decision") {
      return {
        state: "invalid",
        code: "ledger.invalid-decision",
        detail: `unexpected <${child.tag}> under Decisions`,
      };
    }
    const parsed = parseDecisionNode(child);
    if ("invalid" in parsed) {
      return {
        state: "invalid",
        code: "ledger.invalid-decision",
        detail: parsed.invalid,
      };
    }
    out.push(parsed);
  }
  return { state: "ok", decisions: out, sectionPresent: true };
}

/**
 * All recorded gate decisions (oldest first). Throws when any entry is unreadable
 * so callers cannot convert an absence into a shorter valid list (A31.2).
 */
export function listGateDecisions(projectRoot: string, changeId: string): GateDecisionRecord[] {
  const result = readGateDecisions(projectRoot, changeId);
  if (result.state === "invalid") {
    throw new GraceCommandError(
      "invalid-project",
      `${result.code}: ${result.detail}`,
      { issues: [result.code] },
    );
  }
  return result.decisions;
}

/**
 * Permit lookup that keeps the reason when the Decisions section is unreadable (A32.1)
 * and distinguishes no section (A33.1 grandfather) from section-without-permit (violation).
 */
export function readPermittingDecision(
  projectRoot: string,
  changeId: string,
  gate: GateId,
): PermittingDecisionStatus {
  const result = readGateDecisions(projectRoot, changeId);
  if (result.state === "invalid") {
    return {
      state: "invalid",
      code: result.code,
      detail: result.detail,
    };
  }
  if (result.decisions.some((entry) => entry.gate === gate && entry.decision === "permit")) {
    return { state: "permit" };
  }
  if (!result.sectionPresent) {
    return { state: "absent", reason: "no-decisions-section" };
  }
  return { state: "no-permit" };
}

/**
 * True when a permitting decision for `gate` exists. Prefer `readPermittingDecision`
 * when the absence reason must reach a report (A32.1).
 */
export function hasPermittingDecision(
  projectRoot: string,
  changeId: string,
  gate: GateId,
): boolean {
  return readPermittingDecision(projectRoot, changeId, gate).state === "permit";
}

/** Exported for tests — tags admitted as non-epoch ledger sections. */
export const LEDGER_NON_EPOCH_SECTIONS = LEDGER_BUNDLE_SECTIONS;

export type ApprovedArtifactName = "spec" | "plan";

export type ApprovedArtifactClassification =
  | { kind: "never-asked" }
  | { kind: "mismatch" }
  | { kind: "match" }
  | { kind: "unfingerprinted"; trackedChanged: boolean }
  | { kind: "git-unavailable"; absence: { verdict: "unable-to-determine"; reason: string } };

function applyingApproveDecision(
  decisions: GateDecisionRecord[],
  artifact: ApprovedArtifactName,
): GateDecisionRecord | undefined {
  const permits = decisions.filter((entry) => entry.gate === "approve" && entry.decision === "permit");
  const named = permits.filter((entry) => entry.artifact === "spec" || entry.artifact === "plan");
  if (named.length > 0) {
    const forFile = permits.filter((entry) => entry.artifact === artifact);
    return forFile.length > 0 ? forFile[forFile.length - 1] : undefined;
  }
  return permits.length > 0 ? permits[permits.length - 1] : undefined;
}

export type AmendmentInstrument = {
  reRatificationCount: number;
  supersedeChainDepth: number;
};

function replacementIdsFromFile(filePath: string): string[] {
  if (!existsSync(filePath)) return [];
  const artifact = readGraceXmlArtifact(filePath);
  const wrapper = artifact.root?.children.find((child) => ANCHOR_PATTERNS.change.test(child.tag));
  if (!wrapper) return [];
  const ids: string[] = [];
  const seen = new Set<string>();
  for (const child of wrapper.children) {
    let id: string | undefined;
    if (ANCHOR_PATTERNS.change.test(child.tag)) id = child.tag;
    else if (
      (child.tag === "Replacement" || child.tag === "ReplacementChange")
      && ANCHOR_PATTERNS.change.test(child.text.trim())
    ) {
      id = child.text.trim();
    }
    if (id && !seen.has(id)) {
      seen.add(id);
      ids.push(id);
    }
  }
  return ids;
}

function replacementIdsForBundle(bundlePath: string): string[] {
  const specIds = replacementIdsFromFile(path.join(bundlePath, "spec.xml"));
  if (specIds.length > 0) return specIds;
  return replacementIdsFromFile(path.join(bundlePath, "plan.xml"));
}

function listChangeBundleDirs(projectRoot: string): Array<{ changeId: string; bundlePath: string }> {
  const root = path.resolve(projectRoot);
  const out: Array<{ changeId: string; bundlePath: string }> = [];
  for (const location of ["active", "archive"] as const) {
    const directory = path.join(root, ARTIFACT_DIR, "changes", location);
    if (!existsSync(directory)) continue;
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      if (entry.isDirectory() && ANCHOR_PATTERNS.change.test(entry.name)) {
        out.push({ changeId: entry.name, bundlePath: path.join(directory, entry.name) });
      }
    }
  }
  return out;
}

const PREDECESSOR_CACHE = new Map<string, { revision: string; map: Map<string, readonly string[]> }>();

/** Test seam: rebuilds observed, so a guard can assert the memo is used. */
export const __predecessorMemoStats = { builds: 0 };

/** Test seam: drop every cached predecessor map. */
export function __resetPredecessorCache(): void {
  PREDECESSOR_CACHE.clear();
  __predecessorMemoStats.builds = 0;
}

/** Test seam: the read-only view the memo hands back, for the mutation-boundary probe. */
export function __predecessorMapView(projectRoot: string): Map<string, readonly string[]> {
  return buildPredecessorMap(projectRoot);
}

/** Sorted (bundle name, spec/plan size, mtimeMs) over active+archive bundle dirs. */
function bundleRevision(root: string): string {
  const parts: string[] = [];
  for (const location of ["active", "archive"] as const) {
    const directory = path.join(root, ARTIFACT_DIR, "changes", location);
    if (!existsSync(directory)) continue;
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      if (!entry.isDirectory() || !ANCHOR_PATTERNS.change.test(entry.name)) continue;
      let sig = "";
      for (const file of ["spec.xml", "plan.xml"]) {
        try {
          const st = statSync(path.join(directory, entry.name, file));
          sig += `:${st.size}:${st.mtimeMs}`;
        } catch {
          sig += ":-";
        }
      }
      parts.push(`${location}/${entry.name}${sig}`);
    }
  }
  parts.sort();
  return parts.join("|");
}

function buildPredecessorMap(projectRoot: string): Map<string, readonly string[]> {
  const root = path.resolve(projectRoot);
  const revision = bundleRevision(root);
  const cached = PREDECESSOR_CACHE.get(root);
  if (cached && cached.revision === revision) {
    return new Map(cached.map);
  }
  const mutable = new Map<string, string[]>();
  for (const { changeId, bundlePath } of listChangeBundleDirs(root)) {
    for (const target of replacementIdsForBundle(bundlePath)) {
      const list = mutable.get(target) ?? [];
      list.push(changeId);
      mutable.set(target, list);
    }
  }
  const predecessors = new Map<string, readonly string[]>();
  for (const [target, list] of mutable) predecessors.set(target, Object.freeze([...list]));
  __predecessorMemoStats.builds += 1;
  PREDECESSOR_CACHE.set(root, { revision, map: predecessors });
  return new Map(predecessors);
}

function chainDepth(
  changeId: string,
  predecessors: Map<string, readonly string[]>,
  visited: Set<string>,
): number {
  if (visited.has(changeId)) return 0;
  const next = new Set(visited);
  next.add(changeId);
  const preds = predecessors.get(changeId) ?? [];
  if (preds.length === 0) return 0;
  let max = 0;
  for (const pred of preds) {
    const depth = chainDepth(pred, predecessors, next);
    if (depth > max) max = depth;
  }
  return 1 + max;
}

function reRatificationCountFromDecisions(listed: DecisionListResult): number {
  if (listed.state !== "ok") return 0;
  const previous = new Map<"spec" | "plan", string>();
  let count = 0;
  for (const entry of listed.decisions) {
    if (entry.gate !== "approve") continue;
    if (entry.decision !== "permit") continue;
    if (entry.artifact !== "spec" && entry.artifact !== "plan") continue;
    const fingerprint = (entry.fingerprint ?? "").trim();
    if (!fingerprint) continue;
    const last = previous.get(entry.artifact);
    if (last === undefined) {
      previous.set(entry.artifact, fingerprint);
      continue;
    }
    if (last !== fingerprint) {
      count += 1;
      previous.set(entry.artifact, fingerprint);
    }
  }
  return count;
}

export function readAmendmentInstrument(projectRoot: string, changeId: string): AmendmentInstrument {
  const listed = readGateDecisions(projectRoot, changeId);
  return {
    reRatificationCount: reRatificationCountFromDecisions(listed),
    supersedeChainDepth: chainDepth(changeId, buildPredecessorMap(projectRoot), new Set()),
  };
}

function readTrackedChangedFiles(projectRoot: string):
  | { kind: "ok"; tracked: Set<string> }
  | { kind: "unavailable" } {
  const statusResult = Bun.spawnSync({
    cmd: ["git", "-c", "status.relativePaths=true", "status", "--porcelain=v1", "-z", "--untracked-files=all", "--", "."],
    cwd: projectRoot,
    stdout: "pipe",
    stderr: "pipe",
  });
  if (statusResult.exitCode !== 0) return { kind: "unavailable" };
  const output = new TextDecoder().decode(statusResult.stdout);
  const records = output.split("\0");
  const tracked = new Set<string>();
  for (let index = 0; index < records.length; index += 1) {
    const record = records[index];
    if (!record || record.length < 4) continue;
    const status = record.slice(0, 2);
    if (status.includes("R") || status.includes("C")) {
      index += 1;
    }
    if (status === "??") continue;
    const filePath = record.slice(3).replaceAll("\\", "/").replace(/^\.\//, "");
    if (!filePath || filePath.startsWith("../") || filePath === ".." || path.posix.isAbsolute(filePath)) continue;
    tracked.add(filePath);
  }
  return { kind: "ok", tracked };
}

/**
 * Three-way classification of one approved spec or plan. Owns the porcelain read.
 * Callers pass no changed-file set.
 */
export function classifyApprovedArtifact(
  projectRoot: string,
  changeId: string,
  artifact: ApprovedArtifactName,
): ApprovedArtifactClassification {
  const listed = readGateDecisions(projectRoot, changeId);
  const decisions = listed.state === "ok" ? listed.decisions : [];
  const applying = applyingApproveDecision(decisions, artifact);
  if (!applying) return { kind: "never-asked" };
  const fingerprint = (applying.fingerprint ?? "").trim();
  if (fingerprint) {
    const filePath = path.join(
      resolveChangeBundle(projectRoot, changeId),
      artifact === "spec" ? "spec.xml" : "plan.xml",
    );
    const digest = createHash("sha256").update(readFileSync(filePath)).digest("hex");
    return digest === fingerprint ? { kind: "match" } : { kind: "mismatch" };
  }
  const porcelain = readTrackedChangedFiles(projectRoot);
  if (porcelain.kind === "unavailable") {
    return {
      kind: "git-unavailable",
      absence: { verdict: "unable-to-determine", reason: "git unavailable" },
    };
  }
  const bundlePath = path
    .relative(path.resolve(projectRoot), resolveChangeBundle(projectRoot, changeId))
    .replaceAll(path.sep, "/");
  const relative = `${bundlePath}/${artifact === "spec" ? "spec.xml" : "plan.xml"}`;
  return { kind: "unfingerprinted", trackedChanged: porcelain.tracked.has(relative) };
}

function rootOpeningTag(fileText: string): string | undefined {
  const end = fileText.indexOf(">");
  if (end < 0) return undefined;
  return fileText.slice(0, end + 1);
}

type CompactStatusAttribute = {
  quote: '"' | "'";
  value: string;
  start: number;
  end: number;
};

function locateCompactStatus(open: string, quote: '"' | "'"): CompactStatusAttribute | undefined {
  const key = `status=${quote}`;
  const start = open.indexOf(key);
  if (start < 0) return undefined;
  const from = start + key.length;
  const end = open.indexOf(quote, from);
  if (end < 0) return undefined;
  return { quote, value: open.slice(from, end), start, end };
}

function findCompactStatusAttribute(open: string): CompactStatusAttribute | undefined {
  const doubleQuoted = locateCompactStatus(open, '"');
  const singleQuoted = locateCompactStatus(open, "'");
  if (doubleQuoted && singleQuoted) {
    return doubleQuoted.start < singleQuoted.start ? doubleQuoted : singleQuoted;
  }
  return doubleQuoted ?? singleQuoted;
}

function rootStatusFromFile(filePath: string): string | undefined {
  const text = readFileSync(filePath, "utf8");
  const open = rootOpeningTag(text);
  if (!open) return undefined;
  return findCompactStatusAttribute(open)?.value;
}

function withOpeningTagStatus(text: string, to: string): string | undefined {
  const open = rootOpeningTag(text);
  if (!open) return undefined;
  const found = findCompactStatusAttribute(open);
  if (!found) return undefined;
  return `${open.slice(0, found.start)}status=${found.quote}${to}${found.quote}${open.slice(found.end + 1)}${text.slice(open.length)}`;
}

function writeDraftRootToApproved(filePath: string): void {
  const text = readFileSync(filePath, "utf8");
  const open = rootOpeningTag(text);
  const found = open ? findCompactStatusAttribute(open) : undefined;
  if (open && found && found.value === "draft") {
    const next = withOpeningTagStatus(text, "approved");
    if (next !== undefined) {
      writeFileSync(filePath, next);
      return;
    }
  }
  const parsed = parseGraceXmlArtifact(filePath, text);
  if (parsed.root?.attributes.status === "draft") {
    throw new GraceCommandError(
      "invalid-project",
      `Could not locate a compact opening-tag status attribute to write on ${filePath}; grammar parse reads status draft.`,
    );
  }
}

function changeLocationDir(projectRoot: string, location: "active" | "archive", changeId: string): string {
  return path.join(projectRoot, ARTIFACT_DIR, "changes", location, changeId);
}

function replacementIdsFromWrapper(wrapper: GraceXmlNode): string[] {
  return [...new Set(wrapper.children.flatMap((child) => {
    if (ANCHOR_PATTERNS.change.test(child.tag)) return [child.tag];
    if (
      (child.tag === "Replacement" || child.tag === "ReplacementChange")
      && ANCHOR_PATTERNS.change.test(child.text.trim())
    ) {
      return [child.text.trim()];
    }
    return [];
  }))];
}

function insertReplacementElement(text: string, wrapperTag: string, replacementId: string): string {
  const open = rootOpeningTag(text);
  if (!open) {
    throw new GraceCommandError("invalid-project", "Change artifact is missing a root opening tag.");
  }
  const rest = text.slice(open.length);
  const match = rest.match(new RegExp(`<${wrapperTag}\\b[^>]*>`));
  if (!match || match.index === undefined) {
    throw new GraceCommandError("invalid-project", `Could not locate wrapper opening tag ${wrapperTag}.`);
  }
  const at = open.length + match.index + match[0].length;
  return `${text.slice(0, at)}<Replacement>${replacementId}</Replacement>${text.slice(at)}`;
}

function nextSupersededArtifactBytes(filePath: string, replacementId: string): string {
  const text = readFileSync(filePath, "utf8");
  const parsed = parseGraceXmlArtifact(filePath, text);
  const status = parsed.root?.attributes.status;
  const wrapper = parsed.root?.children.find((child) => ANCHOR_PATTERNS.change.test(child.tag));
  if (!wrapper) {
    throw new GraceCommandError("invalid-project", `Change artifact ${filePath} is missing a C-* wrapper.`);
  }
  let next = text;
  if (status === "draft" || status === "approved") {
    const swapped = withOpeningTagStatus(text, "superseded");
    if (swapped === undefined) {
      throw new GraceCommandError(
        "invalid-project",
        `Could not locate a compact opening-tag status attribute to write on ${filePath}; grammar parse reads status ${status}.`,
      );
    }
    next = swapped;
  } else if (status === "superseded") {
    next = text;
  } else {
    throw new GraceCommandError(
      "invalid-arguments",
      `Cannot supersede a ${status ?? "missing-status"} artifact at ${filePath}.`,
    );
  }
  const existing = replacementIdsFromWrapper(wrapper);
  if (existing.length === 0) {
    return insertReplacementElement(next, wrapper.tag, replacementId);
  }
  if (existing.length === 1 && existing[0] === replacementId) {
    return next;
  }
  throw new GraceCommandError(
    "invalid-arguments",
    `Existing replacement set on ${filePath} is not empty and is not exactly ${replacementId}.`,
  );
}

function isExdev(error: unknown): boolean {
  return typeof error === "object" && error !== null && "code" in error && (error as { code?: unknown }).code === "EXDEV";
}

/**
 * Surgical superseded write, Replacement insert, and same-filesystem rename. Command-path only.
 *
 * The `io` bag exists solely to test the EXDEV refuse-after-rollback path: a cross-device rename
 * cannot be provoked through a spawned CLI, and chmod yields EACCES rather than EXDEV. It follows
 * the precedent of the injectFailure* hooks at grace-cursor.ts:1053 — unreachable from the CLI,
 * shipped with this module because the write surface is one file, and kept so the rollback
 * ordering stays mechanically testable without a second test-only package.
 */
/** The lineage successor of a supersede: an existing id or a to-be-minted one. */
export type SupersedeReplacement =
  | { kind: "explicit"; id: string }
  | { kind: "mint"; id: string; mint: () => AcquiredCandidate };

/** The replacement must be the predecessor's lineage successor: same slug, next lineage (D38). */
function requireLineageSuccessor(changeId: string, replacementId: string): void {
  const predecessor = parseBundleId(changeId);
  const successor = parseBundleId(replacementId);
  if (successor.slug !== predecessor.slug || successor.lineage !== nextBundleLineage(changeId)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Replacement ${replacementId} is not the lineage successor of ${changeId} (same slug, lineage ${nextBundleLineage(changeId)}).`,
    );
  }
}

export function supersedeChangeBundle(
  projectRoot: string,
  changeId: string,
  replacement: SupersedeReplacement,
  io: {
    renameSync?: typeof renameSync;
    writeFileSync?: typeof writeFileSync;
    unlinkSync?: typeof unlinkSync;
    rmdirSync?: typeof rmdirSync;
    /** Test-only: fires after the initial explicit-replacement validation so a
     * relocation/appearance/disappearance can be driven before the under-lock
     * revalidation (AC-SUPERSEDE-VALIDATE-BEFORE-FOLD row (j)). */
    afterReplacementValidationForTests?: () => void;
    /** Test-only: observes each production cleanup invocation and its outcome,
     * invoked exactly once on every post-mint failure (AC-SUPERSEDE-ROLLBACK-CLEANUP). */
    observeCleanupForTests?: (outcome: { removed: boolean; diagnostic?: string }) => void;
  } = {},
): void {
  const replacementId = replacement.id;
  if (!ANCHOR_PATTERNS.change.test(changeId)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Change id '${changeId}' does not match the accepted pattern C- then uppercase kebab.`,
    );
  }
  if (!ANCHOR_PATTERNS.change.test(replacementId)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Replacement id '${replacementId}' does not match the accepted pattern C- then uppercase kebab.`,
    );
  }
  if (replacementId === changeId) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Replacement ${replacementId} equals the change being superseded.`,
    );
  }
  const [low, high] = changeId < replacementId ? [changeId, replacementId] : [replacementId, changeId];
  withCandidateLock(projectRoot, low, () =>
    withCandidateLock(projectRoot, high, () => {
      const activeDir = changeLocationDir(projectRoot, "active", changeId);
      const archiveDir = changeLocationDir(projectRoot, "archive", changeId);
      const replacementActive = changeLocationDir(projectRoot, "active", replacementId);
      const replacementArchive = changeLocationDir(projectRoot, "archive", replacementId);
      if (existsSync(activeDir)) assertCandidatePublished(activeDir, changeId);
      if (existsSync(replacementActive)) assertCandidatePublished(replacementActive, replacementId);
      // Explicit replacement: capture the initially validated state under the sorted
      // locks — location, mutual exclusivity, directory type, and identity — so the
      // post-seam revalidation compares against it instead of selecting a moved or
      // newly duplicated location afresh (AC-SUPERSEDE-VALIDATE-BEFORE-FOLD row (j)).
      type ReplacementState = { location: "active" | "archive"; dev: number; ino: number };
      const captureReplacementState = (): ReplacementState | undefined => {
        if (replacement.kind !== "explicit") return undefined;
        const activeExists = existsSync(replacementActive);
        const archiveExists = existsSync(replacementArchive);
        if (activeExists && archiveExists) {
          throw new GraceCommandError(
            "invalid-arguments",
            `Replacement ${replacementId} exists under both active/ and archive/; ambiguous, refusing before any fold or write.`,
          );
        }
        if (!activeExists && !archiveExists) {
          throw new GraceCommandError(
            "invalid-arguments",
            `Replacement ${replacementId} is missing as a directory under active/ or archive/.`,
          );
        }
        const located = activeExists ? replacementActive : replacementArchive;
        const identity = statSync(located);
        if (!identity.isDirectory()) {
          throw new GraceCommandError(
            "invalid-arguments",
            `Replacement ${replacementId} exists under ${activeExists ? "active/" : "archive/"} but is not a directory; refusing before any fold or write.`,
          );
        }
        return { location: activeExists ? "active" : "archive", dev: identity.dev, ino: identity.ino };
      };
      const initialReplacementState = captureReplacementState();
      // All successor existence/location and predecessor status validation must
      // precede discardAndFoldEpoch and every other write (C-SUPERSEDE-MEMBERSHIP T-003).
      if (replacement.kind === "mint" && (existsSync(replacementActive) || existsSync(replacementArchive))) {
        throw new GraceCommandError(
          "invalid-arguments",
          `Successor ${replacementId} already exists under active/ or archive/; refusing before any fold or write.`,
        );
      }
      if (existsSync(archiveDir) && !existsSync(activeDir)) {
        throw new GraceCommandError(
          "invalid-arguments",
          `Change ${changeId} is already under archive/ and not under active/; supersede only moves an active bundle.`,
        );
      }
      if (!existsSync(activeDir) || !statSync(activeDir).isDirectory()) {
        throw new GraceCommandError("not-found", `Change ${changeId} is not a directory under active/.`);
      }
      if (existsSync(archiveDir)) {
        throw new GraceCommandError(
          "invalid-arguments",
          `Archive destination already exists for ${changeId}.`,
        );
      }
      const specPath = path.join(activeDir, "spec.xml");
      const planPath = path.join(activeDir, "plan.xml");
      if (!existsSync(specPath)) {
        throw new GraceCommandError("not-found", `spec.xml not found in ${changeId}.`);
      }
      const supersedableStatuses = new Set(["draft", "approved", "superseded"]);
      const predecessorSpecStatus = rootStatusFromFile(specPath);
      if (predecessorSpecStatus === undefined || !supersedableStatuses.has(predecessorSpecStatus)) {
        throw new GraceCommandError(
          "invalid-arguments",
          `Cannot supersede ${changeId}: spec.xml status ${predecessorSpecStatus ?? "unreadable"} is not supersedable; refusing before any fold or write.`,
        );
      }
      if (existsSync(planPath)) {
        const predecessorPlanStatus = rootStatusFromFile(planPath);
        if (predecessorPlanStatus === undefined || !supersedableStatuses.has(predecessorPlanStatus)) {
          throw new GraceCommandError(
            "invalid-arguments",
            `Cannot supersede ${changeId}: plan.xml status ${predecessorPlanStatus ?? "unreadable"} is not supersedable; refusing before any fold or write.`,
          );
        }
      }
      requireLineageSuccessor(changeId, replacementId);
      // Row (j): the seam fires under the sorted locks; the post-seam revalidation
      // compares against the captured state and refuses any relocation, second
      // location, disappearance, or same-path identity change before discard/fold.
      io.afterReplacementValidationForTests?.();
      if (replacement.kind === "explicit") {
        const current = captureReplacementState();
        if (
          initialReplacementState === undefined
          || current === undefined
          || current.location !== initialReplacementState.location
          || current.dev !== initialReplacementState.dev
          || current.ino !== initialReplacementState.ino
        ) {
          throw new GraceCommandError(
            "invalid-arguments",
            `Replacement ${replacementId} changed location or identity under the lock; refusing before any fold or write.`,
          );
        }
      }
      discardAndFoldEpoch(projectRoot, changeId);
      const writeFile = io.writeFileSync ?? writeFileSync;
      const specBefore = readFileSync(specPath, "utf8");
      const planExists = existsSync(planPath);
      const planBefore = planExists ? readFileSync(planPath, "utf8") : undefined;
      const nextSpec = nextSupersededArtifactBytes(specPath, replacementId);
      const nextPlan = planExists ? nextSupersededArtifactBytes(planPath, replacementId) : undefined;
      let acquired: AcquiredCandidate | undefined;
      let wroteSpec = false;
      let wrotePlan = false;
      try {
        // The implicit mint runs inside the transaction's failure boundary, so a
        // post-fold mint failure attempts cleanup through the same exactly-once path
        // as a governance failure (AC-SUPERSEDE-ROLLBACK-CLEANUP). A prepublication
        // mint failure is cleaned by its own publisher; a post-publication failure is
        // owned by the outer attempt below.
        acquired = replacement.kind === "mint" ? replacement.mint() : undefined;
        if (nextSpec !== specBefore) {
          writeFile(specPath, nextSpec);
          wroteSpec = true;
        }
        if (planExists && nextPlan !== undefined && nextPlan !== planBefore) {
          writeFile(planPath, nextPlan);
          wrotePlan = true;
        }
        const archiveParent = path.dirname(archiveDir);
        if (!existsSync(archiveParent)) {
          mkdirSync(archiveParent, { recursive: true });
        }
        (io.renameSync ?? renameSync)(activeDir, archiveDir);
      } catch (error) {
        // Each rollback write is attempted once; a persistent rollback failure is
        // recorded and composed, never allowed to skip successor cleanup or recurse
        // (AC-SUPERSEDE-ROLLBACK-CLEANUP).
        const rollbackFailures: string[] = [];
        if (wrotePlan && planBefore !== undefined && existsSync(planPath)) {
          try {
            writeFile(planPath, planBefore);
          } catch (rollbackError) {
            rollbackFailures.push(`plan rollback failed: ${rollbackError instanceof Error ? rollbackError.message : String(rollbackError)}`);
          }
        }
        if (wroteSpec && existsSync(specPath)) {
          try {
            writeFile(specPath, specBefore);
          } catch (rollbackError) {
            rollbackFailures.push(`spec rollback failed: ${rollbackError instanceof Error ? rollbackError.message : String(rollbackError)}`);
          }
        }
        const rollbackNote = rollbackFailures.length > 0
          ? ` Predecessor left in its last-successfully-written state; rollback residue: ${rollbackFailures.join("; ")}.`
          : "";
        let residual = "";
        if (acquired) {
          const result = cleanupCandidate(acquired, io);
          // The outcome is observed exactly once on every post-mint failure, whether
          // cleanup removed the candidate or preserved residue.
          io.observeCleanupForTests?.(result);
          if (!result.removed && result.diagnostic) {
            residual = ` Residual state preserved: ${result.diagnostic}`;
          }
        } else if (replacement.kind === "mint") {
          // A mint that failed after publishing leaves no returned ownership record;
          // name the retained successor rather than silently orphaning it. When the
          // inner publisher already composed its own residual diagnostic, do not
          // append a second one: at most one residual diagnostic is surfaced.
          const publishedDir = changeLocationDir(projectRoot, "active", replacementId);
          const originalMessage = error instanceof Error ? error.message : String(error);
          if (existsSync(publishedDir) && !/Residual state preserved/.test(originalMessage)) {
            residual = ` Residual state preserved: successor candidate ${replacementId} remains at ${path.relative(projectRoot, publishedDir)} (published without a returned ownership record).`;
          }
        }
        if (isExdev(error)) {
          throw new GraceCommandError(
            "invalid-project",
            `Cross-device rename (EXDEV) is refused after rollback for ${changeId}.${rollbackNote}${residual}`,
          );
        }
        if (error instanceof GraceCommandError) {
          if (residual || rollbackNote) throw new GraceCommandError(error.code, `${error.message}${rollbackNote}${residual}`);
          throw error;
        }
        throw new GraceCommandError(
          "invalid-project",
          `Supersede failed after rollback: ${error instanceof Error ? error.message : String(error)}.${rollbackNote}${residual}`,
        );
      }
    }),
  );
}

function selectApproveTarget(
  bundlePath: string,
  artifact?: ApprovedArtifactName,
): { artifact: ApprovedArtifactName; filePath: string } {
  const specPath = path.join(bundlePath, "spec.xml");
  const planPath = path.join(bundlePath, "plan.xml");
  if (artifact === "spec") {
    if (!existsSync(specPath)) {
      throw new GraceCommandError("not-found", "spec.xml not found in the change bundle.");
    }
    return { artifact: "spec", filePath: specPath };
  }
  if (artifact === "plan") {
    if (!existsSync(planPath)) {
      throw new GraceCommandError("not-found", "plan.xml not found in the change bundle.");
    }
    return { artifact: "plan", filePath: planPath };
  }
  const specExists = existsSync(specPath);
  const planExists = existsSync(planPath);
  const specStatus = specExists ? rootStatusFromFile(specPath) : undefined;
  const planStatus = planExists ? rootStatusFromFile(planPath) : undefined;
  if (specExists && specStatus !== "approved") {
    return { artifact: "spec", filePath: specPath };
  }
  if (planExists && planStatus !== "approved") {
    return { artifact: "plan", filePath: planPath };
  }
  if (planExists) {
    return { artifact: "plan", filePath: planPath };
  }
  return { artifact: "spec", filePath: specPath };
}

/** Surgical draft-to-approved write, then SHA-256 of the on-disk bytes. Command-path only. */
export function stampApproveArtifact(
  projectRoot: string,
  changeId: string,
  artifact?: ApprovedArtifactName,
): { artifact: ApprovedArtifactName; fingerprint: string } {
  return withCandidateLock(projectRoot, changeId, () => {
    const bundlePath = resolveChangeBundle(projectRoot, changeId);
    assertCandidatePublished(bundlePath, changeId);
    const target = selectApproveTarget(bundlePath, artifact);
    writeDraftRootToApproved(target.filePath);
    return {
      artifact: target.artifact,
      fingerprint: createHash("sha256").update(readFileSync(target.filePath)).digest("hex"),
    };
  });
}

/** Options for the sanctioned applied close (C-APPLY-VERB / F224). */
export type ApplyChangeBundleOptions = {
  /** Bypass only the missing apply/archive permit refusals; recorded on both write Decisions. */
  force?: boolean;
  /** Operator-supplied reason stored only with force true. */
  reason?: string;
  /** Test-only rename hook for the EXDEV refuse-after-rollback path. */
  io?: { renameSync?: typeof renameSync };
};

/**
 * One status refuse for the applied close, keyed on rootStatusFromFile.
 * Locatable compact opening-tag, non-terminal, then approved-or-applied.
 */
function requireCloseableArtifactStatus(
  filePath: string,
  artifact: "spec" | "plan",
  changeId: string,
): string {
  const status = rootStatusFromFile(filePath);
  if (status === undefined) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Could not locate a compact opening-tag status attribute on ${artifact}.xml for ${changeId}; the applied write needs a locatable status.`,
    );
  }
  if (status === "draft" || status === "superseded" || status === "rejected" || status === "cancelled") {
    throw new GraceCommandError(
      "invalid-arguments",
      `Cannot apply a ${status} ${artifact}.xml for ${changeId}; only an approved bundle can be written applied.`,
    );
  }
  if (status !== "approved" && status !== "applied") {
    throw new GraceCommandError(
      "invalid-arguments",
      `Change ${changeId} ${artifact} status is ${status}; the applied write requires approved, or applied for a resume.`,
    );
  }
  return status;
}

/** Surgical applied bytes: skip an already-applied artifact, swap an approved one. */
function nextAppliedArtifactBytes(
  filePath: string,
  artifact: "spec" | "plan",
  changeId: string,
): string {
  const text = readFileSync(filePath, "utf8");
  const status = requireCloseableArtifactStatus(filePath, artifact, changeId);
  if (status === "applied") {
    // Resume: skip the matching status write; the on-disk bytes are the record.
    return text;
  }
  const swapped = withOpeningTagStatus(text, "applied");
  if (swapped === undefined) {
    throw new GraceCommandError(
      "invalid-project",
      `Could not locate a compact opening-tag status attribute to write on ${filePath}; grammar cannot relocate the status needle.`,
    );
  }
  return swapped;
}

/** True when the ledger already holds the matching gate=applied fingerprint for that artifact. */
function appliedFingerprintPresent(section: GraceXmlNode, artifact: "spec" | "plan", fingerprint: string): boolean {
  for (const child of section.children) {
    if (child.tag !== "Decision") continue;
    if (child.attributes.gate !== "applied") continue;
    if (child.attributes.decision !== "permit") continue;
    if ((child.attributes.artifact ?? "") !== artifact) continue;
    if ((child.attributes.fingerprint ?? "") === fingerprint) return true;
  }
  return false;
}

/**
 * Validate the applied-close preconditions without writing. Shared by the
 * command's --record=false path and by applyChangeBundle so there is one
 * reader of root status (rootStatusFromFile) and one message per refuse.
 */
export function validateApplyChangeBundle(
  projectRoot: string,
  changeId: string,
  options: Pick<ApplyChangeBundleOptions, "force"> = {},
): { activeDir: string; archiveDir: string; specPath: string; planPath: string } {
  if (!ANCHOR_PATTERNS.change.test(changeId)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `Change id '${changeId}' does not match the accepted pattern C- then uppercase kebab.`,
    );
  }
  const activeDir = changeLocationDir(projectRoot, "active", changeId);
  const archiveDir = changeLocationDir(projectRoot, "archive", changeId);
  if (!existsSync(activeDir) || !statSync(activeDir).isDirectory()) {
    if (existsSync(archiveDir)) {
      throw new GraceCommandError(
        "invalid-arguments",
        `Change ${changeId} is already applied and archived; apply is already done.`,
      );
    }
    throw new GraceCommandError("not-found", `Change ${changeId} is not a directory under active/.`);
  }
  if (existsSync(archiveDir)) {
    throw new GraceCommandError("invalid-arguments", `Archive destination already exists for ${changeId}.`);
  }
  const specPath = path.join(activeDir, "spec.xml");
  const planPath = path.join(activeDir, "plan.xml");
  if (!existsSync(specPath)) {
    throw new GraceCommandError("not-found", `spec.xml not found in ${changeId}.`);
  }
  if (!existsSync(planPath)) {
    throw new GraceCommandError(
      "invalid-arguments",
      `plan.xml is required for the applied close; change ${changeId} has no plan.xml to write.`,
    );
  }
  requireCloseableArtifactStatus(specPath, "spec", changeId);
  requireCloseableArtifactStatus(planPath, "plan", changeId);
  // Permits are read, never re-evaluated; force bypasses only these refusals.
  if (options.force !== true) {
    if (!hasPermittingDecision(projectRoot, changeId, "apply")) {
      throw new GraceCommandError(
        "invalid-arguments",
        `Apply permit missing: run \`ngrace gate apply --change ${changeId}\` before \`ngrace apply\`.`,
      );
    }
    if (!hasPermittingDecision(projectRoot, changeId, "archive")) {
      throw new GraceCommandError(
        "invalid-arguments",
        `Archive permit missing: run \`ngrace gate archive --change ${changeId}\` before \`ngrace apply\`.`,
      );
    }
  }
  return { activeDir, archiveDir, specPath, planPath };
}

/**
 * Sanctioned approved-to-applied close and archive move (C-APPLY-VERB, D37).
 * Surgical status writes on spec then plan, per-artifact fingerprints of the
 * applied bytes, two gate=applied permitting Decisions (document order spec
 * then plan), then a same-filesystem rename with rollback. Not a gate
 * evaluation: permits are read, never re-evaluated. The `io` bag follows
 * supersedeChangeBundle's EXDEV precedent.
 */
export function applyChangeBundle(
  projectRoot: string,
  changeId: string,
  options: ApplyChangeBundleOptions = {},
): { specFingerprint: string; planFingerprint: string; resumed: boolean } {
  const { activeDir, archiveDir, specPath, planPath } = validateApplyChangeBundle(
    projectRoot,
    changeId,
    { force: options.force },
  );
  // Validate fully, write nothing, then compute next bytes in memory.
  const specBefore = readFileSync(specPath, "utf8");
  const planBefore = readFileSync(planPath, "utf8");
  const nextSpec = nextAppliedArtifactBytes(specPath, "spec", changeId);
  const nextPlan = nextAppliedArtifactBytes(planPath, "plan", changeId);
  const resumed = nextSpec === specBefore && nextPlan === planBefore;
  const ledgerPath = path.join(activeDir, "run-ledger.xml");
  const ledgerPrior = existsSync(ledgerPath) ? readFileSync(ledgerPath) : null;
  const bundleRoot = loadOrCreateLedgerRoot(activeDir, changeId);
  const wrapper = ensureWrapper(bundleRoot, changeId);
  const decisionsSection = ensureSection(wrapper, "Decisions");
  const forced = options.force === true;
  const reason = (options.reason ?? "").trim();
  let wroteSpec = false;
  let wrotePlan = false;
  let appended = false;
  try {
    if (nextSpec !== specBefore) {
      writeFileSync(specPath, nextSpec);
      wroteSpec = true;
    }
    if (nextPlan !== planBefore) {
      writeFileSync(planPath, nextPlan);
      wrotePlan = true;
    }
    // Hash the on-disk bytes after the status writes.
    const specFingerprint = createHash("sha256").update(readFileSync(specPath)).digest("hex");
    const planFingerprint = createHash("sha256").update(readFileSync(planPath)).digest("hex");
    // Append Decision records (document order spec then plan) only when the
    // matching gate=applied fingerprint for that artifact is absent.
    for (const [artifact, fingerprint] of [["spec", specFingerprint], ["plan", planFingerprint]] as const) {
      if (appliedFingerprintPresent(decisionsSection, artifact, fingerprint)) continue;
      recordGateDecision(projectRoot, changeId, {
        gate: "applied",
        decision: "permit",
        requirements: [],
        fingerprint,
        artifact,
        ...(forced ? { forced: true, reason } : {}),
      });
      appended = true;
    }
    const archiveParent = path.dirname(archiveDir);
    if (!existsSync(archiveParent)) {
      mkdirSync(archiveParent, { recursive: true });
    }
    (options.io?.renameSync ?? renameSync)(activeDir, archiveDir);
    return { specFingerprint, planFingerprint, resumed };
  } catch (error) {
    if (appended || ledgerPrior === null) {
      restorePriorLedgerBytes(ledgerPath, ledgerPrior);
    }
    if (wrotePlan && existsSync(planPath)) {
      writeFileSync(planPath, planBefore);
    }
    if (wroteSpec && existsSync(specPath)) {
      writeFileSync(specPath, specBefore);
    }
    if (isExdev(error)) {
      throw new GraceCommandError(
        "invalid-project",
        `Cross-device rename (EXDEV) is refused after rollback for ${changeId}.`,
      );
    }
    if (error instanceof GraceCommandError) throw error;
    throw new GraceCommandError(
      "invalid-project",
      `Apply failed after rollback: ${error instanceof Error ? error.message : String(error)}.`,
    );
  }
}
