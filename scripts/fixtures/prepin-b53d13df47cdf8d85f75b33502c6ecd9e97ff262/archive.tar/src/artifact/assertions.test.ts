import { mkdirSync, symlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "bun:test";

import {
  compileSafeAssertionPattern,
  evaluateAssertion,
  extractAssertionsWithIssues,
  type AssertionContext,
  type GraceAssertion,
} from "./assertions";
import { ARTIFACT_DIR } from "./paths";
import { resolveNgracePaths } from "./project";
import { buildGraphProjection, buildVerificationProjection } from "./projections";

function createProject() {
  const root = path.join(os.tmpdir(), `grace4-assertions-${crypto.randomUUID()}`);
  mkdirSync(root, { recursive: true });
  return root;
}

function writeProjectFile(root: string, relativePath: string, contents: string) {
  const filePath = path.join(root, relativePath);
  mkdirSync(path.dirname(filePath), { recursive: true });
  writeFileSync(filePath, contents);
}

function writeProjectionFixture(root: string) {
  writeProjectFile(root, "src/example.ts", "export const marker = 'fresh';\n");
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/index.xml`,
    `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-AUTH-SESSION /><M-USER-PROFILE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/main.xml`,
    `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-AUTH-SESSION><M-USER-PROFILE /></M-AUTH-SESSION><M-USER-PROFILE /></GD-MAIN></NgraceGraphDocument>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/index.xml`,
    `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-AUTH-SESSION /><V-M-USER-PROFILE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/main.xml`,
    `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-AUTH-SESSION><Command>bun test auth</Command></V-M-AUTH-SESSION><V-M-USER-PROFILE><Command>bun test profile</Command></V-M-USER-PROFILE></VD-MAIN></NgraceVerificationDocument>`,
  );
}

function assertion(kind: GraceAssertion["kind"], values: string[]): GraceAssertion {
  return { kind, values, file: "plan.xml" };
}

function context(root: string): AssertionContext {
  const paths = resolveNgracePaths(root);
  const graph = buildGraphProjection(paths);
  return { root, graph, verification: buildVerificationProjection(paths, graph) };
}

describe("neo-grace assertions", () => {
  it("extracts all approved assertion kinds and reports unknown assertion tags", () => {
    const root = createProject();
    const planFile = path.join(root, "plan.xml");
    writeFileSync(
      planFile,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EXAMPLE><BaselineAssertions><MustExist><Value>M-AUTH-SESSION</Value></MustExist><MustNotExist><Value>tmp/missing</Value></MustNotExist><MustOwn><Owner>GD-MAIN</Owner><Anchor>M-AUTH-SESSION</Anchor></MustOwn><MustLink><From>M-AUTH-SESSION</From><To>M-USER-PROFILE</To></MustLink><MustVerify><Module>M-AUTH-SESSION</Module></MustVerify><MustPassCommand><Command>bun --version</Command></MustPassCommand><MustContain><File>src/example.ts</File><Text>fresh</Text></MustContain><MustNotContain><File>src/example.ts</File><Text>stale</Text></MustNotContain><UnknownAssertion /></BaselineAssertions></C-EXAMPLE></NgraceChangePlan>`,
    );

    const result = extractAssertionsWithIssues(planFile, "BaselineAssertions");

    expect(result.assertions.map((item) => item.kind)).toEqual([
      "MustExist",
      "MustNotExist",
      "MustOwn",
      "MustLink",
      "MustVerify",
      "MustPassCommand",
      "MustContain",
      "MustNotContain",
    ]);
    expect(result.issues.map((issue) => issue.code)).toContain("assertion.unknown-kind");
  });

  it("evaluates existence, ownership, links, verification coverage, containment, and commands", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const ctx = context(root);

    expect(evaluateAssertion(assertion("MustExist", ["M-AUTH-SESSION", "src/example.ts"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustNotExist", ["M-MISSING", "src/missing.ts"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustOwn", ["GD-MAIN", "M-AUTH-SESSION"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustOwn", ["VD-MAIN", "V-M-AUTH-SESSION"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustLink", ["M-AUTH-SESSION", "M-USER-PROFILE"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustVerify", ["M-AUTH-SESSION"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustContain", ["src/example.ts", "fresh"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustNotContain", ["src/example.ts", "stale"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustPassCommand", ["exit 99"]), ctx)[0]?.code).toBe("assertion.command-not-evaluated");
    expect(evaluateAssertion(assertion("MustPassCommand", ["exit 99"]), { ...ctx, runCommands: true })).toHaveLength(1);
  });

  (process.platform === "win32" ? it : it.skip)("executes command assertions through Windows cmd.exe", () => {
    const root = createProject();
    writeProjectionFixture(root);
    expect(evaluateAssertion(assertion("MustPassCommand", ["exit /b 0"]), { ...context(root), runCommands: true })).toHaveLength(0);
  });

  it("rejects missing, extra, duplicate, nested, and empty assertion fields", () => {
    const root = createProject();
    const planFile = path.join(root, "plan.xml");
    writeFileSync(
      planFile,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EXAMPLE><BaselineAssertions><MustOwn><Owner>GD-MAIN</Owner><Owner>GD-OTHER</Owner><Anchor /></MustOwn><MustLink><From>M-A</From><To>M-B</To><Extra>x</Extra></MustLink><MustVerify><Module><Nested /></Module></MustVerify><MustContain>text<File>src/example.ts</File></MustContain></BaselineAssertions></C-EXAMPLE></NgraceChangePlan>`,
    );

    const result = extractAssertionsWithIssues(planFile, "BaselineAssertions");
    expect(result.assertions).toHaveLength(0);
    expect(result.issues.filter((item) => item.code === "assertion.invalid-shape").length).toBeGreaterThanOrEqual(6);
  });

  it("rejects text-only assertion sections with no machine-checkable assertions", () => {
    const root = createProject();
    const planFile = path.join(root, "plan.xml");
    writeFileSync(planFile, `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EXAMPLE><BaselineAssertions>assume it works</BaselineAssertions></C-EXAMPLE></NgraceChangePlan>`);

    const result = extractAssertionsWithIssues(planFile, "BaselineAssertions");
    expect(result.assertions).toHaveLength(0);
    expect(result.issues.map((item) => item.code)).toContain("assertion.invalid-section-shape");
    expect(result.issues.map((item) => item.code)).toContain("assertion.empty-section");
  });

  it("rejects current-mode lifecycle lint nested inside target command evidence", () => {
    const root = createProject();
    const planFile = path.join(root, "plan.xml");
    writeFileSync(
      planFile,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EXAMPLE><TargetAssertions><MustPassCommand><Command>ngrace lint --path . --assertions current</Command><Command>bun run check</Command></MustPassCommand></TargetAssertions></C-EXAMPLE></NgraceChangePlan>`,
    );

    const result = extractAssertionsWithIssues(planFile, "TargetAssertions");
    expect(result.issues.map((item) => item.code)).toContain("assertion.phase-incompatible-command");
    expect(result.assertions).toHaveLength(0);
    expect(result.issues.map((item) => item.code)).not.toContain("assertion.empty-section");
    const issue = result.issues.find((item) => item.code === "assertion.phase-incompatible-command");
    expect(issue?.message).toContain("leaf project evidence");
    expect(issue?.message).toContain("omitted --assertions");
    expect(issue?.message).toContain("this project root");
  });

  const implicitCurrentRootCommands = [
    "ngrace lint",
    "ngrace lint --path .",
    "ngrace lint --path ./",
    "ngrace lint --path=.",
    "bun run ngrace lint",
    "bun run ngrace lint --path .",
    "bun run ngrace lint --path ./",
    "src/grace.ts lint",
    "src/grace.ts lint --path .",
    "src/grace.ts lint --path ./",
    "ngrace lint --assertions current",
    "ngrace lint --assertions=current",
    "ngrace lint --assertions \"current\"",
    "bun run ngrace lint --assertions current",
    "src/grace.ts lint --assertions current",
  ];

  for (const command of implicitCurrentRootCommands) {
    it(`rejects implicit-current lint of this project root: ${command}`, () => {
      const root = createProject();
      const planFile = path.join(root, "plan.xml");
      writeFileSync(
        planFile,
        `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EXAMPLE><TargetAssertions><MustPassCommand><Command>${command}</Command></MustPassCommand></TargetAssertions></C-EXAMPLE></NgraceChangePlan>`,
      );

      const result = extractAssertionsWithIssues(planFile, "TargetAssertions");
      expect(result.issues.map((item) => item.code)).toContain("assertion.phase-incompatible-command");
      const issue = result.issues.find((item) => item.code === "assertion.phase-incompatible-command");
      expect(issue?.message).toContain("leaf project evidence");
      expect(issue?.message).toContain("omitted --assertions");
      expect(issue?.message).toContain("this project root");
    });
  }

  const silentConformingCommands = [
    "bun run validate:ci",
    "bun run lint",
    "bun run ngrace:lint",
    "ngrace lint --assertions baseline",
    "ngrace lint --assertions target",
    "ngrace lint --assertions final",
    "ngrace lint --path examples/polyglot",
    "ngrace lint --help",
    "ngrace status --path .",
    "ngrace review --path .",
    "ngrace gate --help",
  ];

  for (const command of silentConformingCommands) {
    it(`stays silent on conforming TargetAssertions command: ${command}`, () => {
      const root = createProject();
      const planFile = path.join(root, "plan.xml");
      writeFileSync(
        planFile,
        `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EXAMPLE><TargetAssertions><MustPassCommand><Command>${command}</Command></MustPassCommand></TargetAssertions></C-EXAMPLE></NgraceChangePlan>`,
      );

      const result = extractAssertionsWithIssues(planFile, "TargetAssertions");
      expect(result.issues.map((item) => item.code)).not.toContain("assertion.phase-incompatible-command");
      expect(result.assertions).toHaveLength(1);
    });
  }

  it("does not emit phase-incompatible-command when extracting an archived plan file", () => {
    const root = createProject();
    const planFile = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-HISTORICAL", "plan.xml");
    mkdirSync(path.dirname(planFile), { recursive: true });
    writeFileSync(
      planFile,
      `<NgraceChangePlan graceVersion="1.0" status="applied"><C-HISTORICAL><TargetAssertions><MustPassCommand><Command>bun run ngrace lint --path .</Command></MustPassCommand></TargetAssertions></C-HISTORICAL></NgraceChangePlan>`,
    );

    const result = extractAssertionsWithIssues(planFile, "TargetAssertions");
    expect(result.issues.map((item) => item.code)).not.toContain("assertion.phase-incompatible-command");
    expect(result.assertions).toHaveLength(1);
  });

  it("rejects absolute, traversal, and escaping-symlink File fields during extraction", () => {
    const root = createProject();
    const outside = createProject();
    writeFileSync(path.join(outside, "secret.txt"), "secret\n");
    symlinkSync(path.join(outside, "secret.txt"), path.join(root, "escape.txt"));
    const planFile = path.join(root, ARTIFACT_DIR, "changes", "active", "C-PATHS", "plan.xml");
    mkdirSync(path.dirname(planFile), { recursive: true });
    writeFileSync(
      planFile,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-PATHS><TargetAssertions><MustContain><File>/tmp/absolute</File><Text>x</Text></MustContain><MustContain><File>../traversal</File><Text>x</Text></MustContain><MustContain><File>escape.txt</File><Text>secret</Text></MustContain></TargetAssertions></C-PATHS></NgraceChangePlan>`,
    );

    const result = extractAssertionsWithIssues(planFile, "TargetAssertions");
    expect(result.assertions).toHaveLength(0);
    expect(result.issues.filter((item) => item.code === "assertion.invalid-path")).toHaveLength(3);
  });

  it("reports failed assertions", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const ctx = context(root);

    expect(evaluateAssertion(assertion("MustExist", ["M-MISSING"]), ctx)[0]?.code).toBe("assertion.MustExist");
    expect(evaluateAssertion(assertion("MustLink", ["M-AUTH-SESSION", "M-MISSING"]), ctx)[0]?.code).toBe("assertion.MustLink");
    expect(evaluateAssertion(assertion("MustVerify", ["M-MISSING"]), ctx)[0]?.code).toBe("assertion.MustVerify");
  });

  it("reports directory containment targets without throwing", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const issues = evaluateAssertion(assertion("MustContain", ["src", "fresh"]), context(root));
    expect(issues).toHaveLength(1);
    expect(issues[0]?.code).toBe("assertion.MustContain");
    expect(issues[0]?.message).toContain("regular file");
  });

  it("fails stale BaselineAssertions after durable graph state changes", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const planFile = path.join(root, `${ARTIFACT_DIR}/changes/active/C-STALE/plan.xml`);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/changes/active/C-STALE/plan.xml`,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-STALE><BaselineAssertions><MustOwn><Owner>GD-MAIN</Owner><Anchor>M-AUTH-SESSION</Anchor></MustOwn></BaselineAssertions></C-STALE></NgraceChangePlan>`,
    );
    const assertionToCheck = extractAssertionsWithIssues(planFile, "BaselineAssertions").assertions[0]!;
    expect(evaluateAssertion(assertionToCheck, context(root))).toHaveLength(0);

    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-USER-PROFILE /></GD-MAIN></NgraceGraphDocument>`,
    );

    expect(evaluateAssertion(assertionToCheck, context(root))[0]?.code).toBe("assertion.MustOwn");
  });

  it("extracts TargetAssertions from a plan", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const planFile = path.join(root, "target-plan.xml");
    writeFileSync(
      planFile,
      `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EXAMPLE><TargetAssertions><MustVerify><Module>M-AUTH-SESSION</Module></MustVerify></TargetAssertions></C-EXAMPLE></NgraceChangePlan>`,
    );
    const result = extractAssertionsWithIssues(planFile, "TargetAssertions");
    expect(result.assertions).toHaveLength(1);
    expect(result.assertions[0]!.kind).toBe("MustVerify");
    expect(result.assertions[0]!.values).toContain("M-AUTH-SESSION");
  });

  it("evaluates TargetAssertions correctly when called directly", () => {
    // TargetAssertion MustVerify for existing module passes
    const root = createProject();
    writeProjectionFixture(root);
    const ctx = context(root);
    const passFile = path.join(root, "pass-plan.xml");
    writeFileSync(passFile, `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EX><TargetAssertions><MustVerify><Module>M-AUTH-SESSION</Module></MustVerify></TargetAssertions></C-EX></NgraceChangePlan>`);
    const pass = extractAssertionsWithIssues(passFile, "TargetAssertions").assertions;
    if (pass.length > 0) {
      expect(evaluateAssertion(pass[0]!, ctx)).toHaveLength(0);
    }

    // TargetAssertion MustVerify for missing module fails
    const failRoot = createProject();
    writeProjectionFixture(failRoot);
    const failCtx = context(failRoot);
    const failFile = path.join(failRoot, "fail-plan.xml");
    writeFileSync(failFile, `<NgraceChangePlan graceVersion="1.0" status="approved"><C-EX><TargetAssertions><MustVerify><Module>M-MISSING</Module></MustVerify></TargetAssertions></C-EX></NgraceChangePlan>`);
    const failAssertions = extractAssertionsWithIssues(failFile, "TargetAssertions").assertions;
    if (failAssertions.length > 0) {
      expect(evaluateAssertion(failAssertions[0]!, failCtx)[0]?.code).toBe("assertion.MustVerify");
    }
  });

  it("evaluates MustMatchPattern and rejects catastrophic-backtracking patterns", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const ctx = context(root);

    expect(evaluateAssertion(assertion("MustMatchPattern", ["src/example.ts", "fr..h"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustMatchPattern", ["src/example.ts", "absent"]), ctx)[0]?.code).toBe("assertion.MustMatchPattern");

    const unsafe = compileSafeAssertionPattern("(a+)+$");
    expect(unsafe.ok).toBe(false);
    if (!unsafe.ok) {
      expect(unsafe.error).toContain("nested unbounded");
    }

    const started = Date.now();
    const issues = evaluateAssertion(assertion("MustMatchPattern", ["src/example.ts", "(a+)+b"]), ctx);
    expect(Date.now() - started).toBeLessThan(1000);
    expect(issues[0]?.code).toBe("assertion.invalid-pattern");

    const tooLong = "a".repeat(201);
    expect(compileSafeAssertionPattern(tooLong).ok).toBe(false);
  });

  it("rejects catastrophic patterns that hide behind paren nesting or overlapping alternation", () => {
    // A regex over the pattern text cannot see nesting, so these slipped past and ran
    // exponentially. Each must be rejected, and the check itself must stay fast.
    for (const source of ["((a+))+$", "(((a+)))+$", "(a|a)*$", "(?:a|a)*$", "(a|ab)*$", "(\\s|\\s)+$", "(a+){2,}"]) {
      const started = Date.now();
      const compiled = compileSafeAssertionPattern(source);
      expect(Date.now() - started).toBeLessThan(1000);
      expect(compiled.ok).toBe(false);
    }
  });

  it("still accepts ordinary design-check patterns", () => {
    for (const source of [
      "^(foo|bar)+$",
      "var\\(--[a-z-]+\\)",
      "^#[0-9a-fA-F]{6}$",
      "(a+){2}",
      "^(https?://[^\\s]+)\\s*$",
      "\\d+px",
      "(?:color|background)-[a-z]+",
      "^(?<name>[a-z]+)$",
      "(?=.*foo).*bar",
      "[(){}]+",
    ]) {
      const compiled = compileSafeAssertionPattern(source);
      expect(compiled.ok).toBe(true);
    }
  });

  it("evaluates MustUseToken against design-system token values", () => {
    const root = createProject();
    writeProjectionFixture(root);
    writeProjectFile(root, "src/tokens.css", ":root { --accent: #0af; }\n");
    writeProjectFile(root, "src/ui.ts", "const c = 'var(--accent)';\n");
    writeProjectFile(root, "src/raw.ts", "const c = '#ff0000';\n");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/context/design-system.xml`,
      `<NgraceDesignSystem graceVersion="1.0"><Applicability>applicable</Applicability><TokenSource>src/tokens.css</TokenSource><Tokens><DT-COLOR-ACCENT><Value>var(--accent)</Value></DT-COLOR-ACCENT></Tokens></NgraceDesignSystem>`,
    );
    const ctx = context(root);
    expect(evaluateAssertion(assertion("MustUseToken", ["src/ui.ts", "DT-COLOR-ACCENT"]), ctx)).toHaveLength(0);
    expect(evaluateAssertion(assertion("MustUseToken", ["src/raw.ts", "DT-COLOR-ACCENT"]), ctx)[0]?.code).toBe("assertion.MustUseToken");
  });

  it("evaluates MustNotUseLiteral against forbidden raw patterns", () => {
    const root = createProject();
    writeProjectionFixture(root);
    writeProjectFile(root, "src/raw.ts", "const c = '#ff0000';\n");
    writeProjectFile(root, "src/clean.ts", "const c = 'var(--accent)';\n");
    const ctx = context(root);
    expect(evaluateAssertion(assertion("MustNotUseLiteral", ["src/raw.ts", "#[0-9a-fA-F]{6}"]), ctx)[0]?.code).toBe("assertion.MustNotUseLiteral");
    expect(evaluateAssertion(assertion("MustNotUseLiteral", ["src/clean.ts", "#[0-9a-fA-F]{6}"]), ctx)).toHaveLength(0);
  });

  it("evaluates MustCoverStates against verification evidence", () => {
    const root = createProject();
    writeProjectFile(root, "src/example.ts", "export const marker = 'fresh';\n");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-WEB /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-WEB><Summary>UI</Summary><Path>src/example.ts</Path><Type>UI_COMPONENT</Type><States><ST-DEFAULT /><ST-ERROR /></States></M-WEB></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-WEB /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-WEB><Command>bun test</Command><Scenario>default render works</Scenario></V-M-WEB></VD-MAIN></NgraceVerificationDocument>`,
    );
    const ctx = context(root);
    const issues = evaluateAssertion(assertion("MustCoverStates", ["M-WEB"]), ctx);
    expect(issues.some((i) => i.message.includes("ST-ERROR"))).toBe(true);
    expect(issues.some((i) => i.message.includes("ST-DEFAULT"))).toBe(false);

    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-WEB><Command>bun test</Command><Scenario>default render works</Scenario><AccessibilityCheck><Tool>axe</Tool><Command>bun run a11y</Command><MaxSeverity>serious</MaxSeverity></AccessibilityCheck><Scenario>error state announced</Scenario></V-M-WEB></VD-MAIN></NgraceVerificationDocument>`,
    );
    expect(evaluateAssertion(assertion("MustCoverStates", ["M-WEB"]), context(root))).toHaveLength(0);
  });
});

describe("C-CALIBRATION-COMMAND-EVIDENCE T-001: command-run evidence recorder", () => {
  it("red-first: successful MustPassCommand with runCommands calls onCommandRun (not discard-only)", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const records: Array<{
      command: string;
      exitCode: number;
      assertionPassed: boolean;
      assertionKind: string;
      source: string;
    }> = [];
    const ctx = {
      ...context(root),
      runCommands: true,
      commandRunSource: "lint-run-commands",
      onCommandRun: (record: (typeof records)[number]) => {
        records.push(record);
      },
    };
    const issues = evaluateAssertion(assertion("MustPassCommand", ["exit 0"]), ctx);
    expect(issues).toHaveLength(0);
    // Discriminating negative: today's path returns [] without durable evidence.
    // After fix, the recorder must fire with exitCode 0 / assertionPassed true.
    expect(records).toHaveLength(1);
    expect(records[0]).toMatchObject({
      command: "exit 0",
      exitCode: 0,
      assertionPassed: true,
      assertionKind: "MustPassCommand",
      source: "lint-run-commands",
    });
  });

  it("records failed MustPassCommand with assertionPassed false and non-zero exitCode", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const records: Array<{ exitCode: number; assertionPassed: boolean }> = [];
    const ctx = {
      ...context(root),
      runCommands: true,
      onCommandRun: (record: { exitCode: number; assertionPassed: boolean }) => {
        records.push(record);
      },
    };
    const issues = evaluateAssertion(assertion("MustPassCommand", ["exit 7"]), ctx);
    expect(issues).toHaveLength(1);
    expect(records).toHaveLength(1);
    expect(records[0]?.exitCode).not.toBe(0);
    expect(records[0]?.assertionPassed).toBe(false);
  });

  it("MustPassBudget metric fail with exitCode 0 records assertionPassed false", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const records: Array<{
      command: string;
      exitCode: number;
      assertionPassed: boolean;
      assertionKind: string;
    }> = [];
    const cmd = process.platform === "win32" ? "echo p99=61" : "printf 'p99=61\\n'";
    const ctx = {
      ...context(root),
      runCommands: true,
      commandRunSource: "lint-run-commands",
      onCommandRun: (record: (typeof records)[number]) => {
        records.push(record);
      },
    };
    const issues = evaluateAssertion(assertion("MustPassBudget", [cmd, "p99", "lt", "50", "ms"]), ctx);
    expect(issues[0]?.code).toBe("assertion.MustPassBudget");
    expect(records).toHaveLength(1);
    expect(records[0]).toMatchObject({
      command: cmd,
      exitCode: 0,
      assertionPassed: false,
      assertionKind: "MustPassBudget",
    });
  });

  it("when runCommands is false, does not invent command-run evidence", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const records: unknown[] = [];
    const ctx = {
      ...context(root),
      runCommands: false,
      onCommandRun: (record: unknown) => {
        records.push(record);
      },
    };
    const issues = evaluateAssertion(assertion("MustPassCommand", ["exit 0"]), ctx);
    expect(issues[0]?.code).toBe("assertion.command-not-evaluated");
    expect(records).toHaveLength(0);
  });
});

describe("C-ARTIFACT-VALIDITY T-002 containment failure messages", () => {
  it("interpolates requested text; MustNotContain names first-hit offset last", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const ctx = context(root);
    const subject = "src/example.ts";
    const missing = "alpha-missing";
    const present = "fresh";
    const fileText = "export const marker = 'fresh';\n";

    const containIssues = evaluateAssertion(assertion("MustContain", [subject, missing]), ctx);
    expect(containIssues).toHaveLength(1);
    expect(containIssues[0]?.code).toBe("assertion.MustContain");
    expect(containIssues[0]?.message).toBe(`${subject} must contain ${JSON.stringify(missing)}.`);
    expect(containIssues[0]?.message.includes("(first hit at offset")).toBe(false);

    const offset = fileText.indexOf(present);
    const notContainIssues = evaluateAssertion(assertion("MustNotContain", [subject, present]), ctx);
    expect(notContainIssues).toHaveLength(1);
    expect(notContainIssues[0]?.code).toBe("assertion.MustNotContain");
    expect(notContainIssues[0]?.message).toBe(
      `${subject} must not contain ${JSON.stringify(present)} (first hit at offset ${offset}).`,
    );
  });

  it("two texts pinned on one file produce distinguishable MustContain messages", () => {
    const root = createProject();
    writeProjectionFixture(root);
    const ctx = context(root);
    const subject = "src/example.ts";
    const first = evaluateAssertion(assertion("MustContain", [subject, "alpha-missing"]), ctx)[0]?.message;
    const second = evaluateAssertion(assertion("MustContain", [subject, "beta-missing"]), ctx)[0]?.message;
    expect(first).toBe(`${subject} must contain ${JSON.stringify("alpha-missing")}.`);
    expect(second).toBe(`${subject} must contain ${JSON.stringify("beta-missing")}.`);
    expect(first).not.toBe(second);
  });
});
