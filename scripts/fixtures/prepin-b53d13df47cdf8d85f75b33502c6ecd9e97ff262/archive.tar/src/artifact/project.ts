// START_MODULE_CONTRACT
//   PURPOSE: Artifact grammar, XML, and project layout
//   SCOPE: Validation of .ngrace artifacts and path resolution
//   DEPENDS: none
//   LINKS: M-GRAMMAR
//   ROLE: RUNTIME
//   MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
//
// START_MODULE_MAP
//   detectGraceProjectKind
//   formatGrace3MigrationGuidance
//   resolveNgracePaths
// END_MODULE_MAP
import { existsSync } from "node:fs";
import path from "node:path";

import { ARTIFACT_DIR } from "./paths";
import { skillName, type NgraceProjectPaths, type GraceProjectKind } from "./types";

const LEGACY_GRACE3_DOCUMENTS = [
  "docs/requirements.xml",
  "docs/technology.xml",
  "docs/development-plan.xml",
  "docs/knowledge-graph.xml",
  "docs/verification-plan.xml",
  "docs/operational-packets.xml",
] as const;

/** Resolves canonical neo-grace project paths from a repository root. */
export function resolveNgracePaths(root: string): NgraceProjectPaths {
  const resolvedRoot = path.resolve(root);
  const graceDir = path.join(resolvedRoot, ARTIFACT_DIR);
  const graphDir = path.join(graceDir, "graph");
  const verificationDir = path.join(graceDir, "verification");
  const changesDir = path.join(graceDir, "changes");

  return {
    root: resolvedRoot,
    graceDir,
    contextDir: path.join(graceDir, "context"),
    graphIndex: path.join(graphDir, "index.xml"),
    graphDir,
    verificationIndex: path.join(verificationDir, "index.xml"),
    verificationDir,
    changesActiveDir: path.join(changesDir, "active"),
    changesArchiveDir: path.join(changesDir, "archive"),
  };
}

/** Detects whether a root contains .ngrace, legacy docs, or no GRACE artifacts. */
export function detectGraceProjectKind(root: string): GraceProjectKind {
  const resolvedRoot = path.resolve(root);

  if (existsSync(path.join(resolvedRoot, ARTIFACT_DIR))) {
    return "grace4";
  }

  if (LEGACY_GRACE3_DOCUMENTS.some((documentPath) => existsSync(path.join(resolvedRoot, documentPath)))) {
    return "grace3";
  }

  return "none";
}

/** Returns a user-facing message for legacy GRACE 3 projects without validating them. */
export function formatGrace3MigrationGuidance(root: string): string {
  return [
    `Legacy GRACE 3 artifacts were detected at ${path.resolve(root)}.`,
    `neo-grace tooling validates only the ${ARTIFACT_DIR} artifact model.`,
    `Use the ${skillName("migrate")} skill to review and agent-apply a migration to ${ARTIFACT_DIR} artifacts.`,
    "The CLI does not migrate, convert, or validate GRACE 3 docs as neo-grace state.",
  ].join(" ");
}
