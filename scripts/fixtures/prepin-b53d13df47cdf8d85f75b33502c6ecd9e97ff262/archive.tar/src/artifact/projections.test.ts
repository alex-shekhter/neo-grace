import { mkdirSync, symlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "bun:test";

import { ARTIFACT_DIR } from "./paths";
import { resolveNgracePaths } from "./project";
import { buildGraphProjection, buildVerificationProjection } from "./projections";

function createProject() {
  const root = path.join(os.tmpdir(), `grace4-projections-${crypto.randomUUID()}`);
  mkdirSync(root, { recursive: true });
  return root;
}

function writeProjectFile(root: string, relativePath: string, contents: string) {
  const filePath = path.join(root, relativePath);
  mkdirSync(path.dirname(filePath), { recursive: true });
  writeFileSync(filePath, contents);
}

function writeMonolithicProject(root: string) {
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/index.xml`,
    `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-AUTH-SESSION /><M-USER-PROFILE /><DF-AUTH-TOKEN-FLOW /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/main.xml`,
    `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-AUTH-SESSION><Summary>Authenticate users.</Summary><M-USER-PROFILE /></M-AUTH-SESSION><M-USER-PROFILE><Summary>Profiles.</Summary></M-USER-PROFILE><DF-AUTH-TOKEN-FLOW><Summary>Token flow.</Summary></DF-AUTH-TOKEN-FLOW></GD-MAIN></NgraceGraphDocument>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/index.xml`,
    `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-AUTH-SESSION /><V-M-USER-PROFILE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/main.xml`,
    `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-AUTH-SESSION><Command>bun test auth</Command><Scenario>valid login</Scenario><Marker>[Auth]</Marker></V-M-AUTH-SESSION><V-M-USER-PROFILE><Command>bun test profile</Command><Scenario>profile view</Scenario><Marker>[Profile]</Marker></V-M-USER-PROFILE></VD-MAIN></NgraceVerificationDocument>`,
  );
}

function writeSegmentedProject(root: string) {
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/index.xml`,
    `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-AUTH><Path>graph/auth.xml</Path><Owns><M-AUTH-SESSION /><DF-AUTH-TOKEN-FLOW /></Owns></GD-AUTH><GD-PROFILE><Path>graph/profile.xml</Path><Owns><M-USER-PROFILE /></Owns></GD-PROFILE></GraphDocuments></NgraceGraphIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/auth.xml`,
    `<NgraceGraphDocument graceVersion="1.0"><GD-AUTH><M-AUTH-SESSION><Summary>Authenticate users.</Summary><M-USER-PROFILE /></M-AUTH-SESSION><DF-AUTH-TOKEN-FLOW><Summary>Token flow.</Summary></DF-AUTH-TOKEN-FLOW></GD-AUTH></NgraceGraphDocument>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/graph/profile.xml`,
    `<NgraceGraphDocument graceVersion="1.0"><GD-PROFILE><M-USER-PROFILE><Summary>Profiles.</Summary></M-USER-PROFILE></GD-PROFILE></NgraceGraphDocument>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/index.xml`,
    `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-AUTH><Path>verification/auth.xml</Path><Owns><V-M-AUTH-SESSION /></Owns></VD-AUTH><VD-PROFILE><Path>verification/profile.xml</Path><Owns><V-M-USER-PROFILE /></Owns></VD-PROFILE></VerificationDocuments></NgraceVerificationIndex>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/auth.xml`,
    `<NgraceVerificationDocument graceVersion="1.0"><VD-AUTH><V-M-AUTH-SESSION><Command>bun test auth</Command><Scenario>valid login</Scenario><Marker>[Auth]</Marker></V-M-AUTH-SESSION></VD-AUTH></NgraceVerificationDocument>`,
  );
  writeProjectFile(
    root,
    `${ARTIFACT_DIR}/verification/profile.xml`,
    `<NgraceVerificationDocument graceVersion="1.0"><VD-PROFILE><V-M-USER-PROFILE><Command>bun test profile</Command><Scenario>profile view</Scenario><Marker>[Profile]</Marker></V-M-USER-PROFILE></VD-PROFILE></NgraceVerificationDocument>`,
  );
}

function issueCodes(issues: { code: string }[]) {
  return issues.map((issue) => issue.code);
}

describe("neo-grace graph and verification projections", () => {
  it("routes graph anchors and verification entries through their indexes", () => {
    const root = createProject();
    writeMonolithicProject(root);
    const paths = resolveNgracePaths(root);

    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);

    expect(graph.issues).toHaveLength(0);
    expect(verification.issues).toHaveLength(0);
    expect([...graph.modules.keys()].sort()).toEqual(["M-AUTH-SESSION", "M-USER-PROFILE"]);
    expect(graph.dataFlows.has("DF-AUTH-TOKEN-FLOW")).toBe(true);
    expect(graph.modules.get("M-AUTH-SESSION")?.owner).toBe("GD-MAIN");
    expect(graph.modules.get("M-AUTH-SESSION")?.links).toEqual(["M-USER-PROFILE"]);
    expect(verification.entries.get("V-M-AUTH-SESSION")?.commands).toEqual(["bun test auth"]);
  });

  it("reports wrapper mismatch, unlisted anchors, duplicate anchors, and missing verification coverage", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-AUTH-SESSION /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-AUTH-SESSION /><M-AUTH-SESSION /><M-UNLISTED /></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(root, `${ARTIFACT_DIR}/verification/main.xml`, `<NgraceVerificationDocument graceVersion="1.0"><VD-OTHER /></NgraceVerificationDocument>`);

    const paths = resolveNgracePaths(root);
    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);

    expect(issueCodes(graph.issues)).toContain("projection.graph.duplicate-anchor");
    expect(issueCodes(graph.issues)).toContain("projection.graph.unlisted-anchor");
    expect(issueCodes(verification.issues)).toContain("projection.verification.wrapper-mismatch");
    expect(issueCodes(verification.issues)).toContain("projection.verification.missing-module-coverage");
  });

  it("reports graph wrapper mismatches", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-AUTH-SESSION /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/main.xml`, `<NgraceGraphDocument graceVersion="1.0"><GD-OTHER><M-AUTH-SESSION /></GD-OTHER></NgraceGraphDocument>`);

    const graph = buildGraphProjection(resolveNgracePaths(root));

    expect(issueCodes(graph.issues)).toContain("projection.graph.wrapper-mismatch");
  });

  it("reports missing routes and dangling graph links", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MISSING-PATH><Owns><M-IGNORED /></Owns></GD-MISSING-PATH><GD-MAIN><Path>graph/main.xml</Path><Owns><M-AUTH-SESSION /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-AUTH-SESSION><M-MISSING /></M-AUTH-SESSION></GD-MAIN></NgraceGraphDocument>`,
    );

    const graph = buildGraphProjection(resolveNgracePaths(root));

    expect(issueCodes(graph.issues)).toContain("projection.index.missing-path");
    expect(issueCodes(graph.issues)).toContain("projection.graph.dangling-link");
  });

  it("reports graph and verification XML documents that are not routed by their indexes", () => {
    const root = createProject();
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/index.xml`, `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments /></NgraceGraphIndex>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/main.xml`, `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE /></GD-MAIN></NgraceGraphDocument>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/verification/index.xml`, `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments /></NgraceVerificationIndex>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/verification/main.xml`, `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE /></VD-MAIN></NgraceVerificationDocument>`);

    const paths = resolveNgracePaths(root);
    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);

    expect(issueCodes(graph.issues)).toContain("projection.graph.unindexed-document");
    expect(issueCodes(verification.issues)).toContain("projection.verification.unindexed-document");
  });

  it("rejects absolute and escaping projection paths without reading them", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-ESCAPE><Path>../outside.xml</Path><Owns /></GD-ESCAPE><GD-ABS><Path>/tmp/outside.xml</Path><Owns /></GD-ABS><GD-WINDOWS><Path>C:\\outside.xml</Path><Owns /></GD-WINDOWS></GraphDocuments></NgraceGraphIndex>`,
    );

    const graph = buildGraphProjection(resolveNgracePaths(root));
    expect(issueCodes(graph.issues).filter((code) => code === "projection.index.invalid-path")).toHaveLength(3);
  });

  it("rejects projection routes that escape through symlinks without reading the target", () => {
    const root = createProject();
    const outside = createProject();
    writeProjectFile(outside, "outside.xml", `<not-valid`);
    mkdirSync(path.join(root, ARTIFACT_DIR, "graph"), { recursive: true });
    symlinkSync(path.join(outside, "outside.xml"), path.join(root, ARTIFACT_DIR, "graph", "escape.xml"));
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-ESCAPE><Path>graph/escape.xml</Path><Owns><M-ESCAPE /></Owns></GD-ESCAPE></GraphDocuments></NgraceGraphIndex>`,
    );

    const graph = buildGraphProjection(resolveNgracePaths(root));
    expect(issueCodes(graph.issues)).toContain("projection.index.invalid-path");
    expect(issueCodes(graph.issues)).not.toContain("xml.parse");
    expect(graph.documents.has("GD-ESCAPE")).toBe(false);
  });

  it("rejects repeated Owns declarations under the same or different owners", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-ONE><Path>graph/one.xml</Path><Owns><M-EXAMPLE /><M-EXAMPLE /></Owns></GD-ONE><GD-TWO><Path>graph/two.xml</Path><Owns><M-EXAMPLE /></Owns></GD-TWO></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/one.xml`, `<NgraceGraphDocument graceVersion="1.0"><GD-ONE><M-EXAMPLE /></GD-ONE></NgraceGraphDocument>`);
    writeProjectFile(root, `${ARTIFACT_DIR}/graph/two.xml`, `<NgraceGraphDocument graceVersion="1.0"><GD-TWO /></NgraceGraphDocument>`);

    const graph = buildGraphProjection(resolveNgracePaths(root));
    expect(issueCodes(graph.issues).filter((code) => code === "projection.graph.duplicate-route")).toHaveLength(2);
  });

  it("produces equivalent projections for monolithic and segmented storage", () => {
    const monolithicRoot = createProject();
    const segmentedRoot = createProject();
    writeMonolithicProject(monolithicRoot);
    writeSegmentedProject(segmentedRoot);

    const monolithicGraph = buildGraphProjection(resolveNgracePaths(monolithicRoot));
    const segmentedGraph = buildGraphProjection(resolveNgracePaths(segmentedRoot));
    const monolithicVerification = buildVerificationProjection(resolveNgracePaths(monolithicRoot), monolithicGraph);
    const segmentedVerification = buildVerificationProjection(resolveNgracePaths(segmentedRoot), segmentedGraph);

    expect(monolithicGraph.issues).toHaveLength(0);
    expect(segmentedGraph.issues).toHaveLength(0);
    expect([...monolithicGraph.modules.keys()].sort()).toEqual([...segmentedGraph.modules.keys()].sort());
    expect([...monolithicGraph.dataFlows.keys()].sort()).toEqual([...segmentedGraph.dataFlows.keys()].sort());
    expect([...monolithicVerification.entries.keys()].sort()).toEqual([...segmentedVerification.entries.keys()].sort());
  });

  it("detects nested graph anchors inside grouping tags", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-AUTH-SESSION /><M-USER-PROFILE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-AUTH-SESSION /><M-USER-PROFILE /><ModuleAnchors><M-AUTH-SESSION><Summary>Authenticate users.</Summary></M-AUTH-SESSION></ModuleAnchors></GD-MAIN></NgraceGraphDocument>`,
    );

    const graph = buildGraphProjection(resolveNgracePaths(root));
    expect(issueCodes(graph.issues)).toContain("projection.graph.nested-anchors");
    // Empty direct anchor is still found, but nested content is NOT projected
    expect(graph.modules.has("M-AUTH-SESSION")).toBe(true);
    expect(graph.modules.get("M-AUTH-SESSION")?.text).not.toContain("Authenticate");
  });

  it("detects nested verification anchors inside grouping tags", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example module.</Summary></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE /><ModuleVerification><V-M-EXAMPLE><Command>bun test example</Command></V-M-EXAMPLE></ModuleVerification></VD-MAIN></NgraceVerificationDocument>`,
    );

    const paths = resolveNgracePaths(root);
    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);
    expect(issueCodes(verification.issues)).toContain("projection.verification.nested-anchors");
    // Empty direct anchor is still found, but nested content is NOT projected
    expect(verification.entries.has("V-M-EXAMPLE")).toBe(true);
    expect(verification.entries.get("V-M-EXAMPLE")?.commands).toEqual([]);
  });

  it("reports nested anchors when populated grouped section shadows empty direct anchor", () => {
    const root = createProject();
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-AUTH-SESSION /><M-USER-PROFILE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-AUTH-SESSION /><M-USER-PROFILE /><Modules><M-AUTH-SESSION><Summary>Nested auth session.</Summary></M-AUTH-SESSION></Modules></GD-MAIN></NgraceGraphDocument>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-AUTH-SESSION /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-AUTH-SESSION /><VerificationAnchors><V-M-AUTH-SESSION><Command>bun test auth</Command></V-M-AUTH-SESSION></VerificationAnchors></VD-MAIN></NgraceVerificationDocument>`,
    );

    const paths = resolveNgracePaths(root);
    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);
    expect(issueCodes(graph.issues)).toContain("projection.graph.nested-anchors");
    expect(issueCodes(verification.issues)).toContain("projection.verification.nested-anchors");
    // Empty direct anchors are still found
    expect(graph.modules.has("M-AUTH-SESSION")).toBe(true);
    expect(verification.entries.has("V-M-AUTH-SESSION")).toBe(true);
    // Nested content NOT projected into records
    expect(verification.entries.get("V-M-AUTH-SESSION")?.commands).toEqual([]);
  });

  it("collects testFiles only from <TestFiles><File> and excludes naked <File> siblings", () => {
    const root = createProject();
    writeProjectFile(root, "apps/web/src/example.test.ts", "test\n");
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/index.xml`,
      `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/graph/main.xml`,
      `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example module.</Summary></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/index.xml`,
      `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`
    );
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE><Cwd>apps/web</Cwd><TestFiles><File>apps/web/src/example.test.ts</File></TestFiles><File>src/metadata.ts</File><Command>bun test example</Command><CommandNotes>ignored command</CommandNotes><ScenarioNotes>ignored scenario</ScenarioNotes><MarkerNotes>ignored marker</MarkerNotes><TraceAssertion>Pure output is deterministic.</TraceAssertion><TraceAssertionNotes>ignored trace</TraceAssertionNotes></V-M-EXAMPLE></VD-MAIN></NgraceVerificationDocument>`
    );

    const paths = resolveNgracePaths(root);
    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);

    expect(verification.issues).toHaveLength(0);
    const entry = verification.entries.get("V-M-EXAMPLE")!;
    expect(entry.cwd).toBe("apps/web");
    expect(entry.testFiles).toEqual(["apps/web/src/example.test.ts"]);
    // src/metadata.ts under a naked <File> (outside <TestFiles>) must NOT appear
    expect(entry.testFiles).not.toContain("src/metadata.ts");
    expect(entry.commands).toEqual(["bun test example"]);
    expect(entry.scenarios).toEqual([]);
    expect(entry.markers).toEqual([]);
    expect(entry.traceAssertions).toEqual(["Pure output is deterministic."]);
  });

  it("rejects verification cwd values that escape the project root", () => {
    const root = createProject();
    writeMonolithicProject(root);
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-AUTH-SESSION><Cwd>../../outside</Cwd></V-M-AUTH-SESSION><V-M-USER-PROFILE><Cwd>C:\\outside</Cwd></V-M-USER-PROFILE></VD-MAIN></NgraceVerificationDocument>`,
    );

    const paths = resolveNgracePaths(root);
    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);
    expect(issueCodes(verification.issues).filter((code) => code === "projection.verification.invalid-cwd")).toHaveLength(2);
    expect(verification.entries.get("V-M-AUTH-SESSION")?.cwd).toBeUndefined();
  });

  it("rejects Cwd and TestFiles that escape through traversal or symlinks", () => {
    const root = createProject();
    const outside = createProject();
    writeProjectFile(outside, "outside.test.ts", "test\n");
    writeMonolithicProject(root);
    symlinkSync(outside, path.join(root, "escaped-cwd"), "dir");
    symlinkSync(path.join(outside, "outside.test.ts"), path.join(root, "escaped.test.ts"));
    writeProjectFile(
      root,
      `${ARTIFACT_DIR}/verification/main.xml`,
      `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-AUTH-SESSION><Cwd>escaped-cwd</Cwd><TestFiles><File>../outside.test.ts</File></TestFiles></V-M-AUTH-SESSION><V-M-USER-PROFILE><TestFiles><File>escaped.test.ts</File></TestFiles></V-M-USER-PROFILE></VD-MAIN></NgraceVerificationDocument>`,
    );

    const paths = resolveNgracePaths(root);
    const graph = buildGraphProjection(paths);
    const verification = buildVerificationProjection(paths, graph);
    expect(issueCodes(verification.issues)).toContain("projection.verification.invalid-cwd");
    expect(issueCodes(verification.issues).filter((code) => code === "projection.verification.invalid-test-file")).toHaveLength(2);
  });

  // C-TOKEN-INTEGRITY T-003 / P0.5 — Owns text diagnosis and index silent discards.
  describe("Owns diagnosis and index list discards (T-003)", () => {
    it("raises a direct Owns diagnosis for text where self-closing anchors belong (silent as unlisted-anchor only today)", () => {
      const root = createProject();
      // Index owns M-EXAMPLE as bare text, not a child tag — owns list empty → unlisted-anchor today.
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/index.xml`,
        `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns>M-EXAMPLE</Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
      );
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/main.xml`,
        `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example.</Summary></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`,
      );
      writeProjectFile(root, `${ARTIFACT_DIR}/verification/index.xml`, `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments /></NgraceVerificationIndex>`);
      writeProjectFile(root, `${ARTIFACT_DIR}/verification/main.xml`, `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN /></NgraceVerificationDocument>`);

      const graph = buildGraphProjection(resolveNgracePaths(root));
      const ownsText = graph.issues.filter((i) => i.code === "projection.index.owns-text");
      expect(ownsText.length).toBeGreaterThanOrEqual(1);
      expect(ownsText[0]!.message).toMatch(/Owns|self-closing|text/i);
      // Must not be only the useless unlisted-anchor path.
      expect(ownsText[0]!.code).not.toBe("projection.graph.unlisted-anchor");
    });

    it("raises projection.index.invalid-owns-child for non-anchor Owns children (silent filter today)", () => {
      const root = createProject();
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/index.xml`,
        `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /><NotAnAnchor /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
      );
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/main.xml`,
        `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example.</Summary></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`,
      );
      writeProjectFile(root, `${ARTIFACT_DIR}/verification/index.xml`, `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments /></NgraceVerificationIndex>`);

      const graph = buildGraphProjection(resolveNgracePaths(root));
      const invalid = graph.issues.filter((i) => i.code === "projection.index.invalid-owns-child");
      expect(invalid.length).toBeGreaterThanOrEqual(1);
      expect(invalid.some((i) => i.message.includes("NotAnAnchor"))).toBe(true);
    });

    it("raises projection.index.invalid-document-child for non-GD under GraphDocuments (silent today)", () => {
      const root = createProject();
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/index.xml`,
        `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><Note>oops</Note><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
      );
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/main.xml`,
        `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example.</Summary></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`,
      );
      writeProjectFile(root, `${ARTIFACT_DIR}/verification/index.xml`, `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments /></NgraceVerificationIndex>`);

      const graph = buildGraphProjection(resolveNgracePaths(root));
      const invalid = graph.issues.filter((i) => i.code === "projection.index.invalid-document-child");
      expect(invalid.length).toBeGreaterThanOrEqual(1);
      expect(invalid.some((i) => i.message.includes("Note"))).toBe(true);
    });

    it("raises projection.index.invalid-document-child for non-VD under VerificationDocuments (silent today)", () => {
      const root = createProject();
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/index.xml`,
        `<NgraceGraphIndex graceVersion="1.0"><GraphDocuments><GD-MAIN><Path>graph/main.xml</Path><Owns><M-EXAMPLE /></Owns></GD-MAIN></GraphDocuments></NgraceGraphIndex>`,
      );
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/graph/main.xml`,
        `<NgraceGraphDocument graceVersion="1.0"><GD-MAIN><M-EXAMPLE><Summary>Example.</Summary><V-M-EXAMPLE /></M-EXAMPLE></GD-MAIN></NgraceGraphDocument>`,
      );
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/verification/index.xml`,
        `<NgraceVerificationIndex graceVersion="1.0"><VerificationDocuments><Note>oops</Note><VD-MAIN><Path>verification/main.xml</Path><Owns><V-M-EXAMPLE /></Owns></VD-MAIN></VerificationDocuments></NgraceVerificationIndex>`,
      );
      writeProjectFile(
        root,
        `${ARTIFACT_DIR}/verification/main.xml`,
        `<NgraceVerificationDocument graceVersion="1.0"><VD-MAIN><V-M-EXAMPLE><Command>bun test</Command><Scenario>ok</Scenario></V-M-EXAMPLE></VD-MAIN></NgraceVerificationDocument>`,
      );

      const graph = buildGraphProjection(resolveNgracePaths(root));
      const verification = buildVerificationProjection(resolveNgracePaths(root), graph);
      const invalid = verification.issues.filter((i) => i.code === "projection.index.invalid-document-child");
      expect(invalid.length).toBeGreaterThanOrEqual(1);
      expect(invalid.some((i) => i.message.includes("Note"))).toBe(true);
    });
  });
});
