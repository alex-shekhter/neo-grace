import { existsSync, lstatSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, readlinkSync, rmSync, statSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import type { GraceXmlNode } from "./artifact/xml";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "bun:test";

import { ARTIFACT_DIR } from "./artifact/paths";
import {
  writeChangeBundleFixture,
  writeMinimalNgraceProject,
} from "./artifact/test-fixtures";
import { setLooseEventReadProbeForTests } from "./artifact/run-membership";
import { RANGE_CLOSING_KINDS, validateNgraceProject } from "./artifact/grammar";
import { snapshotProjectTree } from "./test-support/fixtures";
import {
  advanceCursor,
  appendCommandRunEvent,
  classifyFlakeFromEvidence,
  countTaskAttemptEvents,
  cursorStateForEventKind,
  decideFixBudgetEscalation,
  deriveAttemptOrdinal,
  deriveStateFromEvents,
  discardAndFoldEpoch,
  expectedLedgerEventAttributes,
  FIX_DISTINCT_SIGNATURE_BUDGET,
  FIX_ESCALATION_CEILING,
  FIX_SIGNATURE_REPEAT_BUDGET,
  fixBudgetSkillRequiredSubstrings,
  foldEpoch,
  formatCursorPosition,
  formatRecoverDiagnosis,
  inheritLooseEventTask,
  KNOWN_EVENT_KINDS,
  lastResolvingResumeId,
  listAccountingEvents,
  listLedgerEvents,
  listLooseEvents,
  listRunOrphans,
  type LooseEvent,
  listUnresolvedCircuitTrippedTasks,
  listUnresolvedEscalatedTasks,
  listWindowFailSignatures,
  parseCursorState,
  pauseCursor,
  readAttemptPayload,
  recordAttempt,
  recordVerificationUnavailable,
  recoverCursor,
  setEventIdAllocationProbeForTests,
  regenerateCursor,
  resumeCursor,
  showCursor,
  type ChangedFileEvidence,
  type KnownEventKind,
  type WriteEvidenceSnapshot,
} from "./grace-cursor";
import * as graceCursorModule from "./grace-cursor";
import { GraceCommandError } from "./query/errors";
import { collectProjectStatus, formatStatusText } from "./grace-status";
import { lintGraceProject } from "./lint/core";

/** Test helper: path list → write evidence with stable synthetic content digests. */
function evidencePaths(paths: string[], digests?: Record<string, string>): WriteEvidenceSnapshot {
  const files: ChangedFileEvidence[] = paths.map((filePath) => ({
    path: filePath,
    kind: "content" as const,
    digest: digests?.[filePath] ?? `digest:${filePath}`,
  }));
  return { available: true, files };
}

function evidenceAbsent(paths: string[]): WriteEvidenceSnapshot {
  return {
    available: true,
    files: paths.map((filePath) => ({ path: filePath, kind: "absent" as const })),
  };
}

function evidenceUndetermined(paths: string[], reason = "unreadable"): WriteEvidenceSnapshot {
  return {
    available: true,
    files: paths.map((filePath) => ({
      path: filePath,
      kind: "undetermined" as const,
      absence: { verdict: "unable-to-determine" as const, reason },
    })),
  };
}

function createProject() {
  const root = path.join(os.tmpdir(), `grace-cursor-${crypto.randomUUID()}`);
  mkdirSync(root, { recursive: true });
  return root;
}

function isRangeClosingKind(kind: string): boolean {
  return (RANGE_CLOSING_KINDS as readonly string[]).includes(kind);
}

function seedBundle(root: string, changeId = "C-RUN") {
  writeMinimalNgraceProject(root);
  writeChangeBundleFixture(root, {
    changeId,
    location: "active",
    specStatus: "approved",
    planStatus: "approved",
  });
  // writeMinimalNgraceProject already writes governed src/example.ts (LINKS: M-EXAMPLE)
  // matching ObservedWriteScope in the fixture plan (C-GRAPH-COVERAGE layer 3).
  return path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
}

function runGit(root: string, args: string[]) {
  const result = Bun.spawnSync({ cmd: ["git", ...args], cwd: root, stdout: "pipe", stderr: "pipe" });
  if (result.exitCode !== 0) {
    throw new Error(Buffer.from(result.stderr).toString("utf8") || `git ${args.join(" ")} failed`);
  }
}

function initGitBaseline(root: string) {
  runGit(root, ["init"]);
  runGit(root, ["config", "user.email", "grace@example.test"]);
  runGit(root, ["config", "user.name", "GRACE Test"]);
  runGit(root, ["config", "commit.gpgsign", "false"]);
  runGit(root, ["config", "core.hooksPath", "disabled-hooks"]);
  runGit(root, ["add", "."]);
  runGit(root, ["commit", "-m", "test: baseline"]);
}

/**
 * Literal-substring hits across production sources under src/, excluding *.test.ts.
 * In-process on purpose: shelling out to `rg` made these assertions depend on an
 * undeclared external binary that is absent on CI, and on POSIX path separators
 * that Windows does not emit. Paths are repo-relative and always "/"-joined.
 */
function productionSourceHits(needle: string): { file: string; text: string }[] {
  const srcRoot = import.meta.dir;
  const hits: { file: string; text: string }[] = [];
  const walk = (dir: string): void => {
    for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const absolute = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(absolute);
        continue;
      }
      if (entry.name.endsWith(".test.ts")) continue;
      const relative = `src/${path.relative(srcRoot, absolute).replaceAll("\\", "/")}`;
      for (const text of readFileSync(absolute, "utf8").split("\n")) {
        if (text.includes(needle)) hits.push({ file: relative, text });
      }
    }
  };
  walk(srcRoot);
  return hits;
}

describe("cursor show / regenerate write surface (AC-WRITE-SURFACE)", () => {
  it("cursor show leaves the tree byte-identical", () => {
    const root = createProject();
    seedBundle(root);
    const before = snapshotProjectTree(root);
    const position = showCursor(root, "C-RUN");
    expect(position.changeId).toBe("C-RUN");
    expect(snapshotProjectTree(root)).toEqual(before);
  });

  it("bare regenerate is dry-run and leaves the tree byte-identical", () => {
    const root = createProject();
    seedBundle(root);
    const before = snapshotProjectTree(root);
    const result = regenerateCursor(root, "C-RUN");
    expect(result.dryRun).toBe(true);
    expect(result.applied).toBe(false);
    expect(snapshotProjectTree(root)).toEqual(before);
  });

  it("regenerate --apply writes run.xml", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const result = regenerateCursor(root, "C-RUN", { apply: true, allowDirty: true });
    expect(result.applied).toBe(true);
    expect(existsSync(path.join(bundle, "run.xml"))).toBe(true);
  });
});

describe("fold ordering (AC-FOLD-ORDERING)", () => {
  it("write-verify-delete folds a clean range and empties run/", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", {
      task: "T-001",
      openEpoch: true,
      worker: "w0",
      from: 1,
      to: 99,
      wave: "1",
    });
    // openEpoch wrote id=1 opened; advance densifies with 2..terminal
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "progress" });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });

    const result = foldEpoch(root, "C-RUN", { wave: "1" });
    expect(result.applied).toBe(true);
    expect(result.epoch).toBe(1);
    expect(result.eventCount).toBe(3);
    expect(listLooseEvents(path.join(root, ARTIFACT_DIR, "changes", "active", "C-RUN"))).toHaveLength(0);
    expect(existsSync(path.join(root, ARTIFACT_DIR, "changes", "active", "C-RUN", "run-ledger.xml"))).toBe(true);

    const issues = validateNgraceProject(root).issues.filter((i) => i.code.startsWith("ledger."));
    expect(issues).toHaveLength(0);
  });

  it("interrupted fold leaves both forms; re-fold is idempotent", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });

    expect(() => foldEpoch(root, "C-RUN", { injectFailureAfterWrite: true })).toThrow("injected failure after write");
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(true);
    expect(listLooseEvents(bundle).length).toBeGreaterThan(0);

    const second = foldEpoch(root, "C-RUN");
    expect(second.applied).toBe(true);
    expect(listLooseEvents(bundle)).toHaveLength(0);

    // re-fold with empty run/ is idempotent
    const third = foldEpoch(root, "C-RUN");
    expect(third.eventCount).toBe(0);
    expect(third.epoch).toBe(second.epoch);
  });

  it("concurrent appends from two allocations fold without clock ordering", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    // Manual two-range open: write opened with two allocations, then interleaved ids
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="a" from="1" to="99"/><Allocation worker="b" from="100" to="199"/></NgraceRunEvent>`,
    );
    // Interleave: a=2, b=100, a=3 terminal, b=101 terminal — sort by id never by time
    writeFileSync(
      path.join(runDir, "100-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="100" task="T-001" kind="progress"/>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="progress"/>`,
    );
    writeFileSync(
      path.join(runDir, "101-T-001-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="101" task="T-001" kind="terminal"/>`,
    );
    writeFileSync(
      path.join(runDir, "3-T-001-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="3" task="T-001" kind="terminal"/>`,
    );

    const result = foldEpoch(root, "C-RUN");
    expect(result.eventCount).toBe(5);
    const loose = listLooseEvents(bundle);
    expect(loose).toHaveLength(0);
    // Ordering assertion uses allocated ids only
    const ids = [1, 2, 3, 100, 101];
    expect(ids).toEqual([...ids].sort((a, b) => a - b));
  });

  it("range hole refuses fold before write — no ledger left behind (§0.7.2)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="10"/></NgraceRunEvent>`,
    );
    // hole at 2: skip to 3 terminal
    writeFileSync(
      path.join(runDir, "3-T-001-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="3" task="T-001" kind="terminal"/>`,
    );
    expect(() => foldEpoch(root, "C-RUN")).toThrow(/hole|invalid-project/i);
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
    expect(listLooseEvents(bundle).length).toBeGreaterThan(0);
  });

  it("unterminated range refuses fold before write — no ledger left behind (§0.7.2)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="10"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="progress"/>`,
    );
    expect(() => foldEpoch(root, "C-RUN")).toThrow(/unterminated|invalid-project/i);
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
  });
});

describe("regenerate three sources (AC-REGENERATE-SOURCES)", () => {
  it("labels inferred rows and distinguishes them from ledger-derived", () => {
    const root = createProject();
    seedBundle(root);
    const inferred = regenerateCursor(root, "C-RUN");
    expect(inferred.position.inferred).toBe(true);
    expect(inferred.position.sources.task).toBe("inferred");
    expect(formatCursorPosition(inferred.position)).toContain("Inferred: yes");

    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    const fromLedger = regenerateCursor(root, "C-RUN");
    expect(fromLedger.position.inferred).toBe(false);
    expect(fromLedger.position.sources.epoch).toBe("ledger");
    expect(formatCursorPosition(fromLedger.position)).toContain("Inferred: no");
  });

  it("project with ledger and no loose events regenerates from rows 1-2 alone", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    const first = regenerateCursor(root, "C-RUN");
    const second = regenerateCursor(root, "C-RUN");
    expect(first.position.epoch).toBe(second.position.epoch);
    expect(first.position.inferred).toBe(false);
  });

  it("ObservedWriteScope intersect changed files → in-progress with task absence (A13.2)", () => {
    const root = createProject();
    seedBundle(root);
    initGitBaseline(root);
    // Genuinely modify a file inside ObservedWriteScope (src/example.ts)
    writeFileSync(path.join(root, "src/example.ts"), `export function run() { return "modified"; }\n`);

    const position = showCursor(root, "C-RUN");
    expect(position.inferred).toBe(true);
    expect(position.state).toBe("in-progress");
    expect(position.task).toBeUndefined();
    expect(position.taskAbsence?.verdict).toBe("unable-to-determine");
    expect(position.taskAbsence?.reason).toBeTruthy();
    expect(position.epoch).toBeUndefined();
    expect(formatCursorPosition(position)).toContain("unable-to-determine");
    // Must not invent the plan's first task id
    expect(position.task).not.toBe("T-001");
    expect(formatCursorPosition(position)).not.toMatch(/Task: T-001\b/);
  });

  it("untouched bundle with no events → idle with task absence (A13.2)", () => {
    const root = createProject();
    seedBundle(root);
    initGitBaseline(root);
    // No further writes — worktree clean relative to ObservedWriteScope
    const position = showCursor(root, "C-RUN");
    expect(position.inferred).toBe(true);
    expect(position.state).toBe("idle");
    expect(position.stateAbsence).toBeUndefined();
    expect(position.task).toBeUndefined();
    expect(position.taskAbsence?.verdict).toBe("unable-to-determine");
    expect(position.epoch).toBeUndefined();
  });

  it("git unavailable → stateAbsence, never idle (A14.1 / correction 27)", () => {
    const root = createProject();
    seedBundle(root);
    // No git init — listRepositoryChangedFiles returns available:false
    const position = showCursor(root, "C-RUN");
    expect(position.inferred).toBe(true);
    expect(position.state).toBeUndefined();
    expect(position.stateAbsence?.verdict).toBe("unable-to-determine");
    expect(position.stateAbsence?.reason).toMatch(/git status exited non-zero/);
    expect(formatCursorPosition(position)).toContain("unable-to-determine");
    expect(formatCursorPosition(position)).not.toMatch(/^State: idle$/m);
  });

  it("archived bundle → stateAbsence for missing active scope (A14.1 / correction 27)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-ARCH",
      location: "archive",
      specStatus: "applied",
      planStatus: "applied",
    });
    mkdirSync(path.join(root, "src"), { recursive: true });
    writeFileSync(path.join(root, "src/example.ts"), `export function run() { return "ok"; }\n`);
    initGitBaseline(root);

    const position = showCursor(root, "C-ARCH");
    expect(position.inferred).toBe(true);
    expect(position.state).toBeUndefined();
    expect(position.stateAbsence?.verdict).toBe("unable-to-determine");
    expect(position.stateAbsence?.reason).toMatch(/no active ObservedWriteScope|archived/);
    expect(formatCursorPosition(position)).not.toMatch(/^State: idle$/m);
  });

  it("genuinely complete when structural TargetAssertions clean and no command gate (A14.2)", () => {
    const root = createProject();
    seedBundle(root);
    initGitBaseline(root);
    const position = showCursor(root, "C-RUN");
    expect(position.complete).toBe(true);
    expect(position.completeAbsence).toBeUndefined();
    expect(formatCursorPosition(position)).toContain("Complete: yes");
  });

  it("MustPassCommand skipped → complete absence not-run, not yes/no (A14.2 / correction 28)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-RUN",
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
      planTargetAssertions:
        "<MustVerify><Module>M-EXAMPLE</Module></MustVerify><MustPassCommand><Command>exit 0</Command></MustPassCommand>",
    });
    mkdirSync(path.join(root, "src"), { recursive: true });
    writeFileSync(path.join(root, "src/example.ts"), `export function run() { return "ok"; }\n`);
    initGitBaseline(root);

    const position = showCursor(root, "C-RUN");
    expect(position.complete).toBeUndefined();
    expect(position.completeAbsence?.verdict).toBe("not-run");
    expect(position.completeAbsence?.reason).toMatch(/MustPassCommand|not executed|not evaluable/i);
    expect(formatCursorPosition(position)).toContain("not-run");
    expect(formatCursorPosition(position)).not.toMatch(/^Complete: yes$/m);
    expect(formatCursorPosition(position)).not.toMatch(/^Complete: no$/m);
  });

  it("unapproved change → complete absence, not incomplete (A14.2 / correction 28)", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId: "C-DRAFT",
      location: "active",
      specStatus: "draft",
      planStatus: "draft",
    });
    mkdirSync(path.join(root, "src"), { recursive: true });
    writeFileSync(path.join(root, "src/example.ts"), `export function run() { return "ok"; }\n`);
    initGitBaseline(root);

    const position = showCursor(root, "C-DRAFT");
    expect(position.complete).toBeUndefined();
    expect(position.completeAbsence?.verdict).toBe("unable-to-determine");
    expect(position.completeAbsence?.reason).toMatch(/not an active approved|not evaluated/i);
    expect(formatCursorPosition(position)).not.toMatch(/^Complete: no$/m);
    expect(formatCursorPosition(position)).not.toMatch(/^Complete: yes$/m);
  });
});

describe("recover not block (AC-RECOVER-NOT-BLOCK)", () => {
  it("cursor show never blocks on missing, identity-less, or mismatched cursor", () => {
    const root = createProject();
    const bundle = seedBundle(root);

    // missing
    const missing = showCursor(root, "C-RUN");
    expect(missing.degradation?.verdict).toBe("not-run");

    // mismatched identity
    writeFileSync(
      path.join(bundle, "run.xml"),
      `<NgraceRunCursor graceVersion="1.0"><C-OTHER><Task>T-001</Task><State>idle</State></C-OTHER></NgraceRunCursor>`,
    );
    const mismatched = showCursor(root, "C-RUN");
    expect(mismatched.degradation?.verdict).toBe("unable-to-determine");
    expect(mismatched.changeId).toBe("C-RUN");

    // lint still errors on the written file
    const lint = lintGraceProject(root);
    expect(lint.issues.some((i) => i.code === "cursor.bundle-id-mismatch")).toBe(true);
  });
});

describe("status surface (AC-STATUS-SURFACE)", () => {
  it("prints epoch and task counts; chooseNextAction ignores cursor", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");

    // Cursor claims a weird state — nextAction must stay plan-derived
    writeFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", "C-RUN", "run.xml"),
      `<NgraceRunCursor graceVersion="1.0"><C-RUN><Task>T-001</Task><Epoch>99</Epoch><State>paused</State></C-RUN></NgraceRunCursor>`,
    );

    const status = collectProjectStatus(root);
    const change = status.changes.find((c) => c.changeId === "C-RUN");
    expect(change?.epochCount).toBe(1);
    expect(change?.taskCount).toBe(1);
    const text = formatStatusText(status);
    expect(text).toContain("epochs=1");
    expect(text).toContain("tasks=1");
    // Plan is approved+approved+ready → execute; cursor pause must not change that
    expect(status.nextAction).toContain("ngrace-execute");
  });

  it("prints normally when no cursor exists", () => {
    const root = createProject();
    seedBundle(root);
    const status = collectProjectStatus(root);
    expect(status.changes.some((c) => c.changeId === "C-RUN")).toBe(true);
    expect(formatStatusText(status)).toContain("C-RUN");
  });
});

describe("write-surface inventory (AC-WRITE-SURFACE grep)", () => {
  /**
   * §3.5.8 / A10.9 write surface and A15.1 delete surface.
   * Same shell patterns as the phase report; post-state is pinned here so drift fails CI.
   */
  it("pins writeFileSync|mkdirSync to graph, cursor, gates ledger, dart, and generate only", () => {
    const result = Bun.spawnSync({
      cmd: ["bash", "-lc", "grep -rn 'writeFileSync\\|mkdirSync' src --include='*.ts' | grep -v test"],
      cwd: path.join(import.meta.dir, ".."),
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(result.exitCode).toBe(0);
    const lines = new TextDecoder()
      .decode(result.stdout)
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    // A10.9 baseline + grace-cursor + gates/ledger (A30 Verdicts/Decisions write)
    // + grace-generate (spec new / plan new writers); nothing else.
    for (const line of lines) {
      expect(
        line.startsWith("src/grace-graph.ts:")
          || line.startsWith("src/grace-cursor.ts:")
          || line.startsWith("src/gates/ledger.ts:")
          || line.startsWith("src/lint/adapters/dart.ts:")
          || line.startsWith("src/grace-generate.ts:"),
      ).toBe(true);
    }
    expect(lines.some((line) => line.startsWith("src/grace-cursor.ts:"))).toBe(true);
    expect(lines.some((line) => line.startsWith("src/grace-graph.ts:"))).toBe(true);
    expect(lines.some((line) => line.startsWith("src/gates/ledger.ts:"))).toBe(true);
    expect(lines.some((line) => line.startsWith("src/lint/adapters/dart.ts:"))).toBe(true);
    expect(lines.some((line) => line.startsWith("src/grace-generate.ts:"))).toBe(true);
  });

  it("pins unlinkSync|rmSync|rmdirSync to fold delete, ledger rollback, and dart temp cleanup (A15.1 / A31.5)", () => {
    const result = Bun.spawnSync({
      cmd: ["bash", "-lc", "grep -rn 'unlinkSync\\|rmSync\\|rmdirSync' src --include='*.ts' | grep -v test"],
      cwd: path.join(import.meta.dir, ".."),
      stdout: "pipe",
      stderr: "pipe",
    });
    expect(result.exitCode).toBe(0);
    const lines = new TextDecoder()
      .decode(result.stdout)
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    // Import lines plus call sites: fold delete, ledger post-write rollback (A31.5), dart temp,
    // review scorer temp-project cleanup (Phase 6 corpus scoring), and the
    // C-SUPERSEDE-MEMBERSHIP candidate cleanup + lock surface in grace-generate/grace-cursor.
    for (const line of lines) {
      expect(
        line.startsWith("src/grace-cursor.ts:")
          || line.startsWith("src/gates/ledger.ts:")
          || line.startsWith("src/lint/adapters/dart.ts:")
          || line.startsWith("src/review/scorer.ts:")
          || line.startsWith("src/grace-generate.ts:"),
      ).toBe(true);
    }
    const callSites = lines.filter((line) => /(?:unlinkSync|rmSync|rmdirSync)\s*\(/.test(line)).sort();
    const cursorContained = callSites.filter(
      (line) => line.startsWith("src/grace-cursor.ts:") && /unlinkSync\(contained\.absolutePath\);$/.test(line),
    );
    const cursorLock = callSites.filter(
      (line) => line.startsWith("src/grace-cursor.ts:") && /unlinkSync\(lockPath\);$/.test(line),
    );
    const ledgerUnlink = callSites.find((line) => line.startsWith("src/gates/ledger.ts:"));
    const dartRm = callSites.find((line) => line.startsWith("src/lint/adapters/dart.ts:"));
    const scorerRm = callSites.find((line) => line.startsWith("src/review/scorer.ts:"));
    // F288 adds the loose-event writer lock (stale-holder steal and finally release);
    // B1 (C-SUPERSEDE-MEMBERSHIP-4-20941257) adds the candidate lock reclaim and
    // release in grace-cursor, and the candidate cleanup surface in grace-generate.
    // F313 (C-FOLD-RETRY-CORE) added one contained-path delete in grace-cursor: the
    // interrupted-fold resume. C-FOLD-MIXED-RECOVERY adds the mixed-path residue
    // delete. The lock sites name `lockPath`; the contained-path sites are the fold
    // delete, the writer's own-file renumber, the F313 resume delete, and the
    // mixed-path residue delete.
    expect(cursorContained).toHaveLength(4);
    expect(cursorLock).toHaveLength(4);
    expect(ledgerUnlink).toMatch(/^src\/gates\/ledger\.ts:\d+:\s*unlinkSync\(ledgerPath\);$/);
    expect(dartRm).toMatch(/^src\/lint\/adapters\/dart\.ts:\d+:\s*rmSync\(temporaryDirectory, \{ recursive: true, force: true \}\);$/);
    expect(scorerRm).toMatch(/^src\/review\/scorer\.ts:\d+:\s*rmSync\(root, \{ recursive: true, force: true \}\);$/);
    expect(callSites).toHaveLength(11);
    expect(lines.some((line) => line.includes("rmdirSync"))).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// Phase 4 — attempt log, fix budget, escalation (C-ATTEMPT-LOG)
// ---------------------------------------------------------------------------

describe("fold preserves payload (AC-FOLD-PRESERVES-PAYLOAD / A18.2)", () => {
  it("preserves outcome, FailureSignature, and WriteEvidence in the FOLDED ledger", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99, wave: "1" });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "grace-cursor.test.ts:fold" },
      writeEvidence: evidencePaths(["src/example.ts"]),
    });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });

    const result = foldEpoch(root, "C-RUN", { wave: "1" });
    expect(result.applied).toBe(true);
    expect(listLooseEvents(bundle)).toHaveLength(0);

    const ledger = listLedgerEvents(bundle);
    const attempt = ledger.find((event) => event.kind === "attempt");
    expect(attempt).toBeDefined();
    expect(attempt!.attributes.outcome).toBe("fail");
    // No ordinal persisted (A18.3)
    expect(attempt!.attributes.ordinal).toBeUndefined();
    const payload = readAttemptPayload(attempt!);
    expect(payload.signature).toEqual({ kind: "test-failure", key: "grace-cursor.test.ts:fold" });
    expect(payload.writeEvidence).toEqual(evidencePaths(["src/example.ts"]));

    const text = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(text).toContain('outcome="fail"');
    expect(text).toContain("FailureSignature");
    expect(text).toContain("WriteEvidence");
  });

  it("injected payload drop fails verify and leaves every loose file on disk", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "drop-probe" },
      writeEvidence: evidencePaths([]),
    });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });

    const beforeLoose = listLooseEvents(bundle).map((event) => event.file).sort();
    expect(beforeLoose.length).toBeGreaterThan(0);

    expect(() => foldEpoch(root, "C-RUN", { injectDropPayload: true })).toThrow(/payload mismatch/i);

    const afterLoose = listLooseEvents(bundle).map((event) => event.file).sort();
    expect(afterLoose).toEqual(beforeLoose);
    // Ledger may exist from the write step, but delete must not have run.
    expect(afterLoose.length).toBe(beforeLoose.length);
  });

  it("three-attribute events and re-fold with nothing loose still pass (A7.2 both directions)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "progress" });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    const first = foldEpoch(root, "C-RUN");
    expect(first.applied).toBe(true);
    expect(listLooseEvents(bundle)).toHaveLength(0);
    const second = foldEpoch(root, "C-RUN");
    expect(second.eventCount).toBe(0);
    expect(second.epoch).toBe(first.epoch);
  });
});

describe("attempt events (AC-ATTEMPT-EVENTS / AC-THREE-VALUED-OUTCOME)", () => {
  it("pass-first produces one attempt in the FOLDED ledger; fail-then-pass produces two", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "pass",
      writeEvidence: evidencePaths([]),
    });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    const passOnly = listLedgerEvents(bundle).filter((event) => event.kind === "attempt");
    expect(passOnly).toHaveLength(1);
    expect(passOnly[0]!.attributes.outcome).toBe("pass");

    const root2 = createProject();
    const bundle2 = seedBundle(root2);
    advanceCursor(root2, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root2, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "lint", key: "x" },
      writeEvidence: evidencePaths(["a.ts"]),
    });
    recordAttempt(root2, "C-RUN", {
      task: "T-001",
      outcome: "pass",
      writeEvidence: evidencePaths(["a.ts", "b.ts"]),
    });
    // fail+pass hits budget on fail path only for second fail; pass does not escalate.
    // attempt count is 2; if first was fail and second pass, no escalation (escalation only on fail path).
    // Wait: first fail count=1, second pass count=2 but pass branch — no escalate. Need terminal for fold.
    advanceCursor(root2, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root2, "C-RUN");
    const both = listLedgerEvents(bundle2).filter((event) => event.kind === "attempt");
    expect(both).toHaveLength(2);
    expect(both.map((event) => event.attributes.outcome).sort()).toEqual(["fail", "pass"]);
  });

  it("derived ordinal survives fold; no ordinal attribute on any event (A18.3)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const first = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" },
      writeEvidence: evidencePaths([]),
    });
    // Second same-signature fail escalates R — still has attempt events.
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" },
      writeEvidence: evidencePaths([]),
    });
    const loose = listLooseEvents(bundle);
    const attempts = loose.filter((event) => event.kind === "attempt");
    expect(deriveAttemptOrdinal(attempts, "T-001", first.eventId)).toBe(1);
    expect(deriveAttemptOrdinal(attempts, "T-001", attempts[1]!.id)).toBe(2);
    for (const event of loose) {
      expect(event.attributes.ordinal).toBeUndefined();
      expect(event.attributes.sequence).toBeUndefined();
      expect(event.attributes.index).toBeUndefined();
    }
  });

  it("verification-unavailable appears in FOLDED ledger and is not an attempt (A19.1)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "harness absent" },
    });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "unable-to-determine", reason: "commands skipped" },
    });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    const ledger = listLedgerEvents(bundle);
    const unavailable = ledger.filter((event) => event.kind === "verification-unavailable");
    expect(unavailable).toHaveLength(2);
    expect(countTaskAttemptEvents(ledger, "T-001")).toBe(0);
    expect(unavailable[0]!.attributes.verdict).toBe("not-run");
    expect(unavailable[0]!.attributes.reason).toBe("harness absent");
  });
});

describe("signature fix budget R/D (C-ESCALATION-HONESTY / AC-SIGNATURE-BUDGET-SEQUENCES)", () => {
  const A = { kind: "k", key: "a" };
  const B = { kind: "k", key: "b" };
  const C = { kind: "k", key: "c" };
  const D = { kind: "k", key: "d" };

  function failSig(
    root: string,
    signature: { kind: string; key: string },
    task = "T-001",
  ) {
    return recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature,
      writeEvidence: evidencePaths([]),
    });
  }

  it("constants pin R=2 and D=4 exactly (F23)", () => {
    expect(FIX_SIGNATURE_REPEAT_BUDGET).toBe(2);
    expect(FIX_DISTINCT_SIGNATURE_BUDGET).toBe(4);
    expect(FIX_ESCALATION_CEILING).toBe(2);
  });

  it("fail(A) does not escalate", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const r = failSig(root, A);
    expect(r.escalated).toBe(false);
    expect(r.trigger).toBeUndefined();
  });

  it("fail(A), fail(A) escalates with trigger R", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    expect(failSig(root, A).escalated).toBe(false);
    const second = failSig(root, A);
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.position.state).toBe("paused-pending-approval");
    expect(second.message).toContain("trigger R");
    expect(second.message).toContain("k:a");
    expect(second.message).toContain("paused-pending-approval");
    expect(second.message).toMatch(/has not failed|decision owed/i);
    expect(second.message).not.toMatch(/task failed/i);
    expect(second.message).not.toMatch(/after \d+ attempts/);
  });

  it("fail(A), fail(B) does not escalate (different signatures — red-first progress)", () => {
    // Consequence of approved rule, not accommodation: two distinct reds are not thrash.
    // Replaces the pre-C-ESCALATION-HONESTY §4.5.2 pin that treated any two fails as thrash.
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    expect(failSig(root, A).escalated).toBe(false);
    const second = failSig(root, B);
    expect(second.escalated).toBe(false);
    expect(second.trigger).toBeUndefined();
    expect(second.position.state).not.toBe("paused-pending-approval");
  });

  it("fail(A), pass, fail(B) does not escalate", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "pass",
      writeEvidence: evidencePaths(["src/x.ts"]),
    });
    const third = failSig(root, B);
    expect(third.escalated).toBe(false);
    expect(third.trigger).toBeUndefined();
  });

  it("fail(A), pass, fail(A) escalates with trigger R (intervening pass ignored for R)", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "pass",
      writeEvidence: evidencePaths(["src/x.ts"]),
    });
    const third = failSig(root, A);
    expect(third.escalated).toBe(true);
    expect(third.trigger).toBe("R");
  });

  it("pass, fail(A) does not escalate (attempt-count rule regression)", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "pass",
      writeEvidence: evidencePaths([]),
    });
    const second = failSig(root, A);
    expect(second.escalated).toBe(false);
    expect(second.trigger).toBeUndefined();
  });

  it("fail(A), fail(B), fail(A) escalates with R not D (distinct=2)", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    failSig(root, B);
    const third = failSig(root, A);
    expect(third.escalated).toBe(true);
    expect(third.trigger).toBe("R");
    expect(third.message).toContain("trigger R");
    expect(third.message).not.toContain("trigger D");
  });

  it("fail(A), fail(B), fail(C) does not escalate (backstop not at 3)", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    failSig(root, B);
    const third = failSig(root, C);
    expect(third.escalated).toBe(false);
    expect(third.trigger).toBeUndefined();
  });

  it("fail(A), fail(B), pass, fail(C) does not escalate", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    failSig(root, B);
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "pass",
      writeEvidence: evidencePaths(["src/x.ts"]),
    });
    const fourth = failSig(root, C);
    expect(fourth.escalated).toBe(false);
  });

  it("fail(A), fail(B), fail(C), fail(D) escalates with trigger D on the fourth", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    expect(failSig(root, A).escalated).toBe(false);
    expect(failSig(root, B).escalated).toBe(false);
    expect(failSig(root, C).escalated).toBe(false);
    const fourth = failSig(root, D);
    expect(fourth.escalated).toBe(true);
    expect(fourth.trigger).toBe("D");
    expect(fourth.message).toContain("trigger D");
    expect(fourth.message).toContain(String(FIX_DISTINCT_SIGNATURE_BUDGET));
    expect(fourth.message).toContain("distinct unresolved failures");
    expect(fourth.message).not.toMatch(/after \d+ attempts/);
    expect(fourth.message).toContain("k: a");
    expect(fourth.message).toContain("k: d");
  });

  it("verification-unavailable ×2 does not exhaust the budget", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "first skip" },
    });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "second skip" },
    });
    expect(showCursor(root, "C-RUN").state).not.toBe("paused-pending-approval");
    const after = failSig(root, A);
    expect(after.escalated).toBe(false);
  });

  it("same kind different key is not a repeat of each other", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, { kind: "test", key: "one" });
    const second = failSig(root, { kind: "test", key: "two" });
    expect(second.escalated).toBe(false);
  });

  it("different kind same key is not a repeat of each other", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, { kind: "alpha", key: "shared" });
    const second = failSig(root, { kind: "beta", key: "shared" });
    expect(second.escalated).toBe(false);
  });

  it("equality is exact (case-sensitive): K vs k does not count as repeat", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, { kind: "Test", key: "X" });
    const second = failSig(root, { kind: "test", key: "x" });
    expect(second.escalated).toBe(false);
  });

  it("decideFixBudgetEscalation unit: R before D; empty → no escalate", () => {
    expect(decideFixBudgetEscalation([])).toEqual({ escalate: false });
    expect(decideFixBudgetEscalation([A])).toEqual({ escalate: false });
    expect(decideFixBudgetEscalation([A, A])).toEqual({
      escalate: true,
      trigger: "R",
      repeated: A,
    });
    expect(decideFixBudgetEscalation([A, B, C])).toEqual({ escalate: false });
    const d = decideFixBudgetEscalation([A, B, C, D]);
    expect(d.escalate).toBe(true);
    if (d.escalate) {
      expect(d.trigger).toBe("D");
      if (d.trigger === "D") expect(d.distinctCount).toBe(4);
    }
    // Interaction: third is repeat of A → R, even though distinct would grow
    expect(decideFixBudgetEscalation([A, B, A])).toEqual({
      escalate: true,
      trigger: "R",
      repeated: A,
    });
  });

  it("R message names repeated signature; D message names distinct backstop (wrong-trigger ban)", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    const r = failSig(root, A);
    expect(r.trigger).toBe("R");
    expect(r.message).toContain("repeated failure signature k:a");
    expect(r.message).toContain("trigger R");
    expect(r.message).not.toContain("trigger D");

    const root2 = createProject();
    seedBundle(root2);
    advanceCursor(root2, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root2, A);
    failSig(root2, B);
    failSig(root2, C);
    const d = failSig(root2, D);
    expect(d.trigger).toBe("D");
    expect(d.message).toContain("trigger D");
    expect(d.message).not.toContain("trigger R");
    expect(d.message).not.toContain("repeated failure signature");
  });

  it("two verification-unavailable events do NOT exhaust the budget and both survive fold", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "first skip" },
    });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "second skip" },
    });
    const loose = listLooseEvents(bundle);
    expect(countTaskAttemptEvents(loose, "T-001")).toBe(0);
    expect(showCursor(root, "C-RUN").state).not.toBe("paused-pending-approval");
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    const vu = listLedgerEvents(bundle).filter((event) => event.kind === "verification-unavailable");
    expect(vu).toHaveLength(2);
  });

  it("dropping the cursor and re-deriving still reports paused-pending-approval (both sites)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" },
      writeEvidence: evidencePaths([]),
    });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" }, // R: same signature twice
      writeEvidence: evidencePaths([]),
    });
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");

    // Drop the cursor cache (D1 recovery path).
    const cursorPath = path.join(bundle, "run.xml");
    expect(existsSync(cursorPath)).toBe(true);
    writeFileSync(cursorPath, ""); // destroy written cursor
    // Prefer re-derive without written cursor
    const rederived = regenerateCursor(root, "C-RUN");
    expect(rederived.position.state).toBe("paused-pending-approval");
    // show without preferWrittenCursor also reads events
    const shown = showCursor(root, "C-RUN");
    // show uses preferWrittenCursor:true — empty/broken cursor should degrade and re-derive
    expect(shown.state).toBe("paused-pending-approval");
  });

  it("unrecognized kind does not resolve to in-progress (correction 34)", () => {
    expect(cursorStateForEventKind("attempt-fail")).toMatchObject({ unknown: true });
    expect(cursorStateForEventKind("garbage")).toMatchObject({ unknown: true });
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const position = advanceCursor(root, "C-RUN", { task: "T-001", kind: "mystery-kind" });
    expect(position.state).not.toBe("in-progress");
    expect(position.degradation?.verdict).toBe("unable-to-determine");
  });
});

describe("cursor state parsed (AC-CURSOR-STATE-PARSED)", () => {
  it("unrecognized written state degrades; show still answers; lint still reports", () => {
    expect(parseCursorState("paused-pending-approval")).toEqual({ state: "paused-pending-approval" });
    expect(parseCursorState("paused-pending-supersede")).toEqual({ state: "paused-pending-supersede" });
    expect(parseCursorState("discarded")).toEqual({ state: "discarded" });
    expect(parseCursorState("shipped")).toEqual({ invalid: "shipped" });

    const root = createProject();
    const bundle = seedBundle(root);
    writeFileSync(
      path.join(bundle, "run.xml"),
      `<NgraceRunCursor graceVersion="1.0"><C-RUN><Task>T-001</Task><State>shipped</State></C-RUN></NgraceRunCursor>`,
    );
    const position = showCursor(root, "C-RUN");
    expect(position.changeId).toBe("C-RUN");
    expect(position.degradation?.verdict).toBe("unable-to-determine");
    expect(position.degradation?.reason).toMatch(/shipped/);
    // Does not throw; still answers.
    expect(formatCursorPosition(position)).toContain("Degradation:");
    // lint still reports the written file (identity ok, state is free text in grammar today —
    // at minimum show recovered; structural lint should not throw).
    const lint = lintGraceProject(root);
    expect(lint.issues.every((issue) => issue.severity !== "error" || !issue.code.startsWith("cursor.invalid-root"))).toBe(true);
  });

  it("writeCursorFile round-trips paused-pending-approval (A19.2)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" },
      writeEvidence: evidencePaths([]),
    });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" },
      writeEvidence: evidencePaths([]),
    });
    const written = readFileSync(path.join(bundle, "run.xml"), "utf8");
    expect(written).toContain("paused-pending-approval");
    const shown = showCursor(root, "C-RUN");
    expect(shown.state).toBe("paused-pending-approval");
  });
});

describe("flake classification (AC-FLAKE-CLASSIFICATION / A19.3)", () => {
  const failEv = (evidence: WriteEvidenceSnapshot) => ({
    outcome: "fail",
    writeEvidence: evidence,
  });
  const passEv = (evidence: WriteEvidenceSnapshot) => ({
    outcome: "pass",
    writeEvidence: evidence,
  });

  it("fail then pass with identical write evidence is flaky", () => {
    const evidence: WriteEvidenceSnapshot = evidencePaths(["src/a.ts"]);
    const result = classifyFlakeFromEvidence(failEv(evidence), passEv(evidence));
    expect(result.verdict).toBe("flaky");
  });

  it("fail then pass with intervening write is retry", () => {
    const result = classifyFlakeFromEvidence(
      failEv(evidencePaths(["src/a.ts"])),
      passEv(evidencePaths(["src/a.ts", "src/b.ts"])),
    );
    expect(result.verdict).toBe("retry");
  });

  it("unavailable write evidence is unable-to-determine, not flaky or retry", () => {
    const result = classifyFlakeFromEvidence(
      failEv({
        available: false,
        absence: { verdict: "unable-to-determine", reason: "git unavailable" },
      }),
      passEv(evidencePaths([])),
    );
    expect(result.verdict).toBe("unable-to-determine");
    expect(result.verdict).not.toBe("flaky");
    expect(result.reason).toMatch(/unavailable/i);
  });

  it("classifier issues no git call — reads only recorded snapshots", () => {
    // Evidence is fully synthetic; if classifyFlakeFromEvidence called git it would
    // need a project root. The API accepts only snapshots.
    const result = classifyFlakeFromEvidence(
      failEv(evidencePaths([])),
      passEv(evidencePaths([])),
    );
    expect(result.verdict).toBe("flaky");
  });

  it("same path set with different content digests is retry, not flaky (A20.3 / correction 39)", () => {
    const earlier = evidencePaths(["src/foo.ts"], { "src/foo.ts": "digest-before" });
    const later = evidencePaths(["src/foo.ts"], { "src/foo.ts": "digest-after-fix" });
    const result = classifyFlakeFromEvidence(failEv(earlier), passEv(later));
    expect(result.verdict).toBe("retry");
    expect(result.verdict).not.toBe("flaky");
  });
});

// ---------------------------------------------------------------------------
// A20 corrections 37–40
// ---------------------------------------------------------------------------

describe("budget survives fold (A20.1 / correction 37 / standing rule 9)", () => {
  it("post-fold second same-signature fail escalates R — budget does not reset (folded twin)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    // Epoch 1: fail T-001, terminal on a *different* task so the range can fold
    // while T-001's attempt remains in the ledger (A20.1 multi-task wave).
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99, wave: "1" });
    const first = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" },
      writeEvidence: evidencePaths([]),
    });
    expect(first.escalated).toBe(false);
    expect(first.attemptCount).toBe(1);
    // T-002 terminal densifies and closes the allocation (per-range, not per-task).
    advanceCursor(root, "C-RUN", { task: "T-002", kind: "terminal" });
    const fold = foldEpoch(root, "C-RUN", { wave: "1" });
    expect(fold.applied).toBe(true);
    expect(listLooseEvents(bundle)).toHaveLength(0);
    expect(listLedgerEvents(bundle).filter((e) => e.kind === "attempt" && e.task === "T-001")).toHaveLength(1);

    // Epoch 2: same signature again — R across fold (window not reset by fold).
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 100, to: 199, wave: "2" });
    const second = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" },
      writeEvidence: evidencePaths(["src/x.ts"]),
    });
    expect(second.attemptCount).toBe(2);
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.position.state).toBe("paused-pending-approval");
  });

  it("post-fold R escalation lists this-window same-signature fails (folded twin)", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" },
      writeEvidence: evidencePaths([]),
    });
    advanceCursor(root, "C-RUN", { task: "T-002", kind: "terminal" });
    foldEpoch(root, "C-RUN");

    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 100, to: 199 });
    const second = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" },
      writeEvidence: evidencePaths([]),
    });
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.signatures).toEqual([
      { kind: "test-failure", key: "suite-a" },
      { kind: "test-failure", key: "suite-a" },
    ]);
    expect(second.message).toContain("suite-a");
    expect(second.message).toContain("trigger R");
    const accounting = listAccountingEvents(
      path.join(root, ARTIFACT_DIR, "changes", "active", "C-RUN"),
    );
    expect(countTaskAttemptEvents(accounting, "T-001")).toBe(2);
    expect(listWindowFailSignatures(accounting, "T-001")).toHaveLength(2);
  });
});

describe("fold verify expected side independent of writer (A20.2 / correction 38)", () => {
  it("expectedLedgerEventAttributes strips graceVersion and keeps outcome (own assertion)", () => {
    const attrs = expectedLedgerEventAttributes({
      id: 2,
      task: "T-001",
      kind: "attempt",
      file: "/tmp/x",
      attributes: {
        graceVersion: "1.0",
        id: "2",
        task: "T-001",
        kind: "attempt",
        outcome: "fail",
      },
      children: [],
    });
    expect(attrs.graceVersion).toBeUndefined();
    expect(attrs.outcome).toBe("fail");
    expect(attrs.id).toBe("2");
    expect(attrs.task).toBe("T-001");
    expect(attrs.kind).toBe("attempt");
  });

  it("injectDropPayload still fails verify and leaves loose files (A7.2)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "k" },
      writeEvidence: evidencePaths([]),
    });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    const before = listLooseEvents(bundle).length;
    expect(() => foldEpoch(root, "C-RUN", { injectDropPayload: true })).toThrow(/payload mismatch/i);
    expect(listLooseEvents(bundle).length).toBe(before);
  });
});

describe("CLI attempt surface (A20.4 / correction 40)", () => {
  it("advance --kind attempt is reserved and errors", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    expect(() => advanceCursor(root, "C-RUN", { task: "T-001", kind: "attempt" })).toThrow(
      /reserved|cursor attempt/i,
    );
    expect(() =>
      advanceCursor(root, "C-RUN", { task: "T-001", kind: "verification-unavailable" }),
    ).toThrow(/reserved|verification-unavailable/i);
    expect(() => advanceCursor(root, "C-RUN", { task: "T-001", kind: "escalation" })).toThrow(
      /reserved|escalation/i,
    );
  });

  it("advanceCursor kind discarded is reserved and writes no run file", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const before = readdirSync(path.join(bundle, "run")).sort();
    let caught: unknown;
    try {
      advanceCursor(root, "C-RUN", { task: "T-001", kind: "discarded" });
    } catch (error) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(GraceCommandError);
    expect((caught as GraceCommandError).code).toBe("invalid-arguments");
    expect((caught as GraceCommandError).message).toBe(
      'kind "discarded" is reserved; ngrace supersede writes it when abandoning an open epoch.',
    );
    expect(readdirSync(path.join(bundle, "run")).sort()).toEqual(before);
  });

  it("AC-DISCARDED-CALLER: discardAndFoldEpoch production sites are cursor export and ledger call", () => {
    const hits = productionSourceHits("discardAndFoldEpoch");
    const files = [...new Set(hits.map((hit) => hit.file))].sort();
    expect(files).toEqual(["src/gates/ledger.ts", "src/grace-cursor.ts"]);
    expect(hits.some((hit) => hit.file === "src/grace-cursor.ts" && hit.text.includes("export function discardAndFoldEpoch"))).toBe(true);
    expect(hits.some((hit) => hit.file === "src/gates/ledger.ts" && /discardAndFoldEpoch\(/.test(hit.text))).toBe(true);
  });

  it("AC-DISCARDED-CALLER: kind discarded write is only inside discardAndFoldEpoch", () => {
    const hits = productionSourceHits('kind: "discarded"');
    // C-DISCARD-PREFLIGHT: the deterministic preflight constructs the prospective
    // `discarded` in memory, so the literal now appears twice — both inside the
    // discard operation, still the engine's only abandonment surface.
    expect(hits).toHaveLength(2);
    expect([...new Set(hits.map((hit) => hit.file))]).toEqual(["src/grace-cursor.ts"]);
    const cursorSrc = readFileSync(path.join(import.meta.dir, "grace-cursor.ts"), "utf8");
    const fnStart = cursorSrc.indexOf("export function discardAndFoldEpoch");
    const fnEnd = cursorSrc.indexOf("\nexport function", fnStart + 1);
    expect(fnStart).toBeGreaterThanOrEqual(0);
    expect(fnEnd).toBeGreaterThan(fnStart);
    const discardRegion = cursorSrc.slice(fnStart, fnEnd);
    expect(discardRegion.match(/kind: "discarded"/g)).toHaveLength(2);
  });

  it("fold accepts a discarded-closed allocation written as loose events", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="99" /></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-001-discarded.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="discarded"/>`,
    );
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(ledger).toContain('kind="discarded"');
    expect(ledger).not.toMatch(/kind="terminal"/);
  });

  it("cursor attempt and verification-unavailable subcommands are registered", () => {
    // Import the command definition and assert subcommand keys.
    // Dynamic import keeps the test co-located without starting the CLI main.
    const { cursorCommand } = require("./grace-cursor") as typeof import("./grace-cursor");
    const keys = Object.keys(cursorCommand.subCommands ?? {});
    expect(keys).toContain("attempt");
    expect(keys).toContain("verification-unavailable");
    expect(keys).toContain("advance");
    expect(keys).toContain("fold");
  });
});

// ---------------------------------------------------------------------------
// A21 corrections 41–42
// ---------------------------------------------------------------------------

describe("escalation is sticky until resume (A21.1 / correction 41)", () => {
  function escalate(root: string) {
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" },
      writeEvidence: evidencePaths([]),
    });
    const second = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" }, // R
      writeEvidence: evidencePaths([]),
    });
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.position.state).toBe("paused-pending-approval");
    return second;
  }

  it("write path: verification-unavailable after escalation keeps paused-pending-approval", () => {
    // Fixture position: escalation is NOT last — one more event after it (the twin that catches last-event-wins).
    const root = createProject();
    seedBundle(root);
    escalate(root);
    const after = recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "harness skipped" },
    });
    expect(after.state).toBe("paused-pending-approval");
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");
  });

  it("write path: progress after escalation keeps paused-pending-approval", () => {
    const root = createProject();
    seedBundle(root);
    escalate(root);
    const after = advanceCursor(root, "C-RUN", { task: "T-001", kind: "progress" });
    expect(after.state).toBe("paused-pending-approval");
  });

  it("read path: drop cursor after VU-following-escalation still re-derives paused-pending-approval", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    escalate(root);
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "unable-to-determine", reason: "skipped" },
    });
    writeFileSync(path.join(bundle, "run.xml"), ""); // destroy written cursor
    const rederived = regenerateCursor(root, "C-RUN");
    expect(rederived.position.state).toBe("paused-pending-approval");
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");
  });

  it("resume explicitly resolves escalation to in-progress", () => {
    const root = createProject();
    seedBundle(root);
    escalate(root);
    const resumed = resumeCursor(root, "C-RUN", "T-001", {
      reason: "replan after sticky-escalation check",
    });
    expect(resumed.state).toBe("in-progress");
    expect(showCursor(root, "C-RUN").state).toBe("in-progress");
  });

  it("deriveStateFromEvents: sticky until resume, unit-level", () => {
    const sticky = deriveStateFromEvents([
      { id: 1, kind: "opened", task: "T-001" },
      { id: 2, kind: "attempt", task: "T-001" },
      { id: 3, kind: "attempt", task: "T-001" },
      { id: 4, kind: "escalation", task: "T-001" },
      { id: 5, kind: "verification-unavailable", task: "T-001" },
      { id: 6, kind: "progress", task: "T-001" },
    ]);
    expect(sticky).toEqual({ state: "paused-pending-approval" });
    const resolved = deriveStateFromEvents([
      { id: 1, kind: "opened", task: "T-001" },
      { id: 4, kind: "escalation", task: "T-001" },
      { id: 5, kind: "resume", task: "T-001" },
    ]);
    expect(resolved).toEqual({ state: "in-progress" });
  });
});

// ---------------------------------------------------------------------------
// A22 corrections 43–44 — plurality and fold axes (leave the one-task / one-epoch origin)
// ---------------------------------------------------------------------------

describe("per-task escalation set (A22.1 / correction 43)", () => {
  function escalateTask(root: string, task: string, open = false) {
    if (open) {
      advanceCursor(root, "C-RUN", { task, openEpoch: true, from: 1, to: 99 });
    }
    const sig = { kind: "test-failure", key: `${task}-repeat` };
    recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature: sig,
      writeEvidence: evidencePaths([]),
    });
    const second = recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature: sig, // R: same signature twice
      writeEvidence: evidencePaths([]),
    });
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.position.state).toBe("paused-pending-approval");
    return second;
  }

  it("resume --task T-002 leaves T-001 escalated (plurality twin)", () => {
    // Fixture leaves plurality origin: two tasks; T-001 escalated, T-002 resume must not clear it.
    const root = createProject();
    seedBundle(root);
    escalateTask(root, "T-001", true);
    // T-002 becomes active without escalating
    advanceCursor(root, "C-RUN", { task: "T-002", kind: "progress" });
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");

    const resumed = resumeCursor(root, "C-RUN", "T-002");
    // Unrelated task's resume must not resolve T-001's owed decision.
    expect(resumed.state).toBe("paused-pending-approval");
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");

    // Only T-001's own resume clears the set (reason required for escalation clear).
    const cleared = resumeCursor(root, "C-RUN", "T-001", {
      reason: "replan: clear T-001 after plurality check",
    });
    expect(cleared.state).toBe("in-progress");
    expect(showCursor(root, "C-RUN").state).toBe("in-progress");
  });

  it("T-002 progress is recorded and not swallowed while T-001 is escalated (plurality twin)", () => {
    // While set non-empty, bundle stays ppa; T-002's events still land and feed lastNonSticky.
    // A23.1: task is drawn from escalated set — position names T-001, not the last-event task.
    const root = createProject();
    const bundle = seedBundle(root);
    escalateTask(root, "T-001", true);
    const afterProgress = advanceCursor(root, "C-RUN", { task: "T-002", kind: "progress" });
    expect(afterProgress.state).toBe("paused-pending-approval");
    expect(afterProgress.task).toBe("T-001");
    expect(afterProgress.escalatedTasks).toEqual(["T-001"]);
    const loose = listLooseEvents(bundle);
    expect(loose.some((e) => e.task === "T-002" && e.kind === "progress")).toBe(true);

    // After T-001 resolves, derivation reflects recent activity (progress was not skipped).
    resumeCursor(root, "C-RUN", "T-001", {
      reason: "replan: clear T-001 after progress-while-escalated check",
    });
    expect(showCursor(root, "C-RUN").state).toBe("in-progress");
    expect(showCursor(root, "C-RUN").escalatedTasks).toEqual([]);
  });

  it("deriveStateFromEvents: resume of unrelated task leaves other escalation (unit)", () => {
    const stillOwed = deriveStateFromEvents([
      { id: 1, kind: "opened", task: "T-001" },
      { id: 2, kind: "escalation", task: "T-001" },
      { id: 3, kind: "progress", task: "T-002" },
      { id: 4, kind: "resume", task: "T-002" },
    ]);
    expect(stillOwed).toEqual({ state: "paused-pending-approval" });

    const bothClear = deriveStateFromEvents([
      { id: 1, kind: "escalation", task: "T-001" },
      { id: 2, kind: "escalation", task: "T-002" },
      { id: 3, kind: "resume", task: "T-001" },
      { id: 4, kind: "resume", task: "T-002" },
    ]);
    expect(bothClear).toEqual({ state: "in-progress" });

    const oneRemains = deriveStateFromEvents([
      { id: 1, kind: "escalation", task: "T-001" },
      { id: 2, kind: "escalation", task: "T-002" },
      { id: 3, kind: "resume", task: "T-002" },
    ]);
    expect(oneRemains).toEqual({ state: "paused-pending-approval" });
  });
});

describe("fold derives unresolved escalation (A22.2 / correction 44)", () => {
  it("fold twin: escalate T-001, T-002 terminal closes range, fold keeps paused-pending-approval", () => {
    // Fixture leaves transition origin (fold) AND plurality origin (two tasks).
    // A19.2 claimed escalated epochs do not fold — false: terminal is per-range, not per-task.
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" },
      writeEvidence: evidencePaths([]),
    });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test-failure", key: "suite-a" },
      writeEvidence: evidencePaths([]),
    });
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");

    // Different task's terminal satisfies the allocation and allows fold.
    advanceCursor(root, "C-RUN", { task: "T-002", kind: "terminal" });
    const fold = foldEpoch(root, "C-RUN");
    expect(fold.applied).toBe(true);
    expect(listLooseEvents(bundle)).toHaveLength(0);

    // Written run.xml must not claim idle over an unresolved escalation.
    const runXml = readFileSync(path.join(bundle, "run.xml"), "utf8");
    expect(runXml).toContain("paused-pending-approval");
    expect(runXml).not.toMatch(/<State>idle<\/State>/);

    // show prefers written cursor — must still report the owed decision.
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");

    // Re-derive without written cursor also recovers from ledger.
    writeFileSync(path.join(bundle, "run.xml"), "");
    expect(regenerateCursor(root, "C-RUN").position.state).toBe("paused-pending-approval");
  });
});

// ---------------------------------------------------------------------------
// A25 / correction 47 — escalation authority is the stream, never the written cursor
// ---------------------------------------------------------------------------

describe("prefer-written escalation from stream (A25.1 / correction 47)", () => {
  function escalateT001(root: string) {
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "a" },
      writeEvidence: evidencePaths([]),
    });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "a" }, // R
      writeEvidence: evidencePaths([]),
    });
  }

  /** Pre-4abc775 shape: State without EscalatedTask children. */
  function writeLegacyCursor(
    bundle: string,
    options: { state: string; task?: string; epoch?: number; escalatedTasks?: string[] },
  ) {
    const epoch = options.epoch !== undefined ? `<Epoch>${options.epoch}</Epoch>` : "";
    const task = options.task ? `<Task>${options.task}</Task>` : "";
    const escalated = (options.escalatedTasks ?? [])
      .map((t) => `<EscalatedTask>${t}</EscalatedTask>`)
      .join("");
    writeFileSync(
      path.join(bundle, "run.xml"),
      `<NgraceRunCursor graceVersion="1.0"><C-RUN>${epoch}${task}${escalated}<State>${options.state}</State></C-RUN></NgraceRunCursor>\n`,
    );
  }

  it("upgrade fixture: legacy run.xml without EscalatedTask over unresolved ledger → ppa from stream + degradation", () => {
    // Authority axis: cache says in-progress; record holds escalation.
    const root = createProject();
    const bundle = seedBundle(root);
    escalateT001(root);
    writeLegacyCursor(bundle, { state: "in-progress", task: "T-001", epoch: 1 });

    const shown = showCursor(root, "C-RUN");
    expect(shown.state).toBe("paused-pending-approval");
    expect(shown.escalatedTasks).toEqual(["T-001"]);
    expect(shown.task).toBe("T-001");
    expect(shown.degradation?.verdict).toBe("unable-to-determine");
    expect(shown.degradation?.reason).toMatch(/disagrees|durable|ledger|stream/i);
    expect(shown.sources.state).not.toBe("cursor");
    expect(["ledger", "events"]).toContain(shown.sources.state);
  });

  it("stale fixture: run.xml still escalated after ledger resolved → not escalated + degradation", () => {
    // Authority axis: cache keeps a resolved escalation alive.
    const root = createProject();
    const bundle = seedBundle(root);
    escalateT001(root);
    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: resolve before stale-cursor fixture" });
    expect(showCursor(root, "C-RUN").state).toBe("in-progress");
    expect(showCursor(root, "C-RUN").escalatedTasks).toEqual([]);

    // Stale write after resume.
    writeLegacyCursor(bundle, {
      state: "paused-pending-approval",
      task: "T-001",
      epoch: 1,
      escalatedTasks: ["T-001"],
    });

    const shown = showCursor(root, "C-RUN");
    expect(shown.state).not.toBe("paused-pending-approval");
    expect(shown.escalatedTasks).toEqual([]);
    expect(shown.degradation?.verdict).toBe("unable-to-determine");
    expect(shown.degradation?.reason).toMatch(/disagrees|durable|ledger|stream/i);
    expect(shown.sources.state).not.toBe("cursor");
  });

  it("unchanged: cursor that agrees with ledger produces no degradation", () => {
    const root = createProject();
    seedBundle(root);
    escalateT001(root);
    // Fresh write from recordAttempt already agrees.
    const shown = showCursor(root, "C-RUN");
    expect(shown.state).toBe("paused-pending-approval");
    expect(shown.escalatedTasks).toEqual(["T-001"]);
    expect(shown.degradation).toBeUndefined();
    // state is stream-authoritative even when agreeing
    expect(["ledger", "events"]).toContain(shown.sources.state);
  });

  it("transition twin: upgrade + stale fixtures still behave after fold", () => {
    // Leaves transition axis (fold) and authority axis (stale/legacy cache).
    const root = createProject();
    const bundle = seedBundle(root);
    escalateT001(root);
    advanceCursor(root, "C-RUN", { task: "T-002", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    expect(listLooseEvents(bundle)).toHaveLength(0);

    // Upgrade shape over folded ledger still unresolved.
    writeLegacyCursor(bundle, { state: "in-progress", task: "T-002", epoch: 1 });
    const upgrade = showCursor(root, "C-RUN");
    expect(upgrade.state).toBe("paused-pending-approval");
    expect(upgrade.escalatedTasks).toEqual(["T-001"]);
    expect(upgrade.task).toBe("T-001");
    expect(upgrade.degradation?.verdict).toBe("unable-to-determine");
    expect(upgrade.sources.state).toBe("ledger"); // loose empty after fold

    // Resolve via new epoch + resume, then plant stale cursor.
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 100, to: 199 });
    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: resolve after fold for stale-cursor twin" });
    writeLegacyCursor(bundle, {
      state: "paused-pending-approval",
      task: "T-001",
      epoch: 2,
      escalatedTasks: ["T-001"],
    });
    const stale = showCursor(root, "C-RUN");
    expect(stale.state).not.toBe("paused-pending-approval");
    expect(stale.escalatedTasks).toEqual([]);
    expect(stale.degradation?.verdict).toBe("unable-to-determine");
  });
});

// ---------------------------------------------------------------------------
// A23 / A24 — escalatedTasks field + budget window from resolving resume
// ---------------------------------------------------------------------------

describe("escalatedTasks on CursorPosition (A23.1 / correction 45)", () => {
  it("plurality: T-001 escalated + T-002 terminal — show names escalated task", () => {
    // Fixture leaves plurality origin: two tasks; state aggregates, task must not last-event-win.
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "a" },
      writeEvidence: evidencePaths([]),
    });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "a" },
      writeEvidence: evidencePaths([]),
    });
    advanceCursor(root, "C-RUN", { task: "T-002", kind: "terminal" });

    const shown = showCursor(root, "C-RUN");
    expect(shown.state).toBe("paused-pending-approval");
    expect(shown.task).toBe("T-001");
    expect(shown.escalatedTasks).toEqual(["T-001"]);
    expect(shown.task).not.toBe("T-002");

    const text = formatCursorPosition(shown);
    expect(text).toContain("Task: T-001");
    expect(text).toContain("EscalatedTasks: T-001");

    // A5.4: written cursor round-trips EscalatedTask elements.
    const runXml = readFileSync(path.join(bundle, "run.xml"), "utf8");
    expect(runXml).toContain("<EscalatedTask>T-001</EscalatedTask>");
    expect(runXml).toMatch(/<Task>T-001<\/Task>/);
  });

  it("writeCursorFile / show / regenerate round-trip escalatedTasks (A5.4)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" },
      writeEvidence: evidencePaths([]),
    });
    recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "a", key: "1" },
      writeEvidence: evidencePaths([]),
    });
    expect(showCursor(root, "C-RUN").escalatedTasks).toEqual(["T-001"]);
    writeFileSync(path.join(bundle, "run.xml"), ""); // drop written cursor
    const rederived = regenerateCursor(root, "C-RUN");
    expect(rederived.position.escalatedTasks).toEqual(["T-001"]);
    expect(rederived.position.task).toBe("T-001");
  });
});

describe("budget window from resolving resume (A24 / correction 46)", () => {
  function fail(root: string, task: string, key: string) {
    return recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature: { kind: "test", key },
      writeEvidence: evidencePaths([]),
    });
  }

  it("window: escalate R, resume, two more same-key fails — re-escalate R this-window only", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const first = fail(root, "T-001", "a");
    expect(first.escalated).toBe(false);
    const second = fail(root, "T-001", "a"); // R
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.attemptCount).toBe(2);
    expect(second.signatures).toEqual([
      { kind: "test", key: "a" },
      { kind: "test", key: "a" },
    ]);

    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: open new budget window after R" });
    expect(showCursor(root, "C-RUN").state).toBe("in-progress");

    const third = fail(root, "T-001", "c");
    expect(third.escalated).toBe(false);
    expect(third.attemptCount).toBe(1); // window after resolving resume

    const fourth = fail(root, "T-001", "c"); // second in-window R → circuit
    expect(fourth.escalated).toBe(false);
    expect(fourth.circuit).toBe(true);
    expect(fourth.trigger).toBe("R");
    expect(fourth.position.state).toBe("paused-pending-supersede");
    expect(fourth.attemptCount).toBe(2); // not 4
    expect(fourth.signatures).toEqual([
      { kind: "test", key: "c" },
      { kind: "test", key: "c" },
    ]);
    expect(fourth.message).toContain("trigger R");
    expect(fourth.message).toContain("test:c");
    expect(fourth.message).toContain("paused-pending-supersede");
    expect(fourth.message).not.toContain("test: a");
    expect(fourth.message).not.toMatch(/test: a\b/);
    expect(fourth.message).toMatch(/Signatures \(2\)/);
  });

  it("negative: two ordinary resumes do not open a budget window; same-key pair still escalates R", () => {
    // Ordinary resumes do not resolve an escalation → window start stays 0.
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const first = fail(root, "T-001", "pre");
    expect(first.escalated).toBe(false);
    expect(first.attemptCount).toBe(1);

    resumeCursor(root, "C-RUN", "T-001"); // ordinary — nothing to resolve
    resumeCursor(root, "C-RUN", "T-001"); // still ordinary

    const second = fail(root, "T-001", "pre"); // same key → R
    expect(second.attemptCount).toBe(2); // full history still counted
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.signatures.map((s) => s.key)).toEqual(["pre", "pre"]);
  });

  it("transition: window + escalatedTasks hold after fold", () => {
    // Leaves both plurality and transition axes: escalate T-001, T-002 terminal, fold,
    // then resume and re-exhaust window; also check escalatedTasks before resume after fold.
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    fail(root, "T-001", "a");
    fail(root, "T-001", "a"); // R
    advanceCursor(root, "C-RUN", { task: "T-002", kind: "terminal" });
    foldEpoch(root, "C-RUN");

    const afterFold = showCursor(root, "C-RUN");
    expect(afterFold.state).toBe("paused-pending-approval");
    expect(afterFold.task).toBe("T-001");
    expect(afterFold.escalatedTasks).toEqual(["T-001"]);
    expect(listLooseEvents(bundle)).toHaveLength(0);

    // Resume opens a window; two more same-key fails trip the circuit (second in-window R).
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 100, to: 199 });
    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: open window after fold" });
    fail(root, "T-001", "c");
    const reEsc = fail(root, "T-001", "c");
    expect(reEsc.escalated).toBe(false);
    expect(reEsc.circuit).toBe(true);
    expect(reEsc.trigger).toBe("R");
    expect(reEsc.position.state).toBe("paused-pending-supersede");
    expect(reEsc.attemptCount).toBe(2);
    expect(reEsc.signatures.map((s) => s.key)).toEqual(["c", "c"]);
    expect(reEsc.message).toContain("trigger R");
    expect(reEsc.message).toMatch(/Signatures \(2\)/);
  });

  it("unit: lastResolvingResumeId ignores ordinary resumes", () => {
    const events = [
      { id: 1, kind: "opened", task: "T-001" },
      { id: 2, kind: "attempt", task: "T-001" },
      { id: 3, kind: "resume", task: "T-001" }, // ordinary
      { id: 4, kind: "attempt", task: "T-001" },
      { id: 5, kind: "escalation", task: "T-001" },
      { id: 6, kind: "resume", task: "T-001" }, // resolving
      { id: 7, kind: "attempt", task: "T-001" },
    ];
    expect(lastResolvingResumeId(events, "T-001")).toBe(6);
    expect(countTaskAttemptEvents(events, "T-001")).toBe(1); // only id 7
    expect(listUnresolvedEscalatedTasks(events)).toEqual([]);
  });
});

// ---------------------------------------------------------------------------
// C-ESCALATION-HONESTY T-002 — resume reason on escalation clear
// ---------------------------------------------------------------------------

describe("resume reason on escalation clear (C-ESCALATION-HONESTY T-002)", () => {
  function escalateR(root: string, task = "T-001", key = "a") {
    advanceCursor(root, "C-RUN", { task, openEpoch: true, from: 1, to: 99 });
    recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature: { kind: "test", key },
      writeEvidence: evidencePaths([]),
    });
    const second = recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature: { kind: "test", key },
      writeEvidence: evidencePaths([]),
    });
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    return second;
  }

  function reasonFromResumeEvent(event: { kind: string; children: { tag: string; text: string }[] }) {
    expect(event.kind).toBe("resume");
    const reasonChild = event.children.find((c) => c.tag === "Reason");
    expect(reasonChild).toBeDefined();
    return reasonChild!.text;
  }

  it("AC-RESUME-REASON-REQUIRED: absent reason refuses before write; task stays escalated (resumeCursor)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    escalateR(root);
    const before = listLooseEvents(bundle).map((e) => e.id);
    expect(listUnresolvedEscalatedTasks(listAccountingEvents(bundle))).toEqual(["T-001"]);

    let caught: unknown;
    try {
      resumeCursor(root, "C-RUN", "T-001");
    } catch (error) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(GraceCommandError);
    expect((caught as GraceCommandError).code).toBe("invalid-arguments");
    expect((caught as GraceCommandError).message).toMatch(/--reason/);

    const after = listLooseEvents(bundle);
    expect(after.map((e) => e.id)).toEqual(before);
    expect(after.some((e) => e.kind === "resume")).toBe(false);
    expect(listUnresolvedEscalatedTasks(listAccountingEvents(bundle))).toEqual(["T-001"]);
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");
    expect(showCursor(root, "C-RUN").escalatedTasks).toEqual(["T-001"]);
  });

  it("AC-RESUME-REASON-REQUIRED: whitespace-only reason refuses before write (resumeCursor)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    escalateR(root);
    const before = listLooseEvents(bundle).map((e) => e.id);

    let caught: unknown;
    try {
      resumeCursor(root, "C-RUN", "T-001", { reason: "   \n\t  " });
    } catch (error) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(GraceCommandError);
    expect((caught as GraceCommandError).code).toBe("invalid-arguments");
    expect((caught as GraceCommandError).message).toMatch(/--reason/);

    expect(listLooseEvents(bundle).map((e) => e.id)).toEqual(before);
    expect(listLooseEvents(bundle).some((e) => e.kind === "resume")).toBe(false);
    expect(listUnresolvedEscalatedTasks(listAccountingEvents(bundle))).toEqual(["T-001"]);
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");
  });

  it("AC-RESUME-REASON-REQUIRED: advance --kind resume without reason refuses before write", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    escalateR(root);
    const before = listLooseEvents(bundle).map((e) => e.id);

    let caught: unknown;
    try {
      advanceCursor(root, "C-RUN", { task: "T-001", kind: "resume" });
    } catch (error) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(GraceCommandError);
    expect((caught as GraceCommandError).code).toBe("invalid-arguments");
    expect((caught as GraceCommandError).message).toMatch(/--reason/);

    expect(listLooseEvents(bundle).map((e) => e.id)).toEqual(before);
    expect(listLooseEvents(bundle).some((e) => e.kind === "resume")).toBe(false);
    expect(listUnresolvedEscalatedTasks(listAccountingEvents(bundle))).toEqual(["T-001"]);
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-approval");
  });

  it("AC-RESUME-REASON-RECORDED: special-character reason exact toBe on loose event and after fold", () => {
    // Counterweight: free-text replan prose with XML-significant chars + newline.
    const specialReason =
      'replan: use assertX & not assertY; guard <foo> and >bar; quotes "double" and \'single\'\nsecond line';
    const root = createProject();
    const bundle = seedBundle(root);
    escalateR(root);

    const resumed = resumeCursor(root, "C-RUN", "T-001", { reason: specialReason });
    expect(resumed.state).toBe("in-progress");
    expect(showCursor(root, "C-RUN").escalatedTasks).toEqual([]);

    const looseResume = listLooseEvents(bundle).find((e) => e.kind === "resume");
    expect(looseResume).toBeDefined();
    expect(reasonFromResumeEvent(looseResume!)).toBe(specialReason);
    // Must be a child element, not attributes.reason (VU's home).
    expect(looseResume!.attributes.reason).toBeUndefined();

    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    expect(listLooseEvents(bundle)).toHaveLength(0);

    const ledgerResume = listLedgerEvents(bundle).find((e) => e.kind === "resume");
    expect(ledgerResume).toBeDefined();
    expect(reasonFromResumeEvent(ledgerResume!)).toBe(specialReason);
    expect(ledgerResume!.attributes.reason).toBeUndefined();
  });

  it("AC-RESUME-REASON-RECORDED: advance --kind resume with reason records Reason child", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    escalateR(root);
    const reason = "advance-path replan: switch suite order";
    const resumed = advanceCursor(root, "C-RUN", { task: "T-001", kind: "resume", reason });
    expect(resumed.state).toBe("in-progress");
    const looseResume = listLooseEvents(bundle).find((e) => e.kind === "resume");
    expect(looseResume).toBeDefined();
    expect(reasonFromResumeEvent(looseResume!)).toBe(reason);
  });

  it("AC-RESUME-ORDINARY-WITHOUT-REASON: pause then resume without reason still works", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "pause" });
    expect(showCursor(root, "C-RUN").state).toBe("paused");
    expect(listUnresolvedEscalatedTasks(listAccountingEvents(bundle))).toEqual([]);

    const resumed = resumeCursor(root, "C-RUN", "T-001");
    expect(resumed.state).toBe("in-progress");
    const looseResume = listLooseEvents(bundle).find((e) => e.kind === "resume");
    expect(looseResume).toBeDefined();
    expect(looseResume!.children.find((c) => c.tag === "Reason")).toBeUndefined();
    expect(listUnresolvedEscalatedTasks(listAccountingEvents(bundle))).toEqual([]);
  });

  it("AC-RESUME-ORDINARY-WITHOUT-REASON: ordinary resume may still record optional reason", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "pause" });
    const reason = "optional note on ordinary resume";
    const resumed = resumeCursor(root, "C-RUN", "T-001", { reason });
    expect(resumed.state).toBe("in-progress");
    const looseResume = listLooseEvents(bundle).find((e) => e.kind === "resume");
    expect(reasonFromResumeEvent(looseResume!)).toBe(reason);
  });

  it("AC-BUDGET-WINDOW-PRESERVED: escalate → reason-resume → fail(C)×2 escalates R this-window only", () => {
    const root = createProject();
    seedBundle(root);
    escalateR(root, "T-001", "prior-window-a");

    resumeCursor(root, "C-RUN", "T-001", {
      reason: "replan: abandon prior-window signatures; new approach on C",
    });
    expect(showCursor(root, "C-RUN").state).toBe("in-progress");

    const firstC = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "C" },
      writeEvidence: evidencePaths([]),
    });
    expect(firstC.escalated).toBe(false);
    expect(firstC.signatures).toEqual([{ kind: "test", key: "C" }]);

    const secondC = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "C" },
      writeEvidence: evidencePaths([]),
    });
    expect(secondC.escalated).toBe(false);
    expect(secondC.circuit).toBe(true);
    expect(secondC.trigger).toBe("R");
    expect(secondC.position.state).toBe("paused-pending-supersede");
    expect(secondC.signatures).toEqual([
      { kind: "test", key: "C" },
      { kind: "test", key: "C" },
    ]);
    // Prior-window signature must not appear in this window's list or message.
    expect(secondC.signatures.some((s) => s.key === "prior-window-a")).toBe(false);
    expect(secondC.message).toContain("trigger R");
    expect(secondC.message).toContain("test:C");
    expect(secondC.message).not.toContain("prior-window-a");
    expect(secondC.attemptCount).toBe(2);
  });

  it("AC-BUDGET-WINDOW-PRESERVED: ordinary non-resolving resume does not reset the window", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const first = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "pre" },
      writeEvidence: evidencePaths([]),
    });
    expect(first.escalated).toBe(false);

    resumeCursor(root, "C-RUN", "T-001"); // ordinary — nothing to resolve; no reason required
    resumeCursor(root, "C-RUN", "T-001");

    const second = recordAttempt(root, "C-RUN", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "test", key: "pre" },
      writeEvidence: evidencePaths([]),
    });
    expect(second.escalated).toBe(true);
    expect(second.trigger).toBe("R");
    expect(second.signatures.map((s) => s.key)).toEqual(["pre", "pre"]);
  });

  it("verification-unavailable attributes.reason is unchanged (NonGoal)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const vuReason = "harness missing binary & not a Reason child";
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: vuReason },
    });
    const vu = listLooseEvents(bundle).find((e) => e.kind === "verification-unavailable");
    expect(vu).toBeDefined();
    expect(vu!.attributes.reason).toBe(vuReason);
    expect(vu!.children.find((c) => c.tag === "Reason")).toBeUndefined();
  });
});

describe("digest undetermined is absence not flaky (A21.2 / correction 42)", () => {
  const failEv = (evidence: WriteEvidenceSnapshot) => ({ outcome: "fail", writeEvidence: evidence });
  const passEv = (evidence: WriteEvidenceSnapshot) => ({ outcome: "pass", writeEvidence: evidence });

  it("both sides undetermined (unreadable) → unable-to-determine, not flaky", () => {
    const result = classifyFlakeFromEvidence(
      failEv(evidenceUndetermined(["src/a.ts"], "file unreadable")),
      passEv(evidenceUndetermined(["src/a.ts"], "file unreadable")),
    );
    expect(result.verdict).toBe("unable-to-determine");
    expect(result.verdict).not.toBe("flaky");
    expect(result.reason).toMatch(/undetermined|unreadable/i);
  });

  it("one side undetermined → unable-to-determine", () => {
    const result = classifyFlakeFromEvidence(
      failEv(evidencePaths(["src/a.ts"])),
      passEv(evidenceUndetermined(["src/a.ts"])),
    );
    expect(result.verdict).toBe("unable-to-determine");
  });

  it("both sides absent is genuine evidence → flaky when identical", () => {
    const result = classifyFlakeFromEvidence(
      failEv(evidenceAbsent(["src/gone.ts"])),
      passEv(evidenceAbsent(["src/gone.ts"])),
    );
    expect(result.verdict).toBe("flaky");
  });

  it("absent then content is retry", () => {
    const result = classifyFlakeFromEvidence(
      failEv(evidenceAbsent(["src/new.ts"])),
      passEv(evidencePaths(["src/new.ts"])),
    );
    expect(result.verdict).toBe("retry");
  });
});

describe("numeric epoch bounds (C-CURSOR-INTEGRITY T-002 / P0.4)", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");

  function listRunFiles(root: string, changeId = "C-RUN"): string[] {
    const runDir = path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run");
    if (!existsSync(runDir)) return [];
    return readdirSync(runDir).sort();
  }

  function cliOpenEpoch(root: string, from: string, to: string) {
    return Bun.spawnSync({
      cmd: [
        process.execPath,
        "./src/grace.ts",
        "cursor",
        "advance",
        "--change",
        "C-RUN",
        "--task",
        "T-001",
        "--open-epoch",
        "--from",
        from,
        "--to",
        to,
        "--path",
        root,
      ],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
  }

  it("AC-EPOCH-BOUNDS-REJECT: CLI --from T-001 --to T-001 exits non-zero and writes no run/*", () => {
    const root = createProject();
    seedBundle(root);
    const result = cliOpenEpoch(root, "T-001", "T-001");
    const stderr = Buffer.from(result.stderr).toString("utf8");
    const stdout = Buffer.from(result.stdout).toString("utf8");
    const combined = `${stdout}\n${stderr}`;
    expect(result.exitCode).not.toBe(0);
    expect(combined).toMatch(/positive integer/i);
    expect(combined).toMatch(/event id/i);
    expect(combined).toMatch(/task id/i);
    expect(listRunFiles(root)).toEqual([]);
    expect(listRunFiles(root).some((f) => f.startsWith("NaN-"))).toBe(false);
  });

  it("AC-EPOCH-BOUNDS-CLASS: refuses non-integer, zero, negative, float, and from>to via CLI", () => {
    const cases: Array<[string, string]> = [
      ["abc", "10"],
      ["1.5", "10"],
      ["0", "10"],
      ["-1", "10"],
      ["10", "1"],
    ];
    for (const [from, to] of cases) {
      const root = createProject();
      seedBundle(root);
      const result = cliOpenEpoch(root, from, to);
      const combined = `${Buffer.from(result.stdout).toString("utf8")}\n${Buffer.from(result.stderr).toString("utf8")}`;
      expect(result.exitCode).not.toBe(0);
      expect(combined).toMatch(/positive integer|event id|from|to/i);
      expect(listRunFiles(root)).toEqual([]);
    }
  });

  it("AC-EPOCH-BOUNDS-LIBRARY: advanceCursor refuses NaN, 0, -1, 1.5, and from>to; writes nothing", () => {
    const invalid: Array<{ from: number; to: number; label: string }> = [
      { from: Number("T-001"), to: Number("T-001"), label: "NaN task-id" },
      { from: NaN, to: 10, label: "NaN from" },
      { from: 0, to: 10, label: "zero" },
      { from: -1, to: 10, label: "negative" },
      { from: 1.5, to: 10, label: "float" },
      { from: 10, to: 1, label: "from>to" },
    ];
    for (const { from, to, label } of invalid) {
      const root = createProject();
      seedBundle(root);
      let threw: Error | undefined;
      try {
        advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from, to });
      } catch (error) {
        threw = error as Error;
      }
      expect(threw, label).toBeDefined();
      expect(threw!.message, label).toMatch(/positive integer/i);
      expect(threw!.message, label).toMatch(/event id/i);
      expect(threw!.message, label).toMatch(/task id/i);
      expect(listRunFiles(root), label).toEqual([]);
    }
  });

  it("valid --from 1 --to 10 still opens (library and CLI)", () => {
    const root = createProject();
    seedBundle(root);
    const position = advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    expect(position.state).toBe("in-progress");
    expect(listRunFiles(root).some((f) => f.endsWith("-opened.xml"))).toBe(true);

    const root2 = createProject();
    seedBundle(root2);
    const result = cliOpenEpoch(root2, "1", "10");
    expect(result.exitCode).toBe(0);
    expect(listRunFiles(root2).length).toBeGreaterThan(0);
  });
});

/**
 * F8.1-shaped fixture: NaN-* opened (EVENT_FILENAME :459 class) + valid loose
 * integer events + optional well-named invalid-id file (:470 class). Temp only.
 */
function seedF8Shape(
  root: string,
  options: {
    changeId?: string;
    withInvalidIdFile?: boolean;
    withTerminal?: boolean;
    validIds?: number[];
  } = {},
): string {
  const changeId = options.changeId ?? "C-RUN";
  const bundle = seedBundle(root, changeId);
  const runDir = path.join(bundle, "run");
  mkdirSync(runDir, { recursive: true });
  // Live F8 shape — no recoverable event id.
  writeFileSync(
    path.join(runDir, "NaN-T-001-opened.xml"),
    `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-001" kind="opened"><Allocation worker="w0" from="NaN" to="NaN" /></NgraceRunEvent>`,
  );
  const validIds = options.validIds ?? [1, 2, 3];
  for (const id of validIds) {
    const kind = id === validIds[0] ? "progress" : id === validIds[validIds.length - 1] && options.withTerminal ? "terminal" : "progress";
    writeFileSync(
      path.join(runDir, `${id}-T-001-${kind}.xml`),
      `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="${kind}"/>`,
    );
  }
  if (options.withInvalidIdFile) {
    // Well-named file (:459 match) whose XML id fails the positive-integer guard (:470).
    writeFileSync(
      path.join(runDir, "99-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="abc" task="T-001" kind="progress"/>`,
    );
  }
  return bundle;
}

describe("orphan inventory both skip classes (C-CURSOR-INTEGRITY T-003 / D8.7 / F8.2)", () => {
  it("listLooseEvents alone is blind to NaN-* and to well-named invalid-id files", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { withInvalidIdFile: true, validIds: [1, 2] });
    const loose = listLooseEvents(bundle);
    expect(loose.map((e) => e.id)).toEqual([1, 2]);
    expect(loose.some((e) => String(e.id) === "NaN")).toBe(false);
    expect(loose.some((e) => e.file.includes("NaN-"))).toBe(false);
    expect(loose.some((e) => e.file.includes("99-T-001"))).toBe(false);
  });

  it("AC-ORPHAN-BOTH-SKIPS: listRunOrphans reports EVENT_FILENAME miss (NaN-*) and invalid-id", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { withInvalidIdFile: true, validIds: [1, 2] });
    const orphans = listRunOrphans(bundle);
    const byClass = Object.fromEntries(orphans.map((o) => [o.class, o]));
    expect(orphans.length).toBeGreaterThanOrEqual(2);
    expect(byClass["event-filename"]).toBeDefined();
    expect(byClass["event-filename"]!.name).toBe("NaN-T-001-opened.xml");
    expect(byClass["event-filename"]!.recoverable).toBe(false);
    expect(byClass["event-filename"]!.reason).toMatch(/event id|filename|recoverable/i);
    expect(byClass["invalid-id"]).toBeDefined();
    expect(byClass["invalid-id"]!.name).toBe("99-T-001-progress.xml");
    expect(byClass["invalid-id"]!.recoverable).toBe(false);
    expect(byClass["invalid-id"]!.rawId).toBe("abc");
  });

  it("discriminating negative: :470-only inventory misses NaN-* (event-filename class required)", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { withInvalidIdFile: true, validIds: [1] });
    const orphans = listRunOrphans(bundle);
    // A reader that only checked positive-integer id after EVENT_FILENAME match
    // would report invalid-id but not NaN-*. Both classes must be present.
    expect(orphans.some((o) => o.class === "event-filename" && o.name.startsWith("NaN-"))).toBe(true);
    expect(orphans.some((o) => o.class === "invalid-id")).toBe(true);
  });

  it("discriminating negative: :459-only inventory misses well-named non-integer id", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { withInvalidIdFile: true, validIds: [1] });
    const orphans = listRunOrphans(bundle);
    // A reader that only flagged EVENT_FILENAME misses would report NaN-* but not 99-*.
    expect(orphans.some((o) => o.class === "invalid-id" && o.name === "99-T-001-progress.xml")).toBe(true);
    expect(orphans.some((o) => o.class === "event-filename")).toBe(true);
  });

  it("D8.7: listLooseEvents primary list stays ordered positive-integer only (unchanged contract)", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { withInvalidIdFile: true, validIds: [3, 1, 2] });
    const loose = listLooseEvents(bundle);
    expect(loose.map((e) => e.id)).toEqual([1, 2, 3]);
    // Orphans are not mixed into the primary list.
    for (const event of loose) {
      expect(Number.isInteger(event.id) && event.id > 0).toBe(true);
    }
    const orphanNames = new Set(listRunOrphans(bundle).map((o) => o.name));
    expect(orphanNames.has("NaN-T-001-opened.xml")).toBe(true);
    expect(orphanNames.has("99-T-001-progress.xml")).toBe(true);
    expect(loose.every((e) => !orphanNames.has(path.basename(e.file)))).toBe(true);
  });
});

describe("cursor recover diagnose (C-CURSOR-INTEGRITY T-004 / P0.6)", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");

  function cliRecover(root: string, changeId = "C-RUN", extra: string[] = []) {
    return Bun.spawnSync({
      cmd: [
        process.execPath,
        "./src/grace.ts",
        "cursor",
        "recover",
        "--change",
        changeId,
        "--path",
        root,
        ...extra,
      ],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
  }

  it("AC-RECOVER-DIAGNOSE: subcommand exists and reports F8.1 shape on a temp copy", () => {
    const root = createProject();
    seedF8Shape(root, { validIds: [1, 2, 3], withTerminal: false });
    const result = cliRecover(root);
    const stdout = Buffer.from(result.stdout).toString("utf8");
    const stderr = Buffer.from(result.stderr).toString("utf8");
    const combined = `${stdout}\n${stderr}`;
    // Diagnose is informational; exit 0 with a report a reviewer can run.
    expect(result.exitCode).toBe(0);
    expect(combined).toMatch(/unrecoverable orphan/i);
    expect(combined).toMatch(/NaN-T-001-opened\.xml/);
    expect(combined).toMatch(/no recoverable event id/i);
    expect(combined).toMatch(/missing|no valid|covering allocation/i);
    expect(combined).toMatch(/1\s*[.…]{1,3}\s*3|from=1.*to=3|1\.\.3|range.*1.*3/i);
    expect(combined).toMatch(/fold.*block/i);
  });

  it("AC-RECOVER-DIAGNOSE: library diagnosis fields are stable for JSON consumers", () => {
    const root = createProject();
    seedF8Shape(root, { validIds: [1, 2, 3] });
    const diagnosis = recoverCursor(root, "C-RUN");
    expect(diagnosis.fixApplied).toBe(false);
    expect(diagnosis.orphans.some((o) => o.name === "NaN-T-001-opened.xml" && o.recoverable === false)).toBe(true);
    expect(diagnosis.coveringAllocation).toBe("missing");
    expect(diagnosis.looseEventRange).toEqual({ from: 1, to: 3 });
    expect(diagnosis.looseEventIds).toEqual([1, 2, 3]);
    expect(diagnosis.foldBlocked).toBe(true);
    expect(diagnosis.foldBlockReasons.some((r) => /allocation/i.test(r))).toBe(true);
  });

  it("does not mutate the temp run/ on diagnose (and never touches live C-TOKEN)", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { validIds: [1, 2] });
    const before = readdirSync(path.join(bundle, "run")).sort();
    const nanBefore = readFileSync(path.join(bundle, "run", "NaN-T-001-opened.xml"), "utf8");
    recoverCursor(root, "C-RUN");
    expect(readdirSync(path.join(bundle, "run")).sort()).toEqual(before);
    expect(readFileSync(path.join(bundle, "run", "NaN-T-001-opened.xml"), "utf8")).toBe(nanBefore);
  });
});

describe("recover --fix and auto-open (C-CURSOR-INTEGRITY T-005 / P0.6 / D8.2 / D8.3)", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");

  function cliRecoverFix(root: string, changeId = "C-RUN") {
    return Bun.spawnSync({
      cmd: [
        process.execPath,
        "./src/grace.ts",
        "cursor",
        "recover",
        "--change",
        changeId,
        "--fix",
        "--path",
        root,
      ],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
  }

  it("AC-RECOVER-FIX-PRESERVES-ORPHAN: --fix covers valid ids; NaN-* stays on disk and diagnosed; fold succeeds", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { validIds: [1, 2, 3], withTerminal: true });
    const nanPath = path.join(bundle, "run", "NaN-T-001-opened.xml");
    const nanBefore = readFileSync(nanPath, "utf8");

    // Pre-fix diagnosis: missing covering allocation, orphan visible, fold blocked for allocation.
    const pre = recoverCursor(root, "C-RUN");
    expect(pre.coveringAllocation).toBe("missing");
    expect(pre.foldBlocked).toBe(true);
    expect(pre.foldBlockReasons.some((r) => /allocation/i.test(r))).toBe(true);
    expect(pre.orphans.some((o) => o.name === "NaN-T-001-opened.xml")).toBe(true);
    expect(collectAllocationsSafe(bundle)).toHaveLength(0);

    // --fix writes covering allocation for valid integer stream only (A29.2: derived bounds).
    const fixed = recoverCursor(root, "C-RUN", { fix: "extend-allocation" });
    expect(fixed.fixApplied).toBe(true);
    expect(fixed.coveringAllocation).toBe("present");
    expect(fixed.validAllocations.length).toBeGreaterThan(0);
    const cover = fixed.validAllocations[0]!;
    expect(cover.from).toBeLessThanOrEqual(1);
    expect(cover.to).toBeGreaterThanOrEqual(3);

    // D8.3 / F8.1: orphan still on disk with identical bytes.
    expect(existsSync(nanPath)).toBe(true);
    expect(readFileSync(nanPath, "utf8")).toBe(nanBefore);
    // And recover still reports it as unrecoverable orphan (deletion would pass a weaker bar).
    const after = recoverCursor(root, "C-RUN");
    expect(after.orphans.some((o) => o.name === "NaN-T-001-opened.xml" && o.recoverable === false)).toBe(true);
    expect(after.orphans.some((o) => o.class === "event-filename")).toBe(true);

    // Valid stream is foldable; fold must not require the orphan as a member.
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    expect(folded.eventCount).toBeGreaterThanOrEqual(3);
    // Orphan survives fold of the valid stream (fold only deletes listLooseEvents files).
    expect(existsSync(nanPath)).toBe(true);
    expect(readFileSync(nanPath, "utf8")).toBe(nanBefore);
  });

  it("AC-RECOVER-FIX: auto-open on fold also leaves NaN-* orphan on disk (F8.1 single-controller)", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { validIds: [1, 2, 3], withTerminal: true });
    const nanPath = path.join(bundle, "run", "NaN-T-001-opened.xml");
    const nanBefore = readFileSync(nanPath, "utf8");
    // F8.1 is single-controller (worker w0 on the NaN allocation only) → fold auto-opens.
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    expect(existsSync(nanPath)).toBe(true);
    expect(readFileSync(nanPath, "utf8")).toBe(nanBefore);
    expect(listRunOrphans(bundle).some((o) => o.name === "NaN-T-001-opened.xml")).toBe(true);
  });

  it("AC-RECOVER-FIX-PRESERVES-ORPHAN: CLI --fix leaves NaN-* and still diagnoses it", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { validIds: [1, 2], withTerminal: true });
    const nanPath = path.join(bundle, "run", "NaN-T-001-opened.xml");
    const result = cliRecoverFix(root);
    expect(result.exitCode).toBe(0);
    const text = `${Buffer.from(result.stdout).toString("utf8")}\n${Buffer.from(result.stderr).toString("utf8")}`;
    expect(text).toMatch(/Fix applied:\s*yes/i);
    expect(existsSync(nanPath)).toBe(true);
    const again = cliRecoverFix(root); // second call: covering already present, still diagnose
    // Diagnose path (without needing fix) — use library
    const diag = recoverCursor(root, "C-RUN");
    expect(diag.orphans.some((o) => o.name.startsWith("NaN-"))).toBe(true);
    expect(again.exitCode).toBe(0);
  });

  it("AC-AUTO-OPEN-SINGLE-CONTROLLER: fold synthesizes covering opened when single worker", () => {
    const root = createProject();
    // No opened, no NaN — pure loose progress without allocation (single-controller).
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    for (const [id, kind] of [
      [1, "progress"],
      [2, "progress"],
      [3, "terminal"],
    ] as const) {
      writeFileSync(
        path.join(runDir, `${id}-T-001-${kind}.xml`),
        `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="${kind}"/>`,
      );
    }
    // Pre-fix: fold fails without allocation / auto-open.
    // After fix: fold auto-opens single-controller covering allocation and succeeds.
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    expect(folded.eventCount).toBeGreaterThanOrEqual(3);
  });

  it("AC-AUTO-OPEN multi-worker: recover --fix refuses when >1 distinct worker", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    // No valid covering allocation; two worker names appear on broken opened-like files
    // that still contribute worker identity via Allocation attributes.
    writeFileSync(
      path.join(runDir, "NaN-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-001" kind="opened"><Allocation worker="wA" from="NaN" to="NaN"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "NaN-T-002-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-002" kind="opened"><Allocation worker="wB" from="NaN" to="NaN"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "1-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="progress"/>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-001-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="terminal"/>`,
    );
    let threw: Error | undefined;
    try {
      recoverCursor(root, "C-RUN", { fix: "extend-allocation" });
    } catch (error) {
      threw = error as Error;
    }
    expect(threw).toBeDefined();
    expect(threw!.message).toMatch(/multiple workers|multi-worker|explicit epoch/i);
    // Valid stream still unallocated.
    expect(collectAllocationsSafe(bundle).length).toBe(0);
  });

  it("AC-AUTO-OPEN multi-worker: fold refuses auto-open when >1 distinct worker", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "NaN-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-001" kind="opened"><Allocation worker="alpha" from="NaN" to="NaN"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "NaN-T-002-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-002" kind="opened"><Allocation worker="beta" from="NaN" to="NaN"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "1-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="progress"/>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-001-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="terminal"/>`,
    );
    let threw: Error | undefined;
    try {
      foldEpoch(root, "C-RUN");
    } catch (error) {
      threw = error as Error;
    }
    expect(threw).toBeDefined();
    expect(threw!.message).toMatch(/Allocation|multiple workers|multi-worker|explicit/i);
  });
});

/** Test helper: allocations visible to listLooseEvents (valid opened only). */
function collectAllocationsSafe(bundlePath: string) {
  return listLooseEvents(bundlePath).flatMap((e) => e.allocations ?? []);
}

// ---------------------------------------------------------------------------
// C-RECOVER-FOLDABLE T-001 / T-002 / T-003 — F13 effective-range supersession
// ---------------------------------------------------------------------------

/** Live F13 damaged shape (C-TOKEN-INTEGRITY snapshot): dead w0:[1,19], terminal@20, NaN orphan. */
function seedDamagedTokenShape(root: string, changeId = "C-RUN"): string {
  const bundle = seedBundle(root, changeId);
  const runDir = path.join(bundle, "run");
  mkdirSync(runDir, { recursive: true });
  writeFileSync(
    path.join(runDir, "NaN-T-001-opened.xml"),
    `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-001" kind="opened"><Allocation worker="w0" from="NaN" to="NaN" /></NgraceRunEvent>`,
  );
  for (let id = 1; id <= 18; id += 1) {
    writeFileSync(
      path.join(runDir, `${id}-T-001-progress.xml`),
      `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="progress"/>`,
    );
  }
  // Dead covering opened — closed ceiling, no terminal in range (first --fix under F13).
  writeFileSync(
    path.join(runDir, "19-T-005-opened.xml"),
    `<NgraceRunEvent graceVersion="1.0" id="19" task="T-005" kind="opened"><Allocation worker="w0" from="1" to="19" /></NgraceRunEvent>`,
  );
  writeFileSync(
    path.join(runDir, "20-T-005-terminal.xml"),
    `<NgraceRunEvent graceVersion="1.0" id="20" task="T-005" kind="terminal"/>`,
  );
  return bundle;
}

describe("C-RECOVER-FOLDABLE T-001: effective allocation supersession (F13 / D9 / D9.1)", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");

  it("red-first F13: clean no-terminal shape — after --fix + operator terminal, fold was blocked", () => {
    // Pre-fix property: writeCoveringOpened closed at openedId; terminal lands outside.
    // After the product fix this test still documents the sequence and expects fold to succeed.
    const root = createProject();
    const bundle = seedF8Shape(root, { validIds: [1, 2, 3], withTerminal: false });
    const nanPath = path.join(bundle, "run", "NaN-T-001-opened.xml");
    const nanBefore = readFileSync(nanPath, "utf8");
    const beforeFiles = new Map(
      readdirSync(path.join(bundle, "run")).map((name) => [
        name,
        readFileSync(path.join(bundle, "run", name), "utf8"),
      ]),
    );

    const fixed = recoverCursor(root, "C-RUN", { fix: "extend-allocation" });
    expect(fixed.fixApplied).toBe(true);
    // D9: no pre-existing run/* event file rewritten.
    for (const [name, content] of beforeFiles) {
      expect(readFileSync(path.join(bundle, "run", name), "utf8")).toBe(content);
    }
    // --fix must not emit a range-closing kind (A29.2 / F12).
    expect(listLooseEvents(bundle).some((e) => isRangeClosingKind(e.kind))).toBe(false);
    const cover = fixed.validAllocations[0]!;
    expect(cover.from).toBeLessThanOrEqual(1);
    // Ceiling: max(covering requirement, openedId + 98)
    const coveringOpened = listLooseEvents(bundle).find((e) => e.kind === "opened");
    expect(coveringOpened).toBeDefined();
    const openedId = coveringOpened!.id;
    expect(cover.to).toBeGreaterThanOrEqual(openedId + 98);

    // Operator terminal (not --fix).
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    expect(existsSync(nanPath)).toBe(true);
    expect(readFileSync(nanPath, "utf8")).toBe(nanBefore);
    const afterFold = recoverCursor(root, "C-RUN");
    expect(afterFold.orphans.some((o) => o.name === "NaN-T-001-opened.xml" && o.recoverable === false)).toBe(true);
  });

  it("discriminating negative: sole live effective range without terminal still blocks fold", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="99" /></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="progress"/>`,
    );
    // No terminal — live effective range must still require termination.
    expect(() => foldEpoch(root, "C-RUN")).toThrow(/unterminated/i);
  });

  it("D9 / LWW: dead prior allocation is superseded; no rewrite of recorded events", () => {
    const root = createProject();
    const bundle = seedDamagedTokenShape(root);
    const deadPath = path.join(bundle, "run", "19-T-005-opened.xml");
    const deadBefore = readFileSync(deadPath, "utf8");
    const fixed = recoverCursor(root, "C-RUN", { fix: "extend-allocation" });
    expect(fixed.fixApplied).toBe(true);
    expect(readFileSync(deadPath, "utf8")).toBe(deadBefore);
    // Effective set is the latest opened only — covering present, fold not blocked for dead range.
    expect(fixed.coveringAllocation).toBe("present");
    expect(fixed.foldBlocked).toBe(false);
    expect(fixed.validAllocations).toHaveLength(1);
    expect(fixed.validAllocations[0]!.to).toBeGreaterThanOrEqual(20);
    // Raw stream still has two opened allocations on disk.
    expect(collectAllocationsSafe(bundle).length).toBeGreaterThanOrEqual(2);
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
  });

  it("flag honesty: --fix help still says extend-allocation and describes effective extend", () => {
    const result = Bun.spawnSync({
      cmd: [process.execPath, "./src/grace.ts", "cursor", "recover", "--help"],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    const text = `${Buffer.from(result.stdout).toString("utf8")}\n${Buffer.from(result.stderr).toString("utf8")}`;
    expect(result.exitCode).toBe(0);
    expect(text).toMatch(/extend-allocation/i);
    expect(text).toMatch(/effective/i);
    expect(text).toMatch(/append|supersed/i);
  });

  it("auto-open shares writeCoveringOpened headroom (no carve-out)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    for (const [id, kind] of [
      [1, "progress"],
      [2, "progress"],
      [3, "terminal"],
    ] as const) {
      writeFileSync(
        path.join(runDir, `${id}-T-001-${kind}.xml`),
        `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="${kind}"/>`,
      );
    }
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    // Auto-open wrote a covering opened; its ceiling must include openedId+98 headroom.
    // After fold, loose events are gone — inspect ledger Epoch Allocation.
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(ledger).toMatch(/Allocation[^>]*to="10[0-9]"|to="9[0-9]"/);
    // openedId becomes 4 after events 1..3; to >= 4+98 = 102
    expect(ledger).toMatch(/to="102"/);
  });

  it("carried D8.2: multi-worker recover --fix still refuses", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "NaN-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-001" kind="opened"><Allocation worker="wA" from="NaN" to="NaN"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "NaN-T-002-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="NaN" task="T-002" kind="opened"><Allocation worker="wB" from="NaN" to="NaN"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "1-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="progress"/>`,
    );
    expect(() => recoverCursor(root, "C-RUN", { fix: "extend-allocation" })).toThrow(
      /multiple workers|multi-worker|explicit epoch/i,
    );
    expect(collectAllocationsSafe(bundle).length).toBe(0);
  });

  it("carried D8.3: orphan survives --fix and fold on clean path", () => {
    const root = createProject();
    const bundle = seedF8Shape(root, { validIds: [1, 2], withTerminal: false });
    const nanPath = path.join(bundle, "run", "NaN-T-001-opened.xml");
    const nanBefore = readFileSync(nanPath, "utf8");
    recoverCursor(root, "C-RUN", { fix: "extend-allocation" });
    expect(existsSync(nanPath)).toBe(true);
    expect(recoverCursor(root, "C-RUN").orphans.some((o) => o.name.startsWith("NaN-"))).toBe(true);
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    foldEpoch(root, "C-RUN");
    expect(existsSync(nanPath)).toBe(true);
    expect(readFileSync(nanPath, "utf8")).toBe(nanBefore);
    expect(listRunOrphans(bundle).some((o) => o.name === "NaN-T-001-opened.xml")).toBe(true);
  });
});

describe("C-RECOVER-FOLDABLE T-002: damaged-shape repair", () => {
  it("red-first then green: dead w0:[1,19] + terminal@20 + NaN orphan folds after --fix", () => {
    const root = createProject();
    const bundle = seedDamagedTokenShape(root);
    const nanPath = path.join(bundle, "run", "NaN-T-001-opened.xml");
    const nanBefore = readFileSync(nanPath, "utf8");
    const deadBefore = readFileSync(path.join(bundle, "run", "19-T-005-opened.xml"), "utf8");

    const pre = recoverCursor(root, "C-RUN");
    expect(pre.foldBlocked).toBe(true);
    expect(pre.coveringAllocation).toBe("missing");
    expect(pre.foldBlockReasons.some((r) => /outside|unterminated/i.test(r))).toBe(true);
    expect(pre.orphans.some((o) => o.name === "NaN-T-001-opened.xml")).toBe(true);
    expect(() => foldEpoch(root, "C-RUN")).toThrow(/outside|unterminated|Allocation/i);

    const fixed = recoverCursor(root, "C-RUN", { fix: "extend-allocation" });
    expect(fixed.fixApplied).toBe(true);
    // D9: dead opened file unchanged; --fix did not rewrite it and did not emit another terminal.
    expect(readFileSync(path.join(bundle, "run", "19-T-005-opened.xml"), "utf8")).toBe(deadBefore);
    const terminals = listLooseEvents(bundle).filter((e) => e.kind === "terminal");
    expect(terminals).toHaveLength(1);
    expect(terminals[0]!.id).toBe(20);
    expect(listLooseEvents(bundle).some((e) => e.kind === "discarded")).toBe(false);
    expect(fixed.coveringAllocation).toBe("present");
    expect(fixed.foldBlocked).toBe(false);
    const cover = fixed.validAllocations[0]!;
    const newOpened = listLooseEvents(bundle).filter((e) => e.kind === "opened").sort((a, b) => b.id - a.id)[0]!;
    expect(cover.to).toBeGreaterThanOrEqual(Math.max(20, newOpened.id + 98));
    expect(existsSync(nanPath)).toBe(true);
    expect(recoverCursor(root, "C-RUN").orphans.some((o) => o.name === "NaN-T-001-opened.xml")).toBe(true);

    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    expect(existsSync(nanPath)).toBe(true);
    expect(readFileSync(nanPath, "utf8")).toBe(nanBefore);
    expect(listRunOrphans(bundle).some((o) => o.name === "NaN-T-001-opened.xml" && o.recoverable === false)).toBe(
      true,
    );
  });
});

describe("C-RECOVER-FOLDABLE T-003: clean no-terminal E2E (no withTerminal pre-seed)", () => {
  it("clean shape: --fix → operator terminal (with intervening progress) → fold; orphan survives", () => {
    const root = createProject();
    // Explicitly no terminal anywhere — withTerminal must not be used to satisfy this path.
    const bundle = seedF8Shape(root, { validIds: [1, 2, 3], withTerminal: false });
    expect(listLooseEvents(bundle).some((e) => isRangeClosingKind(e.kind))).toBe(false);
    const nanPath = path.join(bundle, "run", "NaN-T-001-opened.xml");
    const nanBefore = readFileSync(nanPath, "utf8");

    recoverCursor(root, "C-RUN", { fix: "extend-allocation" });
    expect(listLooseEvents(bundle).some((e) => isRangeClosingKind(e.kind))).toBe(false);
    // Intervening work within headroom, then operator terminal.
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "progress" });
    advanceCursor(root, "C-RUN", { task: "T-001", kind: "terminal" });
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    expect(existsSync(nanPath)).toBe(true);
    expect(readFileSync(nanPath, "utf8")).toBe(nanBefore);
    expect(listRunOrphans(bundle).some((o) => o.name === "NaN-T-001-opened.xml")).toBe(true);
  });

  it("regression bar: neither clean nor damaged path pre-seeds terminal inside pre-fix range", () => {
    // Clean path uses withTerminal: false; damaged path places terminal outside dead [1,19].
    const rootClean = createProject();
    const clean = seedF8Shape(rootClean, { validIds: [1, 2, 3], withTerminal: false });
    expect(listLooseEvents(clean).every((e) => !isRangeClosingKind(e.kind))).toBe(true);

    const rootDamaged = createProject();
    const damaged = seedDamagedTokenShape(rootDamaged);
    const preFixTerminals = listLooseEvents(damaged).filter((e) => e.kind === "terminal");
    expect(preFixTerminals).toHaveLength(1);
    expect(preFixTerminals[0]!.id).toBe(20);
    // Terminal is outside the dead allocation [1,19] — not a withTerminal-inside-range seed.
    const dead = listLooseEvents(damaged).find((e) => e.id === 19);
    expect(dead?.allocations?.[0]).toEqual({ worker: "w0", from: 1, to: 19 });
    expect(preFixTerminals[0]!.id).toBeGreaterThan(19);
  });
});

describe("C-CALIBRATION-COMMAND-EVIDENCE T-002: fold joins command-run evidence", () => {
  const DEFAULT_WRITE_EVIDENCE: WriteEvidenceSnapshot = {
    available: true,
    files: [{ path: "src/example.ts", kind: "content", digest: "a".repeat(64) }],
  };

  /** Adjudication outcome only — attempt events also carry outcome= attributes. */
  function adjudicationOutcome(ledger: string): string | undefined {
    return ledger.match(/<CalibrationAdjudication\b[^>]*\boutcome="([^"]+)"/)?.[1];
  }

  function adjudicationBlock(ledger: string): string {
    return ledger.match(/<CalibrationAdjudication\b[^/]*\/>/)?.[0]
      ?? ledger.match(/<CalibrationAdjudication\b[\s\S]*?<\/CalibrationAdjudication>/)?.[0]
      ?? "";
  }

  function seedCalBundle(
    root: string,
    changeId: string,
    command: string,
  ): string {
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId,
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
      planTargetAssertions:
        `<MustExist><Value>src/example.ts</Value></MustExist>`
        + `<MustPassCommand><Command>${command}</Command></MustPassCommand>`,
    });
    return path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
  }

  function openClaimAndTerminal(root: string, changeId: string): void {
    advanceCursor(root, changeId, { task: "T-001", openEpoch: true });
    recordAttempt(root, changeId, {
      task: "T-001",
      outcome: "pass",
      claimedConfidence: "medium",
      writeEvidence: DEFAULT_WRITE_EVIDENCE,
    });
  }

  it("red-first: planted matching command-run evidence is joined at fold → pass (pre-fix ignored records → pending)", () => {
    const root = createProject();
    const changeId = "C-JOIN-PASS";
    // Use a non-existent shell command so fold-time spawn (if any) cannot invent a pass.
    const command = "ngrace-command-run-evidence-marker-xyzzy-never-spawn";
    seedCalBundle(root, changeId, command);
    openClaimAndTerminal(root, changeId);
    appendCommandRunEvent(root, changeId, {
      command,
      exitCode: 0,
      assertionPassed: true,
      assertionKind: "MustPassCommand",
      source: "lint-run-commands",
    });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    foldEpoch(root, changeId);

    const ledger = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml"),
      "utf8",
    );
    expect(ledger).toContain("CalibrationAdjudication");
    expect(adjudicationBlock(ledger)).toContain('adjudicatedAt="fold"');
    // Pre-fix: evaluateTargetComplete(runCommands:false) stored pending and ignored records.
    // After join: matching assertionPassed=true evidence → pass.
    expect(adjudicationOutcome(ledger)).toBe("pass");
  });

  it("matching assertionPassed=false evidence → fold stores fail", () => {
    const root = createProject();
    const changeId = "C-JOIN-FAIL";
    const command = "exit 0";
    seedCalBundle(root, changeId, command);
    openClaimAndTerminal(root, changeId);
    appendCommandRunEvent(root, changeId, {
      command,
      exitCode: 1,
      assertionPassed: false,
      assertionKind: "MustPassCommand",
      source: "lint-run-commands",
    });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    foldEpoch(root, changeId);

    const ledger = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml"),
      "utf8",
    );
    expect(adjudicationOutcome(ledger)).toBe("fail");
    expect(adjudicationBlock(ledger)).toContain('adjudicatedAt="fold"');
  });

  it("no matching recorded evidence → pending with reason naming absent recorded evidence", () => {
    const root = createProject();
    const changeId = "C-JOIN-ABSENT";
    seedCalBundle(root, changeId, "exit 0");
    openClaimAndTerminal(root, changeId);
    // No command-run planted.
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    foldEpoch(root, changeId);

    const ledger = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml"),
      "utf8",
    );
    expect(adjudicationOutcome(ledger)).toBe("pending");
    expect(adjudicationBlock(ledger)).toMatch(/absent recorded evidence/i);
    expect(adjudicationBlock(ledger)).toContain('adjudicatedAt="fold"');
  });

  it("match-key edit: evidence for A does not cover plan command B → pending; re-record B → pass", () => {
    const root = createProject();
    const changeId = "C-JOIN-EDIT";
    const commandA = "exit 0";
    const commandB = "true";
    seedCalBundle(root, changeId, commandA);
    openClaimAndTerminal(root, changeId);
    appendCommandRunEvent(root, changeId, {
      command: commandA,
      exitCode: 0,
      assertionPassed: true,
      assertionKind: "MustPassCommand",
      source: "lint-run-commands",
    });
    // Edit plan command A → B without new evidence.
    writeChangeBundleFixture(root, {
      changeId,
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
      planTargetAssertions:
        `<MustExist><Value>src/example.ts</Value></MustExist>`
        + `<MustPassCommand><Command>${commandB}</Command></MustPassCommand>`,
    });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    foldEpoch(root, changeId);

    const ledger1 = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml"),
      "utf8",
    );
    expect(adjudicationOutcome(ledger1)).toBe("pending");
    expect(adjudicationBlock(ledger1)).toMatch(/absent recorded evidence/i);

    // Recovery: open new epoch covering post-fold ids (default from=1 would hole).
    const bundlePath = path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
    const maxFolded = listLedgerEvents(bundlePath).reduce((m, e) => Math.max(m, e.id), 0);
    const from = maxFolded + 1;
    advanceCursor(root, changeId, {
      task: "T-001",
      openEpoch: true,
      from,
      to: from + 98,
    });
    recordAttempt(root, changeId, {
      task: "T-001",
      outcome: "pass",
      claimedConfidence: "high",
      writeEvidence: DEFAULT_WRITE_EVIDENCE,
    });
    appendCommandRunEvent(root, changeId, {
      command: commandB,
      exitCode: 0,
      assertionPassed: true,
      assertionKind: "MustPassCommand",
      source: "lint-run-commands",
    });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    foldEpoch(root, changeId);

    const ledger2 = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml"),
      "utf8",
    );
    // Both epochs present: first pending, second pass (append-only).
    const outcomes = [...ledger2.matchAll(/<CalibrationAdjudication\b[^>]*\boutcome="([^"]+)"/g)].map(
      (m) => m[1],
    );
    expect(outcomes).toEqual(["pending", "pass"]);
  });

  it("D6.6: fold never spawns — non-existent command with planted pass evidence still folds pass", () => {
    const root = createProject();
    const changeId = "C-JOIN-NOSPAWN";
    const command = "definitely-not-a-real-binary-for-fold-join-test-$$";
    seedCalBundle(root, changeId, command);
    openClaimAndTerminal(root, changeId);
    appendCommandRunEvent(root, changeId, {
      command,
      exitCode: 0,
      assertionPassed: true,
      assertionKind: "MustPassCommand",
      source: "lint-run-commands",
    });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    // If fold spawned this command it would fail (non-zero). Join-only must pass.
    foldEpoch(root, changeId);
    const ledger = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml"),
      "utf8",
    );
    expect(adjudicationOutcome(ledger)).toBe("pass");
  });

  it("AC-D65: fold still writes CalibrationAdjudication when claimedConfidence exists", () => {
    const root = createProject();
    const changeId = "C-JOIN-D65";
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId,
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
      planTargetAssertions: `<MustExist><Value>src/example.ts</Value></MustExist>`,
    });
    openClaimAndTerminal(root, changeId);
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    foldEpoch(root, changeId);
    const ledger = readFileSync(
      path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run-ledger.xml"),
      "utf8",
    );
    expect(ledger).toContain("CalibrationAdjudication");
    expect(adjudicationBlock(ledger)).toContain('adjudicatedAt="fold"');
    expect(adjudicationOutcome(ledger)).toBe("pass");
  });

  it("kind=command-run is registered so cursor state does not degrade", () => {
    const resolved = cursorStateForEventKind("command-run");
    expect("state" in resolved).toBe(true);
    if ("state" in resolved) {
      expect(resolved.state).toBe("in-progress");
    }
  });
});

/**
 * Collect `<kind id="…">` values that are children of a `<cursor_kinds>` block.
 * Kinds outside the block do not count (AC-KIND-COMPLETENESS-TIED-TO-CODE).
 * Incidental English, backticks, or headings without that element do not match.
 */
function parseSkillCursorKindIds(skillMarkdown: string): string[] {
  const blockMatch = skillMarkdown.match(/<cursor_kinds>([\s\S]*?)<\/cursor_kinds>/);
  if (!blockMatch) return [];
  const ids: string[] = [];
  for (const match of blockMatch[1].matchAll(/<kind\s+id="([^"]+)"\s*>/g)) {
    ids.push(match[1]!);
  }
  return ids;
}

// ---------------------------------------------------------------------------
// C-ESCALATION-HONESTY T-003 — skill prose agrees with live threshold constants
// ---------------------------------------------------------------------------

/**
 * Stale attempt-count budget claims (F21). Any match means the skill still
 * teaches "any two fails exhaust the budget" (or "after the second fail")
 * instead of triggers R/D. One sweep covers the four measured sites and any
 * fifth residual of the same family — not four hand-written exact strings
 * that TargetAssertions MustNotContain only partially cover.
 *
 * Sites measured at plan-authoring:
 *   rule 5            "Two failed attempts exhaust the fix budget…"
 *   attempt Meaning   "Two failed attempts exhaust the budget…"
 *   escalation When   "two failed attempts have exhausted…"
 *   escalation How    "…after the second failed attempt"
 */
const STALE_ATTEMPT_COUNT_BUDGET_CLAIM =
  /two failed attempts exhaust|two failed attempts have exhausted|second failed attempt|failed attempts exhaust the (?:fix )?budget/i;

const NGRACE_EXECUTE_SKILL_PATHS = [
  "skills/ngrace/ngrace-execute/SKILL.md",
  "plugins/ngrace/skills/ngrace/ngrace-execute/SKILL.md",
] as const;

describe("fix-budget skill prose agrees with constants (C-ESCALATION-HONESTY T-003 / AC-PROSE-ENFORCEMENT-AGREE)", () => {
  /**
   * Bidirectional agreement (both skill trees):
   * - Mutate FIX_DISTINCT_SIGNATURE_BUDGET (or REPEAT or FIX_ESCALATION_CEILING)
   *   without skill → required substring becomes e.g. "5 distinct failing
   *   signatures" or "3 escalations per task" → skill still has the old digits →
   *   toContain fails (code→skill direction).
   * - Mutate a skill sentence (drop "4 distinct failing signatures", drop
   *   "2 escalations per task", or restore a stale attempt-count claim) while
   *   constants stay → toContain / stale sweep fails (skill→code direction).
   * - Edit only canonical → packaged fails its loop iteration; parity also fails
   *   validate-marketplace (AC-SKILL-MIRROR-IDENTICAL is separate).
   * Kind-set completeness alone does not satisfy this AC (C-EXECUTION-CONTRACT trap).
   */
  it("both skill trees contain live threshold substrings and no stale attempt-count claim", () => {
    const repoRoot = path.resolve(import.meta.dir, "..");
    const required = fixBudgetSkillRequiredSubstrings();
    // Pins the helper shape the skill must match (digits mid-sentence, not English words).
    expect([...required]).toEqual([
      `${FIX_SIGNATURE_REPEAT_BUDGET} failed attempts of the same signature`,
      `${FIX_DISTINCT_SIGNATURE_BUDGET} distinct failing signatures`,
      `${FIX_ESCALATION_CEILING} escalations per task`,
    ]);

    for (const rel of NGRACE_EXECUTE_SKILL_PATHS) {
      const text = readFileSync(path.join(repoRoot, rel), "utf8");
      for (const sub of required) {
        expect({ path: rel, missing: sub, present: text.includes(sub) }).toEqual({
          path: rel,
          missing: sub,
          present: true,
        });
      }
      // Plan TargetAssertions MustNotContain only the rule-5 sentence; this
      // sweep also catches attempt Meaning / escalation When / How residues.
      const stale = STALE_ATTEMPT_COUNT_BUDGET_CLAIM.exec(text);
      expect({ path: rel, staleMatch: stale?.[0] ?? null }).toEqual({
        path: rel,
        staleMatch: null,
      });
    }
  });

  it("both skill trees document escalation-clearing resume requires --reason; ordinary resume does not", () => {
    // T-002 contract surface: F22 replan reason on escalation clear only.
    // Co-occurrence (not bare toContain): "--reason" alone matches verification-unavailable
    // and rule 5; "cursor resume" alone matches the pre-T-002 How form that T-002 refuses.
    // The claim is that each documented resume entry path's command form itself carries
    // --reason. A full-literal pin of the entire command would also catch a stripped flag
    // but would redden on a harmless placeholder rename (C-ID → CHANGE-ID).
    const resumeCmdHasReason = /ngrace cursor resume\b[^`\n]*--reason/;
    const advanceResumeCmdHasReason = /ngrace cursor advance\b[^`\n]*--kind resume[^`\n]*--reason/;
    const repoRoot = path.resolve(import.meta.dir, "..");
    for (const rel of NGRACE_EXECUTE_SKILL_PATHS) {
      const text = readFileSync(path.join(repoRoot, rel), "utf8");
      expect({
        path: rel,
        resumeCmdHasReason: resumeCmdHasReason.test(text),
        advanceResumeCmdHasReason: advanceResumeCmdHasReason.test(text),
      }).toEqual({
        path: rel,
        resumeCmdHasReason: true,
        advanceResumeCmdHasReason: true,
      });
      // Ordinary non-clearing resume must remain allowed without reason.
      expect(text).toMatch(/ordinary resume|does not clear an escalation/i);
      expect(text).toMatch(/without `--reason`|without --reason/i);
    }
  });

  it("canonical and packaged ngrace-execute skill bodies are byte-identical", () => {
    // AC-SKILL-MIRROR-IDENTICAL — same check validate-marketplace uses directionally.
    const repoRoot = path.resolve(import.meta.dir, "..");
    const a = readFileSync(path.join(repoRoot, NGRACE_EXECUTE_SKILL_PATHS[0]));
    const b = readFileSync(path.join(repoRoot, NGRACE_EXECUTE_SKILL_PATHS[1]));
    expect(Buffer.compare(a, b)).toBe(0);
  });
});

describe("KNOWN_EVENT_KINDS export and ngrace-execute completeness (C-EXECUTION-CONTRACT)", () => {
  it("exports a frozen list definitionally tied to KNOWN_KIND_STATE keys", () => {
    // Import-only: does not parse grace-cursor.ts source (F10 / AC-EXPORT-MINIMAL).
    expect(Object.isFrozen(KNOWN_EVENT_KINDS)).toBe(true);
    expect(KNOWN_EVENT_KINDS.length).toBeGreaterThan(0);
    const seen = new Set<string>();
    for (const kind of KNOWN_EVENT_KINDS) {
      expect(seen.has(kind)).toBe(false);
      seen.add(kind);
      const resolved = cursorStateForEventKind(kind);
      expect("state" in resolved).toBe(true);
    }
    // Denominator is the export alone — currently 11 keys of KNOWN_KIND_STATE.
    expect(KNOWN_EVENT_KINDS.length).toBe(11);
    expect([...KNOWN_EVENT_KINDS]).toEqual([
      "opened",
      "progress",
      "resume",
      "attempt",
      "verification-unavailable",
      "command-run",
      "pause",
      "terminal",
      "escalation",
      "discarded",
      "circuit",
    ]);
    expect(cursorStateForEventKind("discarded")).toEqual({ state: "discarded" });
    expect(cursorStateForEventKind("circuit")).toEqual({ state: "paused-pending-supersede" });
  });

  it("every RANGE_CLOSING_KINDS member is a known event kind", () => {
    for (const kind of RANGE_CLOSING_KINDS) {
      expect(KNOWN_EVENT_KINDS).toContain(kind);
    }
  });

  it("ngrace-execute documents every exported kind with a structural <kind id> marker", () => {
    // Sole denominator: imported KNOWN_EVENT_KINDS (not a fixed string list, not a source parse).
    // Adding a tenth key to KNOWN_KIND_STATE without a skill marker fails this suite.
    // A check that only greps for "terminal" or parses grace-cursor.ts would fail AC-KIND-COMPLETENESS-TIED-TO-CODE.
    const repoRoot = path.resolve(import.meta.dir, "..");
    const skillPath = path.join(repoRoot, "skills/ngrace/ngrace-execute/SKILL.md");
    const skill = readFileSync(skillPath, "utf8");
    const documented = parseSkillCursorKindIds(skill);
    const documentedSet = new Set(documented);
    const missing = KNOWN_EVENT_KINDS.filter((kind) => !documentedSet.has(kind));
    const exportSet = new Set<string>(KNOWN_EVENT_KINDS);
    const extras = documented.filter((id) => !exportSet.has(id));
    const duplicateIds = documented.filter((id, index) => documented.indexOf(id) !== index);

    // F12.2: report missing count and missing kind ids — not a bare expect(false).
    expect({
      missingCount: missing.length,
      missing,
      denominator: KNOWN_EVENT_KINDS.length,
      extras,
      duplicateIds,
    }).toEqual({
      missingCount: 0,
      missing: [],
      denominator: KNOWN_EVENT_KINDS.length,
      extras: [],
      duplicateIds: [],
    });

    for (const kind of KNOWN_EVENT_KINDS) {
      expect(documented.filter((id) => id === kind)).toHaveLength(1);
    }
  });
});

describe("C-REWORK-CIRCUIT T-001 — ceiling trips on second breaker fire", () => {
  const A = { kind: "k", key: "a" };
  const B = { kind: "k", key: "b" };
  const C = { kind: "k", key: "c" };
  const D = { kind: "k", key: "d" };
  const E = { kind: "k", key: "e" };
  const F = { kind: "k", key: "f" };
  const G = { kind: "k", key: "g" };
  const H = { kind: "k", key: "h" };

  function failSig(
    root: string,
    signature: { kind: string; key: string },
    task = "T-001",
  ) {
    return recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature,
      writeEvidence: evidencePaths([]),
    });
  }

  function classKinds(bundle: string, task = "T-001") {
    return listAccountingEvents(bundle)
      .filter((event) => event.task === task && (event.kind === "escalation" || event.kind === "circuit"))
      .map((event) => event.kind);
  }

  function artifactStatus(file: string): string | undefined {
    return readFileSync(file, "utf8").match(/\bstatus="([^"]+)"/)?.[1];
  }

  it("fail(A), fail(A), resume, fail(A) does not escalate or circuit (F9.8); second fail(A) writes circuit", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    expect(failSig(root, A).escalated).toBe(false);
    const first = failSig(root, A);
    expect(first.escalated).toBe(true);
    expect(first.trigger).toBe("R");
    expect(first.position.state).toBe("paused-pending-approval");
    expect(classKinds(bundle)).toEqual(["escalation"]);

    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: new approach after first R" });
    const redFirst = failSig(root, A);
    expect(redFirst.escalated).toBe(false);
    expect(redFirst.position.state).not.toBe("paused-pending-supersede");
    expect(classKinds(bundle)).toEqual(["escalation"]);

    const specBefore = readFileSync(path.join(bundle, "spec.xml"), "utf8");
    const planBefore = readFileSync(path.join(bundle, "plan.xml"), "utf8");
    const statusBefore = {
      spec: artifactStatus(path.join(bundle, "spec.xml")),
      plan: artifactStatus(path.join(bundle, "plan.xml")),
    };
    expect(statusBefore).toEqual({ spec: "approved", plan: "approved" });

    const tripped = failSig(root, A);
    expect(tripped.escalated).toBe(false);
    expect(tripped.trigger).toBe("R");
    expect(tripped.position.state).toBe("paused-pending-supersede");
    expect(classKinds(bundle)).toEqual(["escalation", "circuit"]);
    expect(tripped.message).toContain("paused-pending-supersede");
    expect(tripped.message).not.toMatch(/task failed/i);
    expect(readFileSync(path.join(bundle, "run.xml"), "utf8")).not.toContain("CircuitTrippedTask");
    expect(artifactStatus(path.join(bundle, "spec.xml"))).toBe(statusBefore.spec);
    expect(artifactStatus(path.join(bundle, "plan.xml"))).toBe(statusBefore.plan);
    expect(readFileSync(path.join(bundle, "spec.xml"), "utf8")).toBe(specBefore);
    expect(readFileSync(path.join(bundle, "plan.xml"), "utf8")).toBe(planBefore);
    expect(readFileSync(path.join(bundle, "spec.xml"), "utf8")).not.toContain("Replacement");
    expect(readFileSync(path.join(bundle, "plan.xml"), "utf8")).not.toContain("Replacement");
  });

  it("second-window D with new keys writes circuit; first D stays escalation", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    failSig(root, B);
    failSig(root, C);
    const firstD = failSig(root, D);
    expect(firstD.escalated).toBe(true);
    expect(firstD.trigger).toBe("D");
    expect(firstD.position.state).toBe("paused-pending-approval");
    expect(classKinds(bundle)).toEqual(["escalation"]);

    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: after D" });
    failSig(root, E);
    failSig(root, F);
    failSig(root, G);
    const secondD = failSig(root, H);
    expect(secondD.escalated).toBe(false);
    expect(secondD.trigger).toBe("D");
    expect(secondD.position.state).toBe("paused-pending-supersede");
    expect(classKinds(bundle)).toEqual(["escalation", "circuit"]);
  });

  it("fail(A)×2, resume, fail(B)×2 writes circuit (second in-window R, different signature)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    failSig(root, A);
    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: switch signature" });
    failSig(root, B);
    const tripped = failSig(root, B);
    expect(tripped.escalated).toBe(false);
    expect(tripped.trigger).toBe("R");
    expect(tripped.position.state).toBe("paused-pending-supersede");
    expect(classKinds(bundle)).toEqual(["escalation", "circuit"]);
  });

  it("verification-unavailable ×2 does not trip the circuit", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "first skip" },
    });
    recordVerificationUnavailable(root, "C-RUN", {
      task: "T-001",
      absence: { verdict: "not-run", reason: "second skip" },
    });
    expect(showCursor(root, "C-RUN").state).not.toBe("paused-pending-supersede");
    expect(classKinds(bundle)).toEqual([]);
  });

  it("circuit is reserved on advanceCursor and is not a range closer", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    const before = readdirSync(path.join(bundle, "run")).sort();
    let caught: unknown;
    try {
      advanceCursor(root, "C-RUN", { task: "T-001", kind: "circuit" });
    } catch (error) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(GraceCommandError);
    expect((caught as GraceCommandError).code).toBe("invalid-arguments");
    expect((caught as GraceCommandError).message).toMatch(/reserved/);
    expect((caught as GraceCommandError).message).toMatch(/circuit/);
    expect(readdirSync(path.join(bundle, "run")).sort()).toEqual(before);
    expect(RANGE_CLOSING_KINDS).not.toContain("circuit");
  });

  it("unrecognized kinds still do not resolve to in-progress", () => {
    const mapped = cursorStateForEventKind("not-a-real-kind");
    expect("unknown" in mapped).toBe(true);
    expect("state" in mapped ? mapped.state : undefined).not.toBe("in-progress");
  });

  it("listUnresolvedCircuitTrippedTasks adds on circuit and never removes on resume", () => {
    const events = [
      { id: 1, kind: "escalation", task: "T-001" },
      { id: 2, kind: "resume", task: "T-001" },
      { id: 3, kind: "circuit", task: "T-001" },
      { id: 4, kind: "resume", task: "T-001" },
      { id: 5, kind: "circuit", task: "T-002" },
    ];
    expect(listUnresolvedCircuitTrippedTasks(events)).toEqual(["T-001", "T-002"]);
    expect(listUnresolvedEscalatedTasks(events)).toEqual([]);
  });

  it("deriveStateFromEvents: circuit takes precedence over paused-pending-approval", () => {
    expect(
      deriveStateFromEvents([
        { id: 1, kind: "circuit", task: "T-001" },
        { id: 2, kind: "escalation", task: "T-002" },
      ]),
    ).toEqual({ state: "paused-pending-supersede" });
    expect(
      deriveStateFromEvents([
        { id: 1, kind: "escalation", task: "T-002" },
      ]),
    ).toEqual({ state: "paused-pending-approval" });
  });

  it("fail(A,B,C,D) still writes ordinary escalation, not circuit", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    failSig(root, B);
    failSig(root, C);
    const fourth = failSig(root, D);
    expect(fourth.escalated).toBe(true);
    expect(fourth.circuit).toBe(false);
    expect(fourth.trigger).toBe("D");
    expect(fourth.position.state).toBe("paused-pending-approval");
    expect(classKinds(bundle)).toEqual(["escalation"]);
    expect(fourth.message).toMatch(/has not failed|decision owed/i);
  });

  it("reason-bearing resume after first R returns in-progress and opens a new window", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failSig(root, A);
    failSig(root, A);
    const resumed = resumeCursor(root, "C-RUN", "T-001", { reason: "replan: first checkpoint" });
    expect(resumed.state).toBe("in-progress");
    expect(resumed.escalatedTasks).toEqual([]);
    expect(resumed.circuitTrippedTasks).toEqual([]);
  });
});

describe("C-REWORK-CIRCUIT T-003 — resume refuses circuit; per-task grain", () => {
  const A = { kind: "k", key: "a" };
  const repoRoot = path.resolve(import.meta.dir, "..");

  function failSig(
    root: string,
    signature: { kind: string; key: string },
    task = "T-001",
    changeId = "C-RUN",
  ) {
    return recordAttempt(root, changeId, {
      task,
      outcome: "fail",
      signature,
      writeEvidence: evidencePaths([]),
    });
  }

  function tripCircuit(root: string, task = "T-001") {
    advanceCursor(root, "C-RUN", { task, openEpoch: true, from: 1, to: 99 });
    failSig(root, A, task);
    failSig(root, A, task);
    resumeCursor(root, "C-RUN", task, { reason: "replan: after first R" });
    failSig(root, A, task);
    const tripped = failSig(root, A, task);
    expect(tripped.circuit).toBe(true);
    return tripped;
  }

  function cliResume(root: string, extra: string[] = []) {
    return Bun.spawnSync({
      cmd: [
        process.execPath,
        "./src/grace.ts",
        "cursor",
        "resume",
        "--change",
        "C-RUN",
        "--task",
        "T-001",
        "--path",
        root,
        ...extra,
      ],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
  }

  function cliAdvanceResume(root: string, extra: string[] = []) {
    return Bun.spawnSync({
      cmd: [
        process.execPath,
        "./src/grace.ts",
        "cursor",
        "advance",
        "--kind",
        "resume",
        "--change",
        "C-RUN",
        "--task",
        "T-001",
        "--path",
        root,
        ...extra,
      ],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
  }

  it("resumeCursor and advance --kind resume refuse circuit before write", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    tripCircuit(root);
    const specBefore = readFileSync(path.join(bundle, "spec.xml"), "utf8");
    const planBefore = readFileSync(path.join(bundle, "plan.xml"), "utf8");
    const beforeKinds = listLooseEvents(bundle).map((event) => event.kind);
    const beforeIds = listLooseEvents(bundle).map((event) => event.id);

    let caught: unknown;
    try {
      resumeCursor(root, "C-RUN", "T-001", { reason: "should not clear circuit" });
    } catch (error) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(GraceCommandError);
    expect((caught as GraceCommandError).code).toBe("invalid-arguments");
    expect((caught as GraceCommandError).message).toMatch(/paused-pending-supersede/);
    expect((caught as GraceCommandError).message).toMatch(/supersede/);
    expect((caught as GraceCommandError).message).not.toMatch(/--reason/);

    let caughtAdvance: unknown;
    try {
      advanceCursor(root, "C-RUN", { task: "T-001", kind: "resume", reason: "should not clear circuit" });
    } catch (error) {
      caughtAdvance = error;
    }
    expect(caughtAdvance).toBeInstanceOf(GraceCommandError);
    expect((caughtAdvance as GraceCommandError).code).toBe("invalid-arguments");
    expect((caughtAdvance as GraceCommandError).message).toMatch(/paused-pending-supersede/);
    expect((caughtAdvance as GraceCommandError).message).toMatch(/supersede/);
    expect((caughtAdvance as GraceCommandError).message).not.toMatch(/--reason/);

    expect(listLooseEvents(bundle).map((event) => event.id)).toEqual(beforeIds);
    expect(listLooseEvents(bundle).some((event) => event.kind === "resume" && !beforeKinds.includes("resume") && event.id > Math.max(...beforeIds))).toBe(false);
    expect(listLooseEvents(bundle).filter((event) => event.kind === "resume")).toHaveLength(
      beforeKinds.filter((kind) => kind === "resume").length,
    );
    expect(listUnresolvedCircuitTrippedTasks(listAccountingEvents(bundle))).toEqual(["T-001"]);
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-supersede");
    expect(readFileSync(path.join(bundle, "spec.xml"), "utf8")).toBe(specBefore);
    expect(readFileSync(path.join(bundle, "plan.xml"), "utf8")).toBe(planBefore);
  });

  it("real CLI resume and advance --kind resume refuse a circuit-tripped task", () => {
    const root = createProject();
    seedBundle(root);
    tripCircuit(root);
    const viaResume = cliResume(root, ["--reason", "should not continue"]);
    expect(viaResume.exitCode).not.toBe(0);
    const resumeErr = `${new TextDecoder().decode(viaResume.stdout)}${new TextDecoder().decode(viaResume.stderr)}`;
    expect(resumeErr).toMatch(/paused-pending-supersede/);
    expect(resumeErr).toMatch(/supersede/);
    expect(resumeErr).not.toMatch(/pass a reason|pass --reason/i);

    const viaAdvance = cliAdvanceResume(root, ["--reason", "should not continue"]);
    expect(viaAdvance.exitCode).not.toBe(0);
    const advanceErr = `${new TextDecoder().decode(viaAdvance.stdout)}${new TextDecoder().decode(viaAdvance.stderr)}`;
    expect(advanceErr).toMatch(/paused-pending-supersede/);
    expect(advanceErr).toMatch(/supersede/);
  });

  it("ordinary pause/resume and escalation-clearing resume stay green; circuit is per task", () => {
    const root = createProject();
    seedBundle(root);
    tripCircuit(root, "T-001");
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-supersede");

    const siblingFail = failSig(root, A, "T-002");
    expect(siblingFail.escalated).toBe(false);
    expect(siblingFail.circuit).toBe(false);
    const siblingEsc = failSig(root, A, "T-002");
    expect(siblingEsc.escalated).toBe(true);
    expect(siblingEsc.position.state).toBe("paused-pending-supersede");
    const siblingResume = resumeCursor(root, "C-RUN", "T-002", { reason: "replan: T-002 own window" });
    expect(siblingResume.escalatedTasks).toEqual([]);
    expect(siblingResume.circuitTrippedTasks).toEqual(["T-001"]);
    expect(showCursor(root, "C-RUN").state).toBe("paused-pending-supersede");
    expect(failSig(root, { kind: "k", key: "z" }, "T-002").escalated).toBe(false);

    const ordinary = createProject();
    seedBundle(ordinary);
    advanceCursor(ordinary, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    pauseCursor(ordinary, "C-RUN", "T-001");
    const resumed = resumeCursor(ordinary, "C-RUN", "T-001");
    expect(resumed.state).toBe("in-progress");
  });
});

describe("C-REWORK-CIRCUIT T-004 — churn is payload, never a trip predicate", () => {
  const A = { kind: "k", key: "a" };
  const B = { kind: "k", key: "b" };
  const C = { kind: "k", key: "c" };
  const D = { kind: "k", key: "d" };
  const E = { kind: "k", key: "e" };
  const F = { kind: "k", key: "f" };
  const G = { kind: "k", key: "g" };
  const H = { kind: "k", key: "h" };

  function failWith(
    root: string,
    signature: { kind: string; key: string },
    files: string[],
    digests?: Record<string, string>,
    task = "T-001",
  ) {
    return recordAttempt(root, "C-RUN", {
      task,
      outcome: "fail",
      signature,
      writeEvidence: evidencePaths(files, digests),
    });
  }

  it("ordinary first R lists this-window churn paths and rewrite counts", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failWith(root, A, ["src/foo.ts", ".ngrace/changes/active/C-RUN/run.xml"], {
      "src/foo.ts": "d1",
      ".ngrace/changes/active/C-RUN/run.xml": "n1",
    });
    const second = failWith(root, A, ["src/foo.ts", ".ngrace/changes/active/C-RUN/run.xml"], {
      "src/foo.ts": "d2",
      ".ngrace/changes/active/C-RUN/run.xml": "n2",
    });
    expect(second.escalated).toBe(true);
    expect(second.circuit).toBe(false);
    expect(second.message).toContain("src/foo.ts×1");
    expect(second.message).toMatch(/Churn \(this-window, windows=1\)/);
    expect(second.message).not.toContain(".ngrace/");
    expect(second.message).not.toMatch(/\bbytes\b/i);
    expect(second.message).not.toMatch(/\blines\b/i);
  });

  it("five rewrites of one file and only one fail of A stays unescalated", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    for (let i = 0; i < 5; i += 1) {
      recordAttempt(root, "C-RUN", {
        task: "T-001",
        outcome: "pass",
        writeEvidence: evidencePaths(["src/hot.ts"], { "src/hot.ts": `digest-${i}` }),
      });
    }
    const onlyFail = failWith(root, A, ["src/hot.ts"], { "src/hot.ts": "digest-5" });
    expect(onlyFail.escalated).toBe(false);
    expect(onlyFail.circuit).toBe(false);
    expect(onlyFail.position.state).not.toBe("paused-pending-approval");
    expect(onlyFail.position.state).not.toBe("paused-pending-supersede");
  });

  it("circuit message lists cross-window churn and recurring signatures or none", () => {
    const root = createProject();
    seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failWith(root, A, ["src/a.ts"], { "src/a.ts": "w1a" });
    failWith(root, A, ["src/a.ts"], { "src/a.ts": "w1b" });
    resumeCursor(root, "C-RUN", "T-001", { reason: "replan: after first R" });
    failWith(root, A, ["src/a.ts"], { "src/a.ts": "w2a" });
    const tripped = failWith(root, A, ["src/a.ts"], { "src/a.ts": "w2b" });
    expect(tripped.circuit).toBe(true);
    expect(tripped.message).toMatch(/Churn \(cross-window, windows=2\)/);
    expect(tripped.message).toContain("src/a.ts×3");
    expect(tripped.message).toContain("Recurring signatures: k:a");
    expect(tripped.message).not.toContain(".ngrace/");

    const root2 = createProject();
    seedBundle(root2);
    advanceCursor(root2, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    failWith(root2, A, ["src/x.ts"], { "src/x.ts": "1" });
    failWith(root2, B, ["src/x.ts"], { "src/x.ts": "2" });
    failWith(root2, C, ["src/x.ts"], { "src/x.ts": "3" });
    failWith(root2, D, ["src/x.ts"], { "src/x.ts": "4" });
    resumeCursor(root2, "C-RUN", "T-001", { reason: "replan: after D" });
    failWith(root2, E, ["src/x.ts"], { "src/x.ts": "5" });
    failWith(root2, F, ["src/x.ts"], { "src/x.ts": "6" });
    failWith(root2, G, ["src/x.ts"], { "src/x.ts": "7" });
    const secondD = failWith(root2, H, ["src/x.ts"], { "src/x.ts": "8" });
    expect(secondD.circuit).toBe(true);
    expect(secondD.message).toContain("Recurring signatures: none");
    expect(secondD.message).toContain("src/x.ts×7");
  });
});

describe("appendEpochToLedger structural clone pin (C-SUBSTANCE-OVER-NAME)", () => {
  it("rebuilds children with .map(cloneXmlNode), not an inline one-level copy", () => {
    // Structural pin; no behavioural discriminator exists — the shared grandchild
    // level is never mutated, so a clone-isolation test would pass on the pre-change code.
    const source = readFileSync(path.join(import.meta.dir, "grace-cursor.ts"), "utf8");
    const start = source.indexOf("function appendEpochToLedger");
    expect(start).toBeGreaterThanOrEqual(0);
    const nextFn = source.indexOf("\nfunction ", start + 1);
    const slice = source.slice(start, nextFn === -1 ? undefined : nextFn);
    expect(slice).not.toContain("children: [...child.children]");
    expect(slice).toContain(".map(cloneXmlNode)");
  });
});

describe("C-CURSOR-TASK-RESOLVER T-001: command-run inherits a declared in-scope task", () => {
  it("inherit-declared: after a T-001 fold, lintGraceProject final+runCommands writes command-run as T-001 not T-000", () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    const changeId = "C-INHERIT";
    writeChangeBundleFixture(root, {
      changeId,
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
      planTargetAssertions:
        `<MustExist><Value>src/example.ts</Value></MustExist>`
        + `<MustPassCommand><Command>exit 0</Command></MustPassCommand>`,
    });
    advanceCursor(root, changeId, {
      task: "T-001",
      openEpoch: true,
      worker: "w0",
      from: 1,
      to: 20,
    });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    const folded = foldEpoch(root, changeId);
    expect(folded.applied).toBe(true);

    const bundlePath = path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
    expect(listLooseEvents(bundlePath)).toHaveLength(0);
    expect(readFileSync(path.join(bundlePath, "run.xml"), "utf8")).toContain("<Task>T-001</Task>");

    lintGraceProject(root, {
      assertionMode: "final",
      changeId,
      runCommands: true,
    });

    const runDir = path.join(bundlePath, "run");
    const files = existsSync(runDir)
      ? readdirSync(runDir).filter((name) => name.includes("command-run"))
      : [];
    // Discriminating negative at HEAD: 3-T-000-command-run.xml after a T-001 fold.
    expect(files).not.toContain("3-T-000-command-run.xml");
    expect(files).toContain("3-T-001-command-run.xml");
    const commandRuns = listLooseEvents(bundlePath).filter((event) => event.kind === "command-run");
    expect(commandRuns.length).toBeGreaterThanOrEqual(1);
    expect(commandRuns[commandRuns.length - 1]!.task).toBe("T-001");
  });
});

describe("C-CURSOR-TASK-RESOLVER T-001: command-run refuses when no declared task is in scope", () => {
  function seedUnscopedCommandProject(changeId: string): { root: string; bundlePath: string } {
    const root = createProject();
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId,
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
      planTargetAssertions:
        `<MustExist><Value>src/example.ts</Value></MustExist>`
        + `<MustPassCommand><Command>exit 0</Command></MustPassCommand>`,
    });
    return { root, bundlePath: path.join(root, ARTIFACT_DIR, "changes", "active", changeId) };
  }

  function expectRefuseWithoutRunWrite(root: string, bundlePath: string, run: () => void): void {
    const runDir = path.join(bundlePath, "run");
    expect(existsSync(runDir) ? readdirSync(runDir) : []).toEqual([]);
    try {
      run();
      throw new Error("expected GraceCommandError invalid-arguments");
    } catch (error) {
      expect(error).toBeInstanceOf(GraceCommandError);
      const commandError = error as GraceCommandError;
      expect(commandError.code).toBe("invalid-arguments");
      expect(commandError.message).toContain("no declared task is in scope");
      expect(commandError.message).toContain("cursor advance");
      expect(commandError.message).toContain("declared T-");
      expect(commandError.message).toContain("run.xml");
      expect(commandError.message).not.toMatch(/--task\b/);
    }
    expect(existsSync(runDir) ? readdirSync(runDir) : []).toEqual([]);
  }

  it("refuse-unscoped: first run-commands before any cursor refuses without writing run/", () => {
    const changeId = "C-REFUSE";
    const { root, bundlePath } = seedUnscopedCommandProject(changeId);
    expectRefuseWithoutRunWrite(root, bundlePath, () => {
      lintGraceProject(root, {
        assertionMode: "target",
        changeId,
        runCommands: true,
      });
    });
  });

  it("refuse-unscoped: poisoned run.xml Task T-000 plus last ledger T-000 refuses", () => {
    const changeId = "C-POISON";
    const { root, bundlePath } = seedUnscopedCommandProject(changeId);
    writeFileSync(
      path.join(bundlePath, "run.xml"),
      `<NgraceRunCursor graceVersion="1.0"><${changeId}><Task>T-000</Task></${changeId}></NgraceRunCursor>\n`,
    );
    writeFileSync(
      path.join(bundlePath, "run-ledger.xml"),
      `<NgraceRunLedger graceVersion="1.0"><${changeId}><Epoch-1><Event id="1" task="T-000" kind="opened" /></Epoch-1></${changeId}></NgraceRunLedger>\n`,
    );
    expectRefuseWithoutRunWrite(root, bundlePath, () => {
      lintGraceProject(root, {
        assertionMode: "target",
        changeId,
        runCommands: true,
      });
    });
  });

  it("refuse-unscoped: explicit options.task absent from planTaskIds refuses", () => {
    const changeId = "C-EXPLICIT";
    const { root, bundlePath } = seedUnscopedCommandProject(changeId);
    expectRefuseWithoutRunWrite(root, bundlePath, () => {
      appendCommandRunEvent(root, changeId, {
        command: "exit 0",
        exitCode: 0,
        assertionPassed: true,
        assertionKind: "MustPassCommand",
        source: "test",
      }, { task: "T-999" });
    });
  });
});

describe("C-CURSOR-TASK-RESOLVER T-002: sibling no-guess helper", () => {
  it("sibling-refuse: inheritLooseEventTask(undefined) throws invalid-arguments and does not return T-001", () => {
    expect(() => inheritLooseEventTask(undefined)).toThrow(GraceCommandError);
    try {
      inheritLooseEventTask(undefined);
      throw new Error("expected inheritLooseEventTask to throw");
    } catch (error) {
      expect(error).toBeInstanceOf(GraceCommandError);
      expect((error as GraceCommandError).code).toBe("invalid-arguments");
      expect((error as GraceCommandError).message).not.toContain("T-001");
    }
  });

  it("inherit-undeclared: recover --fix after planted T-000 command-run writes T-000 opened", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-000-command-run.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-000" kind="command-run"/>`,
    );
    const fixed = recoverCursor(root, "C-RUN", { fix: true });
    expect(fixed.fixApplied).toBe(true);
    expect(fixed.coveringOpenedFile).toMatch(/T-000-opened\.xml$/);
    const opened = listLooseEvents(bundle).filter((event) => event.kind === "opened");
    expect(opened.some((event) => event.task === "T-000")).toBe(true);
    expect(opened.some((event) => event.task === "T-001")).toBe(false);
  });

  it("inherit-undeclared: fold after planted T-000 command-run auto-opens T-000", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-000-command-run.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-000" kind="command-run"/>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-000-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-000" kind="terminal"/>`,
    );
    const folded = foldEpoch(root, "C-RUN");
    expect(folded.applied).toBe(true);
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(ledger).toContain('task="T-000"');
    expect(ledger).toMatch(/kind="opened"/);
    expect(ledger).not.toContain('task="T-001"');
  });
});



describe("cursor event-id integrity (C-CURSOR-EVENT-ID-INTEGRITY-2-E18DFE92)", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");

  async function runConcurrentAdvances(root: string, changeId: string, tasks: string[]): Promise<number[]> {
    const procs = tasks.map((task) =>
      Bun.spawn({
        cmd: [
          process.execPath,
          "./src/grace.ts",
          "cursor",
          "advance",
          "--change",
          changeId,
          "--task",
          task,
          "--path",
          root,
        ],
        cwd: repoRoot,
        stdout: "pipe",
        stderr: "pipe",
      }),
    );
    const stderrs = procs.map((proc) => new Response(proc.stderr).text());
    const codes = await Promise.all(procs.map((proc) => proc.exited));
    if (codes.some((code) => code !== 0)) {
      const texts = await Promise.all(stderrs);
      for (let index = 0; index < tasks.length; index += 1) {
        console.error(`runConcurrentAdvances: ${tasks[index]} exited ${codes[index]}\n${texts[index]}`);
      }
    }
    return codes;
  }

  function pinNextAllocationOnce(pinned: number): void {
    let forced = true;
    setEventIdAllocationProbeForTests((_bundle, candidate) => {
      if (forced) {
        forced = false;
        return pinned;
      }
      return candidate;
    });
  }

  it("prints each failing task's id, code and stderr (AC-CONCURRENCY-DIAGNOSABLE)", async () => {
    const root = createProject();
    seedBundle(root);
    const printed: string[] = [];
    const originalError = console.error;
    console.error = (...parts: unknown[]) => printed.push(parts.map(String).join(" "));
    let codes: number[];
    try {
      codes = await runConcurrentAdvances(root, "C-DOES-NOT-EXIST", ["T-002", "T-003"]);
    } finally {
      console.error = originalError;
    }
    expect(codes.every((code) => code !== 0), "both spawns fail").toBe(true);
    const text = printed.join("\n");
    expect(text, "the failing task id is printed").toContain("T-002");
    expect(text, "the exit code is printed").toContain("1");
    expect(text, "the captured stderr is printed").toContain("C-DOES-NOT-EXIST");
  });

  it("forced event-id collision renumbers the writer's own file (AC-FORCED-COLLISION)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    const existing = path.join(runDir, "5-T-001-progress.xml");
    writeFileSync(
      existing,
      `<NgraceRunEvent graceVersion="1.0" id="5" task="T-001" kind="progress"/>`,
    );
    const before = readFileSync(existing);

    // Force the writer onto the id another loose event already holds. The collision
    // is deterministic, not scheduler-dependent: the allocator is pinned once.
    pinNextAllocationOnce(5);
    try {
      advanceCursor(root, "C-RUN", { task: "T-002" });
    } finally {
      setEventIdAllocationProbeForTests(undefined);
    }

    const events = listLooseEvents(bundle);
    const fives = events.filter((event) => event.id === 5);
    expect(fives.length).toBe(1);
    expect(path.resolve(fives[0]!.file)).toBe(path.resolve(existing));
    const appended = events.find((event) => event.task === "T-002");
    expect(appended).toBeDefined();
    expect(appended!.id).not.toBe(5);
    // The recorded event is byte-identical; only the writer's own file moved.
    expect(readFileSync(existing)).toEqual(before);
  });

  it("concurrent advances with distinct tasks yield unique event ids (AC-UNIQUE-CONCURRENT)", async () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    const tasks = Array.from({ length: 12 }, (_, index) => `T-${String(index + 2).padStart(3, "0")}`);
    for (let round = 0; round < 3; round += 1) {
      rmSync(runDir, { recursive: true, force: true });
      advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 199 });
      const codes = await runConcurrentAdvances(root, "C-RUN", tasks);
      expect(codes.every((code) => code === 0), `round ${round} exits`).toBe(true);
      const events = listLooseEvents(bundle);
      expect(events.length, `round ${round} files`).toBe(13);
      expect(new Set(events.map((event) => event.id)).size, `round ${round} unique ids`).toBe(13);
    }
  });

  it("concurrent advances on one task lose no event (AC-NO-SILENT-OVERWRITE)", async () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    const tasks = Array.from({ length: 12 }, () => "T-001");
    for (let round = 0; round < 3; round += 1) {
      rmSync(runDir, { recursive: true, force: true });
      advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 199 });
      const codes = await runConcurrentAdvances(root, "C-RUN", tasks);
      expect(codes.every((code) => code === 0), `round ${round} exits`).toBe(true);
      const events = listLooseEvents(bundle);
      expect(events.length, `round ${round} files`).toBe(13);
      expect(new Set(events.map((event) => event.id)).size, `round ${round} unique ids`).toBe(13);
    }
  });

  it("an advance does not touch a pre-existing collided stream (AC-NO-RECORDED-EVENT-TOUCHED)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    const holder = path.join(runDir, "3-T-001-progress.xml");
    const other = path.join(runDir, "3-T-002-progress.xml");
    writeFileSync(holder, `<NgraceRunEvent graceVersion="1.0" id="3" task="T-001" kind="progress"/>`);
    writeFileSync(other, `<NgraceRunEvent graceVersion="1.0" id="3" task="T-002" kind="progress"/>`);
    const beforeHolder = readFileSync(holder);
    const beforeOther = readFileSync(other);

    // Pin the allocator onto the duplicated id; the writer must renumber its own file.
    pinNextAllocationOnce(3);
    try {
      advanceCursor(root, "C-RUN", { task: "T-003" });
    } finally {
      setEventIdAllocationProbeForTests(undefined);
    }

    // D41: a recorded event is never rewritten or deleted.
    expect(readFileSync(holder)).toEqual(beforeHolder);
    expect(readFileSync(other)).toEqual(beforeOther);
    const appended = listLooseEvents(bundle).find((event) => event.task === "T-003");
    expect(appended).toBeDefined();
    expect(appended!.id).not.toBe(3);
  });

  it("recover and fold name a duplicate event id (AC-RECOVER-NAMES-DUPLICATE)", () => {
    const root = createProject();
    const bundle = seedBundle(root);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="99"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "7-T-002-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="7" task="T-002" kind="progress"/>`,
    );
    writeFileSync(
      path.join(runDir, "7-T-003-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="7" task="T-003" kind="progress"/>`,
    );
    writeFileSync(
      path.join(runDir, "8-T-003-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="8" task="T-003" kind="terminal"/>`,
    );

    const diagnosis = recoverCursor(root, "C-RUN");
    expect(diagnosis.foldBlocked).toBe(true);
    expect(diagnosis.foldBlockReasons.some((reason) => /duplicate event id 7/.test(reason))).toBe(true);
    const rendered = formatRecoverDiagnosis(diagnosis);
    expect(rendered).toContain("duplicate event id 7");
    expect(rendered).not.toMatch(/Fold: ok/);

    let thrown: unknown;
    try {
      foldEpoch(root, "C-RUN");
    } catch (error) {
      thrown = error;
    }
    expect(thrown).toBeInstanceOf(GraceCommandError);
    expect(String((thrown as Error).message)).toMatch(/duplicate event id 7/);
  });
});

// C-EVENT-LOCK-ATOMIC-1-9711E83D T-001: the event write lock keeps its
// exclusive `wx` create, classifies an empty or non-numeric holder `unknown`
// (never `stale`), bounds the wait by the TTL with the lock file's mtime as
// the age fallback, and guards the stale unlink against a lost race. The TTL
// override is reached through a namespace import with an optional call so the
// file loads on the base tree, where the export does not exist.
const setEventWriteLockTtlForTests = (
  graceCursorModule as { setEventWriteLockTtlForTests?: (ms: number | null) => void }
).setEventWriteLockTtlForTests;

function withShortLockTtl<T>(ms: number, fn: () => T): T {
  setEventWriteLockTtlForTests?.(ms);
  try {
    return fn();
  } finally {
    setEventWriteLockTtlForTests?.(null);
  }
}

describe("C-EVENT-LOCK-ATOMIC-1-9711E83D event write lock", () => {
  function contendedBundle(content: string): string {
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 199 });
    writeFileSync(path.join(bundle, ".run-write.lock"), content);
    return root;
  }

  it("waits on a 0-byte lock instead of stealing it (AC-EMPTY-HOLDER-UNKNOWN)", () => {
    const root = contendedBundle("");
    const t0 = Date.now();
    withShortLockTtl(200, () => advanceCursor(root, "C-RUN", { task: "T-002" }));
    const elapsed = Date.now() - t0;
    expect(elapsed, `an empty holder is unknown, so the contender waits: ${elapsed}ms`).toBeGreaterThanOrEqual(100);
  });

  it("waits on an unparsable or zero pid instead of stealing it (AC-EMPTY-HOLDER-UNKNOWN)", () => {
    for (const pidText of ["x", "0"]) {
      const content = `${pidText}\n${Date.now()}\n`;
      const root = contendedBundle(content);
      const t0 = Date.now();
      withShortLockTtl(200, () => advanceCursor(root, "C-RUN", { task: "T-002" }));
      const elapsed = Date.now() - t0;
      expect(elapsed, `pid ${JSON.stringify(pidText)} is unknown: ${elapsed}ms`).toBeGreaterThanOrEqual(100);
    }
  });

  it("waits on a record with a pid line but no stamp line (AC-EMPTY-HOLDER-UNKNOWN)", () => {
    for (const pidText of ["x", "1234"]) {
      const content = `${pidText}\n`;
      const root = contendedBundle(content);
      const t0 = Date.now();
      withShortLockTtl(200, () => advanceCursor(root, "C-RUN", { task: "T-002" }));
      const elapsed = Date.now() - t0;
      expect(elapsed, `an incomplete holder record (${JSON.stringify(content)}) is unknown: ${elapsed}ms`).toBeGreaterThanOrEqual(100);
    }
  });

  it("still steals a known dead pid's lock immediately (AC-EMPTY-HOLDER-UNKNOWN)", () => {
    const root = contendedBundle(`999999\n${Date.now()}\n`);
    const t0 = Date.now();
    withShortLockTtl(60000, () => advanceCursor(root, "C-RUN", { task: "T-002" }));
    const elapsed = Date.now() - t0;
    expect(elapsed, `the real stale path is not blunted by the unknown state: ${elapsed}ms`).toBeLessThan(5000);
  });

  it("catches a stale unlink that loses the race (AC-STALE-UNLINK-GUARDED)", async () => {
    if (process.platform !== "darwin") return;
    const root = createProject();
    const bundle = seedBundle(root);
    advanceCursor(root, "C-RUN", { task: "T-001", openEpoch: true, from: 1, to: 199 });
    const lockPath = path.join(bundle, ".run-write.lock");
    writeFileSync(lockPath, `999999\n${Date.now()}\n`);
    const marker = Bun.spawnSync(["chflags", "uchg", lockPath]);
    expect(marker.exitCode, "chflags uchg").toBe(0);
    const childScript = `import { advanceCursor } from ${JSON.stringify(path.resolve(import.meta.dir, "grace-cursor.ts"))}; advanceCursor(${JSON.stringify(root)}, "C-RUN", { task: "T-002" });`;
    const child = Bun.spawn({ cmd: [process.execPath, "-e", childScript], stdout: "pipe", stderr: "pipe" });
    await Bun.sleep(200);
    Bun.spawnSync(["chflags", "nouchg", lockPath]);
    const code = await child.exited;
    const stderr = await new Response(child.stderr).text();
    expect(code, `the guarded stale unlink retried after the EPERM: ${stderr}`).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// C-EPOCH-OPEN-DEFAULT-1-CE010A4C T-001: the unbounded-open default (F308).
// ---------------------------------------------------------------------------

describe("C-EPOCH-OPEN-DEFAULT-1-CE010A4C T-001: unbounded open after a fold", () => {
  it("AC-UNBOUNDED-OPEN-AFTER-FOLD: an unbounded open after a fold allocates from the next id and folds", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-EPOCH");
    advanceCursor(root, "C-EPOCH", { task: "T-001", openEpoch: true });
    advanceCursor(root, "C-EPOCH", { task: "T-001", kind: "progress" });
    advanceCursor(root, "C-EPOCH", { task: "T-001", kind: "terminal" });
    expect(foldEpoch(root, "C-EPOCH").applied).toBe(true);

    advanceCursor(root, "C-EPOCH", { task: "T-001", openEpoch: true });
    const opened = listLooseEvents(bundle).find((event) => event.kind === "opened");
    expect(opened).toBeDefined();
    const allocation = (opened!.allocations ?? [])[0];
    expect(allocation).toBeDefined();
    expect(allocation!.from).toBe(opened!.id);
    expect(allocation!.to).toBe(opened!.id + 98);
    advanceCursor(root, "C-EPOCH", { task: "T-001", kind: "progress" });
    advanceCursor(root, "C-EPOCH", { task: "T-001", kind: "terminal" });
    expect(foldEpoch(root, "C-EPOCH").applied).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// C-EPOCH-OPEN-DEFAULT-1-CE010A4C T-002: recover --fix leading-hole re-home.
// ---------------------------------------------------------------------------

describe("C-EPOCH-OPEN-DEFAULT-1-CE010A4C T-002: recover --fix leading hole", () => {
  it("AC-RECOVER-FIX-REHOMES-LEADING-HOLE: a leading hole is re-homed and folds", () => {
    const root = createProject();
    seedBundle(root, "C-FIXLEAD");
    advanceCursor(root, "C-FIXLEAD", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    advanceCursor(root, "C-FIXLEAD", { task: "T-001", kind: "progress" });
    advanceCursor(root, "C-FIXLEAD", { task: "T-001", kind: "terminal" });
    expect(foldEpoch(root, "C-FIXLEAD").applied).toBe(true);

    advanceCursor(root, "C-FIXLEAD", { task: "T-001", openEpoch: true, from: 1, to: 99 });
    advanceCursor(root, "C-FIXLEAD", { task: "T-001", kind: "progress" });
    advanceCursor(root, "C-FIXLEAD", { task: "T-001", kind: "terminal" });
    const pre = recoverCursor(root, "C-FIXLEAD");
    expect(pre.coveringAllocation).toBe("present");
    expect(pre.foldBlocked).toBe(true);
    expect(() => foldEpoch(root, "C-FIXLEAD")).toThrow(/range hole at 1/i);

    const fixed = recoverCursor(root, "C-FIXLEAD", { fix: true });
    expect(fixed.fixApplied).toBe(true);
    expect(fixed.foldBlocked).toBe(false);
    expect(fixed.coveringOpenedFile).toBeDefined();
    expect(foldEpoch(root, "C-FIXLEAD").applied).toBe(true);
  });

  it("AC-RECOVER-FIX-REHOMES-LEADING-HOLE control: a mid-range hole still declines", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-FIXMID");
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(
      path.join(runDir, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="10"/></NgraceRunEvent>`,
    );
    writeFileSync(
      path.join(runDir, "2-T-001-progress.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="progress"/>`,
    );
    writeFileSync(
      path.join(runDir, "4-T-001-terminal.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="4" task="T-001" kind="terminal"/>`,
    );
    const before = listLooseEvents(bundle).map((event) => event.file).sort();
    const fixed = recoverCursor(root, "C-FIXMID", { fix: true });
    expect(fixed.fixApplied).toBe(false);
    expect(listLooseEvents(bundle).map((event) => event.file).sort()).toEqual(before);
    expect(() => foldEpoch(root, "C-FIXMID")).toThrow(/range hole at 3/i);
  });
});

// ---------------------------------------------------------------------------
// C-CURSOR-STATE-HONESTY-1-53C5EC0B T-001: state from the range's closer (F310).
// ---------------------------------------------------------------------------

describe("C-CURSOR-STATE-HONESTY-1-53C5EC0B: state from the range's closer (F310)", () => {
  function seedEndStateBundle(root: string, changeId: string) {
    writeMinimalNgraceProject(root);
    writeChangeBundleFixture(root, {
      changeId,
      location: "active",
      specStatus: "approved",
      planStatus: "approved",
      planTargetAssertions:
        `<MustExist><Value>src/example.ts</Value></MustExist>`
        + `<MustPassCommand><Command>exit 0</Command></MustPassCommand>`,
    });
  }

  it("AC-END-STATE-READS-COMPLETE: the end-state fold reads complete, not in-progress", () => {
    const root = createProject();
    const changeId = "C-ENDSTATE";
    seedEndStateBundle(root, changeId);
    advanceCursor(root, changeId, { task: "T-001", openEpoch: true, worker: "w0", from: 1, to: 20 });
    advanceCursor(root, changeId, { task: "T-001", kind: "progress" });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    expect(foldEpoch(root, changeId).applied).toBe(true);
    lintGraceProject(root, { assertionMode: "final", changeId, runCommands: true });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    expect(foldEpoch(root, changeId).applied).toBe(true);
    const bundle = path.join(root, ARTIFACT_DIR, "changes", "active", changeId);
    const runDir = path.join(bundle, "run");
    expect(existsSync(runDir) ? readdirSync(runDir) : []).toEqual([]);
    const position = showCursor(root, changeId);
    expect(position.state).toBe("complete");
    expect(readFileSync(path.join(bundle, "run.xml"), "utf8")).toContain("<State>complete</State>");
  });

  it("range control: a bounded reopen over a prior terminal stays in-progress", () => {
    const root = createProject();
    const changeId = "C-BOUNDED";
    seedEndStateBundle(root, changeId);
    advanceCursor(root, changeId, { task: "T-001", openEpoch: true, worker: "w0", from: 1, to: 20 });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    expect(foldEpoch(root, changeId).applied).toBe(true);
    advanceCursor(root, changeId, { task: "T-001", openEpoch: true, worker: "w0", from: 1, to: 99 });
    expect(showCursor(root, changeId).state).toBe("in-progress");
  });

  it("range control: a stray terminal inside a live range reads its closer's state", () => {
    const root = createProject();
    const changeId = "C-STRAY";
    seedEndStateBundle(root, changeId);
    advanceCursor(root, changeId, { task: "T-001", openEpoch: true, worker: "w0", from: 1, to: 20 });
    advanceCursor(root, changeId, { task: "T-001", kind: "progress" });
    advanceCursor(root, changeId, { task: "T-001", kind: "terminal" });
    advanceCursor(root, changeId, { task: "T-001", kind: "progress" });
    expect(showCursor(root, changeId).state).toBe("complete");
    expect(foldEpoch(root, changeId).applied).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// C-CURSOR-STATE-HONESTY-1-53C5EC0B T-002: recover --fix refuses a lost event (F309).
// ---------------------------------------------------------------------------

describe("C-CURSOR-STATE-HONESTY-1-53C5EC0B: recover --fix refuses a lost event (F309)", () => {
  function seedLoose(root: string, changeId: string, ids: Array<[number, string]>) {
    const bundle = seedBundle(root, changeId);
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    for (const [id, kind] of ids) {
      writeFileSync(
        path.join(runDir, `${id}-T-001-${kind}.xml`),
        `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="${kind}"/>`,
      );
    }
    return bundle;
  }

  it("AC-FIX-REFUSES-LOST-EVENT: a missing covering over a mid-range hole is not repaired", () => {
    const root = createProject();
    const bundle = seedLoose(root, "C-LOST", [[27, "progress"], [29, "progress"], [30, "terminal"]]);
    const before = listLooseEvents(bundle).map((event) => event.file).sort();
    const fixed = recoverCursor(root, "C-LOST", { fix: true });
    expect(fixed.fixApplied).toBe(false);
    expect(fixed.foldBlockReasons.some((reason) => /range hole at 28/.test(reason))).toBe(true);
    expect(listLooseEvents(bundle).map((event) => event.file).sort()).toEqual(before);
    expect(() => foldEpoch(root, "C-LOST")).toThrow(/range hole at 28/);
    const rendered = formatRecoverDiagnosis(fixed);
    expect(rendered).toContain("Fix applied: no");
    expect(rendered).not.toMatch(/Fix applied:\s*yes/i);
    expect(rendered).toContain("range hole at 28");
  });

  it("control: a dense loose range with no covering still writes and folds", () => {
    const root = createProject();
    const bundle = seedLoose(root, "C-DENSE", [[1, "progress"], [2, "progress"], [3, "terminal"]]);
    const fixed = recoverCursor(root, "C-DENSE", { fix: true });
    expect(fixed.fixApplied).toBe(true);
    expect(fixed.coveringOpenedFile).toBeDefined();
    expect(foldEpoch(root, "C-DENSE").applied).toBe(true);
    expect(listLooseEvents(bundle)).toHaveLength(0);
  });

  it("control: a leading hole still re-homes and folds", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-LEADING");
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(path.join(runDir, "12-T-001-opened.xml"), `<NgraceRunEvent graceVersion="1.0" id="12" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="20"/></NgraceRunEvent>`);
    writeFileSync(path.join(runDir, "13-T-001-progress.xml"), `<NgraceRunEvent graceVersion="1.0" id="13" task="T-001" kind="progress"/>`);
    writeFileSync(path.join(runDir, "14-T-001-terminal.xml"), `<NgraceRunEvent graceVersion="1.0" id="14" task="T-001" kind="terminal"/>`);
    const fixed = recoverCursor(root, "C-LEADING", { fix: true });
    expect(fixed.fixApplied).toBe(true);
    expect(fixed.foldBlocked).toBe(false);
    expect(foldEpoch(root, "C-LEADING").applied).toBe(true);
  });

  it("control: a present covering with a mid-range hole still declines", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-MIDPRESENT");
    const runDir = path.join(bundle, "run");
    mkdirSync(runDir, { recursive: true });
    writeFileSync(path.join(runDir, "1-T-001-opened.xml"), `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="10"/></NgraceRunEvent>`);
    writeFileSync(path.join(runDir, "2-T-001-progress.xml"), `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="progress"/>`);
    writeFileSync(path.join(runDir, "4-T-001-terminal.xml"), `<NgraceRunEvent graceVersion="1.0" id="4" task="T-001" kind="terminal"/>`);
    const before = listLooseEvents(bundle).map((event) => event.file).sort();
    const fixed = recoverCursor(root, "C-MIDPRESENT", { fix: true });
    expect(fixed.fixApplied).toBe(false);
    expect(listLooseEvents(bundle).map((event) => event.file).sort()).toEqual(before);
    expect(() => foldEpoch(root, "C-MIDPRESENT")).toThrow(/range hole at 3/);
  });
});

// C-SUPERSEDE-MEMBERSHIP-1-7D8B2BE8 T-001: candidate coordination primitives.
describe("candidate lock primitive", () => {
  const lockDirFor = (root: string) => path.join(root, ARTIFACT_DIR, "changes", "active");
  const lockPathFor = (root: string, id: string) => path.join(lockDirFor(root), `.candidate-${id}.lock`);

  function candidateRoot(label: string): string {
    const root = mkdtempSync(path.join(os.tmpdir(), `grace-candidate-lock-${label}-`));
    mkdirSync(lockDirFor(root), { recursive: true });
    return root;
  }

  it("exports withCandidateLock and setCandidateLockTtlForTests", () => {
    expect(typeof graceCursorModule.withCandidateLock).toBe("function");
    expect(typeof graceCursorModule.setCandidateLockTtlForTests).toBe("function");
  });

  it("acquires, runs, and releases its own lock", () => {
    const root = candidateRoot("basic");
    const lock = lockPathFor(root, "C-LOCK-BASIC");
    let inside = false;
    graceCursorModule.withCandidateLock(root, "C-LOCK-BASIC", () => {
      inside = existsSync(lock);
    });
    expect(inside).toBe(true);
    expect(existsSync(lock)).toBe(false);
  });

  it("reclaims a dead fresh holder immediately", () => {
    const root = candidateRoot("dead");
    const lock = lockPathFor(root, "C-LOCK-DEAD");
    writeFileSync(lock, `2147483647\n${Date.now()}\ndead-token\n`, { flag: "wx" });
    let ran = false;
    graceCursorModule.withCandidateLock(root, "C-LOCK-DEAD", () => {
      ran = true;
    });
    expect(ran).toBe(true);
    expect(existsSync(lock)).toBe(false);
  });

  it("waits out then reclaims an unknown holder bounded by the TTL", () => {
    const root = candidateRoot("unknown");
    const lock = lockPathFor(root, "C-LOCK-UNKNOWN");
    writeFileSync(lock, "not-a-pid\nnot-a-stamp\n", { flag: "wx" });
    graceCursorModule.setCandidateLockTtlForTests(1);
    try {
      let ran = false;
      graceCursorModule.withCandidateLock(root, "C-LOCK-UNKNOWN", () => {
        ran = true;
      });
      expect(ran).toBe(true);
    } finally {
      graceCursorModule.setCandidateLockTtlForTests(null);
    }
  });

  it("never steals a known-live holder for age (waits for release)", async () => {
    const root = candidateRoot("live");
    const lock = lockPathFor(root, "C-LOCK-LIVE");
    const lockLiteral = JSON.stringify(lock);
    const body =
      "const fs=require('node:fs');"
      + `fs.writeFileSync(${lockLiteral}, String(process.pid) + '\\n' + String(Date.now() - 31000) + '\\nlive-token\\n', {flag:'wx'});`
      + "await Bun.sleep(400);"
      + `try { fs.unlinkSync(${lockLiteral}); } catch {}`;
    const child = Bun.spawn({ cmd: [process.execPath, "-e", body], stdout: "pipe", stderr: "pipe" });
    for (let i = 0; i < 200 && !existsSync(lock); i += 1) await Bun.sleep(5);
    expect(existsSync(lock)).toBe(true);
    graceCursorModule.setCandidateLockTtlForTests(1);
    const started = Date.now();
    try {
      let ran = false;
      graceCursorModule.withCandidateLock(root, "C-LOCK-LIVE", () => {
        ran = true;
      });
      expect(ran).toBe(true);
    } finally {
      graceCursorModule.setCandidateLockTtlForTests(null);
    }
    const elapsed = Date.now() - started;
    await child.exited;
    // A live-but-old holder may not be stolen by the 1ms TTL: acquisition waits
    // for the holder to release at ~400ms.
    expect(elapsed).toBeGreaterThanOrEqual(250);
  });

  it("releases on throw", () => {
    const root = candidateRoot("throw");
    const lock = lockPathFor(root, "C-LOCK-THROW");
    expect(() =>
      graceCursorModule.withCandidateLock(root, "C-LOCK-THROW", () => {
        throw new Error("boom");
      }),
    ).toThrow(/boom/);
    expect(existsSync(lock)).toBe(false);
  });

  it("a token-mismatched release preserves a successor's lock", () => {
    const root = candidateRoot("token");
    const lock = lockPathFor(root, "C-LOCK-TOKEN");
    graceCursorModule.withCandidateLock(root, "C-LOCK-TOKEN", () => {
      writeFileSync(lock, `999999\n${Date.now()}\nsuccessor-token\n`);
    });
    expect(existsSync(lock)).toBe(true);
    expect(readFileSync(lock, "utf8")).toContain("successor-token");
  });

  it("is reentrant per (root, changeId) without re-opening or re-removing", () => {
    const root = candidateRoot("reentrant");
    const lock = lockPathFor(root, "C-LOCK-REENTRANT");
    let innerSawLock = false;
    graceCursorModule.withCandidateLock(root, "C-LOCK-REENTRANT", () => {
      graceCursorModule.withCandidateLock(root, "C-LOCK-REENTRANT", () => {
        innerSawLock = existsSync(lock);
      });
      expect(existsSync(lock)).toBe(true);
    });
    expect(innerSawLock).toBe(true);
    expect(existsSync(lock)).toBe(false);
  });

  it("is never captured as WriteEvidence", () => {
    const root = createProject();
    mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "active"), { recursive: true });
    writeFileSync(path.join(root, "seed.txt"), "seed\n");
    initGitBaseline(root);
    writeFileSync(lockPathFor(root, "C-LOCK-EVIDENCE"), `99999\n${Date.now()}\ntok\n`, { flag: "wx" });
    const evidence = graceCursorModule.snapshotWriteEvidence(root);
    expect(evidence.available).toBe(true);
    const paths = evidence.available ? evidence.files.map((file) => file.path) : [];
    expect(paths.some((file) => file.includes(".candidate-C-LOCK-EVIDENCE.lock"))).toBe(false);
  });

  it("AC-EVIDENCE-FILTER-CANONICAL-ONLY: the exact canonical lock is filtered and every near miss stays visible", () => {
    const root = createProject();
    for (const dir of [
      path.join(root, ARTIFACT_DIR, "changes", "active"),
      path.join(root, ARTIFACT_DIR, "changes", "active", "sub"),
      path.join(root, ARTIFACT_DIR, "changes", "archive"),
      path.join(root, "src"),
      path.join(root, "other"),
    ]) {
      mkdirSync(dir, { recursive: true });
    }
    writeFileSync(path.join(root, "seed.txt"), "seed\n");
    initGitBaseline(root);
    const canonical = ".ngrace/changes/active/.candidate-C-LOCK-EVIDENCE.lock";
    const nearMisses = [
      ".ngrace/changes/archive/.candidate-C-LOCK-EVIDENCE.lock",
      ".ngrace/changes/active/sub/.candidate-C-LOCK-EVIDENCE.lock",
      "src/.candidate-C-LOCK-EVIDENCE.lock",
      "other/.candidate-C-LOCK-EVIDENCE.lock",
      ".ngrace/changes/active/.candidate-not-a-change.lock",
    ];
    for (const relative of [canonical, ...nearMisses]) {
      writeFileSync(path.join(root, relative), `1\n${Date.now()}\ntok\n`, { flag: "wx" });
    }
    const evidence = graceCursorModule.snapshotWriteEvidence(root);
    expect(evidence.available).toBe(true);
    const paths = evidence.available ? evidence.files.map((file) => file.path) : [];
    expect(paths).not.toContain(canonical);
    for (const nearMiss of nearMisses) {
      expect(paths, nearMiss).toContain(nearMiss);
    }
  });
});

// C-SUPERSEDE-MEMBERSHIP-1-7D8B2BE8 T-002: candidate-lock cooperation.
describe("candidate-lock cooperation", () => {
  const markerOf = (bundle: string) => path.join(bundle, ".ngrace-mint-owner");
  const repoRoot = path.resolve(import.meta.dir, "..");
  const graceBin = path.join(repoRoot, "src", "grace.ts");

  function openedBundle(root: string, id: string): string {
    const bundle = seedBundle(root, id);
    advanceCursor(root, id, { task: "T-001", openEpoch: true, from: 1, to: 10 });
    advanceCursor(root, id, { task: "T-001", kind: "progress" });
    advanceCursor(root, id, { task: "T-001", kind: "terminal" });
    return bundle;
  }

  it("foldEpoch refuses an unpublished candidate before any write", () => {
    const root = createProject();
    const bundle = openedBundle(root, "C-UNPUB");
    const ledger = path.join(bundle, "run-ledger.xml");
    const runBefore = readdirSync(path.join(bundle, "run")).sort();
    const ledgerBefore = existsSync(ledger) ? readFileSync(ledger, "utf8") : "";
    writeFileSync(markerOf(bundle), "token\n");
    expect(() => foldEpoch(root, "C-UNPUB")).toThrow(/unpublished candidate/i);
    expect(readdirSync(path.join(bundle, "run")).sort()).toEqual(runBefore);
    expect(existsSync(ledger) ? readFileSync(ledger, "utf8") : "").toBe(ledgerBefore);
  });

  it("advanceCursor refuses an unpublished candidate before creating run/", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-UNPUB2");
    writeFileSync(markerOf(bundle), "token\n");
    expect(() =>
      advanceCursor(root, "C-UNPUB2", { task: "T-001", openEpoch: true, from: 1, to: 10 }),
    ).toThrow(/unpublished candidate/i);
    expect(existsSync(path.join(bundle, "run"))).toBe(false);
  });

  it("recordAttempt refuses an unpublished candidate", () => {
    const root = createProject();
    const bundle = openedBundle(root, "C-UNPUB3");
    writeFileSync(markerOf(bundle), "token\n");
    expect(() => recordAttempt(root, "C-UNPUB3", { task: "T-001", outcome: "pass" })).toThrow(
      /unpublished candidate/i,
    );
    expect(readdirSync(path.join(bundle, "run")).sort()).toEqual([
      "1-T-001-opened.xml",
      "2-T-001-progress.xml",
      "3-T-001-terminal.xml",
    ]);
  });

  it("a live publisher is waited on, then the contender proceeds", async () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "active"), { recursive: true });
    const pauseFile = path.join(root, "release-candidate");
    const env = { ...process.env, NGRACE_PAUSE_CANDIDATE_FILE: pauseFile };
    const publisher = Bun.spawn({
      cmd: [
        process.execPath,
        graceBin,
        "spec",
        "new",
        "T002-LIVE",
        "--timestamp",
        "2026-09-19T00:00:00Z",
        "--branch",
        "probe",
        "--path",
        root,
      ],
      cwd: repoRoot,
      env,
      stdout: "pipe",
      stderr: "pipe",
    });
    // Wait until the publisher has written its exclusive spec.xml (paused before publish).
    const activeDir = path.join(root, ARTIFACT_DIR, "changes", "active");
    let bundle: string | undefined;
    for (let i = 0; i < 400 && !bundle; i += 1) {
      const found = existsSync(activeDir)
        ? readdirSync(activeDir).find((name) => name.startsWith("C-T002-LIVE-1-"))
        : undefined;
      if (found && existsSync(path.join(activeDir, found, "spec.xml"))) bundle = path.join(activeDir, found);
      if (!bundle) await Bun.sleep(5);
    }
    expect(bundle).toBeDefined();
    const changeId = path.basename(bundle!);
    // Contender: open an epoch. Must wait on the held candidate lock.
    const contender = Bun.spawn({
      cmd: [process.execPath, graceBin, "cursor", "advance", "--change", changeId, "--task", "T-001", "--open-epoch", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    await Bun.sleep(250);
    const exitedWhileHeld = await Promise.race([contender.exited, Bun.sleep(1).then(() => null)]);
    expect(exitedWhileHeld).toBeNull();
    expect(existsSync(path.join(bundle!, "run"))).toBe(false);
    // Release the publisher; it publishes, the contender then acquires and proceeds.
    writeFileSync(pauseFile, "go");
    const pubExit = await publisher.exited;
    const conExit = await contender.exited;
    expect(pubExit).toBe(0);
    expect(conExit).toBe(0);
    expect(existsSync(markerOf(bundle!))).toBe(false);
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-002: under-lock attempt snapshot.
describe("attempt snapshot placement", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");
  const graceBin = path.join(repoRoot, "src", "grace.ts");

  it("AC-ATTEMPT-SNAPSHOT-UNDER-LOCK: a file changed while the attempt waits is recorded", async () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "active"), { recursive: true });
    initGitBaseline(root);
    const pauseFile = path.join(root, "release-publisher");
    const env = { ...process.env, NGRACE_PAUSE_CANDIDATE_FILE: pauseFile };
    const publisher = Bun.spawn({
      cmd: [process.execPath, graceBin, "spec", "new", "SNAP", "--timestamp", "2026-09-19T00:00:00Z", "--branch", "probe", "--path", root],
      cwd: repoRoot,
      env,
      stdout: "pipe",
      stderr: "pipe",
    });
    const activeDir = path.join(root, ARTIFACT_DIR, "changes", "active");
    let id: string | undefined;
    for (let i = 0; i < 400 && !id; i += 1) {
      const found = existsSync(activeDir) ? readdirSync(activeDir).find((name) => name.startsWith("C-SNAP-1-")) : undefined;
      if (found && existsSync(path.join(activeDir, found, "spec.xml"))) id = found;
      if (!id) await Bun.sleep(5);
    }
    expect(id).toBeDefined();
    const bundle = path.join(activeDir, id!);
    const contender = Bun.spawn({
      cmd: [process.execPath, graceBin, "cursor", "attempt", "--change", id!, "--task", "T-001", "--outcome", "pass", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    await Bun.sleep(300);
    // Pending while the publisher holds the lock: no attempt event written yet.
    expect(listLooseEvents(bundle).some((event) => event.kind === "attempt")).toBe(false);
    // Written only AFTER the contender queued on the held lock: a pre-lock snapshot
    // cannot have seen it.
    writeFileSync(path.join(root, "wait-marker.txt"), "changed during wait\n");
    writeFileSync(pauseFile, "go\n");
    await publisher.exited;
    const code = await contender.exited;
    expect(code).toBe(0);
    const attempt = listLooseEvents(bundle).find((event) => event.kind === "attempt");
    expect(attempt).toBeDefined();
    const payload = readAttemptPayload(attempt!);
    const evidence = payload.writeEvidence;
    const paths = evidence && evidence.available ? evidence.files.map((file) => file.path) : [];
    expect(paths).toContain("wait-marker.txt");
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-002: token/identity-checked reclaim scheduling.
describe("candidate reclaim exclusivity", () => {
  const lockDirFor = (root: string) => path.join(root, ARTIFACT_DIR, "changes", "active");
  const lockPathFor = (root: string, id: string) => path.join(lockDirFor(root), `.candidate-${id}.lock`);

  it("AC-CANDIDATE-RECLAIM-EXCLUSIVE: a stale observer cannot unlink a replacement holder (B/A/B)", async () => {
    const root = mkdtempSync(path.join(os.tmpdir(), "grace-reclaim-race-"));
    mkdirSync(lockDirFor(root), { recursive: true });
    const lockPath = lockPathFor(root, "C-RACE");
    writeFileSync(lockPath, `2147483647\n${Date.now()}\ndead-token\n`, { flag: "wx" });
    const bObserved = path.join(root, "b-observed");
    const bRelease = path.join(root, "b-release");
    const bBeforeUnlink = path.join(root, "b-before-unlink");
    const bAcquired = path.join(root, "b-acquired");
    const bDone = path.join(root, "b-done");
    const body = `
      const fs = require('node:fs');
      const mod = await import(${JSON.stringify(path.join(import.meta.dir, "grace-cursor.ts"))});
      mod.setCandidateReclaimProbeForTests((phase, lockPath, observedRaw) => {
        if (phase === 'observed') {
          fs.writeFileSync(${JSON.stringify(bObserved)}, '1');
          while (!fs.existsSync(${JSON.stringify(bRelease)})) Bun.sleep(5);
        } else {
          fs.writeFileSync(${JSON.stringify(bBeforeUnlink)}, observedRaw);
        }
      });
      mod.withCandidateLock(${JSON.stringify(root)}, 'C-RACE', () => { fs.writeFileSync(${JSON.stringify(bAcquired)}, '1'); });
      fs.writeFileSync(${JSON.stringify(bDone)}, '1');
    `;
    const b = Bun.spawn({ cmd: [process.execPath, "-e", body], stdout: "pipe", stderr: "pipe" });
    for (let i = 0; i < 400 && !existsSync(bObserved); i += 1) await Bun.sleep(5);
    expect(existsSync(bObserved)).toBe(true);

    let heldBytes = "";
    graceCursorModule.withCandidateLock(root, "C-RACE", () => {
      heldBytes = readFileSync(lockPath, "utf8");
      // Let B resume from its stale observation and attempt to reclaim.
      writeFileSync(bRelease, "go");
      Bun.sleepSync(500);
      // B observed the dead bytes; A replaced them. B must not unlink A's bytes.
      expect(existsSync(lockPath)).toBe(true);
      expect(readFileSync(lockPath, "utf8")).toBe(heldBytes);
      expect(existsSync(bBeforeUnlink)).toBe(false);
      expect(existsSync(bAcquired)).toBe(false);
    });
    // A released: B acquires on its own retry and removes only its own lock.
    for (let i = 0; i < 1000 && !existsSync(bDone); i += 1) await Bun.sleep(5);
    expect(existsSync(bDone)).toBe(true);
    expect(existsSync(bAcquired)).toBe(true);
    expect(existsSync(lockPath)).toBe(false);
    rmSync(root, { recursive: true, force: true });
    await b.exited;
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-002: regenerate entry locking and alias mapping.
describe("regenerate entry lock", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");
  const graceBin = path.join(repoRoot, "src", "grace.ts");

  it("AC-REGEN-ENTRY-LOCK: pending under a live publisher, then post-lock dirty refusal with default allowDirty:false", async () => {
    const root = createProject();
    writeMinimalNgraceProject(root);
    mkdirSync(path.join(root, ARTIFACT_DIR, "changes", "active"), { recursive: true });
    initGitBaseline(root);
    const pauseFile = path.join(root, "release-publisher");
    const env = { ...process.env, NGRACE_PAUSE_CANDIDATE_FILE: pauseFile };
    const publisher = Bun.spawn({
      cmd: [process.execPath, graceBin, "spec", "new", "REGEN", "--timestamp", "2026-09-19T00:00:00Z", "--branch", "probe", "--path", root],
      cwd: repoRoot,
      env,
      stdout: "pipe",
      stderr: "pipe",
    });
    const activeDir = path.join(root, ARTIFACT_DIR, "changes", "active");
    let id: string | undefined;
    for (let i = 0; i < 400 && !id; i += 1) {
      const found = existsSync(activeDir) ? readdirSync(activeDir).find((name) => name.startsWith("C-REGEN-1-")) : undefined;
      if (found && existsSync(path.join(activeDir, found, "spec.xml"))) id = found;
      if (!id) await Bun.sleep(5);
    }
    expect(id).toBeDefined();
    const bundle = path.join(activeDir, id!);
    const cursorPath = path.join(bundle, "run.xml");
    // Dirt created while the publisher holds the lock.
    writeFileSync(path.join(root, "regen-dirt.txt"), "dirty\n");
    const contender = Bun.spawn({
      cmd: [process.execPath, graceBin, "cursor", "regenerate", "--change", id!, "--apply", "--path", root],
      cwd: repoRoot,
      stdout: "pipe",
      stderr: "pipe",
    });
    await Bun.sleep(300);
    // Pending and byte-invariant: no run.xml written while the lock is held.
    expect(existsSync(cursorPath)).toBe(false);
    writeFileSync(pauseFile, "go\n");
    await publisher.exited;
    const code = await contender.exited;
    expect(code).not.toBe(0);
    // Post-lock dirty refusal, not the pre-lock one; no write.
    expect(existsSync(cursorPath)).toBe(false);
  });

  it("AC-REGEN-ENTRY-LOCK controls: clean tree writes; allowDirty:true writes over dirt", () => {
    const clean = createProject();
    writeMinimalNgraceProject(clean);
    seedBundle(clean, "C-REGEN-CLEAN");
    initGitBaseline(clean);
    const applied = graceCursorModule.regenerateCursor(clean, "C-REGEN-CLEAN", { apply: true });
    expect(applied.applied).toBe(true);
    expect(existsSync(path.join(clean, ARTIFACT_DIR, "changes", "active", "C-REGEN-CLEAN", "run.xml"))).toBe(true);

    const dirty = createProject();
    writeMinimalNgraceProject(dirty);
    seedBundle(dirty, "C-REGEN-DIRTY");
    initGitBaseline(dirty);
    writeFileSync(path.join(dirty, "dirt.txt"), "dirty\n");
    const allowed = graceCursorModule.regenerateCursor(dirty, "C-REGEN-DIRTY", { apply: true, allowDirty: true });
    expect(allowed.applied).toBe(true);
  });
});

describe("pause/resume alias mapping", () => {
  it("AC-ALIAS-MAPPING: pauseCursor and resumeCursor are exported and delegate to advanceCursor", () => {
    const src = readFileSync(path.join(import.meta.dir, "grace-cursor.ts"), "utf8");
    expect(typeof graceCursorModule.pauseCursor).toBe("function");
    expect(typeof graceCursorModule.resumeCursor).toBe("function");
    expect(src).toMatch(/export function pauseCursor\([\s\S]*?return advanceCursor\(projectRoot, changeId, \{ task, kind: "pause" \}\);/);
    expect(src).toMatch(/export function resumeCursor\([\s\S]*?return advanceCursor\(projectRoot, changeId, \{[\s\S]*?kind: "resume"/);
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-002: filesystem-identity reclaim control.
describe("candidate reclaim identity", () => {
  it("AC-CANDIDATE-RECLAIM-EXCLUSIVE: a same-bytes replacement inode is not unlinked", async () => {
    const lockDirFor = (root: string) => path.join(root, ARTIFACT_DIR, "changes", "active");
    const lockPathFor = (root: string, id: string) => path.join(lockDirFor(root), `.candidate-${id}.lock`);
    const root = mkdtempSync(path.join(os.tmpdir(), "grace-reclaim-ident-"));
    mkdirSync(lockDirFor(root), { recursive: true });
    const lockPath = lockPathFor(root, "C-IDENT");
    const stale = `2147483647\n${Date.now()}\ndead-token\n`;
    writeFileSync(lockPath, stale, { flag: "wx" });
    const bReplaced = path.join(root, "b-replaced");
    const bSecond = path.join(root, "b-second-observed");
    const bAcquired = path.join(root, "b-acquired");
    const body = `
      const fs = require('node:fs');
      const mod = await import(${JSON.stringify(path.join(import.meta.dir, "grace-cursor.ts"))});
      let observed = 0;
      let replaced = false;
      mod.setCandidateReclaimProbeForTests((phase, lockPath) => {
        if (phase === 'observed') {
          observed += 1;
          if (observed >= 2) { fs.writeFileSync(${JSON.stringify(bSecond)}, '1'); while (true) Bun.sleep(50); }
        } else if (!replaced) {
          replaced = true;
          const bytes = fs.readFileSync(lockPath, 'utf8');
          fs.unlinkSync(lockPath);
          fs.writeFileSync(lockPath, bytes, { flag: 'wx' });
          fs.writeFileSync(${JSON.stringify(bReplaced)}, String(fs.statSync(lockPath).ino));
        }
      });
      mod.withCandidateLock(${JSON.stringify(root)}, 'C-IDENT', () => { fs.writeFileSync(${JSON.stringify(bAcquired)}, '1'); });
    `;
    const b = Bun.spawn({ cmd: [process.execPath, "-e", body], stdout: "pipe", stderr: "pipe" });
    for (let i = 0; i < 400 && !existsSync(bReplaced); i += 1) await Bun.sleep(5);
    expect(existsSync(bReplaced)).toBe(true);
    const replacementIno = Number(readFileSync(bReplaced, "utf8"));
    for (let i = 0; i < 800 && !existsSync(bSecond); i += 1) await Bun.sleep(5);
    expect(existsSync(bSecond), "B retried and observed the replacement").toBe(true);
    expect(existsSync(bAcquired), "B never acquired by unlinking the replacement inode").toBe(false);
    expect(statSync(lockPath).ino, "the replacement inode survives").toBe(replacementIno);
    expect(readFileSync(lockPath, "utf8")).toBe(stale);
    b.kill();
    await b.exited;
    rmSync(root, { recursive: true, force: true });
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-002: the exact-path dirty filter.
describe("dirty filter exact path", () => {
  const repoRoot = path.resolve(import.meta.dir, "..");

  function dirtyFixture(changeId: string, nearRel: string): string {
    const root = createProject();
    writeMinimalNgraceProject(root);
    seedBundle(root, changeId);
    // Track the near-miss so its full path (not a collapsed untracked directory) is
    // what git status reports, then modify it so the tree is dirty.
    const near = path.join(root, nearRel);
    mkdirSync(path.dirname(near), { recursive: true });
    writeFileSync(near, "committed\n");
    initGitBaseline(root);
    writeFileSync(near, "modified\n");
    return root;
  }

  it("AC-REGEN-ENTRY-LOCK: a tracked nested near-miss lock basename keeps the tree dirty", () => {
    const changeId = "C-REGEN-MISS";
    const root = dirtyFixture(changeId, path.join("nested", ".ngrace", "changes", "active", `.candidate-${changeId}.lock`));
    const cursorPath = path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run.xml");
    expect(() => graceCursorModule.regenerateCursor(root, changeId, { apply: true })).toThrow(/dirty/i);
    expect(existsSync(cursorPath)).toBe(false);
  });

  it("AC-REGEN-ENTRY-LOCK: a quoted path with a space still counts as dirt", () => {
    const changeId = "C-REGEN-QUOTED";
    const root = dirtyFixture(changeId, path.join("nested dir", "user note.txt"));
    const cursorPath = path.join(root, ARTIFACT_DIR, "changes", "active", changeId, "run.xml");
    expect(() => graceCursorModule.regenerateCursor(root, changeId, { apply: true })).toThrow(/dirty/i);
    expect(existsSync(cursorPath)).toBe(false);
  });
});

// C-SUPERSEDE-MEMBERSHIP-2-C459A20C T-006: exact epoch payload preservation.
describe("epoch payload preservation", () => {
  function canonicalNode(node: GraceXmlNode): unknown {
    const attrs = Object.fromEntries(Object.entries(node.attributes ?? {}).sort(([a], [b]) => a.localeCompare(b)));
    return { tag: node.tag, attrs, text: node.text ?? "", children: (node.children ?? []).map(canonicalNode) };
  }
  const canonicalChildren = (children: GraceXmlNode[]): string => JSON.stringify(children.map(canonicalNode));

  it("each folded event matches its loose event under expectedLedgerEventAttributes plus complete child subtrees", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-PAYLOAD");
    advanceCursor(root, "C-PAYLOAD", { task: "T-001", openEpoch: true, from: 1, to: 10 });
    recordAttempt(root, "C-PAYLOAD", {
      task: "T-001",
      outcome: "fail",
      signature: { kind: "compile", key: "T-001" },
      writeEvidence: { available: true, files: [{ path: "src/example.ts", kind: "content", digest: "digest-abc" }] },
    });
    advanceCursor(root, "C-PAYLOAD", { task: "T-001", kind: "terminal" });
    const loose = listLooseEvents(bundle);
    expect(loose.some((event) => event.children.length > 0), "fixture has nontrivial children").toBe(true);
    foldEpoch(root, "C-PAYLOAD");
    const folded = listLedgerEvents(bundle);
    expect(folded).toHaveLength(loose.length);
    for (const event of loose) {
      const written = folded.find((candidate) => candidate.id === event.id);
      expect(written, `event ${event.id} folded`).toBeDefined();
      expect(expectedLedgerEventAttributes(written!)).toEqual(expectedLedgerEventAttributes(event));
      expect(canonicalChildren(written!.children), `event ${event.id} child subtrees`).toBe(canonicalChildren(event.children));
    }
    expect(folded.filter((event) => event.id === 1)).toHaveLength(1);
    // Non-vacuity: the comparator detects a mutated child attribute (the fold's own
    // verify already rejects such a write, so this proves the test layer too).
    const withChild = loose.find((event) => event.children.length > 0)!;
    const mutated = withChild.children.map((child) => ({ ...child, attributes: { ...child.attributes, to: "999" } }));
    expect(canonicalChildren(mutated as GraceXmlNode[])).not.toBe(canonicalChildren(withChild.children));
  });

  it("negative controls: the comparator detects attribute, text-whitespace, order, and nested-descendant changes", () => {
    const node = (tag: string, attributes: Record<string, string>, text: string, children: GraceXmlNode[] = []): GraceXmlNode =>
      ({ tag, attributes, text, children });
    const childA = node("Note", { key: "a" }, "A");
    const childB = node("Note", { key: "b" }, "B");
    const base = node("Allocation", { worker: "w0", from: "1", to: "10" }, "", [childA, childB]);
    const reversed = node("Allocation", { worker: "w0", from: "1", to: "10" }, "", [childB, childA]);
    const extra = node("Allocation", { worker: "w0", from: "1", to: "10" }, "", [childA, childB, node("Note", { key: "c" }, "C")]);
    const changedAttr = node("Allocation", { worker: "w0", from: "1", to: "999" }, "", [childA, childB]);
    const changedTextWhitespace = node("Allocation", { worker: "w0", from: "1", to: "10" }, "", [childA, node("Note", { key: "b" }, " B ")]);
    const nested = node("Allocation", { worker: "w0", from: "1", to: "10" }, "", [childA, node("Note", { key: "b" }, "B", [node("Deep", {}, "d")])]);
    expect(canonicalChildren([reversed]), "same two children reversed").not.toBe(canonicalChildren([base]));
    expect(canonicalChildren([extra]), "one extra child").not.toBe(canonicalChildren([base]));
    expect(canonicalChildren([changedAttr]), "attribute change").not.toBe(canonicalChildren([base]));
    expect(canonicalChildren([changedTextWhitespace]), "leading/trailing whitespace change").not.toBe(canonicalChildren([base]));
    expect(canonicalChildren([nested]), "nested descendant").not.toBe(canonicalChildren([base]));
  });
});

// ---------------------------------------------------------------------------
// F295 fold consequences (C-FOLD-MEMBERSHIP-RECOVERY-2-2E6A79D5 T-002)
// ---------------------------------------------------------------------------

const FOLD_REPO_ROOT = path.resolve(import.meta.dir, "..");
const FOLD_INSTRUMENT_DIR = mkdtempSync(path.join(os.tmpdir(), "fold-instrument-"));
const FOLD_LATE_PRELOAD = path.join(FOLD_INSTRUMENT_DIR, "late-preload.ts");
writeFileSync(
  FOLD_LATE_PRELOAD,
  [
    'import fs from "node:fs";',
    'import { mock } from "bun:test";',
    "let fired = false;",
    "const realExists = fs.existsSync;",
    "const realRead = fs.readFileSync;",
    "const target = process.env.LATE_TARGET!;",
    "const instrumented = function (file: any, ...args: any[]) {",
    "  if (!fired && String(file) === target && realExists(target)) {",
    "    fired = true;",
    '    fs.rmSync(target, { force: true });',
    '    process.stderr.write("LATE_FIRED\\n");',
    "  }",
    "  return realRead.call(fs, file, ...args);",
    "};",
    'mock.module("node:fs", () => ({ ...fs, readFileSync: instrumented }));',
    'process.on("exit", () => { if (!fired) { process.stderr.write("LATE_NOT_FIRED\\n"); process.exitCode = 97; } });',
  ].join("\n"),
);

function foldGrace(
  root: string,
  args: string[],
  options: { preload?: string; env?: Record<string, string> } = {},
): { exit: number; stdout: string; stderr: string; fired: boolean } {
  const cmd = [
    process.execPath,
    ...(options.preload ? ["--preload", options.preload] : []),
    "./src/grace.ts",
    ...args,
    "--path",
    root,
  ];
  const result = Bun.spawnSync({
    cmd,
    cwd: FOLD_REPO_ROOT,
    stdout: "pipe",
    stderr: "pipe",
    env: { ...process.env, ...options.env },
  });
  const stdout = Buffer.from(result.stdout).toString("utf8");
  const stderr = Buffer.from(result.stderr).toString("utf8");
  return { exit: result.exitCode, stdout, stderr, fired: stderr.includes("LATE_FIRED") };
}

/** Recursive snapshot of run/ that records directory entries as well as file bytes. */
function snapshotRun(run: string): Record<string, string> {
  const acc: Record<string, string> = {};
  const walk = (dir: string) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      const rel = path.relative(run, full);
      if (entry.isDirectory()) {
        acc[rel] = "DIR";
        walk(full);
      } else if (entry.isFile()) {
        acc[rel] = readFileSync(full, "utf8");
      } else {
        acc[rel] = "OTHER";
      }
    }
  };
  walk(run);
  return acc;
}

const foldOpened = (id: number) =>
  `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="opened"><Allocation worker="w0" from="${id}" to="99"/></NgraceRunEvent>`;
const foldEvent = (id: number, kind: string) =>
  `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="${kind}"/>`;

describe("F295 fold consequences (AC-MEMBER-FOLD-CONSEQUENCES)", () => {
  it("(a) an interior hole refuses with a byte-identical run/ listing and no ledger", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-HOLE");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "3-T-001-terminal.xml"), foldEvent(3, "terminal"));
    const before = snapshotRun(run);
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-HOLE"]);
    expect(fold.exit).not.toBe(0);
    expect(fold.stdout + fold.stderr).toMatch(/range hole at 2 for w0/);
    expect(snapshotRun(run)).toEqual(before);
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
    rmSync(root, { recursive: true, force: true });
  });

  it("(b) a trailing event removed in the true late window folds the survivors with no ghost", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-TRAIL");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-progress.xml"), foldEvent(2, "progress"));
    writeFileSync(path.join(run, "3-T-001-terminal.xml"), foldEvent(3, "terminal"));
    const target = path.join(run, "4-T-001-progress.xml");
    writeFileSync(target, foldEvent(4, "progress"));
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-TRAIL"], {
      preload: FOLD_LATE_PRELOAD,
      env: { LATE_TARGET: target },
    });
    expect(fold.fired, "the after-existsSync interceptor must report it fired").toBe(true);
    expect(fold.exit).toBe(0);
    expect(readdirSync(run)).toEqual([]);
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(ledger).toContain('Event id="1" task="T-001" kind="opened"');
    expect(ledger).toContain('Event id="2" task="T-001" kind="progress"');
    expect(ledger).toContain('Event id="3" task="T-001" kind="terminal"');
    expect(ledger).not.toContain('Event id="4"');
    rmSync(root, { recursive: true, force: true });
  });

  it("(c) a vanished opened folds with only one fresh covering opened", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-VANISH");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-progress.xml"), foldEvent(2, "progress"));
    writeFileSync(path.join(run, "3-T-001-terminal.xml"), foldEvent(3, "terminal"));
    rmSync(path.join(run, "1-T-001-opened.xml"), { force: true });
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-VANISH"]);
    expect(fold.exit).toBe(0);
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(ledger).toContain('Event id="2" task="T-001" kind="progress"');
    expect(ledger).toContain('Event id="3" task="T-001" kind="terminal"');
    expect(ledger).not.toContain('Event id="1"');
    const openedIds = [...ledger.matchAll(/Event id="(\d+)"[^>]*kind="opened"/g)].map((match) => Number(match[1]));
    expect(openedIds).toHaveLength(1);
    expect(openedIds[0]).toBeGreaterThanOrEqual(4);
    rmSync(root, { recursive: true, force: true });
  });
});

// ---------------------------------------------------------------------------
// F315 malformed/unreadable input at both write boundaries (C-LOOSE-MALFORMED-FOLD-1-4C18E876 T-001)
// ---------------------------------------------------------------------------

/** Recursive project snapshot: directory entries, symlinks, relative paths, and per-file sha256. */
function snapshotTree(root: string): Record<string, string> {
  const acc: Record<string, string> = {};
  const walk = (dir: string) => {
    for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const full = path.join(dir, entry.name);
      const rel = path.relative(root, full);
      if (entry.isSymbolicLink()) {
        acc[rel] = "SYMLINK:" + readlinkSync(full);
      } else if (entry.isDirectory()) {
        acc[rel] = "DIR";
        walk(full);
      } else if (entry.isFile()) {
        acc[rel] = "FILE:" + createHash("sha256").update(readFileSync(full)).digest("hex");
      } else {
        acc[rel] = "OTHER";
      }
    }
  };
  walk(root);
  return acc;
}

describe("F315 fold/discard refusal (AC-MEMBER-MALFORMED-AND-UNREADABLE)", () => {
  it("ordinary fold refuses a malformed closer before any write, naming the file and xml.parse", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-MALFOLD");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-terminal.xml"), "<broken");
    const before = snapshotTree(root);
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-MALFOLD"]);
    expect(fold.exit).not.toBe(0);
    expect(fold.stdout + fold.stderr).toContain("2-T-001-terminal.xml");
    expect(fold.stdout + fold.stderr).toContain("xml.parse");
    expect(snapshotTree(root)).toEqual(before);
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
    rmSync(root, { recursive: true, force: true });
  });

  it("ordinary fold refuses a malformed progress with a valid later terminal before any write", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-MALPROG");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-progress.xml"), "<broken");
    writeFileSync(path.join(run, "3-T-001-terminal.xml"), foldEvent(3, "terminal"));
    const before = snapshotTree(root);
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-MALPROG"]);
    expect(fold.exit).not.toBe(0);
    expect(fold.stdout + fold.stderr).toContain("2-T-001-progress.xml");
    expect(fold.stdout + fold.stderr).toContain("xml.parse");
    expect(snapshotTree(root)).toEqual(before);
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
    rmSync(root, { recursive: true, force: true });
  });

  it("valid closer folds successfully (positive control)", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-VALID");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-terminal.xml"), foldEvent(2, "terminal"));
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-VALID"]);
    expect(fold.exit).toBe(0);
    rmSync(root, { recursive: true, force: true });
  });

  it("a simply absent trailing file is tolerated (F295 control)", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-ABSENT");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-progress.xml"), foldEvent(2, "progress"));
    writeFileSync(path.join(run, "3-T-001-terminal.xml"), foldEvent(3, "terminal"));
    writeFileSync(path.join(run, "4-T-001-progress.xml"), foldEvent(4, "progress"));
    rmSync(path.join(run, "4-T-001-progress.xml"), { force: true });
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-ABSENT"]);
    expect(fold.exit).toBe(0);
    rmSync(root, { recursive: true, force: true });
  });

  it("a parseable event with omitted attributes keeps the filename fallback", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-OMIT");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-progress.xml"), `<NgraceRunEvent graceVersion="1.0"/>`);
    writeFileSync(path.join(run, "3-T-001-terminal.xml"), foldEvent(3, "terminal"));
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-OMIT"]);
    expect(fold.exit).toBe(0);
    rmSync(root, { recursive: true, force: true });
  });

  it("a directory at the event path exits non-zero, preserves EISDIR, and names the path", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-DIR");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    const eventDir = path.join(run, "2-T-001-progress.xml");
    mkdirSync(eventDir);
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-DIR"]);
    expect(fold.exit).not.toBe(0);
    expect(fold.stdout + fold.stderr).toMatch(/EISDIR|illegal operation on a directory/i);
    expect(fold.stdout + fold.stderr).toContain(eventDir);
    rmSync(root, { recursive: true, force: true });
  });

  it("real ngrace supersede refuses malformed input before writing discarded and leaves both bundles in place", () => {
    const root = createProject();
    seedBundle(root, "C-OLD");
    writeChangeBundleFixture(root, { changeId: "C-OLD-2", location: "active", specStatus: "draft", planStatus: "draft" });
    const run = path.join(root, ".ngrace", "changes", "active", "C-OLD", "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), foldOpened(1));
    writeFileSync(path.join(run, "2-T-001-progress.xml"), "<broken"); // no closer
    const before = snapshotTree(root);
    const result = foldGrace(root, ["supersede", "--change", "C-OLD", "--replacement", "C-OLD-2"]);
    expect(result.exit).not.toBe(0);
    expect(result.stdout + result.stderr).toContain("2-T-001-progress.xml");
    expect(result.stdout + result.stderr).toContain("xml.parse");
    expect(readdirSync(run).some((name) => name.includes("discarded"))).toBe(false);
    expect(existsSync(path.join(root, ".ngrace/changes/active/C-OLD/spec.xml"))).toBe(true);
    expect(existsSync(path.join(root, ".ngrace/changes/active/C-OLD-2/spec.xml"))).toBe(true);
    expect(existsSync(path.join(root, ".ngrace/changes/archive/C-OLD/spec.xml"))).toBe(false);
    expect(snapshotTree(root)).toEqual(before);
    rmSync(root, { recursive: true, force: true });
  });
});

// ---------------------------------------------------------------------------
// C-FOLD-RETRY-CORE-1-000C564C T-001: interrupted-fold recovery (F313)
// ---------------------------------------------------------------------------

function b3EpochNumbers(bundle: string): number[] {
  const ledger = path.join(bundle, "run-ledger.xml");
  if (!existsSync(ledger)) return [];
  return [...readFileSync(ledger, "utf8").matchAll(/<Epoch-(\d+)>/g)]
    .map((match) => Number(match[1]))
    .sort((a, b) => a - b);
}

function b3EpochSlice(bundle: string, epoch: number): string {
  const text = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
  const match = new RegExp(`<Epoch-${epoch}>[\\s\\S]*?</Epoch-${epoch}>`).exec(text);
  return match ? match[0] : "";
}

const b3Opened = (id: number) =>
  `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="opened"><Allocation worker="w0" from="${id}" to="99"/></NgraceRunEvent>`;
const b3Event = (id: number, kind: string) =>
  `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="${kind}"/>`;

/** Independent payload comparison: expectedLedgerEventAttributes plus complete children. */
function b3Payload(event: any): string {
  const attributes = expectedLedgerEventAttributes(event);
  return JSON.stringify({
    attributes: Object.keys(attributes)
      .sort()
      .map((key) => [key, attributes[key]]),
    children: event.children,
  });
}

function b3Seed(changeId: string) {
  const root = createProject();
  const bundle = seedBundle(root, changeId);
  const run = path.join(bundle, "run");
  mkdirSync(run, { recursive: true });
  writeFileSync(path.join(run, "1-T-001-opened.xml"), b3Opened(1));
  writeFileSync(path.join(run, "2-T-001-terminal.xml"), b3Event(2, "terminal"));
  return { root, bundle, run };
}

describe("F313 interrupted-fold recovery (AC-FOLD-RETRY-IDEMPOTENT)", () => {
  for (const hook of ["injectFailureBeforeVerify", "injectFailureAfterWrite"] as const) {
    it(`${hook}: the real-CLI retry reuses the written epoch once and empties run/`, () => {
      const { root, bundle } = b3Seed("C-RETRY");
      expect(() => foldEpoch(root, "C-RETRY", hook === "injectFailureBeforeVerify" ? { injectFailureBeforeVerify: true } : { injectFailureAfterWrite: true })).toThrow();
      expect(b3EpochNumbers(bundle)).toEqual([1]);
      expect(listLooseEvents(bundle)).toHaveLength(2);
      const retry = foldGrace(root, ["cursor", "fold", "--change", "C-RETRY"]);
      expect(retry.exit).toBe(0);
      expect(b3EpochNumbers(bundle)).toEqual([1]);
      expect(listLooseEvents(bundle)).toHaveLength(0);
      rmSync(root, { recursive: true, force: true });
    });
  }

  for (const hook of ["injectFailureBeforeVerify", "injectFailureAfterWrite"] as const) {
    it(`${hook}: same-hook interruption/recovery on two successive fresh epochs keeps each logical epoch once`, () => {
      const { root, bundle, run } = b3Seed("C-SUCC");
      const injection = hook === "injectFailureBeforeVerify" ? { injectFailureBeforeVerify: true } : { injectFailureAfterWrite: true };
      expect(() => foldEpoch(root, "C-SUCC", injection)).toThrow();
      expect(foldGrace(root, ["cursor", "fold", "--change", "C-SUCC"]).exit).toBe(0);
      const epoch1 = b3EpochSlice(bundle, 1);
      writeFileSync(path.join(run, "3-T-001-opened.xml"), b3Opened(3));
      writeFileSync(path.join(run, "4-T-001-terminal.xml"), b3Event(4, "terminal"));
      expect(() => foldEpoch(root, "C-SUCC", injection)).toThrow();
      expect(foldGrace(root, ["cursor", "fold", "--change", "C-SUCC"]).exit).toBe(0);
      expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
      expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
      expect(listLooseEvents(bundle)).toHaveLength(0);
      rmSync(root, { recursive: true, force: true });
    });
  }

  it("the third empty fold is a no-op returning the same last epoch with eventCount 0", () => {
    const { root, bundle } = b3Seed("C-EMPTY");
    expect(() => foldEpoch(root, "C-EMPTY", { injectFailureAfterWrite: true })).toThrow();
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-EMPTY"]).exit).toBe(0);
    const empty = foldEpoch(root, "C-EMPTY");
    expect(empty.eventCount).toBe(0);
    expect(empty.epoch).toBe(1);
    expect(b3EpochNumbers(bundle)).toEqual([1]);
    rmSync(root, { recursive: true, force: true });
  });

  it("a partial verified deletion (first delete-loop event) resumes with the recorded ledger bytes and payload preserved", () => {
    const { root, bundle, run } = b3Seed("C-PARTIAL");
    const looseTerminal = b3Payload(listLooseEvents(bundle).find((event) => event.id === 2)!);
    expect(() => foldEpoch(root, "C-PARTIAL", { injectFailureAfterWrite: true })).toThrow();
    const recordedLedger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    rmSync(path.join(run, "1-T-001-opened.xml"), { force: true });
    const retry = foldGrace(root, ["cursor", "fold", "--change", "C-PARTIAL"]);
    expect(retry.exit).toBe(0);
    expect(readFileSync(path.join(bundle, "run-ledger.xml"), "utf8")).toBe(recordedLedger);
    expect(b3EpochNumbers(bundle)).toEqual([1]);
    expect(listLooseEvents(bundle)).toHaveLength(0);
    const recorded = listLedgerEvents(bundle);
    expect(recorded.filter((event) => event.kind === "opened")).toHaveLength(1);
    expect(b3Payload(recorded.find((event) => event.id === 2)!)).toBe(looseTerminal);
    rmSync(root, { recursive: true, force: true });
  });

  it("a prior completed epoch stays byte-identical across a later recovery, and a fresh-only set folds normally", () => {
    const { root, bundle, run } = b3Seed("C-PRIOR");
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-PRIOR"]).exit).toBe(0);
    const epoch1 = b3EpochSlice(bundle, 1);
    writeFileSync(path.join(run, "3-T-001-opened.xml"), b3Opened(3));
    writeFileSync(path.join(run, "4-T-001-terminal.xml"), b3Event(4, "terminal"));
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-PRIOR"]).exit).toBe(0);
    expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
    expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
    rmSync(root, { recursive: true, force: true });
  });

  it("a genuine payload conflict refuses naming the id and the mismatch, with the whole tree unchanged", () => {
    const { root, bundle, run } = b3Seed("C-CONFLICT");
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-CONFLICT"]).exit).toBe(0);
    writeFileSync(
      path.join(run, "1-T-001-opened.xml"),
      `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened" outcome="different"><Allocation worker="w0" from="1" to="99"/></NgraceRunEvent>`,
    );
    const before = snapshotTree(root);
    const conflict = foldGrace(root, ["cursor", "fold", "--change", "C-CONFLICT"]);
    expect(conflict.exit).not.toBe(0);
    expect(conflict.stdout + conflict.stderr).toMatch(/\b1\b/);
    expect(conflict.stdout + conflict.stderr).toMatch(/payload|mismatch/i);
    expect(snapshotTree(root)).toEqual(before);
    expect(b3EpochNumbers(bundle)).toEqual([1]);
    rmSync(root, { recursive: true, force: true });
  });

  it("an older-epoch id reuse refuses naming the id and the older epoch, with the whole tree unchanged", () => {
    const { root, bundle, run } = b3Seed("C-OLDER");
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-OLDER"]).exit).toBe(0);
    writeFileSync(path.join(run, "3-T-001-opened.xml"), b3Opened(3));
    writeFileSync(path.join(run, "4-T-001-terminal.xml"), b3Event(4, "terminal"));
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-OLDER"]).exit).toBe(0);
    writeFileSync(path.join(run, "1-T-001-opened.xml"), b3Opened(1));
    writeFileSync(path.join(run, "2-T-001-terminal.xml"), b3Event(2, "terminal"));
    const before = snapshotTree(root);
    const older = foldGrace(root, ["cursor", "fold", "--change", "C-OLDER"]);
    expect(older.exit).not.toBe(0);
    expect(older.stdout + older.stderr).toMatch(/\b1\b/);
    expect(older.stdout + older.stderr).toMatch(/Epoch-1|older/i);
    expect(snapshotTree(root)).toEqual(before);
    expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
    rmSync(root, { recursive: true, force: true });
  });

  it("a post-ledger interruption preserves the written ledger across the retry and a second retry", () => {
    const { root, bundle } = b3Seed("C-POSTLEDGER");
    expect(() => foldEpoch(root, "C-POSTLEDGER", { injectFailureAfterWrite: true })).toThrow();
    const written = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-POSTLEDGER"]).exit).toBe(0);
    expect(readFileSync(path.join(bundle, "run-ledger.xml"), "utf8")).toBe(written);
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-POSTLEDGER"]).exit).toBe(0);
    expect(readFileSync(path.join(bundle, "run-ledger.xml"), "utf8")).toBe(written);
    expect(b3EpochNumbers(bundle)).toEqual([1]);
    expect(listLooseEvents(bundle)).toHaveLength(0);
    rmSync(root, { recursive: true, force: true });
  });
});

// ---------------------------------------------------------------------------
// C-FOLD-MIXED-RECOVERY-1-62A1B852 T-001: mixed residue-plus-fresh recovery
// ---------------------------------------------------------------------------

/**
 * The two bundle-4 stage hooks are test-only and land with the T-001 mechanism.
 * The intersection keeps this test file type-compatible with the pre-mechanism
 * base, so the base red is behavioral rather than a compile error.
 */
type FoldInjectionOptions = NonNullable<Parameters<typeof foldEpoch>[2]> & {
  injectFailureAfterResidueDelete?: boolean;
  injectFailureAfterAutoOpen?: boolean;
};

/** Measured fixture opened: Epoch-1 allocation is exactly w0[1,2]. */
const b4Opened = (id: number) =>
  `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="opened"><Allocation worker="w0" from="${id}" to="${id + 1}"/></NgraceRunEvent>`;

/**
 * The measured mixed fixture, reached through the product path: the initial loose
 * epoch {1:opened w0[1,2], 2:terminal} is folded and interrupted after the ledger
 * write, the shipped delete-loop's first delete (1-opened) leaves the matching
 * residue {2:terminal}, and F is later allocated by the real CLI.
 */
function b4MixedFixture(changeId: string) {
  const root = createProject();
  const bundle = seedBundle(root, changeId);
  const run = path.join(bundle, "run");
  mkdirSync(run, { recursive: true });
  writeFileSync(path.join(run, "1-T-001-opened.xml"), b4Opened(1));
  writeFileSync(path.join(run, "2-T-001-terminal.xml"), b3Event(2, "terminal"));
  expect(() => foldEpoch(root, changeId, { injectFailureAfterWrite: true })).toThrow();
  expect(b3EpochNumbers(bundle)).toEqual([1]);
  expect(listLooseEvents(bundle)).toHaveLength(2);
  rmSync(path.join(run, "1-T-001-opened.xml"), { force: true });
  expect(listLooseEvents(bundle).map((event) => event.id)).toEqual([2]);
  return { root, bundle, run };
}

/** Allocate F={3:progress, 4:terminal} through the real CLI (the allocator, not a direct write). */
function b4AllocateFresh(root: string, changeId: string): void {
  expect(foldGrace(root, ["cursor", "advance", "--change", changeId, "--task", "T-001"]).exit).toBe(0);
  expect(
    foldGrace(root, ["cursor", "advance", "--change", changeId, "--task", "T-001", "--kind", "terminal"]).exit,
  ).toBe(0);
}

/** Epoch Event ids+kinds, parsed from the durable ledger slice. */
function b4EpochEvents(bundle: string, epoch: number): Array<{ id: number; kind: string }> {
  return [...b3EpochSlice(bundle, epoch).matchAll(/<Event\b([^>]*?)\/?>/g)].map((match) => ({
    id: Number(/\bid="(\d+)"/.exec(match[1]!)?.[1] ?? "0"),
    kind: /\bkind="([^"]*)"/.exec(match[1]!)?.[1] ?? "",
  }));
}

/** Byte snapshot of every file in run/, keyed by filename. */
function b4RunBytes(run: string): Record<string, string> {
  const acc: Record<string, string> = {};
  for (const entry of readdirSync(run)) acc[entry] = readFileSync(path.join(run, entry), "utf8");
  return acc;
}

/** The captured bytes of F={3:progress, 4:terminal} alone. */
const b4FBytes = (run: string) => ({
  "3-T-001-progress.xml": readFileSync(path.join(run, "3-T-001-progress.xml"), "utf8"),
  "4-T-001-terminal.xml": readFileSync(path.join(run, "4-T-001-terminal.xml"), "utf8"),
});

describe("C-FOLD-MIXED-RECOVERY mixed residue-plus-fresh (AC-FOLD-MIXED-RECOVERY)", () => {
  it("real CLI folds exactly F union A once, leaves Epoch-1 byte-identical, and never re-folds the residue", () => {
    const { root, bundle, run } = b4MixedFixture("C-MIXED");
    b4AllocateFresh(root, "C-MIXED");
    expect(listLooseEvents(bundle).map((event) => event.id)).toEqual([2, 3, 4]);
    const epoch1 = b3EpochSlice(bundle, 1);
    const looseF = new Map(
      listLooseEvents(bundle)
        .filter((event) => event.id === 3 || event.id === 4)
        .map((event) => [event.id, b3Payload(event)]),
    );
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-MIXED"]);
    expect(fold.exit).toBe(0);
    expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
    expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
    const epoch2 = b4EpochEvents(bundle, 2);
    // No already-recorded event is duplicated; only the fresh set is folded.
    expect(epoch2.map((event) => event.id).sort((a, b) => a - b)).toEqual([3, 4, 5]);
    expect(epoch2.filter((event) => event.id === 1 || event.id === 2)).toEqual([]);
    // No opened is synthesized for the already-recorded epoch; exactly one fresh A.
    expect(epoch2.filter((event) => event.kind === "opened").map((event) => event.id)).toEqual([5]);
    // The measured covering allocation runs from the fresh minimum 3, not the residue id 2.
    expect(b3EpochSlice(bundle, 2)).toContain('Allocation worker="w0" from="3" to="103"');
    // Independent payload comparison of F through the recorded ledger, never the writer's transform.
    for (const event of listLedgerEvents(bundle).filter((entry) => entry.id === 3 || entry.id === 4)) {
      expect(b3Payload(event)).toBe(looseF.get(event.id)!);
    }
    expect(readdirSync(run)).toEqual([]);
    rmSync(root, { recursive: true, force: true });
  });

  it("progress-only F_bad refuses unterminated range with a byte-complete snapshot and no synthesized opened", () => {
    const { root, bundle, run } = b4MixedFixture("C-BADFRESH");
    expect(foldGrace(root, ["cursor", "advance", "--change", "C-BADFRESH", "--task", "T-001"]).exit).toBe(0);
    expect(listLooseEvents(bundle).map((event) => event.id)).toEqual([2, 3]);
    const ledgerBefore = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    const before = snapshotTree(root);
    const fold = foldGrace(root, ["cursor", "fold", "--change", "C-BADFRESH"]);
    expect(fold.exit).not.toBe(0);
    expect(fold.stdout + fold.stderr).toContain("unterminated range for w0");
    expect(readFileSync(path.join(bundle, "run-ledger.xml"), "utf8")).toBe(ledgerBefore);
    expect(snapshotTree(root)).toEqual(before);
    expect(b3EpochNumbers(bundle)).toEqual([1]);
    expect(readdirSync(run).sort()).toEqual(["2-T-001-terminal.xml", "3-T-001-progress.xml"]);
    expect(listLooseEvents(bundle).some((event) => event.kind === "opened")).toBe(false);
    rmSync(root, { recursive: true, force: true });
  });

  it("injectFailureAfterResidueDelete leaves exactly F, and a real-CLI retry writes Epoch-2 once with no second opened", () => {
    const { root, bundle, run } = b4MixedFixture("C-RESIDUE");
    b4AllocateFresh(root, "C-RESIDUE");
    const epoch1 = b3EpochSlice(bundle, 1);
    const f = b4FBytes(run);
    const inject: FoldInjectionOptions = { injectFailureAfterResidueDelete: true };
    expect(() => foldEpoch(root, "C-RESIDUE", inject)).toThrow();
    expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
    expect(b3EpochNumbers(bundle)).toEqual([1]);
    // Hash-exact F: the residue entry is absent and the fresh bytes are unchanged.
    expect(b4RunBytes(run)).toEqual(f);
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-RESIDUE"]).exit).toBe(0);
    expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
    expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
    const epoch2 = b4EpochEvents(bundle, 2);
    expect(epoch2.map((event) => event.id).sort((a, b) => a - b)).toEqual([3, 4, 5]);
    expect(epoch2.filter((event) => event.kind === "opened").map((event) => event.id)).toEqual([5]);
    expect(readdirSync(run)).toEqual([]);
    // Second real-CLI retry is idempotent and writes no Epoch-3.
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-RESIDUE"]).exit).toBe(0);
    expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
    rmSync(root, { recursive: true, force: true });
  });

  it("injectFailureAfterAutoOpen leaves exactly F union A, and a real-CLI retry reuses A and writes Epoch-2 once", () => {
    const { root, bundle, run } = b4MixedFixture("C-AUTOOPEN");
    b4AllocateFresh(root, "C-AUTOOPEN");
    const epoch1 = b3EpochSlice(bundle, 1);
    const f = b4FBytes(run);
    const inject: FoldInjectionOptions = { injectFailureAfterAutoOpen: true };
    expect(() => foldEpoch(root, "C-AUTOOPEN", inject)).toThrow();
    expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
    expect(b3EpochNumbers(bundle)).toEqual([1]);
    // Hash-exact F union A: F bytes preserved, exactly one generated opened.
    const afterHook = b4RunBytes(run);
    expect(Object.keys(afterHook).sort()).toEqual([
      "3-T-001-progress.xml",
      "4-T-001-terminal.xml",
      "5-T-001-opened.xml",
    ]);
    expect(afterHook["3-T-001-progress.xml"]).toBe(f["3-T-001-progress.xml"]);
    expect(afterHook["4-T-001-terminal.xml"]).toBe(f["4-T-001-terminal.xml"]);
    const looseA = listLooseEvents(bundle).find((event) => event.id === 5)!;
    const aPayload = b3Payload(looseA);
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-AUTOOPEN"]).exit).toBe(0);
    const epoch2 = b4EpochEvents(bundle, 2);
    expect(epoch2.map((event) => event.id).sort((a, b) => a - b)).toEqual([3, 4, 5]);
    expect(epoch2.filter((event) => event.kind === "opened").map((event) => event.id)).toEqual([5]);
    expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
    expect(readdirSync(run)).toEqual([]);
    // Independent payload comparison: the generated A is the recorded Epoch-2 event.
    const recordedA = listLedgerEvents(bundle).find((event) => event.id === 5)!;
    expect(b3Payload(recordedA)).toBe(aPayload);
    expect(foldGrace(root, ["cursor", "fold", "--change", "C-AUTOOPEN"]).exit).toBe(0);
    expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
    rmSync(root, { recursive: true, force: true });
  });

  for (const hook of ["injectFailureBeforeVerify", "injectFailureAfterWrite"] as const) {
    it(`${hook} on the mixed path leaves Epoch-1 unchanged and F union A, then real-CLI retries are idempotent`, () => {
      const changeId = hook === "injectFailureBeforeVerify" ? "C-MIXED-BV" : "C-MIXED-AW";
      const { root, bundle, run } = b4MixedFixture(changeId);
      b4AllocateFresh(root, changeId);
      const epoch1 = b3EpochSlice(bundle, 1);
      const f = b4FBytes(run);
      const inject: FoldInjectionOptions =
        hook === "injectFailureBeforeVerify"
          ? { injectFailureBeforeVerify: true }
          : { injectFailureAfterWrite: true };
      expect(() => foldEpoch(root, changeId, inject)).toThrow();
      // Epoch-1 is captured before the injected fold and asserted byte-identical after it.
      expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
      expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
      const epoch2 = b3EpochSlice(bundle, 2);
      // The written Epoch-2 holds F union A; F bytes are preserved and A is one generated opened.
      const afterInjection = b4RunBytes(run);
      expect(Object.keys(afterInjection).sort()).toEqual([
        "3-T-001-progress.xml",
        "4-T-001-terminal.xml",
        "5-T-001-opened.xml",
      ]);
      expect(afterInjection["3-T-001-progress.xml"]).toBe(f["3-T-001-progress.xml"]);
      expect(afterInjection["4-T-001-terminal.xml"]).toBe(f["4-T-001-terminal.xml"]);
      const looseA = listLooseEvents(bundle).find((event) => event.id === 5)!;
      const aPayload = b3Payload(looseA);
      const recordedA = listLedgerEvents(bundle).find((event) => event.id === 5)!;
      expect(b3Payload(recordedA)).toBe(aPayload);
      // First real-CLI retry deletes the matching residue and writes no Epoch-3.
      expect(foldGrace(root, ["cursor", "fold", "--change", changeId]).exit).toBe(0);
      expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
      expect(b3EpochSlice(bundle, 1)).toBe(epoch1);
      expect(b3EpochSlice(bundle, 2)).toBe(epoch2);
      expect(readdirSync(run)).toEqual([]);
      // Second real-CLI retry is idempotent.
      expect(foldGrace(root, ["cursor", "fold", "--change", changeId]).exit).toBe(0);
      expect(b3EpochNumbers(bundle)).toEqual([1, 2]);
      expect(b3EpochSlice(bundle, 2)).toBe(epoch2);
      expect(readdirSync(run)).toEqual([]);
      rmSync(root, { recursive: true, force: true });
    });
  }
});


// ---------------------------------------------------------------------------
// C-DISCARD-PREFLIGHT-1-5087B21A: deterministic discard preflight (F158 / F292.1)
// ---------------------------------------------------------------------------

const b5Opened = (id: number, from: number, to: number) =>
  `<NgraceRunEvent graceVersion="1.0" id="${id}" task="T-001" kind="opened"><Allocation worker="w0" from="${from}" to="${to}"/></NgraceRunEvent>`;
const b5Event = (id: number, kind: string, task = "T-001") =>
  `<NgraceRunEvent graceVersion="1.0" id="${id}" task="${task}" kind="${kind}"/>`;

function b5Seed(changeId: string, events: Array<[string, string]>) {
  const root = createProject();
  const bundle = seedBundle(root, changeId);
  const run = path.join(bundle, "run");
  mkdirSync(run, { recursive: true });
  for (const [name, body] of events) writeFileSync(path.join(run, name), body);
  return { root, bundle, run };
}

function b5SeedPair(changeId: string, events: Array<[string, string]>) {
  const { root, bundle, run } = b5Seed(changeId, events);
  seedBundleReplacement(root);
  return { root, bundle, run };
}

function seedBundleReplacement(root: string) {
  writeChangeBundleFixture(root, {
    changeId: "C-OLD-2",
    location: "active",
    specStatus: "draft",
    planStatus: "draft",
  });
}

function b5Loose(bundle: string): string[] {
  const run = path.join(bundle, "run");
  return existsSync(run) ? readdirSync(run).sort() : [];
}

/** Test-only seam: the candidate accepts it; the untouched base ignores the extra arg. */
const discardWithSeam = discardAndFoldEpoch as unknown as (
  root: string,
  changeId: string,
  options: { afterPreflight?: () => void },
) => unknown;

/**
 * Complete ledger projection: every event's full expected attributes (independent
 * `expectedLedgerEventAttributes`, never the writer transform) plus its complete child
 * subtree. Two projections compare the whole payload, not a regex count.
 */
function b5Normalize(nodes: GraceXmlNode[]): unknown {
  return nodes.map((node) => ({
    tag: node.tag,
    text: node.text,
    attributes: Object.entries(node.attributes).sort(),
    children: b5Normalize(node.children),
  }));
}

function b5Projection(events: LooseEvent[]): string {
  return JSON.stringify(
    events.map((event) => ({
      attributes: Object.entries(expectedLedgerEventAttributes(event)).sort(),
      children: b5Normalize(event.children),
    })),
  );
}


function b5LedgerDiscarded(bundle: string): LooseEvent[] {
  return listLedgerEvents(bundle).filter((event) => event.kind === "discarded");
}

describe("C-DISCARD-PREFLIGHT deterministic refusal (AC-DISCARD-NOT-WRITTEN-ON-PREWRITE-REFUSE)", () => {
  const rows: Array<{ changeId: string; events: Array<[string, string]>; match: RegExp }> = [
    {
      changeId: "C-B5-NARROW",
      events: [
        ["1-T-001-opened.xml", b5Opened(1, 1, 1)],
        ["2-T-001-progress.xml", b5Event(2, "progress")],
      ],
      match: /unterminated range for w0/,
    },
    {
      changeId: "C-B5-DUP",
      events: [
        ["1-T-001-opened.xml", b5Opened(1, 1, 99)],
        ["2-T-001-progress.xml", b5Event(2, "progress")],
        ["2-T-001-progress-b.xml", b5Event(2, "progress")],
      ],
      match: /duplicate event id 2 appears 2 times/,
    },
    {
      changeId: "C-B5-HOLE",
      events: [
        ["1-T-001-opened.xml", b5Opened(1, 1, 99)],
        ["3-T-001-terminal.xml", b5Event(3, "terminal")],
      ],
      match: /range hole at 2 for w0/,
    },
  ];

  for (const row of rows) {
    it(`${row.changeId}: refuses before any discarded write and preserves the whole tree`, () => {
      const { root, bundle } = b5Seed(row.changeId, row.events);
      const before = snapshotTree(root);
      let thrown: string | undefined;
      try {
        discardAndFoldEpoch(root, row.changeId);
      } catch (error) {
        thrown = (error as Error).message;
      }
      expect(thrown, `expected a refusal for ${row.changeId}`).toMatch(row.match);
      expect(snapshotTree(root)).toEqual(before);
      expect(b5Loose(bundle).some((name) => name.endsWith("-discarded.xml"))).toBe(false);
      expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
      rmSync(root, { recursive: true, force: true });
    });
  }

  it("a repaired dense uniquely-identified stream still writes exactly one discarded and folds", () => {
    const { root, bundle } = b5Seed("C-B5-POS", [
      ["1-T-001-opened.xml", b5Opened(1, 1, 99)],
      ["2-T-001-progress.xml", b5Event(2, "progress")],
    ]);
    const looseBefore = listLooseEvents(bundle);
    const expected = b5Projection([
      ...looseBefore,
      { id: 3, task: "T-001", kind: "discarded", file: "", attributes: {}, children: [] },
    ].sort((a, b) => a.id - b.id));
    const result = discardAndFoldEpoch(root, "C-B5-POS") as { applied?: boolean; eventCount?: number };
    expect(result.applied).toBe(true);
    expect(b5Loose(bundle)).toEqual([]);
    expect(b5LedgerDiscarded(bundle)).toHaveLength(1);
    expect(b5Projection(listLedgerEvents(bundle))).toBe(expected);
    rmSync(root, { recursive: true, force: true });
  });
});

describe("C-DISCARD-PREFLIGHT no-allocation stream (AC-DISCARD-PREFLIGHT-NO-ALLOC)", () => {
  it("{1:progress, 3:progress} refuses the range hole with no discarded and no synthesized opened", () => {
    const { root, bundle } = b5Seed("C-B5-NOALLOC", [
      ["1-T-001-progress.xml", b5Event(1, "progress")],
      ["3-T-001-progress.xml", b5Event(3, "progress")],
    ]);
    const before = snapshotTree(root);
    let thrown: string | undefined;
    try {
      discardAndFoldEpoch(root, "C-B5-NOALLOC");
    } catch (error) {
      thrown = (error as Error).message;
    }
    expect(thrown).toMatch(/range hole at 2 for w0/);
    expect(snapshotTree(root)).toEqual(before);
    expect(b5Loose(bundle)).toEqual(["1-T-001-progress.xml", "3-T-001-progress.xml"]);
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);
    rmSync(root, { recursive: true, force: true });
  });

  it("an empty run/ remains the no-op and writes nothing", () => {
    const { root, bundle } = b5Seed("C-B5-EMPTY", []);
    const before = snapshotTree(root);
    expect(discardAndFoldEpoch(root, "C-B5-EMPTY")).toBeUndefined();
    expect(snapshotTree(root)).toEqual(before);
    expect(b5Loose(bundle)).toEqual([]);
    rmSync(root, { recursive: true, force: true });
  });
});

describe("C-DISCARD-PREFLIGHT competing-writer seam (AC-DISCARD-NOT-WRITTEN-ON-PREWRITE-REFUSE)", () => {
  it("a pre-ledger conflict leaves exactly one discarded that a real-CLI retry consumes once unchanged", () => {
    const { root, bundle } = b5Seed("C-B5-RACE", [
      ["1-T-001-opened.xml", b5Opened(1, 1, 99)],
      ["2-T-001-progress.xml", b5Event(2, "progress")],
    ]);
    let actorAdded = false;
    let thrown: string | undefined;
    try {
      discardWithSeam(root, "C-B5-RACE", {
        afterPreflight: () => {
          writeFileSync(path.join(bundle, "run", "2-T-002-progress.xml"), b5Event(2, "progress", "T-002"));
          actorAdded = true;
        },
      });
    } catch (error) {
      thrown = (error as Error).message;
    }
    expect(actorAdded, "the pre-write seam must fire on the candidate").toBe(true);
    expect(thrown).toMatch(/duplicate event id 2 appears 2 times/);
    expect(existsSync(path.join(bundle, "run-ledger.xml"))).toBe(false);

    // Capture the preserved residue's complete payload before the retry.
    const discardedResidue = listLooseEvents(bundle).filter((event) => event.kind === "discarded");
    expect(discardedResidue).toHaveLength(1);
    const residueProjection = b5Projection(discardedResidue);

    // The same actor removes only its own mutation; capture the whole loose population
    // from which the complete expected ledger projection is built independently.
    rmSync(path.join(bundle, "run", "2-T-002-progress.xml"), { force: true });
    const looseBeforeRetry = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    expect(looseBeforeRetry.map((event) => `${event.id}:${event.kind}`)).toEqual([
      "1:opened",
      "2:progress",
      "3:discarded",
    ]);
    const expectedLedgerProjection = b5Projection(looseBeforeRetry);

    const retry = foldGrace(root, ["cursor", "fold", "--change", "C-B5-RACE"]);
    expect(retry.exit).toBe(0);
    expect(b5Loose(bundle)).toEqual([]);
    const ledger = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    expect([...new Set([...ledger.matchAll(/<Epoch-(\d+)>/g)].map((match) => Number(match[1])))].sort()).toEqual([1]);

    // Complete population, attributes, and children: the recorded ledger equals the
    // independently captured loose population; no event is lost, added, or changed.
    const recorded = listLedgerEvents(bundle).sort((a, b) => a.id - b.id);
    expect(b5Projection(recorded)).toBe(expectedLedgerProjection);
    const discarded = recorded.filter((event) => event.kind === "discarded");
    expect(discarded).toHaveLength(1);
    // Consumed exactly once and unchanged: the recorded payload equals the captured residue.
    expect(b5Projection(discarded)).toBe(residueProjection);
    rmSync(root, { recursive: true, force: true });
  });
});

describe("C-DISCARD-PREFLIGHT recovery preservation through the changed caller (AC-DISCARD-NOT-WRITTEN-ON-PREWRITE-REFUSE)", () => {
  it("a partial-deletion residue hole resumes through discardAndFoldEpoch and preserves the recorded epoch payload", () => {
    const { root, bundle } = b5Seed("C-B5-PARTIAL", [
      ["1-T-001-opened.xml", b5Opened(1, 1, 99)],
      ["2-T-001-progress.xml", b5Event(2, "progress")],
      ["3-T-001-terminal.xml", b5Event(3, "terminal")],
    ]);
    expect(() => foldEpoch(root, "C-B5-PARTIAL", { injectFailureAfterWrite: true })).toThrow();
    const recordedLoose = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    expect(recordedLoose.map((event) => `${event.id}:${event.kind}`)).toEqual([
      "1:opened",
      "2:progress",
      "3:terminal",
    ]);
    const expectedLedgerProjection = b5Projection(recordedLoose);
    // A deliberately selected supported matching subset of the recorded epoch: an interior
    // progress event is removed. This is not evidence that id 2 is first in the shipped
    // delete loop, which iterates the ordered event set (`src/grace-cursor.ts:1750-1756`).
    rmSync(path.join(bundle, "run", "2-T-001-progress.xml"), { force: true });
    const ledgerBefore = readFileSync(path.join(bundle, "run-ledger.xml"), "utf8");
    const result = discardAndFoldEpoch(root, "C-B5-PARTIAL") as { applied?: boolean; epoch?: number };
    expect(result.applied).toBe(true);
    expect(result.epoch).toBe(1);
    expect(b5Loose(bundle)).toEqual([]);
    expect(b5LedgerDiscarded(bundle)).toHaveLength(0);
    expect(readFileSync(path.join(bundle, "run-ledger.xml"), "utf8")).toBe(ledgerBefore);
    // Complete payload preservation: the recorded ledger equals the captured epoch projection.
    expect(b5Projection(listLedgerEvents(bundle).sort((a, b) => a.id - b.id))).toBe(expectedLedgerProjection);
    rmSync(root, { recursive: true, force: true });
  });

  it("a mixed residue-plus-fresh set through discardAndFoldEpoch writes the complete expected epoch", () => {
    const { root, bundle, run } = b5Seed("C-B5-MIXED", [
      ["1-T-001-opened.xml", b5Opened(1, 1, 2)],
      ["2-T-001-terminal.xml", b5Event(2, "terminal")],
    ]);
    expect(() => foldEpoch(root, "C-B5-MIXED", { injectFailureAfterWrite: true })).toThrow();
    const epoch1Loose = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    expect(epoch1Loose.map((event) => `${event.id}:${event.kind}`)).toEqual(["1:opened", "2:terminal"]);
    const epoch1Before = b3EpochSlice(bundle, 1);
    rmSync(path.join(run, "1-T-001-opened.xml"), { force: true });
    expect(foldGrace(root, ["cursor", "advance", "--change", "C-B5-MIXED", "--task", "T-001"]).exit).toBe(0);
    expect(
      foldGrace(root, ["cursor", "advance", "--change", "C-B5-MIXED", "--task", "T-001", "--kind", "terminal"]).exit,
    ).toBe(0);
    const looseBefore = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    expect(looseBefore.map((event) => `${event.id}:${event.kind}`)).toEqual([
      "2:terminal",
      "3:progress",
      "4:terminal",
    ]);
    const fresh = looseBefore.filter((event) => event.id !== 2);

    const result = discardAndFoldEpoch(root, "C-B5-MIXED") as { applied?: boolean };
    expect(result.applied).toBe(true);
    expect(b5Loose(bundle)).toEqual([]);
    expect(b3EpochSlice(bundle, 1)).toBe(epoch1Before);

    // The complete expected population, built independently from the captured epoch-1 and
    // fresh events plus the engine's derived synthetic events — never from the result.
    const discardedId = Math.max(...looseBefore.map((event) => event.id)) + 1;
    const openedId = discardedId + 1;
    const allocFrom = Math.min(Math.min(...fresh.map((event) => event.id)), openedId);
    const allocTo = Math.max(Math.max(...looseBefore.map((event) => event.id), openedId), openedId + 98);
    const synthetic: LooseEvent[] = [
      { id: discardedId, task: "T-001", kind: "discarded", file: "", attributes: {}, children: [] },
      {
        id: openedId,
        task: "T-001",
        kind: "opened",
        file: "",
        attributes: {},
        children: [
          { tag: "Allocation", attributes: { worker: "w0", from: String(allocFrom), to: String(allocTo) }, children: [], text: "" },
        ],
      },
    ];
    const expected = b5Projection([...epoch1Loose, ...fresh, ...synthetic].sort((a, b) => a.id - b.id));
    expect(b5Projection(listLedgerEvents(bundle).sort((a, b) => a.id - b.id))).toBe(expected);
    expect(b5LedgerDiscarded(bundle)).toHaveLength(1);
    rmSync(root, { recursive: true, force: true });
  });

  it("real CLI supersede refuses the too-narrow stream with the whole tree unchanged", () => {
    const { root, bundle } = b5SeedPair("C-OLD", [
      ["1-T-001-opened.xml", b5Opened(1, 1, 1)],
      ["2-T-001-progress.xml", b5Event(2, "progress")],
    ]);
    const before = snapshotTree(root);
    const result = foldGrace(root, ["supersede", "--change", "C-OLD", "--replacement", "C-OLD-2"]);
    expect(result.exit).not.toBe(0);
    expect(result.stdout + result.stderr).toMatch(/unterminated range for w0/);
    expect(snapshotTree(root)).toEqual(before);
    expect(b5Loose(bundle).some((name) => name.endsWith("-discarded.xml"))).toBe(false);
    rmSync(root, { recursive: true, force: true });
  });

  it("real CLI supersede archives the predecessor from a partial-deletion residue hole with the recorded epoch intact", () => {
    const { root, bundle } = b5SeedPair("C-OLD", [
      ["1-T-001-opened.xml", b5Opened(1, 1, 99)],
      ["2-T-001-progress.xml", b5Event(2, "progress")],
      ["3-T-001-terminal.xml", b5Event(3, "terminal")],
    ]);
    expect(() => foldEpoch(root, "C-OLD", { injectFailureAfterWrite: true })).toThrow();
    const recordedLoose = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    const expectedLedgerProjection = b5Projection(recordedLoose);
    rmSync(path.join(bundle, "run", "2-T-001-progress.xml"), { force: true });
    const result = foldGrace(root, ["supersede", "--change", "C-OLD", "--replacement", "C-OLD-2"]);
    expect(result.exit).toBe(0);
    const archived = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-OLD");
    expect(existsSync(archived)).toBe(true);
    expect(b5Projection(listLedgerEvents(archived).sort((a, b) => a.id - b.id))).toBe(expectedLedgerProjection);
    rmSync(root, { recursive: true, force: true });
  });

  it("real CLI supersede archives the predecessor from a mixed residue-plus-fresh set with the complete expected epoch", () => {
    const { root, bundle } = b5SeedPair("C-OLD", [
      ["1-T-001-opened.xml", b5Opened(1, 1, 2)],
      ["2-T-001-terminal.xml", b5Event(2, "terminal")],
    ]);
    expect(() => foldEpoch(root, "C-OLD", { injectFailureAfterWrite: true })).toThrow();
    const epoch1Loose = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    rmSync(path.join(bundle, "run", "1-T-001-opened.xml"), { force: true });
    expect(foldGrace(root, ["cursor", "advance", "--change", "C-OLD", "--task", "T-001"]).exit).toBe(0);
    expect(foldGrace(root, ["cursor", "advance", "--change", "C-OLD", "--task", "T-001", "--kind", "terminal"]).exit).toBe(0);
    const looseBefore = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    const fresh = looseBefore.filter((event) => event.id !== 2);
    const discardedId = Math.max(...looseBefore.map((event) => event.id)) + 1;
    const openedId = discardedId + 1;
    const allocFrom = Math.min(Math.min(...fresh.map((event) => event.id)), openedId);
    const allocTo = Math.max(Math.max(...looseBefore.map((event) => event.id), openedId), openedId + 98);
    const synthetic: LooseEvent[] = [
      { id: discardedId, task: "T-001", kind: "discarded", file: "", attributes: {}, children: [] },
      {
        id: openedId,
        task: "T-001",
        kind: "opened",
        file: "",
        attributes: {},
        children: [
          { tag: "Allocation", attributes: { worker: "w0", from: String(allocFrom), to: String(allocTo) }, children: [], text: "" },
        ],
      },
    ];
    const expected = b5Projection([...epoch1Loose, ...fresh, ...synthetic].sort((a, b) => a.id - b.id));

    const result = foldGrace(root, ["supersede", "--change", "C-OLD", "--replacement", "C-OLD-2"]);
    expect(result.exit).toBe(0);
    const archived = path.join(root, ARTIFACT_DIR, "changes", "archive", "C-OLD");
    expect(existsSync(archived)).toBe(true);
    expect(b5Projection(listLedgerEvents(archived).sort((a, b) => a.id - b.id))).toBe(expected);
    rmSync(root, { recursive: true, force: true });
  });
});

// --- C-SUPERSEDE-INTEGRATION-CLOSE-1-82073AAC plan rehearsal rows (T-005..T-006) ---
function b3cGitInit(root: string): void {
  const g = (args: string[]) => {
    const result = Bun.spawnSync({ cmd: ["git", "-C", root, ...args], stdout: "pipe", stderr: "pipe" });
    if (result.exitCode !== 0) {
      throw new Error(
        `b3c git ${args.join(" ")} failed (exit ${result.exitCode}): ${Buffer.from(result.stderr).toString("utf8").trim()}`,
      );
    }
    return result;
  };
  g(["init"]);
  g(["config", "user.email", "b3@example.test"]);
  g(["config", "user.name", "B3 Rehearsal"]);
  g(["config", "commit.gpgsign", "false"]);
  g(["add", "."]);
  g(["commit", "-m", "baseline"]);
  const head = Buffer.from(g(["rev-parse", "HEAD"]).stdout).toString("utf8").trim();
  expect(head, "real-.git subject fixture has a baseline commit").toMatch(/^[0-9a-f]{40}$/);
}
function b3cSnap(root: string): Map<string, string> {
  const out = new Map<string, string>();
  const walk = (dir: string): void => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, entry.name);
      const rel = path.relative(root, abs).replaceAll("\\", "/");
      const st = lstatSync(abs);
      if (st.isSymbolicLink()) out.set(rel, `SYMLINK:${readlinkSync(abs)}`);
      else if (st.isDirectory()) { out.set(rel, "DIR"); walk(abs); }
      else out.set(rel, `FILE:${createHash("sha256").update(readFileSync(abs)).digest("hex")}`);
    }
  };
  walk(root);
  return out;
}
function b3cDelta(before: Map<string, string>, after: Map<string, string>): string[] {
  const keys = [...new Set([...before.keys(), ...after.keys()])].sort();
  const d: string[] = [];
  for (const k of keys) {
    const b = before.get(k); const a = after.get(k);
    if (b === a) continue;
    d.push(b === undefined ? `ADDED ${k}` : a === undefined ? `DELETED ${k}` : `CHANGED ${k}`);
  }
  return d;
}
function b3cCanon(children: GraceXmlNode[]): unknown {
  return children.map((c) => ({ tag: c.tag, attrs: Object.entries(c.attributes).sort(), text: c.text, children: b3cCanon(c.children) }));
}
function b3cProjection(events: Array<{ id: number; kind: string; task: string; file: string; attributes: Record<string, string>; children: GraceXmlNode[] }>): string {
  return JSON.stringify(events.sort((a, b) => a.id - b.id).map((e) => ({ attrs: Object.entries(expectedLedgerEventAttributes(e)).sort(), children: b3cCanon(e.children) })));
}

describe("AC-LOCK-AND-ALLOCATOR-KEPT (C-SUPERSEDE-INTEGRATION-CLOSE-1-82073AAC)", () => {
  it("AC-LOCK-AND-ALLOCATOR-KEPT: structural pin keeps the event lock, uniqueness scan, and own-file unlink in src/grace-cursor.ts", () => {
    const src = readFileSync(path.join(FOLD_REPO_ROOT, "src", "grace-cursor.ts"), "utf8");
    expect(src).toContain("const EVENT_WRITE_LOCK = \".run-write.lock\";");
    expect(src).toContain("function withEventWriteLock");
    expect(src).toContain("const existing = listLooseEvents(bundlePath)");
    expect(src).toContain("unlinkSync(contained.absolutePath)");
  });

  it("AC-LOCK-AND-ALLOCATOR-KEPT: twelve concurrent real-CLI writers then an explicit-replacement supersede exit 0", async () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-B3-LOCK");
    writeChangeBundleFixture(root, { changeId: "C-B3-LOCK-2", location: "active", specStatus: "draft", planStatus: "draft" });
    advanceCursor(root, "C-B3-LOCK", { task: "T-001", openEpoch: true, from: 1, to: 199 });
    b3cGitInit(root);
    const tasks = Array.from({ length: 12 }, (_, i) => `T-${String(i + 2).padStart(3, "0")}`);
    const procs = tasks.map((task) =>
      Bun.spawn({ cmd: [process.execPath, "./src/grace.ts", "cursor", "advance", "--change", "C-B3-LOCK", "--task", task, "--path", root], cwd: FOLD_REPO_ROOT, stdout: "ignore", stderr: "ignore" }),
    );
    const codes = await Promise.all(procs.map((p) => p.exited));
    expect(codes.every((code: number) => code === 0)).toBe(true);
    const events = listLooseEvents(bundle);
    expect(events).toHaveLength(13);
    expect(new Set(events.map((e) => e.id)).size).toBe(13);
    expect(events.map((e) => e.id).sort((a, b) => a - b)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]);
    const r = foldGrace(root, ["supersede", "--change", "C-B3-LOCK", "--replacement", "C-B3-LOCK-2"]);
    expect(r.exit, r.stdout + r.stderr).toBe(0);
    expect(existsSync(path.join(root, ARTIFACT_DIR, "changes", "archive", "C-B3-LOCK"))).toBe(true);
  });
});

describe("AC-MEMBER-MATRIX-COMPLETE item17 (C-SUPERSEDE-INTEGRATION-CLOSE-1-82073AAC)", () => {
  it("AC-MEMBER-MATRIX-COMPLETE item17: an early-vanished entry is omitted without fabricating an event", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-B3-VAN");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="99"/></NgraceRunEvent>`);
    writeFileSync(path.join(run, "2-T-001-progress.xml"), `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="progress"/>`);
    b3cGitInit(root);
    rmSync(path.join(run, "2-T-001-progress.xml"), { force: true });
    const direct = listLooseEvents(bundle);
    expect(direct.map((e) => e.id)).toEqual([1]);
    expect(direct.some((e) => e.id === 2)).toBe(false);
    const r = foldGrace(root, ["cursor", "show", "--change", "C-B3-VAN"]);
    expect(r.exit, r.stdout + r.stderr).toBe(0);
  });

  it("AC-MEMBER-MATRIX-COMPLETE item17: a late ENOENT between enumeration and read is tolerated with the probe fired", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-B3-LATE");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    const victim = path.join(run, "2-T-001-progress.xml");
    writeFileSync(path.join(run, "1-T-001-opened.xml"), `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="99"/></NgraceRunEvent>`);
    writeFileSync(victim, `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="progress"/>`);
    b3cGitInit(root);
    let fired = false;
    setLooseEventReadProbeForTests((file) => {
      if (file === victim) { fired = true; rmSync(victim, { force: true }); }
    });
    try {
      const direct = listLooseEvents(bundle);
      expect(fired, "the read-boundary probe fired on the victim").toBe(true);
      expect(direct.map((e) => e.id)).toEqual([1]);
    } finally {
      setLooseEventReadProbeForTests(undefined);
    }
  });

  it("AC-MEMBER-MATRIX-COMPLETE item17: a malformed closer refuses fold with a union-key byte-identical tree", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-B3-MAL");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="99"/></NgraceRunEvent>`);
    writeFileSync(path.join(run, "2-T-001-terminal.xml"), "<broken");
    b3cGitInit(root);
    const before = b3cSnap(bundle);
    const r = foldGrace(root, ["cursor", "fold", "--change", "C-B3-MAL"]);
    expect(r.exit).not.toBe(0);
    expect(r.stdout + r.stderr).toMatch(/xml\.parse|not parseable|Cannot fold or abandon/);
    expect(b3cDelta(before, b3cSnap(bundle))).toEqual([]);
  });

  it("AC-MEMBER-MATRIX-COMPLETE item17: mixed residue-plus-fresh recovery writes the complete expected epoch", () => {
    const root = createProject();
    const bundle = seedBundle(root, "C-B3-MIXED");
    const run = path.join(bundle, "run");
    mkdirSync(run, { recursive: true });
    writeFileSync(path.join(run, "1-T-001-opened.xml"), `<NgraceRunEvent graceVersion="1.0" id="1" task="T-001" kind="opened"><Allocation worker="w0" from="1" to="2"/></NgraceRunEvent>`);
    writeFileSync(path.join(run, "2-T-001-terminal.xml"), `<NgraceRunEvent graceVersion="1.0" id="2" task="T-001" kind="terminal"/>`);
    expect(() => foldEpoch(root, "C-B3-MIXED", { injectFailureAfterWrite: true })).toThrow();
    const epoch1 = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    expect(epoch1.map((e) => `${e.id}:${e.kind}`)).toEqual(["1:opened", "2:terminal"]);
    b3cGitInit(root);
    rmSync(path.join(run, "1-T-001-opened.xml"), { force: true });
    expect(foldGrace(root, ["cursor", "advance", "--change", "C-B3-MIXED", "--task", "T-001"]).exit).toBe(0);
    expect(foldGrace(root, ["cursor", "advance", "--change", "C-B3-MIXED", "--task", "T-001", "--kind", "terminal"]).exit).toBe(0);
    const looseBefore = listLooseEvents(bundle).sort((a, b) => a.id - b.id);
    expect(looseBefore.map((e) => `${e.id}:${e.kind}`)).toEqual(["2:terminal", "3:progress", "4:terminal"]);
    const fresh = looseBefore.filter((e) => e.id !== 2);
    const discardedId = Math.max(...looseBefore.map((e) => e.id)) + 1;
    const openedId = discardedId + 1;
    const allocFrom = Math.min(Math.min(...fresh.map((e) => e.id)), openedId);
    const allocTo = Math.max(Math.max(...looseBefore.map((e) => e.id), openedId), openedId + 98);
    const expected = b3cProjection([
      ...epoch1,
      ...fresh,
      { id: discardedId, task: "T-001", kind: "discarded", file: "", attributes: {}, children: [] as never },
      { id: openedId, task: "T-001", kind: "opened", file: "", attributes: {}, children: [{ tag: "Allocation", attributes: { worker: "w0", from: String(allocFrom), to: String(allocTo) }, children: [], text: "" }] },
    ]);
    const result = discardAndFoldEpoch(root, "C-B3-MIXED") as { applied?: boolean };
    expect(result.applied).toBe(true);
    expect(readdirSync(run)).toEqual([]);
    expect(b3cProjection(listLedgerEvents(bundle))).toBe(expected);
  });
});
