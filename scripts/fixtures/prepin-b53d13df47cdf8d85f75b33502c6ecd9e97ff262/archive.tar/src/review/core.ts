// START_MODULE_CONTRACT
//   PURPOSE: Review surface
//   SCOPE: Process audits, pattern detectors, and review.* findings
//   DEPENDS: none
//   LINKS: M-REVIEW
//   ROLE: RUNTIME
//   MAP_MODE: EXPORTS
// END_MODULE_CONTRACT
//
// START_MODULE_MAP
//   ATTEMPT_PAIR_FINDING_CODE
//   WRITE_EVIDENCE_SCOPE_FINDING_CODE
//   HunkCoverageInput
//   JoinProbe
//   REVIEW_CATALOG
//   RegexOverStructureScan
//   ReviewFinding
//   ReviewOptions
//   AmendmentCountAuditReport
//   AttemptPairAuditReport
//   AttemptPairEvidenceInput
//   WriteEvidenceScopeAuditReport
//   WriteEvidenceScopeAuditInput
//   ReviewResult
//   ScopeAuditReport
//   TestFileDiff
//   allReviewCodes
//   auditAttemptPairWriteEvidence
//   auditCompatNewErrors
//   auditHunkCoverage
//   auditScopeOutsideWriteScope
//   auditWriteEvidenceOutsideScope
//   auditTestWeakening
//   expandScopePathsForArchiveIdentity
//   findingId
//   applyReviewSeverityThreshold
//   formatReviewResult
//   isReviewIssueCode
//   listRuntimeSourceFilesForMarkerScan
//   resolveChangePlanPath
//   resolveReviewSeverity
//   runJoinProbes
//   runPatternDetectors
//   runPatternDetectorsWithMeta
//   runReview
//   ScopeAuditIdentity
// END_MODULE_MAP
/**
 * Review surface (D4, D14, §6.4, A35/A36): pattern detectors, process audits,
 * join engine, and deterministic finding IDs.
 *
 * Does not write Verdicts, Decisions, or status (F1). Recording stays on ngrace gate verdict.
 */

import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";

import { collectCloseBoundCriterionIds, collectCloseEvidenceEvaluations } from "../artifact/grammar";
import { ARTIFACT_DIR } from "../artifact/paths";
import { resolveNgracePaths } from "../artifact/project";
import { observedWriteScopeContains } from "../artifact/scope";
import { GraceCommandError } from "../query/errors";
import {
  ANCHOR_PATTERNS,
  isRegisteredSemanticAnchor,
  VERIFICATION_THREADED_CHILD_TAGS,
} from "../artifact/types";
import { readGraceXmlArtifact, walkNodes } from "../artifact/xml";
import { extractObservedWriteScopeFromPlan } from "./scope-helpers";
import {
  listFilesChangedAgainstBase,
  listLedgerEvents,
  listLooseEvents,
  listRepositoryChangedFiles,
  readAttemptPayload,
  resolveChangeBundle,
  type AbsenceValue,
  type LooseEvent,
  type WriteEvidenceSnapshot,
} from "../grace-cursor";
import { classifyApprovedArtifact, listGateDecisions, readAmendmentInstrument } from "../gates/ledger";
import { CODE_EXTENSIONS } from "../language-registry";
import {
  getModuleImplementationFiles,
  isLikelyTestPath,
  loadGraceArtifactIndex,
} from "../query/core";
import {
  ATTEMPT_PAIR_FINDING_CODE,
  ATTEMPT_PAIR_UNPAIRED_FAIL_FINDING_CODE,
  ATTEMPT_PAIR_UNPAIRED_PASS_FINDING_CODE,
  CLOSE_EVIDENCE_ABSENCE_FINDING_CODE,
  APPROVAL_NEVER_ASKED_FINDING_CODE,
  APPROVAL_FINGERPRINT_MISMATCH_FINDING_CODE,
  REVIEW_ISSUE_SEVERITIES,
  WRITE_EVIDENCE_SCOPE_FINDING_CODE,
  REVIEW_CATALOG,
  guideFor,
  type ReviewIssueGuide,
  type ReviewIssueSeverity,
} from "./catalog";
import {
  SHAPE_DATA_MARKER,
  patternSourceLooksLikeMarkupGuard,
} from "./shape-data";

export type ReviewFinding = {
  severity: ReviewIssueSeverity;
  code: string;
  file: string;
  message: string;
  title?: string;
  explanation?: string;
  remediation?: string[];
  /** Deterministic id — stable across reruns and unrelated blank-line edits. */
  findingId: string;
  ruleId: string;
  /** Content-stable anchor (never line number alone). */
  anchorOrHunkKey: string;
};

/**
 * Scope-audit outcome for a named --change (A66.4 five states).
 * Always present when changeId was requested; absent when process audits are off
 * or no changeId was given.
 */
export type ScopeAuditReport = {
  status: "ran" | "not-run" | "unable-to-determine";
  reason: string;
  changeId: string;
  /** Where plan.xml was read, when resolved. */
  planLocation?: "active" | "archive";
  /** How the changed-file set was obtained when the audit ran. */
  inputSource?: "explicit" | "base" | "porcelain" | "recorded-base";
  baseRef?: string;
  changedFileCount?: number;
  /** True when status=ran over a caller-supplied empty --changed-files set (state 5). */
  callerSuppliedEmpty?: boolean;
  absence?: AbsenceValue;
};

/**
 * Attempt-pair audit outcome (F31 / C-SUBSTANTIATION-HONESTY).
 * Always present when process audits ran — including unscoped review, where
 * status is not-run with a reason (same honesty bar as ScopeAuditReport).
 */
export type AttemptPairAuditReport = {
  status: "ran" | "not-run" | "unable-to-determine";
  reason: string;
  changeId?: string;
  pairCount?: number;
  findingCount?: number;
  absence?: AbsenceValue;
};

/**
 * WriteEvidence-vs-ObservedWriteScope audit outcome (F27 / C-DECLARED-WRITES).
 * Always present when process audits ran — including unscoped review, where
 * status is not-run with a reason (same honesty bar as ScopeAuditReport / F31).
 * Distinct from porcelain ScopeAuditReport (tree input vs ledger input).
 */
export type WriteEvidenceScopeAuditReport = {
  status: "ran" | "not-run" | "unable-to-determine";
  reason: string;
  changeId?: string;
  pathCount?: number;
  findingCount?: number;
  absence?: AbsenceValue;
};

export type AmendmentCountAuditReport = {
  status: "ran" | "not-run" | "unable-to-determine";
  reason: string;
  changeId?: string;
  reRatificationCount?: number;
  supersedeChainDepth?: number;
  absence?: AbsenceValue;
};

export type ReviewResult = {
  schemaVersion: "1.0.0";
  tool: "ngrace-review";
  root: string;
  findings: ReviewFinding[];
  /**
   * Paths skipped because they hold detector shapes as data (A38.2 / corr 90).
   * Always reported — silent exemptions are anti-pattern 8.
   */
  shapeDataExemptions: string[];
  /** Present when --change was set and process audits ran. */
  scopeAudit?: ScopeAuditReport;
  /**
   * Present when process audits ran. Unscoped review sets status not-run
   * (reason names missing --change) rather than omitting the audit.
   */
  attemptPairAudit?: AttemptPairAuditReport;
  /**
   * Present when process audits ran. Ledger WriteEvidence vs OWS (F27).
   * Unscoped → not-run; empty/missing WriteEvidence → unable-to-determine.
   */
  writeEvidenceScopeAudit?: WriteEvidenceScopeAuditReport;
  /**
   * Present when process audits ran. Derived re-ratification and supersede-depth
   * counts. Unscoped → not-run with a reason naming --change.
   */
  amendmentCountAudit?: AmendmentCountAuditReport;
  summary: {
    findings: number;
    errors: number;
    warnings: number;
    infos: number;
    /** Count of shape-data exemptions (same as shapeDataExemptions.length). */
    shapeDataExemptions: number;
  };
};

export type HunkCoverageInput = {
  hunkKey: string;
  file: string;
  covered: boolean;
};

export type TestFileDiff = {
  file: string;
  before: string;
  after: string;
};

/**
 * Join-engine probe for A34.1 fixtures. Process-shaped by default (A36.2):
 * emits family-B codes unless the caller asserts a corpus pattern instance.
 */
export type JoinProbe =
  | {
      kind: "scope-home";
      recordScope: "task" | "epoch" | "bundle" | "project";
      homeAdmits: Array<"task" | "epoch" | "bundle" | "project">;
      file: string;
    }
  | {
      kind: "writer-command";
      exportedWriters: string[];
      invocableCommands: string[];
      file: string;
    }
  | {
      kind: "lint-vs-reader";
      lintRejects: boolean;
      readerTreatsAsBenign: boolean;
      file: string;
      condition: string;
    }
  | {
      kind: "diagnostic-vs-preexisting";
      diagnosticCode: string;
      preexistingCanNeverClear: boolean;
      file: string;
    };

export type ReviewOptions = {
  changeId?: string;
  /**
   * Explicit changed paths for process audits. When **defined** (including `[]`),
   * the set is caller-owned: no porcelain fallback (A66 Q5 / corr 169).
   */
  changedFiles?: string[];
  /**
   * Git base ref for a three-dot (`base...HEAD`) name-only diff (A66.3).
   * Ignored when `changedFiles` is defined.
   */
  baseRef?: string;
  /**
   * Minimum severity threshold. Omitted equals warning (error plus warning).
   * A finding is kept when its rank is at least this token.
   */
  severity?: ReviewIssueSeverity;
  testFileDiffs?: TestFileDiff[];
  lintCodesBefore?: string[];
  lintCodesAfter?: string[];
  hunkCoverage?: HunkCoverageInput[];
  joinProbes?: JoinProbe[];
  /** Disable pattern detectors (tests of process audits alone). */
  patterns?: boolean;
  processAudits?: boolean;
  joinEngine?: boolean;
};

const REVIEW_SEVERITY_RANK: Record<ReviewIssueSeverity, number> = {
  error: 2,
  warning: 1,
  info: 0,
};

/** Keep findings whose severity rank is at least the threshold. */
export function applyReviewSeverityThreshold(
  findings: ReviewFinding[],
  threshold: ReviewIssueSeverity,
): ReviewFinding[] {
  const minimum = REVIEW_SEVERITY_RANK[threshold];
  return findings.filter((finding) => REVIEW_SEVERITY_RANK[finding.severity] >= minimum);
}

/**
 * Closed-set resolver. Undefined means warning; present must be exactly
 * a REVIEW_ISSUE_SEVERITIES member.
 */
export function resolveReviewSeverity(value: string | undefined): ReviewIssueSeverity {
  if (value === undefined) return "warning";
  if ((REVIEW_ISSUE_SEVERITIES as readonly string[]).includes(value)) {
    return value as ReviewIssueSeverity;
  }
  throw new GraceCommandError(
    "invalid-arguments",
    `Invalid severity ${JSON.stringify(value)}. Accepted values: ${REVIEW_ISSUE_SEVERITIES.join(", ")}.`,
  );
}

/** Resolve plan.xml under active/ first, then archive/ (read-only; corr 139). */
export function resolveChangePlanPath(
  projectRoot: string,
  changeId: string,
): { planPath: string; location: "active" | "archive" } | undefined {
  const paths = resolveNgracePaths(path.resolve(projectRoot));
  const active = path.join(paths.changesActiveDir, changeId, "plan.xml");
  if (existsSync(active)) return { planPath: active, location: "active" };
  const archived = path.join(paths.changesArchiveDir, changeId, "plan.xml");
  if (existsSync(archived)) return { planPath: archived, location: "archive" };
  return undefined;
}

// ---------------------------------------------------------------------------
// Finding IDs (step 6.5.2)
// ---------------------------------------------------------------------------

/**
 * Deterministic finding id. Never uses line numbers alone, timestamps,
 * iteration order, or narration.
 */
export function findingId(parts: {
  auditOrPatternId: string;
  file: string;
  anchorOrHunkKey: string;
  ruleId: string;
}): string {
  const payload = [
    parts.auditOrPatternId,
    normalizeRel(parts.file),
    parts.anchorOrHunkKey,
    parts.ruleId,
  ].join("\0");
  return createHash("sha256").update(payload).digest("hex").slice(0, 16);
}

function normalizeRel(file: string): string {
  return file.replaceAll("\\", "/");
}

function makeFinding(
  code: keyof typeof REVIEW_CATALOG | string,
  file: string,
  message: string,
  ruleId: string,
  anchorOrHunkKey: string,
): ReviewFinding {
  const guide: ReviewIssueGuide | undefined = guideFor(code);
  const auditOrPatternId = guide?.proposedBy ?? code;
  return {
    severity: guide?.severity ?? "error",
    code,
    file: normalizeRel(file),
    message,
    title: guide?.title,
    explanation: guide?.explanation,
    remediation: guide?.remediation,
    ruleId,
    anchorOrHunkKey,
    findingId: findingId({
      auditOrPatternId,
      file: normalizeRel(file),
      anchorOrHunkKey,
      ruleId,
    }),
  };
}

// ---------------------------------------------------------------------------
// Walk helpers
// ---------------------------------------------------------------------------

function listFilesRecursive(root: string, relDir = ""): string[] {
  const abs = path.join(root, relDir);
  if (!existsSync(abs)) return [];
  const out: string[] = [];
  for (const entry of readdirSync(abs, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === ".git") continue;
    const rel = relDir ? `${relDir}/${entry.name}` : entry.name;
    const full = path.join(root, rel);
    if (entry.isDirectory()) {
      out.push(...listFilesRecursive(root, rel));
    } else if (entry.isFile()) {
      out.push(rel.replaceAll("\\", "/"));
    }
  }
  return out;
}

function readText(root: string, rel: string): string | undefined {
  const full = path.join(root, rel);
  if (!existsSync(full) || !statSync(full).isFile()) return undefined;
  try {
    return readFileSync(full, "utf8");
  } catch {
    return undefined;
  }
}

// ---------------------------------------------------------------------------
// Family A — pattern detectors
// ---------------------------------------------------------------------------

/**
 * Runtime sources that may emit verification markers (corr 205-A).
 *
 * Preferred source of truth: graph-linked implementation files via
 * `getModuleImplementationFiles` (same set health uses). Rejected alternative:
 * only TypeScript under a top-level `src/` directory — polyglot monorepos put
 * Go/Rust elsewhere and non-TS markers were false-positive confidently-wrong.
 *
 * Fallback when the index cannot load or no linked files exist: every path under
 * the project root whose extension is in `CODE_EXTENSIONS`, excluding tests and
 * `.ngrace/` / `node_modules` / `.git`.
 */
export function listRuntimeSourceFilesForMarkerScan(root: string): string[] {
  const linked = tryLinkedImplementationPaths(root);
  if (linked.length > 0) {
    return linked;
  }
  return listCodeExtensionRuntimeSources(root);
}

function tryLinkedImplementationPaths(root: string): string[] {
  try {
    const index = loadGraceArtifactIndex(root);
    const paths = new Set<string>();
    for (const moduleRecord of index.modules.values()) {
      for (const file of getModuleImplementationFiles(moduleRecord)) {
        paths.add(file.path.replaceAll("\\", "/"));
      }
    }
    return [...paths].sort();
  } catch {
    return [];
  }
}

function listCodeExtensionRuntimeSources(root: string): string[] {
  return listFilesRecursive(root).filter((rel) => {
    if (
      rel.startsWith(`${ARTIFACT_DIR}/`)
      || rel.startsWith("node_modules/")
      || rel.startsWith(".git/")
    ) {
      return false;
    }
    if (isLikelyTestPath(rel)) return false;
    const ext = path.extname(rel).toLowerCase();
    return CODE_EXTENSIONS.has(ext);
  }).sort();
}

function detectConfidentlyWrong(root: string): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  const sourceFiles = listRuntimeSourceFilesForMarkerScan(root);
  const sourceBlob = sourceFiles.map((f) => readText(root, f) ?? "").join("\n");

  // Markers claimed in verification but never emitted in runtime sources (XML walk, not regex).
  for (const verificationRel of listFilesRecursive(root, `${ARTIFACT_DIR}/verification`).filter(
    (f) => f.endsWith(".xml"),
  )) {
    const abs = path.join(root, verificationRel);
    if (!existsSync(abs)) continue;
    const artifact = readGraceXmlArtifact(abs);
    if (!artifact.root) continue;
    let markerOrdinal = 0;
    for (const node of walkNodes(artifact.root)) {
      if (node.tag !== "Marker") continue;
      const marker = node.text.trim();
      if (!marker) continue;
      if (!sourceBlob.includes(marker)) {
        findings.push(
          makeFinding(
            "review.confidently-wrong",
            verificationRel,
            `Verification requires marker ${marker} that no runtime source emits.`,
            "marker-not-emitted",
            `marker:${marker}#${markerOrdinal++}`,
          ),
        );
      }
    }
  }

  // MustExist targets that do not exist on disk (corr 205-B).
  // Semantic anchors (ANCHOR_PATTERNS) are not disk paths — never check them as files.
  // Corr 171 / F16: when the plan lives under archive/<id>/, active/<id>/… aliases
  // archive/<id>/… for that id only — reuse expandScopePathsForArchiveIdentity (no second rule).
  for (const planRel of listFilesRecursive(root, `${ARTIFACT_DIR}/changes`).filter((f) =>
    f.endsWith("plan.xml"),
  )) {
    const abs = path.join(root, planRel);
    const artifact = readGraceXmlArtifact(abs);
    if (!artifact.root) continue;
    const planStatus = (artifact.root.attributes.status ?? "").trim();
    if (planStatus === "superseded" || planStatus === "rejected" || planStatus === "cancelled") {
      continue;
    }
    const identity = scopeIdentityFromPlanRel(planRel);
    const observed = extractObservedWriteScopeFromPlan(abs, root);
    const declared = {
      files: expandScopePathsForArchiveIdentity(observed.files, identity),
      globs: expandScopePathsForArchiveIdentity(observed.globs, identity),
    };
    const unapplied = planStatus !== "applied";
    let mustExistOrdinal = 0;
    const sectionNodes = [...walkNodes(artifact.root)].filter(
      (n) => n.tag === "BaselineAssertions" || n.tag === "TargetAssertions",
    );
    for (const sectionNode of sectionNodes) {
      const section = sectionNode.tag;
      for (const node of walkNodes(sectionNode)) {
        if (node.tag !== "MustExist") continue;
        const valueNode = node.children.find((c) => c.tag === "Value");
        const target = (valueNode?.text ?? node.text).trim();
        if (!target || isRegisteredSemanticAnchor(target)) {
          continue;
        }
        if (section === "TargetAssertions" && unapplied && observedWriteScopeContains(declared, target)) {
          continue;
        }
        const candidates = expandScopePathsForArchiveIdentity([target], identity);
        const present = candidates.some((candidate) => existsSync(path.join(root, candidate)));
        if (!present) {
          findings.push(
            makeFinding(
              "review.confidently-wrong",
              planRel,
              `MustExist claims ${target} which is not present on disk.`,
              "must-exist-missing",
              `must-exist:${target}#${mustExistOrdinal++}`,
            ),
          );
        }
      }
    }
  }

  return findings;
}

/** Derive corr-171 identity from plan path `.ngrace/changes/{active|archive}/<id>/plan.xml`. */
function scopeIdentityFromPlanRel(planRel: string): ScopeAuditIdentity | undefined {
  const normalized = planRel.replaceAll("\\", "/");
  const prefix = `${ARTIFACT_DIR}/changes/`;
  if (!normalized.startsWith(prefix) || !normalized.endsWith("/plan.xml")) return undefined;
  const middle = normalized.slice(prefix.length, -"/plan.xml".length); // active|archive / changeId
  const slash = middle.indexOf("/");
  if (slash <= 0) return undefined;
  const planLocation = middle.slice(0, slash);
  const changeId = middle.slice(slash + 1);
  if (planLocation !== "active" && planLocation !== "archive") return undefined;
  if (!changeId || changeId.includes("/")) return undefined;
  return { planLocation, changeId };
}

function detectSelfReferential(root: string): ReviewFinding[] {
  const findings: ReviewFinding[] = [];

  for (const rel of listFilesRecursive(root, "src").filter((f) => f.endsWith(".test.ts") || f.endsWith(".test.js"))) {
    // Review-surface unit tests hold defect shapes as fixtures (held-out controls); not production tests.
    if (rel.startsWith("src/review/")) continue;
    const text = readText(root, rel);
    if (!text) continue;
    // expect(x).toBe(x) / expect(src).toEqual(src)
    if (/\bexpect\s*\(\s*([A-Za-z_$][\w$]*)\s*\)\s*\.\s*(?:toBe|toEqual|toStrictEqual)\s*\(\s*\1\s*\)/.test(text)) {
      findings.push(
        makeFinding(
          "review.self-referential-comparison",
          rel,
          "Test asserts a value equals itself (both sides share one origin).",
          "expect-same-identifier",
          "expect-self",
        ),
      );
    }
    // readFileSync of sibling source then compare to itself
    if (
      /readFileSync\s*\(/.test(text)
      && /\bexpect\s*\(\s*([A-Za-z_$][\w$]*)\s*\)\s*\.\s*(?:toBe|toEqual)\s*\(\s*\1\s*\)/.test(text)
    ) {
      // already covered above; keep one finding
    }
  }

  for (const planRel of listFilesRecursive(root, `${ARTIFACT_DIR}/changes`).filter((f) =>
    f.endsWith("plan.xml"),
  )) {
    if (scopeIdentityFromPlanRel(planRel)?.planLocation !== "active") continue;
    const abs = path.join(root, planRel);
    const artifact = readGraceXmlArtifact(abs);
    if (!artifact.root) continue;
    const posixPlan = planRel.replaceAll("\\", "/");
    let mustMatchOrdinal = 0;
    for (const node of walkNodes(artifact.root)) {
      if (node.tag !== "MustMatchPattern") continue;
      const fileNode = node.children.find((c) => c.tag === "File");
      const file = (fileNode?.text ?? "").trim().replaceAll("\\", "/");
      if (!file) continue;
      if (file === posixPlan || file.endsWith(posixPlan) || posixPlan.endsWith(file)) {
        findings.push(
          makeFinding(
            "review.self-referential-comparison",
            planRel,
            "Baseline MustMatchPattern targets the plan itself as oracle.",
            "plan-matches-self",
            `must-match:${file}#${mustMatchOrdinal++}`,
          ),
        );
      }
    }
  }

  return findings;
}

/**
 * Extract pattern *sources* from regex literals and `new RegExp(...)` so we can
 * judge whether the pattern carries markup/attribute syntax (A37.1 shape, not fixture literals).
 */
function extractRegexPatternSources(source: string): string[] {
  const out: string[] = [];
  // new RegExp("..." | '...' | `...`) — first argument only
  for (const m of source.matchAll(
    /new\s+RegExp\s*\(\s*(`(?:\\.|[^`\\])*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/g,
  )) {
    const raw = m[1]!;
    out.push(raw.slice(1, -1));
  }
  // Regex literals immediately consumed as guards: /.../.test( / .exec( / .match(
  for (const m of source.matchAll(
    /\/((?:\\.|[^/\n\\])+)\/[gimsuy]*(?=\s*\.\s*(?:test|exec|match)\s*\()/g,
  )) {
    out.push(m[1]!);
  }
  // Assignment forms: const re = /.../
  for (const m of source.matchAll(
    /(?:const|let|var)\s+[A-Za-z_$][\w$]*\s*=\s*\/((?:\\.|[^/\n\\])+)\/[gimsuy]*/g,
  )) {
    out.push(m[1]!);
  }
  return [...new Set(out)];
}

function fileHoldsShapesAsData(rel: string, text: string): boolean {
  // Corpus stores defect text as fixtures (not a production guard).
  if (rel.includes("defect-corpus")) return true;
  // Explicit opt-in for shape-as-data modules (A37.3 / corr 88) — not a directory prefix.
  if (text.includes(SHAPE_DATA_MARKER)) return true;
  return false;
}

function usesRegexAsGuard(text: string): boolean {
  return /\.test\s*\(|\.exec\s*\(|\.match\s*\(/.test(text);
}

/**
 * Identifiers bound to a call result: `const X = f(...)` or `const X = a.b(...)`.
 * A marker line-scan over such an identifier is a transformed-value scan (A38.1 / corr 89).
 * The helper's *name* is irrelevant — only the dataflow matters.
 */
function identifiersAssignedFromCall(text: string): Set<string> {
  const ids = new Set<string>();
  for (const m of text.matchAll(
    /(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*[A-Za-z_$][\w$.]*\s*\(/g,
  )) {
    ids.add(m[1]!);
  }
  return ids;
}

/**
 * Bare-identifier subjects of *line-oriented* `.split("\n")` chained to an array
 * callback: `source.split("\n").some(...)`.
 *
 * Does not match call-expression subjects (`normalize(source).split(...)`) — those
 * end in `)` before `.split` (A39.1 / corr 92).
 * Non-newline splits (e.g. `body.split(/\s+/)`) are not line scans.
 */
function lineScanBareIdentifierSubjects(text: string): string[] {
  const subjects: string[] = [];
  // Chained: ID.split("\n").(some|every|filter|find) — "\n" as two source chars \ + n
  // Identifier must be immediately before `.split` (not `source).split` from a call arg).
  for (const m of text.matchAll(
    /\b([A-Za-z_$][\w$]*)\s*\.\s*split\s*\(\s*(?:"\\n"|'\\n'|`\\n`)\s*\)\s*\.\s*(?:some|every|filter|find)\s*\(/g,
  )) {
    subjects.push(m[1]!);
  }
  return subjects;
}

/**
 * True when a *call expression* is the subject of a newline split chained to a
 * callback: `normalize(source).split("\n").some(...)` (A39.1 / corr 92).
 * Same dataflow as binding the call result to a name, without requiring the name.
 */
function hasCallExpressionLineScanSubject(text: string): boolean {
  return /\)\s*\.\s*split\s*\(\s*(?:"\\n"|'\\n'|`\\n`)\s*\)\s*\.\s*(?:some|every|filter|find)\s*\(/.test(
    text,
  );
}

/**
 * Defective comment-marker line guard: line-anchored START_MODULE_* regex used as a
 * governance check on *raw* input (corpus re-03 family).
 *
 * Discriminator is dataflow (A38.1 / corr 89), not a production symbol name:
 * re-03 scans the function's raw parameter (`source.split…`); the correct scanner
 * scans a value derived by a transform (`const searchable = f(text)` then split).
 * Marker token must appear *inside a pattern source*, not merely in prose.
 */
/**
 * Comment-prefix tokens in a regex *pattern source*. Literals write `//` as `\/\/`,
 * so a raw `/\/\//` check on the source string misses pure-// scanners (A38 probe / 91).
 */
function patternSourceHasCommentPrefix(patternSource: string): boolean {
  // Decode one level of common regex escapes so `\/\/` becomes `//`.
  const decoded = patternSource.replace(/\\([\\/"'ntr])/g, (_m, ch: string) => {
    if (ch === "n") return "\n";
    if (ch === "t") return "\t";
    if (ch === "r") return "\r";
    return ch;
  });
  return /\/\/|#|--/.test(decoded);
}

function isDefectiveUnstrippedMarkerLineGuard(text: string): boolean {
  const patterns = extractRegexPatternSources(text);
  const markerInPattern = patterns.some((p) =>
    /START_MODULE_CONTRACT|START_MODULE_MAP|START_BLOCK_/.test(p),
  );
  const lineAnchoredMarker = patterns.some(
    (p) =>
      p.startsWith("^")
      && /START_MODULE_CONTRACT|START_MODULE_MAP|START_BLOCK_/.test(p)
      && patternSourceHasCommentPrefix(p),
  );
  if (!markerInPattern || !lineAnchoredMarker) return false;
  if (!usesRegexAsGuard(text)) return false;

  const transformed = identifiersAssignedFromCall(text);
  const bareSubjects = lineScanBareIdentifierSubjects(text);
  const inlineCallSubject = hasCallExpressionLineScanSubject(text);

  // Chained scans: fire only when a bare identifier subject is not call-derived.
  // Call-expression subjects (inline transform) are call-derived without a binding (92).
  if (bareSubjects.length > 0 || inlineCallSubject) {
    const rawBare = bareSubjects.filter((s) => !transformed.has(s));
    return rawBare.length > 0;
  }

  // No chained split-callback: still silent when a call-derived intermediate is
  // newline-split (for-loop / indexed / two-step scan over the transformed value).
  for (const id of transformed) {
    const escaped = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (
      new RegExp(
        String.raw`\b${escaped}\s*\.\s*split\s*\(\s*(?:"\\n"|'\\n'|` + "`\\n`" + String.raw`)\s*\)`,
      ).test(text)
    ) {
      return false;
    }
  }
  // Marker line-regex used as a guard with no transformed line-scan subject.
  // Covers two-step raw form: `const lines = source.split("\n"); lines.some(...)` (d).
  return true;
}

export type RegexOverStructureScan = {
  findings: ReviewFinding[];
  shapeDataExemptions: string[];
};

function detectRegexOverStructure(root: string): RegexOverStructureScan {
  const findings: ReviewFinding[] = [];
  const shapeDataExemptions: string[] = [];
  for (const rel of listFilesRecursive(root, "src").filter(
    (f) => (f.endsWith(".ts") || f.endsWith(".js")) && !f.endsWith(".test.ts"),
  )) {
    const text = readText(root, rel);
    if (!text) continue;
    // Corr 88 / 90: exempt only shape-as-data files; report every exemption.
    if (fileHoldsShapesAsData(rel, text)) {
      shapeDataExemptions.push(normalizeRel(rel));
      continue;
    }
    if (!usesRegexAsGuard(text)) continue;

    const patterns = extractRegexPatternSources(text);
    const markupPattern = patterns.find((p) => patternSourceLooksLikeMarkupGuard(p));
    if (markupPattern) {
      findings.push(
        makeFinding(
          "review.regex-over-structure",
          rel,
          "File uses a regular expression as a structural guard over text that has structure.",
          "markup-or-attribute-regex-guard",
          `pattern:${markupPattern.slice(0, 48)}`,
        ),
      );
      continue;
    }

    if (isDefectiveUnstrippedMarkerLineGuard(text)) {
      findings.push(
        makeFinding(
          "review.regex-over-structure",
          rel,
          "Line-oriented marker regex over source without stripping structured regions first.",
          "unstripped-marker-line-guard",
          "marker-line-unstripped",
        ),
      );
    }
  }
  shapeDataExemptions.sort((a, b) => a.localeCompare(b));
  return { findings, shapeDataExemptions };
}

function detectZeroOrMoreSwallow(root: string): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  for (const planRel of listFilesRecursive(root, `${ARTIFACT_DIR}/changes`).filter((f) =>
    f.endsWith("plan.xml"),
  )) {
    if (scopeIdentityFromPlanRel(planRel)?.planLocation !== "active") continue;
    const abs = path.join(root, planRel);
    const artifact = readGraceXmlArtifact(abs);
    if (!artifact.root) continue;
    for (const node of walkNodes(artifact.root)) {
      if (!/^T-\d+$/.test(node.tag)) continue;
      const title = node.children.find((c) => c.tag === "Title")?.text.trim() ?? "";
      const depends = node.children.find((c) => c.tag === "DependsOn");
      const emptyDepends =
        depends !== undefined
        && depends.children.length === 0
        && !depends.text.trim();
      if (!emptyDepends) continue;
      if (/\bafter\b|\bsecond\b|\bthen\b|\bfollow|\bcompletes?\b|\bonce\b.*\bT-\d+/i.test(title)) {
        findings.push(
          makeFinding(
            "review.zero-or-more-swallow",
            planRel,
            `${node.tag} title claims sequencing ("${title}") but DependsOn is empty.`,
            "empty-depends-with-sequence-title",
            `task:${node.tag}:empty-depends`,
          ),
        );
      }
    }
  }
  return findings;
}

function detectUnthreadedConstruct(root: string): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  for (const verificationRel of listFilesRecursive(root, `${ARTIFACT_DIR}/verification`).filter(
    (f) => f.endsWith(".xml"),
  )) {
    const abs = path.join(root, verificationRel);
    const artifact = readGraceXmlArtifact(abs);
    if (!artifact.root) continue;
    let vmChildOrdinal = 0;
    for (const node of walkNodes(artifact.root)) {
      if (!/^V-M-/.test(node.tag)) continue;
      for (const child of node.children) {
        // corr 205-C: set shared with projections evidence + structure tags
        if (VERIFICATION_THREADED_CHILD_TAGS.has(child.tag)) continue;
        findings.push(
          makeFinding(
            "review.unthreaded-construct",
            verificationRel,
            `Verification child <${child.tag}> under ${node.tag} is not threaded through health or assertion evaluation.`,
            "unknown-verification-child",
            `vm-child:${node.tag}:${child.tag}#${vmChildOrdinal++}`,
          ),
        );
      }
    }
  }
  return findings;
}

export function runPatternDetectors(root: string): ReviewFinding[] {
  return runPatternDetectorsWithMeta(root).findings;
}

/** Pattern detectors plus shape-data exemption paths (A38.2). */
export function runPatternDetectorsWithMeta(root: string): {
  findings: ReviewFinding[];
  shapeDataExemptions: string[];
} {
  const regexScan = detectRegexOverStructure(root);
  return {
    findings: [
      ...detectConfidentlyWrong(root),
      ...detectSelfReferential(root),
      ...regexScan.findings,
      ...detectZeroOrMoreSwallow(root),
      ...detectUnthreadedConstruct(root),
    ],
    shapeDataExemptions: regexScan.shapeDataExemptions,
  };
}

// ---------------------------------------------------------------------------
// Family C — join engine (A34.1 pairs as process-shaped codes per A36.2)
// ---------------------------------------------------------------------------

export function runJoinProbes(probes: JoinProbe[]): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  for (const probe of probes) {
    if (probe.kind === "scope-home") {
      if (!probe.homeAdmits.includes(probe.recordScope)) {
        findings.push(
          makeFinding(
            "review.counterpart-scope-mismatch",
            probe.file,
            `Record scope "${probe.recordScope}" is not admitted by home constraints [${probe.homeAdmits.join(", ")}].`,
            "join-scope-home",
            `scope:${probe.recordScope}`,
          ),
        );
      }
    } else if (probe.kind === "writer-command") {
      for (const writer of probe.exportedWriters) {
        if (!probe.invocableCommands.includes(writer)) {
          findings.push(
            makeFinding(
              "review.counterpart-writer-missing",
              probe.file,
              `Exported writer "${writer}" has no invocable command surface.`,
              "join-writer-command",
              `writer:${writer}`,
            ),
          );
        }
      }
    } else if (probe.kind === "lint-vs-reader") {
      if (probe.lintRejects && probe.readerTreatsAsBenign) {
        findings.push(
          makeFinding(
            "review.counterpart-reader-tolerates",
            probe.file,
            `Lint rejects "${probe.condition}" but a blocking reader treats it as benign.`,
            "join-lint-reader",
            `cond:${probe.condition}`,
          ),
        );
      }
    } else if (probe.kind === "diagnostic-vs-preexisting") {
      if (probe.preexistingCanNeverClear) {
        findings.push(
          makeFinding(
            "review.counterpart-grandfather-gap",
            probe.file,
            `Diagnostic ${probe.diagnosticCode} fires permanently on artifacts that can never clear it.`,
            "join-grandfather",
            `diag:${probe.diagnosticCode}`,
          ),
        );
      }
    }
  }
  return findings;
}

// ---------------------------------------------------------------------------
// Family B — process audits (§6.4)
// ---------------------------------------------------------------------------

export type ScopeAuditIdentity = {
  /** Reviewed change id (C-*). Required for archive identity (corr 171). */
  changeId: string;
  /** Where plan.xml was resolved. Archive enables active↔archive aliases for this id only. */
  planLocation: "active" | "archive";
};

/**
 * Corr 171: when the plan resolved from `archive/<id>/`, declared paths under
 * `active/<id>/…` name the same bundle artifacts now living under `archive/<id>/…`.
 * Expand only that id's prefixes — never a global `.ngrace/changes/` swap (other bundles
 * must still flag as out of scope).
 */
export function expandScopePathsForArchiveIdentity(
  paths: string[],
  identity: ScopeAuditIdentity | undefined,
): string[] {
  if (!identity || identity.planLocation !== "archive" || !identity.changeId) {
    return paths.map(normalizeRel);
  }
  const activePrefix = `.ngrace/changes/active/${identity.changeId}/`;
  const archivePrefix = `.ngrace/changes/archive/${identity.changeId}/`;
  const out = new Set<string>();
  for (const raw of paths) {
    const n = normalizeRel(raw);
    out.add(n);
    if (n.startsWith(activePrefix)) {
      out.add(archivePrefix + n.slice(activePrefix.length));
    } else if (n.startsWith(archivePrefix)) {
      out.add(activePrefix + n.slice(archivePrefix.length));
    }
  }
  return [...out].sort();
}

/**
 * CLI lifecycle porcelain under a real change bundle (F11 / F11.2).
 * Matches, for any canonical C-* id (ANCHOR_PATTERNS.change):
 *   .ngrace/changes/{active|archive}/<C-ID>/run/**
 *   .ngrace/changes/{active|archive}/<C-ID>/run.xml
 *   .ngrace/changes/{active|archive}/<C-ID>/run-ledger.xml
 * Path-only (covers fold deletions). Not keyed on the reviewed change id (cross-bundle).
 * Does not match plan.xml / spec.xml or non-canonical directory names (e.g. scratch/).
 */
function isCliLifecyclePath(rel: string): boolean {
  const n = normalizeRel(rel);
  const prefix = `${ARTIFACT_DIR}/changes/`;
  if (!n.startsWith(prefix)) return false;
  const rest = n.slice(prefix.length); // active|archive / <id> / …
  const firstSlash = rest.indexOf("/");
  if (firstSlash <= 0) return false;
  const location = rest.slice(0, firstSlash);
  if (location !== "active" && location !== "archive") return false;
  const afterLocation = rest.slice(firstSlash + 1);
  const secondSlash = afterLocation.indexOf("/");
  if (secondSlash <= 0) return false;
  const changeId = afterLocation.slice(0, secondSlash);
  if (!ANCHOR_PATTERNS.change.test(changeId)) return false;
  const leaf = afterLocation.slice(secondSlash + 1);
  if (leaf === "run.xml" || leaf === "run-ledger.xml") return true;
  if (leaf === "run" || leaf.startsWith("run/")) return true;
  return false;
}

/**
 * Identity-keyed skip for the changed-files audit only.
 * Never merge into isCliLifecyclePath: that helper is shared with WriteEvidence.
 */
function isReviewedChangeSpecOrPlanPath(
  rel: string,
  identity?: ScopeAuditIdentity,
): boolean {
  if (!identity || identity.changeId === "") return false;
  const n = normalizeRel(rel);
  const id = identity.changeId;
  const leaves = ["spec.xml", "plan.xml", "design-context.xml"];
  for (const location of ["active", "archive"]) {
    for (const leaf of leaves) {
      if (n === `${ARTIFACT_DIR}/changes/${location}/${id}/${leaf}`) return true;
    }
  }
  return false;
}

export function auditScopeOutsideWriteScope(
  changedFiles: string[],
  scopeFiles: string[],
  scopeGlobs: string[],
  identity?: ScopeAuditIdentity,
): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  const expandedFiles = expandScopePathsForArchiveIdentity(scopeFiles, identity);
  const expandedGlobs = expandScopePathsForArchiveIdentity(scopeGlobs, identity);
  const fileSet = new Set(expandedFiles);
  for (const changed of changedFiles.map(normalizeRel)) {
    // F11: tool-owned lifecycle paths are not agent out-of-scope work (any C-*, any source).
    if (isCliLifecyclePath(changed)) continue;
    if (isReviewedChangeSpecOrPlanPath(changed, identity)) continue;
    if (fileSet.has(changed)) continue;
    const globHit = observedWriteScopeContains({ files: [], globs: expandedGlobs }, changed);
    if (globHit) continue;
    if (scopeFiles.length === 0 && scopeGlobs.length === 0) continue;
    findings.push(
      makeFinding(
        "review.scope-outside-write-scope",
        changed,
        `Changed file ${changed} is outside ObservedWriteScope.`,
        "scope-outside",
        `file:${changed}`,
      ),
    );
  }
  return findings;
}

/**
 * Authority roadmap tree (F27.1 / C-DECLARED-WRITES).
 * Hole this exclusion wrongly permits: an agent (or anyone) editing under
 * docs/plans/ (roadmap, decisions, review notes) without this finding firing.
 * Those paths are authority-owned concurrent work in this repo's model; the
 * residual is process + git history, not this audit. Does not swallow src/,
 * skills/, or non-lifecycle .ngrace/ paths.
 */
function isDocsPlansPath(rel: string): boolean {
  const n = normalizeRel(rel);
  return n === "docs/plans" || n.startsWith("docs/plans/");
}

/**
 * The exact canonical engine candidate-lock path: the sibling of a bundle leaf
 * under `active/`, `.candidate-<C-ID>.lock` for a valid canonical C-* id. Reached
 * only from `auditWriteEvidenceOutsideScope`; deliberately NOT part of
 * `isCliLifecyclePath`, whose byte-semantics stay restricted to `run.xml`,
 * `run-ledger.xml`, and `run/**` (C-SCOPE-AUDIT-ATTRIBUTION). Every near miss —
 * archive location, extra nesting, another top-level directory, or a malformed id
 * — still raises (AC-EVIDENCE-AUDIT-CANONICAL-ONLY).
 */
function isCanonicalEngineCandidateLockPath(rel: string): boolean {
  const n = normalizeRel(rel);
  const prefix = `${ARTIFACT_DIR}/changes/active/.candidate-`;
  const suffix = ".lock";
  if (!n.startsWith(prefix) || !n.endsWith(suffix)) return false;
  const id = n.slice(prefix.length, n.length - suffix.length);
  if (id.includes("/")) return false;
  return ANCHOR_PATTERNS.change.test(id);
}

export type WriteEvidenceScopeAuditInput = {
  changeId: string;
  /** Union of WriteEvidence content paths (already normalized preferred). */
  writeEvidencePaths: string[];
  scopeFiles: string[];
  scopeGlobs: string[];
  identity?: ScopeAuditIdentity;
};

/**
 * Ledger-backed scope audit (C-DECLARED-WRITES / F27): raise when a WriteEvidence
 * content path is outside ObservedWriteScope after lifecycle + docs/plans/
 * exclusions. Distinct code from porcelain auditScopeOutsideWriteScope.
 *
 * Non-lifecycle .ngrace/ paths (spec.xml, plan.xml, graph, verification) raise
 * when undeclared — approved-artifact immutability.
 */
export function auditWriteEvidenceOutsideScope(
  input: WriteEvidenceScopeAuditInput,
): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  const expandedFiles = expandScopePathsForArchiveIdentity(input.scopeFiles, input.identity);
  const expandedGlobs = expandScopePathsForArchiveIdentity(input.scopeGlobs, input.identity);
  const fileSet = new Set(expandedFiles);
  const seen = new Set<string>();

  for (const raw of input.writeEvidencePaths) {
    const changed = normalizeRel(raw);
    if (seen.has(changed)) continue;
    seen.add(changed);
    // F11: tool-owned lifecycle only (run.xml / run-ledger.xml / run/**) — not
    // spec.xml or plan.xml.
    if (isCliLifecyclePath(changed)) continue;
    // F27.1: authority concurrent roadmap — hole named on isDocsPlansPath.
    if (isDocsPlansPath(changed)) continue;
    // Durable historical WriteEvidence may name the exact canonical engine
    // candidate lock; that is transient coordination evidence, not a breach.
    // Local to this audit — isCliLifecyclePath is never widened.
    if (isCanonicalEngineCandidateLockPath(changed)) continue;
    if (fileSet.has(changed)) continue;
    const globHit = observedWriteScopeContains({ files: [], globs: expandedGlobs }, changed);
    if (globHit) continue;
    findings.push(
      makeFinding(
        WRITE_EVIDENCE_SCOPE_FINDING_CODE,
        changed,
        `WriteEvidence path ${changed} is outside ObservedWriteScope (ledger).`,
        "write-evidence-outside-scope",
        `file:${changed}`,
      ),
    );
  }
  return findings;
}

/**
 * Union of content paths from WriteEvidence on all ledger + loose events.
 * Empty union with no evidence → no-evidence; missing bundle → no-bundle.
 */
function loadWriteEvidencePathsFromBundle(
  projectRoot: string,
  changeId: string,
): { kind: "paths"; paths: string[] } | { kind: "no-bundle" } | { kind: "no-evidence"; reason: string } {
  let bundlePath: string;
  try {
    bundlePath = resolveChangeBundle(projectRoot, changeId);
  } catch {
    return { kind: "no-bundle" };
  }
  const ledgerPath = path.join(bundlePath, "run-ledger.xml");
  const hasLedger = existsSync(ledgerPath);
  const events: LooseEvent[] = [
    ...listLedgerEvents(bundlePath),
    ...listLooseEvents(bundlePath),
  ];
  const pathSet = new Set<string>();
  let sawWriteEvidenceNode = false;
  for (const event of events) {
    const payload = readAttemptPayload(event);
    if (!payload.writeEvidence) continue;
    sawWriteEvidenceNode = true;
    const digests = contentDigestsFromEvidence(payload.writeEvidence);
    for (const p of Object.keys(digests)) pathSet.add(normalizeRel(p));
  }
  if (pathSet.size > 0) {
    return { kind: "paths", paths: [...pathSet].sort() };
  }
  if (!hasLedger && events.length === 0) {
    return {
      kind: "no-evidence",
      reason: `no run-ledger.xml and no WriteEvidence for ${changeId}`,
    };
  }
  if (!hasLedger) {
    return {
      kind: "no-evidence",
      reason: `no run-ledger.xml for ${changeId}`,
    };
  }
  if (!sawWriteEvidenceNode) {
    return {
      kind: "no-evidence",
      reason: `no WriteEvidence in ledger for ${changeId}`,
    };
  }
  return {
    kind: "no-evidence",
    reason: `WriteEvidence present but no content digests for ${changeId}`,
  };
}

export function auditTestWeakening(diffs: TestFileDiff[]): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  for (const diff of diffs) {
    const beforeAsserts = countAssertions(diff.before);
    const afterAsserts = countAssertions(diff.after);
    if (afterAsserts < beforeAsserts) {
      findings.push(
        makeFinding(
          "review.test-assertion-weakened",
          diff.file,
          `Test file lost assertions (${beforeAsserts} → ${afterAsserts}).`,
          "assert-count-drop",
          `asserts:${beforeAsserts}->${afterAsserts}`,
        ),
      );
    }
    // expect(...).toBe(true) replacing a specific value is a weakening signal when toBe(true) increased
    const beforeStrict = (diff.before.match(/\.toBe\s*\(\s*[^t]/g) ?? []).length;
    const afterStrict = (diff.after.match(/\.toBe\s*\(\s*[^t]/g) ?? []).length;
    const beforeLoose = (diff.before.match(/\.toBeTruthy\s*\(|\.toBe\s*\(\s*true\s*\)/g) ?? []).length;
    const afterLoose = (diff.after.match(/\.toBeTruthy\s*\(|\.toBe\s*\(\s*true\s*\)/g) ?? []).length;
    if (afterStrict < beforeStrict && afterLoose > beforeLoose) {
      findings.push(
        makeFinding(
          "review.test-assertion-weakened",
          diff.file,
          "Strict equality assertions were replaced with looser checks.",
          "strict-to-loose",
          "strict-to-loose",
        ),
      );
    }
  }
  return findings;
}

function countAssertions(source: string): number {
  return (source.match(/\bexpect\s*\(/g) ?? []).length
    + (source.match(/\bassert\s*\(/g) ?? []).length;
}

export function auditCompatNewErrors(
  codesBefore: string[],
  codesAfter: string[],
): ReviewFinding[] {
  const before = new Set(codesBefore);
  const findings: ReviewFinding[] = [];
  for (const code of codesAfter) {
    if (!before.has(code)) {
      findings.push(
        makeFinding(
          "review.compat-new-error",
          "*",
          `New issue code ${code} appeared on a previously clean comparison set.`,
          "compat-new",
          `code:${code}`,
        ),
      );
    }
  }
  return findings;
}

export function auditHunkCoverage(hunks: HunkCoverageInput[]): ReviewFinding[] {
  return hunks
    .filter((h) => !h.covered)
    .map((h) =>
      makeFinding(
        "review.hunk-uncovered",
        h.file,
        `Changed hunk ${h.hunkKey} has no covering test attribution.`,
        "hunk-uncovered",
        h.hunkKey,
      ),
    );
}

// ---------------------------------------------------------------------------
// Attempt-pair write evidence (C-SUBSTANTIATION-HONESTY / F9.10 / F31 / F32)
// Identical-tree rule: raise when no non-.ngrace/ content digest differs.
// ---------------------------------------------------------------------------

/** One fail→pass pair with WriteEvidence content digests (path → digest). */
export type AttemptPairEvidenceInput = {
  changeId: string;
  /**
   * Project root for resolveChangeBundle anchor (F32). When omitted, unit fixtures
   * get a synthetic anchor that does not hardcode active/ for archived ids.
   */
  projectRoot?: string;
  /**
   * Optional pre-resolved finding file (posix relative). Wins over projectRoot.
   */
  resolvedAnchorFile?: string;
  /**
   * Unused by the identical-tree raise condition (OWS is not consulted).
   * Retained optional for call-site compatibility with older fixtures.
   */
  scopeFiles?: string[];
  pairs: Array<{
    task: string;
    failEventId: number;
    passEventId: number;
    /** Content digests from fail attempt WriteEvidence (path → digest). */
    failDigests: Record<string, string>;
    /** Content digests from pass attempt WriteEvidence (path → digest). */
    passDigests: Record<string, string>;
  }>;
};

/**
 * True when path is a ledger/tool artifact under `.ngrace/`.
 *
 * Excluded from identical-tree comparison because the cursor writes `run.xml`
 * and loose event files on every attempt command — those digests differ across
 * almost any honest pair and prove nothing about authored work (F9.10 / F11).
 */
function isNgraceLedgerPath(filePath: string): boolean {
  const n = normalizeRel(filePath);
  return n === ".ngrace" || n.startsWith(".ngrace/");
}

/**
 * Content digests from a WriteEvidence snapshot (available content files only).
 * Absent/undetermined entries are not comparable substantiation.
 */
function contentDigestsFromEvidence(evidence: WriteEvidenceSnapshot | undefined): Record<string, string> {
  if (!evidence || !evidence.available) return {};
  const out: Record<string, string> = {};
  for (const file of evidence.files) {
    if (file.kind === "content" && file.digest) {
      out[normalizeRel(file.path)] = file.digest;
    }
  }
  return out;
}

/**
 * Relative finding path for an attempt-pair finding (F32).
 * Prefer resolveChangeBundle so archived bundles do not point at missing active/.
 */
function resolveAttemptPairAnchorFile(
  changeId: string,
  projectRoot: string | undefined,
  resolvedAnchorFile: string | undefined,
): string {
  if (resolvedAnchorFile) return normalizeRel(resolvedAnchorFile);
  if (projectRoot) {
    try {
      const bundlePath = resolveChangeBundle(projectRoot, changeId);
      const relBundle = path.relative(path.resolve(projectRoot), bundlePath).replaceAll("\\", "/");
      const runDir = path.join(bundlePath, "run");
      if (existsSync(runDir)) return `${relBundle}/run`;
      const ledger = path.join(bundlePath, "run-ledger.xml");
      if (existsSync(ledger)) return `${relBundle}/run-ledger.xml`;
      return relBundle;
    } catch {
      // fall through
    }
  }
  // Unit fixtures without a real bundle — do not invent active/ for archive ids.
  return `.ngrace/changes/${changeId}/run`;
}

/**
 * True when any non-`.ngrace/` content path differs across the pair
 * (digest change, or presence on only one side).
 */
function nonNgraceContentDiffers(
  failDigests: Record<string, string>,
  passDigests: Record<string, string>,
): boolean {
  const keys = new Set([...Object.keys(failDigests), ...Object.keys(passDigests)]);
  for (const filePath of keys) {
    if (isNgraceLedgerPath(filePath)) continue;
    if (failDigests[filePath] !== passDigests[filePath]) return true;
  }
  return false;
}

/**
 * Identical-tree audit (C-SUBSTANTIATION-HONESTY): raise when a fail→pass pair
 * has no non-`.ngrace/` WriteEvidence content difference.
 *
 * Does not consult ObservedWriteScope or production-vs-test path filters.
 * Production-must-move is retired (F9.10: 100% false-positive rate on archive).
 */
export function auditAttemptPairWriteEvidence(input: AttemptPairEvidenceInput): ReviewFinding[] {
  const findings: ReviewFinding[] = [];
  const file = resolveAttemptPairAnchorFile(
    input.changeId,
    input.projectRoot,
    input.resolvedAnchorFile,
  );

  for (const pair of input.pairs) {
    const failD = Object.fromEntries(
      Object.entries(pair.failDigests).map(([p, d]) => [normalizeRel(p), d]),
    );
    const passD = Object.fromEntries(
      Object.entries(pair.passDigests).map(([p, d]) => [normalizeRel(p), d]),
    );

    // Raise only when the non-.ngrace/ trees are identical (including both empty).
    if (nonNgraceContentDiffers(failD, passD)) continue;

    const anchor = `attempt-pair:${pair.task}:${pair.failEventId}->${pair.passEventId}`;
    const message =
      `Fail→pass attempt pair ${pair.task} (events ${pair.failEventId}→${pair.passEventId}) `
      + "has identical non-.ngrace/ WriteEvidence content digests "
      + "(no authored path outside .ngrace/ differs across the pair). "
      + "Red-first is not corroborated by any non-ledger content change (F9.10).";

    findings.push(
      makeFinding(
        ATTEMPT_PAIR_FINDING_CODE,
        file,
        message,
        "attempt-pair-write-evidence",
        anchor,
      ),
    );
  }
  return findings;
}

/**
 * Archived statuses that are terminal but not `applied` — abandoned governance
 * (`ngrace supersede` discards governance, never code). F286.
 */
const ABANDONED_ARCHIVE_STATUSES = new Set(["superseded", "rejected", "cancelled"]);

/**
 * F286: an archived bundle whose spec status is terminal-but-not-`applied` is
 * abandoned governance, not delivered evidence, so the attempt-pair
 * corroboration standard does not apply to it — the same stance archived plans
 * take in `src/lint/core.ts` (syntax only, never semantic). An `applied`
 * archived bundle is not exempt and its stream is fully audited.
 */
function isAbandonedArchiveBundle(bundlePath: string): boolean {
  const archiveMarker = `${path.sep}changes${path.sep}archive${path.sep}`;
  if (!bundlePath.includes(archiveMarker)) return false;
  const specPath = path.join(bundlePath, "spec.xml");
  if (!existsSync(specPath)) return false;
  const status = readGraceXmlArtifact(specPath).root?.attributes.status;
  return status !== undefined && ABANDONED_ARCHIVE_STATUSES.has(status);
}

/**
 * Load fail→pass attempt pairs for a change from loose run/ + folded ledger.
 * Read-only. Pairs each pass with the most recent prior fail on the same task.
 */
function loadAttemptPairsFromBundle(
  projectRoot: string,
  changeId: string,
): { pairs: AttemptPairEvidenceInput["pairs"]; unpaired: LooseEvent[] } {
  let bundlePath: string;
  try {
    bundlePath = resolveChangeBundle(projectRoot, changeId);
  } catch {
    return { pairs: [], unpaired: [] };
  }
  // F286: abandoned archived governance is not held to the corroboration standard.
  if (isAbandonedArchiveBundle(bundlePath)) {
    return { pairs: [], unpaired: [] };
  }
  const events: LooseEvent[] = [
    ...listLedgerEvents(bundlePath),
    ...listLooseEvents(bundlePath),
  ]
    .filter((e) => e.kind === "attempt")
    .sort((a, b) => a.id - b.id);

  const pendingFailsByTask = new Map<string, LooseEvent[]>();
  const pairs: AttemptPairEvidenceInput["pairs"] = [];
  const unpaired: LooseEvent[] = [];

  for (const event of events) {
    const payload = readAttemptPayload(event);
    const outcome = (payload.outcome ?? event.attributes.outcome ?? "").trim();
    if (outcome === "fail") {
      const queue = pendingFailsByTask.get(event.task) ?? [];
      queue.push(event);
      pendingFailsByTask.set(event.task, queue);
      continue;
    }
    if (outcome !== "pass") continue;
    const queue = pendingFailsByTask.get(event.task);
    const failEvent = queue && queue.length > 0 ? queue.shift() : undefined;
    if (!failEvent) {
      unpaired.push(event);
      continue;
    }
    const failPayload = readAttemptPayload(failEvent);
    pairs.push({
      task: event.task,
      failEventId: failEvent.id,
      passEventId: event.id,
      failDigests: contentDigestsFromEvidence(failPayload.writeEvidence),
      passDigests: contentDigestsFromEvidence(payload.writeEvidence),
    });
  }
  for (const queue of pendingFailsByTask.values()) unpaired.push(...queue);
  return { pairs, unpaired };
}

// ---------------------------------------------------------------------------
// Public entry
// ---------------------------------------------------------------------------

const NO_CHANGE_SUPPLIED_REASON = "no --change supplied";

export function runReview(projectRoot: string, options: ReviewOptions = {}): ReviewResult {
  const root = path.resolve(projectRoot);
  const runPatterns = options.patterns !== false;
  const runProcess = options.processAudits !== false;
  const runJoin = options.joinEngine !== false;

  const findings: ReviewFinding[] = [];
  let shapeDataExemptions: string[] = [];

  if (runPatterns) {
    const patternResult = runPatternDetectorsWithMeta(root);
    findings.push(...patternResult.findings);
    shapeDataExemptions = patternResult.shapeDataExemptions;
  }

  if (runJoin && options.joinProbes && options.joinProbes.length > 0) {
    findings.push(...runJoinProbes(options.joinProbes));
  }

  let scopeAudit: ScopeAuditReport | undefined;
  let attemptPairAudit: AttemptPairAuditReport | undefined;
  let writeEvidenceScopeAudit: WriteEvidenceScopeAuditReport | undefined;
  let amendmentCountAudit: AmendmentCountAuditReport | undefined;

  if (runProcess) {
    if (options.changeId) {
      findings.push(...auditCloseEvidenceUnevaluated(root, options.changeId));
      findings.push(...auditApprovedArtifact(root, options.changeId));
      const changeId = options.changeId;
      const resolved = resolveChangePlanPath(root, changeId);
      if (!resolved) {
        const reason = `no plan found for ${changeId} under active/ or archive/`;
        scopeAudit = {
          status: "not-run",
          reason,
          changeId,
          absence: { verdict: "not-run", reason },
        };
      } else if (resolved.location === "archive") {
        const reason = `plan for ${changeId} resolved under archive/`;
        scopeAudit = {
          status: "not-run",
          reason,
          changeId,
          planLocation: "archive",
          absence: { verdict: "not-run", reason },
        };
      } else {
        const extracted = extractObservedWriteScopeFromPlan(resolved.planPath, root);
        const scopeFiles = extracted.files;
        const scopeGlobs = extracted.globs;
        const input = resolveScopeChangedFiles(root, options);
        if (input.kind === "absence") {
          scopeAudit = {
            status: input.absence.verdict === "not-run" ? "not-run" : "unable-to-determine",
            reason: input.absence.reason,
            changeId,
            planLocation: resolved.location,
            absence: input.absence,
          };
        } else if (scopeFiles.length === 0 && scopeGlobs.length === 0) {
          const reason = `plan for ${changeId} has empty ObservedWriteScope`;
          scopeAudit = {
            status: "not-run",
            reason,
            changeId,
            planLocation: resolved.location,
            absence: { verdict: "not-run", reason },
          };
        } else {
          const callerSuppliedEmpty =
            input.source === "explicit" && input.files.length === 0;
          const scopeFindings = auditScopeOutsideWriteScope(
            input.files,
            scopeFiles,
            scopeGlobs,
            { changeId, planLocation: resolved.location },
          );
          findings.push(...scopeFindings);
          const outOfScope = scopeFindings.length;
          scopeAudit = {
            status: "ran",
            reason: callerSuppliedEmpty
              ? `ran over caller-supplied empty set against ObservedWriteScope for ${changeId}`
              : outOfScope === 0
                ? `ran over ${input.files.length} changed file(s) against ObservedWriteScope for ${changeId}; no out-of-scope paths`
                : `ran over ${input.files.length} changed file(s) against ObservedWriteScope for ${changeId}; ${outOfScope} out-of-scope`,
            changeId,
            planLocation: resolved.location,
            inputSource: input.source,
            baseRef: input.baseRef,
            changedFileCount: input.files.length,
            callerSuppliedEmpty: callerSuppliedEmpty || undefined,
          };
        }
      }
    }

    if (options.testFileDiffs) {
      findings.push(...auditTestWeakening(options.testFileDiffs));
    }
    if (options.lintCodesBefore && options.lintCodesAfter) {
      findings.push(...auditCompatNewErrors(options.lintCodesBefore, options.lintCodesAfter));
    }
    if (options.hunkCoverage) {
      findings.push(...auditHunkCoverage(options.hunkCoverage));
    }

    // C-SUBSTANTIATION-HONESTY: fail→pass identical-tree audit + absence record (F31).
    if (!options.changeId) {
      const reason = NO_CHANGE_SUPPLIED_REASON;
      attemptPairAudit = {
        status: "not-run",
        reason,
        absence: { verdict: "not-run", reason },
      };
    } else {
      const changeId = options.changeId;
      let bundleResolves = true;
      try {
        resolveChangeBundle(root, changeId);
      } catch {
        bundleResolves = false;
      }
      if (!bundleResolves) {
        const reason = `change bundle ${changeId} not found under active/ or archive/`;
        attemptPairAudit = {
          status: "not-run",
          reason,
          changeId,
          absence: { verdict: "not-run", reason },
        };
      } else {
        const { pairs, unpaired } = loadAttemptPairsFromBundle(root, changeId);
        const pairFindings = auditAttemptPairWriteEvidence({
          changeId,
          projectRoot: root,
          pairs,
        });
        const unpairedFindings = unpaired.map((event) => {
          const payload = readAttemptPayload(event);
          const outcome = (payload.outcome ?? event.attributes.outcome ?? "").trim();
          return makeFinding(
            outcome === "pass"
              ? ATTEMPT_PAIR_UNPAIRED_PASS_FINDING_CODE
              : ATTEMPT_PAIR_UNPAIRED_FAIL_FINDING_CODE,
            resolveAttemptPairAnchorFile(changeId, root, undefined),
            `Attempt ${event.id} (${outcome}) for ${event.task} is unpaired: `
              + (outcome === "pass"
                ? "no preceding fail corroborates red-first (pass-only attempt)."
                : "no following pass resolved this red (the red stands unresolved)."),
            outcome === "pass" ? "attempt-pair-unpaired-pass" : "attempt-pair-unpaired-fail",
            `attempt-pair:unpaired:${event.task}:${event.id}`,
          );
        });
        findings.push(...pairFindings, ...unpairedFindings);
        attemptPairAudit = {
          status: "ran",
          reason: `ran over ${pairs.length} fail→pass pair(s) for ${changeId}`,
          changeId,
          pairCount: pairs.length,
          findingCount: pairFindings.length + unpairedFindings.length,
        };
      }
    }

    // C-DECLARED-WRITES: WriteEvidence paths vs ObservedWriteScope (F27 / F31 absence).
    if (!options.changeId) {
      const reason = NO_CHANGE_SUPPLIED_REASON;
      writeEvidenceScopeAudit = {
        status: "not-run",
        reason,
        absence: { verdict: "not-run", reason },
      };
    } else {
      const changeId = options.changeId;
      const resolved = resolveChangePlanPath(root, changeId);
      if (!resolved) {
        const reason = `no plan found for ${changeId} under active/ or archive/`;
        writeEvidenceScopeAudit = {
          status: "not-run",
          reason,
          changeId,
          absence: { verdict: "not-run", reason },
        };
      } else {
        const loaded = loadWriteEvidencePathsFromBundle(root, changeId);
        if (loaded.kind === "no-bundle") {
          const reason = `change bundle ${changeId} not found under active/ or archive/`;
          writeEvidenceScopeAudit = {
            status: "unable-to-determine",
            reason,
            changeId,
            absence: { verdict: "unable-to-determine", reason },
          };
        } else if (loaded.kind === "no-evidence") {
          writeEvidenceScopeAudit = {
            status: "unable-to-determine",
            reason: loaded.reason,
            changeId,
            absence: { verdict: "unable-to-determine", reason: loaded.reason },
          };
        } else {
          const extracted = extractObservedWriteScopeFromPlan(resolved.planPath, root);
          const weFindings = auditWriteEvidenceOutsideScope({
            changeId,
            writeEvidencePaths: loaded.paths,
            scopeFiles: extracted.files,
            scopeGlobs: extracted.globs,
            identity: { changeId, planLocation: resolved.location },
          });
          findings.push(...weFindings);
          writeEvidenceScopeAudit = {
            status: "ran",
            reason:
              weFindings.length === 0
                ? `ran over ${loaded.paths.length} WriteEvidence path(s) for ${changeId}; no out-of-scope paths`
                : `ran over ${loaded.paths.length} WriteEvidence path(s) for ${changeId}; ${weFindings.length} out-of-scope`,
            changeId,
            pathCount: loaded.paths.length,
            findingCount: weFindings.length,
          };
        }
      }
    }

    if (!options.changeId) {
      const reason = NO_CHANGE_SUPPLIED_REASON;
      amendmentCountAudit = {
        status: "not-run",
        reason,
        absence: { verdict: "not-run", reason },
      };
    } else {
      const changeId = options.changeId;
      let bundleResolves = true;
      try {
        resolveChangeBundle(root, changeId);
      } catch {
        bundleResolves = false;
      }
      if (!bundleResolves) {
        const reason = `change bundle ${changeId} not found under active/ or archive/`;
        amendmentCountAudit = {
          status: "not-run",
          reason,
          changeId,
          absence: { verdict: "not-run", reason },
        };
      } else {
        const instrument = readAmendmentInstrument(root, changeId);
        amendmentCountAudit = {
          status: "ran",
          reason: `ran amendment counts for ${changeId}`,
          changeId,
          reRatificationCount: instrument.reRatificationCount,
          supersedeChainDepth: instrument.supersedeChainDepth,
        };
      }
    }
  }

  if (scopeAudit) {
    scopeAudit = attachNoBaseCommitCaveat(scopeAudit, options);
  }

  findings.sort(
    (a, b) =>
      a.file.localeCompare(b.file)
      || a.code.localeCompare(b.code)
      || a.findingId.localeCompare(b.findingId),
  );

  const displayed = applyReviewSeverityThreshold(findings, options.severity ?? "warning");

  return {
    schemaVersion: "1.0.0",
    tool: "ngrace-review",
    root,
    findings: displayed,
    shapeDataExemptions,
    scopeAudit,
    attemptPairAudit,
    writeEvidenceScopeAudit,
    amendmentCountAudit,
    summary: {
      findings: displayed.length,
      errors: displayed.filter((f) => f.severity === "error").length,
      warnings: displayed.filter((f) => f.severity === "warning").length,
      infos: displayed.filter((f) => f.severity === "info").length,
      shapeDataExemptions: shapeDataExemptions.length,
    },
  };
}

type ScopeChangedFilesResolution =
  | { kind: "files"; files: string[]; source: "explicit" | "base" | "porcelain" | "recorded-base"; baseRef?: string }
  | { kind: "absence"; absence: AbsenceValue };

function auditApprovedArtifact(root: string, changeId: string): ReviewFinding[] {
  let bundlePath: string;
  try {
    bundlePath = resolveChangeBundle(root, changeId);
  } catch {
    return [];
  }
  const out: ReviewFinding[] = [];
  for (const artifact of ["spec", "plan"] as const) {
    const filePath = path.join(bundlePath, `${artifact}.xml`);
    if (!existsSync(filePath)) continue;
    if (readGraceXmlArtifact(filePath).root?.attributes.status !== "approved") continue;
    const classification = classifyApprovedArtifact(root, changeId, artifact);
    const rel = path.relative(root, filePath).replaceAll("\\", "/");
    if (classification.kind === "never-asked") {
      out.push(
        makeFinding(
          APPROVAL_NEVER_ASKED_FINDING_CODE,
          rel,
          `approved ${artifact}.xml has no applying permitting approve Decision.`,
          APPROVAL_NEVER_ASKED_FINDING_CODE,
          artifact,
        ),
      );
    } else if (classification.kind === "mismatch") {
      out.push(
        makeFinding(
          APPROVAL_FINGERPRINT_MISMATCH_FINDING_CODE,
          rel,
          `approved ${artifact}.xml fingerprint does not match the current file bytes.`,
          APPROVAL_FINGERPRINT_MISMATCH_FINDING_CODE,
          artifact,
        ),
      );
    }
  }
  return out;
}

function auditCloseEvidenceUnevaluated(root: string, changeId: string): ReviewFinding[] {
  let bundlePath: string;
  try {
    bundlePath = resolveChangeBundle(root, changeId);
  } catch {
    return [];
  }
  const archiveMarker = `${path.sep}changes${path.sep}archive${path.sep}`;
  if (!bundlePath.includes(archiveMarker)) return [];
  const specPath = path.join(bundlePath, "spec.xml");
  if (!existsSync(specPath)) return [];
  const spec = readGraceXmlArtifact(specPath);
  if (spec.root?.attributes.status !== "applied") return [];
  const wrapper = spec.root.children.find((child) => ANCHOR_PATTERNS.change.test(child.tag));
  if (!wrapper) return [];
  const closeBound = collectCloseBoundCriterionIds(wrapper);
  if (closeBound.size === 0) return [];

  const evaluated = new Set<string>();
  const ledgerPath = path.join(bundlePath, "run-ledger.xml");
  if (existsSync(ledgerPath)) {
    const ledger = readGraceXmlArtifact(ledgerPath);
    const ledgerWrapper = ledger.root?.children.find((child) => ANCHOR_PATTERNS.change.test(child.tag));
    const verdicts = ledgerWrapper?.children.find((child) => child.tag === "Verdicts");
    for (const verdict of verdicts?.children ?? []) {
      for (const evaluation of collectCloseEvidenceEvaluations(verdict)) {
        evaluated.add(evaluation.criterionId);
      }
    }
  }

  const specRel = path.relative(root, specPath).replaceAll("\\", "/");
  const out: ReviewFinding[] = [];
  for (const id of closeBound) {
    if (evaluated.has(id)) continue;
    out.push(
      makeFinding(
        CLOSE_EVIDENCE_ABSENCE_FINDING_CODE,
        specRel,
        `${id} has no recorded CloseEvidence evaluation on any Verdict.`,
        CLOSE_EVIDENCE_ABSENCE_FINDING_CODE,
        id,
      ),
    );
  }
  return out;
}

function readRecordedBaseCommit(root: string, changeId: string): string | undefined {
  try {
    const found = listGateDecisions(root, changeId).find(
      (entry) =>
        entry.gate === "approve"
        && entry.decision === "permit"
        && Boolean(entry.baseCommit?.trim()),
    );
    return found?.baseCommit?.trim();
  } catch {
    return undefined;
  }
}

const NO_BASE_COMMIT_CAVEAT = "no base commit — cannot attribute pre-existing changes";

function reviewOverrideIsSet(options: ReviewOptions): boolean {
  if (options.changedFiles !== undefined) return true;
  return Boolean(options.baseRef !== undefined && options.baseRef !== null && String(options.baseRef).trim());
}

function attachNoBaseCommitCaveat(
  audit: ScopeAuditReport,
  options: ReviewOptions,
): ScopeAuditReport {
  if (!options.changeId || reviewOverrideIsSet(options)) return audit;
  if (
    audit.inputSource === "recorded-base"
    || audit.inputSource === "explicit"
    || audit.inputSource === "base"
  ) {
    return audit;
  }
  const porcelainRan = audit.inputSource === "porcelain" && audit.status === "ran";
  const porcelainNotRun =
    audit.status === "not-run" && /no changed files available/i.test(audit.reason);
  const gitUnavailable =
    audit.status === "unable-to-determine" && /git status unavailable/i.test(audit.reason);
  if (!porcelainRan && !porcelainNotRun && !gitUnavailable) return audit;
  if (audit.reason.includes(NO_BASE_COMMIT_CAVEAT)) return audit;
  const reason = `${audit.reason} ${NO_BASE_COMMIT_CAVEAT}`;
  return {
    ...audit,
    reason,
    absence: audit.absence ? { ...audit.absence, reason } : audit.absence,
  };
}

function posixProjectRel(entry: string): string | undefined {
  const normalized = entry.replaceAll("\\", "/").replace(/^\.\//, "").trim();
  if (!normalized || normalized === ".." || normalized.startsWith("../")) return undefined;
  if (path.posix.isAbsolute(normalized) || path.win32.isAbsolute(normalized)) return undefined;
  return normalized;
}

/** git stderr as a one-line diagnostic tail, or the exit code when git said nothing (F40). */
function gitFailureDetail(result: { stderr: Uint8Array; exitCode: number | null }): string {
  const stderr = new TextDecoder().decode(result.stderr).trim().split("\n")[0]?.trim() ?? "";
  return stderr ? stderr.slice(0, 200) : `exit ${result.exitCode}`;
}

/**
 * Commit-versus-working-tree name-only set for a recorded approve base.
 * Unexported: tests go through runReview. Do not reuse listFilesChangedAgainstBase.
 *
 * Three distinct failures, three distinct reasons (F40 / F55): the sha not resolving,
 * the diff failing, and the untracked walk failing are different facts, and only the
 * first one indicts the sha. All three stay `unable-to-determine`.
 */
function listFilesChangedAgainstRecordedBase(
  root: string,
  sha: string,
): { available: true; files: string[] } | { available: false; absence: AbsenceValue } {
  const verified = Bun.spawnSync({
    cmd: ["git", "rev-parse", "--verify", "--quiet", `${sha}^{commit}`],
    cwd: root,
    stdout: "pipe",
    stderr: "pipe",
  });
  if (verified.exitCode !== 0) {
    return {
      available: false,
      absence: {
        verdict: "unable-to-determine",
        reason: `recorded base ${sha} does not resolve`,
      },
    };
  }
  const diff = Bun.spawnSync({
    cmd: ["git", "-c", "status.relativePaths=true", "diff", "--name-only", "--diff-filter=ACMR", sha],
    cwd: root,
    stdout: "pipe",
    stderr: "pipe",
  });
  if (diff.exitCode !== 0) {
    return {
      available: false,
      absence: {
        verdict: "unable-to-determine",
        reason:
          `recorded base ${sha} resolved, but git diff against it failed: ${gitFailureDetail(diff)}`,
      },
    };
  }
  const porcelain = Bun.spawnSync({
    cmd: [
      "git",
      "-c",
      "status.relativePaths=true",
      "status",
      "--porcelain=v1",
      "-z",
      "--untracked-files=all",
      "--",
      ".",
    ],
    cwd: root,
    stdout: "pipe",
    stderr: "pipe",
  });
  if (porcelain.exitCode !== 0) {
    return {
      available: false,
      absence: {
        verdict: "unable-to-determine",
        reason:
          `recorded base ${sha} diffed, but git status (untracked walk) failed: `
          + gitFailureDetail(porcelain),
      },
    };
  }

  const fromDiff = new TextDecoder()
    .decode(diff.stdout)
    .split("\n")
    .map((entry) => posixProjectRel(entry))
    .filter((entry): entry is string => Boolean(entry));

  const records = new TextDecoder().decode(porcelain.stdout).split("\0");
  const untracked: string[] = [];
  for (let index = 0; index < records.length; index += 1) {
    const record = records[index];
    if (!record || record.length < 4) continue;
    const status = record.slice(0, 2);
    if (status.includes("R") || status.includes("C")) {
      index += 1;
    }
    if (status !== "??") continue;
    const normalized = posixProjectRel(record.slice(3));
    if (normalized) untracked.push(normalized);
  }

  const files = [...new Set([...fromDiff, ...untracked])].sort();
  return { available: true, files };
}

/**
 * Resolve the changed-file set for the scope audit.
 * - defined `changedFiles` (incl. []) → caller-owned explicit set (A66 Q5)
 * - else `baseRef` → three-dot name-only (A66.3)
 * - else recorded approve baseCommit → commit-versus-worktree plus untracked
 * - else porcelain: non-empty usable; empty or unavailable → not-run / unable-to-determine (corr 169)
 */
function resolveScopeChangedFiles(
  root: string,
  options: ReviewOptions,
): ScopeChangedFilesResolution {
  if (options.changedFiles !== undefined) {
    const files = [
      ...new Set(
        options.changedFiles
          .map((entry) => entry.replaceAll("\\", "/").replace(/^\.\//, "").trim())
          .filter((entry) => entry !== ""),
      ),
    ].sort();
    return { kind: "files", files, source: "explicit" };
  }
  if (options.baseRef !== undefined && options.baseRef !== null && String(options.baseRef).trim() !== "") {
    const listed = listFilesChangedAgainstBase(root, String(options.baseRef));
    if (!listed.available) {
      return { kind: "absence", absence: listed.absence };
    }
    return {
      kind: "files",
      files: listed.changedFiles,
      source: "base",
      baseRef: String(options.baseRef).trim(),
    };
  }
  if (options.changeId) {
    const recorded = readRecordedBaseCommit(root, options.changeId);
    if (recorded) {
      const listed = listFilesChangedAgainstRecordedBase(root, recorded);
      if (!listed.available) {
        return { kind: "absence", absence: listed.absence };
      }
      return {
        kind: "files",
        files: listed.files,
        source: "recorded-base",
        baseRef: recorded,
      };
    }
  }
  const listed = listRepositoryChangedFiles(root);
  if (!listed.available) {
    return {
      kind: "absence",
      absence: {
        verdict: "unable-to-determine",
        reason: "git status unavailable; cannot derive changed files (supply --base or --changed-files)",
      },
    };
  }
  if (listed.changedFiles.length === 0) {
    return {
      kind: "absence",
      absence: {
        verdict: "not-run",
        reason:
          "no changed files available (working tree clean; supply --base or --changed-files)",
      },
    };
  }
  return { kind: "files", files: listed.changedFiles, source: "porcelain" };
}

export function formatReviewResult(result: ReviewResult): string {
  const lines = [
    "neo-grace Review Report",
    "=======================",
    `Root: ${result.root}`,
    `Findings: ${result.summary.findings} (errors: ${result.summary.errors}, warnings: ${result.summary.warnings}, infos: ${result.summary.infos})`,
    `Shape-data exemptions: ${result.summary.shapeDataExemptions}`,
    "",
  ];
  if (result.shapeDataExemptions.length > 0) {
    for (const p of result.shapeDataExemptions) {
      lines.push(`  - ${p}`);
    }
    lines.push("");
  }

  if (result.scopeAudit) {
    lines.push(formatScopeAuditLine(result.scopeAudit));
    lines.push("");
  }

  if (result.writeEvidenceScopeAudit) {
    lines.push(formatWriteEvidenceScopeAuditLine(result.writeEvidenceScopeAudit));
    lines.push("");
  }

  if (result.attemptPairAudit) {
    lines.push(formatAttemptPairAuditLine(result.attemptPairAudit));
    lines.push("");
  }

  if (result.amendmentCountAudit) {
    lines.push(formatAmendmentCountAuditLine(result.amendmentCountAudit));
    lines.push("");
  }

  if (result.findings.length === 0) {
    // A66.4 / rule 11 / F31: "No review findings" is false when a process audit did not run.
    const scopeSkipped =
      result.scopeAudit
      && (result.scopeAudit.status === "not-run"
        || result.scopeAudit.status === "unable-to-determine");
    const attemptPairSkipped =
      result.attemptPairAudit
      && (result.attemptPairAudit.status === "not-run"
        || result.attemptPairAudit.status === "unable-to-determine");
    const writeEvidenceScopeSkipped =
      result.writeEvidenceScopeAudit
      && (result.writeEvidenceScopeAudit.status === "not-run"
        || result.writeEvidenceScopeAudit.status === "unable-to-determine");
    const amendmentCountSkipped =
      result.amendmentCountAudit
      && (result.amendmentCountAudit.status === "not-run"
        || result.amendmentCountAudit.status === "unable-to-determine");
    if (!scopeSkipped && !attemptPairSkipped && !writeEvidenceScopeSkipped && !amendmentCountSkipped) {
      lines.push("No review findings.");
    }
    return lines.join("\n");
  }
  lines.push("Findings");
  for (const f of result.findings) {
    lines.push(
      `- [${f.severity}] ${f.code} ${f.file} — ${f.message} (id=${f.findingId})`,
    );
  }
  return lines.join("\n");
}

function formatAttemptPairAuditLine(audit: AttemptPairAuditReport): string {
  if (audit.status === "not-run" || audit.status === "unable-to-determine") {
    return `Attempt-pair audit: ${audit.status} — ${audit.reason}`;
  }
  const n = audit.pairCount ?? 0;
  const f = audit.findingCount ?? 0;
  const id = audit.changeId ?? "?";
  return `Attempt-pair audit: ran over ${n} fail→pass pair(s) for ${id} (${f} finding(s)).`;
}

function formatWriteEvidenceScopeAuditLine(audit: WriteEvidenceScopeAuditReport): string {
  if (audit.status === "not-run" || audit.status === "unable-to-determine") {
    return `WriteEvidence scope audit: ${audit.status} — ${audit.reason}`;
  }
  const n = audit.pathCount ?? 0;
  const f = audit.findingCount ?? 0;
  const id = audit.changeId ?? "?";
  return `WriteEvidence scope audit: ran over ${n} path(s) for ${id} (${f} finding(s)).`;
}

function formatAmendmentCountAuditLine(audit: AmendmentCountAuditReport): string {
  if (audit.status === "not-run" || audit.status === "unable-to-determine") {
    return `Amendment count: ${audit.status} — ${audit.reason}`;
  }
  const rerat = audit.reRatificationCount ?? 0;
  const depth = audit.supersedeChainDepth ?? 0;
  const id = audit.changeId ?? "?";
  return `Amendment count: re-ratifications=${rerat} supersede-depth=${depth} for ${id}`;
}

function formatScopeAuditLine(audit: ScopeAuditReport): string {
  if (audit.status === "not-run" || audit.status === "unable-to-determine") {
    return `Scope audit: ${audit.status} — ${audit.reason}`;
  }
  // status === "ran"
  if (audit.callerSuppliedEmpty) {
    return (
      `Scope audit: ran over 0 changed files against ObservedWriteScope for ${audit.changeId}`
      + ` (input: caller-supplied empty set). No out-of-scope paths.`
    );
  }
  const sourceLabel =
    audit.inputSource === "base" && audit.baseRef
      ? `base ${audit.baseRef}`
      : audit.inputSource === "recorded-base" && audit.baseRef
        ? `recorded-base ${audit.baseRef}`
        : audit.inputSource === "explicit"
          ? "explicit --changed-files"
          : audit.inputSource === "porcelain"
            ? "working-tree porcelain"
            : "unknown";
  const n = audit.changedFileCount ?? 0;
  const planBit = audit.planLocation ? ` [${audit.planLocation}]` : "";
  const caveat =
    audit.reason.includes(NO_BASE_COMMIT_CAVEAT) ? ` ${NO_BASE_COMMIT_CAVEAT}` : "";
  if (audit.reason.includes("no out-of-scope")) {
    return (
      `Scope audit: ran over ${n} changed file(s) against ObservedWriteScope for ${audit.changeId}${planBit}`
      + ` (input: ${sourceLabel}). No out-of-scope paths.${caveat}`
    );
  }
  return (
    `Scope audit: ran over ${n} changed file(s) against ObservedWriteScope for ${audit.changeId}${planBit}`
    + ` (input: ${sourceLabel}).${caveat}`
  );
}

// Re-export catalog helpers used by boundary tests
export {
  ATTEMPT_PAIR_FINDING_CODE,
  WRITE_EVIDENCE_SCOPE_FINDING_CODE,
  isReviewIssueCode,
  allReviewCodes,
  REVIEW_CATALOG,
} from "./catalog";
