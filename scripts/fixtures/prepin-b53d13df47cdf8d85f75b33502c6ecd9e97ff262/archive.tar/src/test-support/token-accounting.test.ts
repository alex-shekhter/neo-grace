import { describe, expect, it } from "bun:test";
import { readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";

import { minimalTsFixture } from "./fixtures";
import {
  commandOutputBytes,
  packageRoot,
  selectionRatio,
  skillTextLines,
} from "./token-accounting";

describe("token-accounting (D15)", () => {
  it("skillTextLines().total reports the measured SKILL.md line count at HEAD", () => {
    // Phase 2: three skills each gained a four-line <verdicts> block (636 → 648).
    // Phase 3: ngrace-cli cursor surface line + ngrace-execute advance/fold rule (648 → 650).
    // Phase 4: ngrace-execute attempt/budget/escalation rule (650 → 651).
    // Phase 5: gate calls in execute/plan + clarification + reviewer verdict-home note (651 → 674).
    // Phase 6: detachment contract + review-first path in reviewer/execute (674 → 709).
    // Phase 7: ngrace-fix localization path (709 → 715; +6 lines on ngrace-fix only).
    // Phase 7 round 2: capture run stream + ground honesty in ngrace-fix (715 → 720).
    // Phase 7 round 3: requirement/transcript semantics in ngrace-fix (720 → 721).
    // Phase 7 round 4: absent vs out-of-order in ngrace-fix (721 → 723).
    // Phase 8: ngrace-cli context --task/--skills line; execute preflight extended in-place (723 → 724).
    // Phase 9: ngrace-execute claimedConfidence + calibration promotion bar (724 → 728).
    // 6.1.0 docs pass: ngrace-cli gains gate/review/doctor and lint --explain lines (728 → 730).
    // C-EXECUTION-CONTRACT: ngrace-execute <cursor_kinds> protocol block (730 → 779; measured).
    // C-ESCALATION-HONESTY T-003: rewrite ngrace-execute R/D + resume --reason prose first,
    // then re-measure — total stayed 779 (in-place line-neutral rewrite of four budget sites
    // + resume How; not a target written toward). Pin remains exact toBe of that measure.
    // C-APPROVE-TIME-REVIEW T-005: approve-time review, F152 lexicon, and XML-escape
    // teaching in ngrace-spec, ngrace-plan, and ngrace-reviewer moved
    // 823 → 832 lines and 60545 → 64021 bytes.
    // C-TAUGHT-RULES T-002: ngrace-execute attempt-kind item-21 rewrite
    // (line-neutral, byte-moving) measured 832 → 832 lines and 64021 → 64155 bytes.
    // C-TAUGHT-RULES T-003: the twenty-seven taught rules landed in the four
    // skills, both trees (measured): 832 → 861 lines and 64155 → 71505 bytes.
    const measured = skillTextLines();
    expect(measured.total).toBe(875);
    expect(measured.perSkill["ngrace-fix"]).toBe(32);
    expect(Object.keys(measured.perSkill).length).toBe(16);
    // Sanity: known skills present
    expect(measured.perSkill["ngrace-init"]).toBeGreaterThan(0);
    expect(measured.perSkill["ngrace-migrate"]).toBeGreaterThan(0);
    // References are counted separately so skill-body deltas stay comparable
    expect(measured.referencesTotal).toBeGreaterThan(0);
  });

  it("skillTextLines().totalBytes is UTF-8 byte sum of SKILL.md files (C-CONTRACT-DEBT T-001)", () => {
    // Measured after instrument landed (not written toward):
    //   bun -e 'import { skillTextLines } from "./src/test-support/token-accounting.ts";
    //           console.log(skillTextLines().totalBytes);'
    // → 53771 at C-CONTRACT-DEBT. C-GRAMMAR-SEAM T-004 skill-prose
    //   rewrite moved the UTF-8 sum; re-measured 53864. Line total
    //   stays 779 (frozen semantics; archived reports cite it).
    // C-CURSOR-TASK-RESOLVER T-003: ngrace-execute protocol sentences
    // moved totalBytes 55106 → 55486; line total stayed 806.
    // C-CRITERION-CLOSE-EVIDENCE T-005: CloseEvidence teaching in the spec,
    // plan and reviewer skills moved both figures: 806 → 810 lines and
    // 55486 → 56110 bytes.
    // C-LINT-PHASE-HONESTY T-005: MustPassCommand doctrine rewrite moved
    // totalBytes 56971 → 58400; line total stayed 812.
    // C-SUPERSEDE-RECORD-2 T-001: discarded kind + supersede teaching
    // moved 812 → 817 lines and 58400 → 58931 bytes.
    // C-REWORK-CIRCUIT T-005: ceiling + circuit kind + resume refuse teaching
    // moved 817 → 822 lines and 58931 → 60325 bytes.
    // C-EVIDENCE-DISCRIMINATION T-003: CloseEvidence discriminating-shape teaching
    // in ngrace-spec moved 822 → 823 lines and 60325 → 60545 bytes.
    // C-APPROVE-TIME-REVIEW T-005: approve-time review, F152 lexicon, and XML-escape
    // teaching in ngrace-spec, ngrace-plan, and ngrace-reviewer moved
    // 823 → 832 lines and 60545 → 64021 bytes.
    // C-TAUGHT-RULES T-002: ngrace-execute attempt-kind item-21 rewrite
    // (line-neutral, byte-moving) measured 832 → 832 lines and 64021 → 64155 bytes.
    // C-TAUGHT-RULES T-003: the twenty-seven taught rules landed in the four
    // skills, both trees (measured): 832 → 861 lines and 64155 → 71505 bytes.
    // C-APPLY-VERB T-005: ngrace-execute items 9 and 10 teach the sanctioned
    // ngrace apply close (line-neutral, byte-moving), measured 861 → 861 lines
    // and 71505 → 71927 bytes.
    // C-FLUSH-AND-TEACH T-002: the five taught rules and the twelve
    // `argv token `explain`` line repairs landed in six skills, both trees
    // (line-neutral, byte-moving): 861 → 861 lines and 71927 → 73362 bytes.
    // C-TEACH-DRIVE-BEFORE-APPROVE-2 T-002: the six taught sentences and the
    // eight stale F247 occurrences repaired landed in four skills, both trees
    // (measured): 861 → 864 lines and 73362 → 75236 bytes.
    // C-HASHED-BUNDLE-IDS T-004: the minted-id sentences landed in ngrace-spec
    // and ngrace-plan, both trees (line-neutral, byte-moving): 864 → 864 lines
    // and 75236 → 75626 bytes.
    // C-PAIR-AUDIT-MINT-CWD-1-ED6B7D22 T-003: the interleaving sentence landed in
    // ngrace-execute, both trees (line-neutral, byte-moving): 864 → 864 lines
    // and 75626 → 75791 bytes.
    // C-TEACH-PLAN-DRIVES-CORRECTIONS-2-1E59AEAA T-002: the seven taught
    // sentences landed in ngrace-plan and ngrace-execute, both trees
    // (line-neutral, byte-moving): 864 → 864 lines and 75791 → 77124 bytes.
    // C-EXPLAIN-ANCHOR-COMMANDS-1-FC0ED3DA T-005: the namespaced-codes sentence
    // landed in ngrace-spec, both trees (line-neutral, byte-moving): 864 → 864
    // lines and 77124 → 77198 bytes.
    // C-TEST-TIMEOUT-CEILING-2-7AD2A006 T-001: the per-test-timeout rule became the
    // --timeout=0 + job-ceiling rule in ngrace-spec, both trees (line-neutral,
    // byte-moving): 866 → 866 lines and 78384 → 78456 bytes.
    // C-TEACHING-INCREMENT-2-4E28E16C T-005: the six taught rules and the D41
    // run-stream rule landed in ngrace-execute, ngrace-plan, ngrace-spec and
    // ngrace-reviewer, both trees (measured): 871 → 873 lines and
    // 81285 → 85595 bytes.
    // C-CI-LINT-AND-PLAN-SHAPE-1-3526D6F0 T-005: the anchor-miss pending-file
    // teaching in ngrace-plan, both trees (line-neutral, byte-moving):
    // 875 → 875 lines and 88664 → 88728 bytes.
    const measured = skillTextLines();
    expect(measured.total).toBe(875);
    expect(measured.totalBytes).toBe(88728);
    const sumBytes = Object.values(measured.perSkillBytes).reduce((a, b) => a + b, 0);
    expect(sumBytes).toBe(measured.totalBytes);
    expect(Object.keys(measured.perSkillBytes).length).toBe(16);
    expect(Object.keys(measured.perSkillBytes).sort()).toEqual(
      Object.keys(measured.perSkill).sort(),
    );
  });

  it("README measurement cell publishes the same skillTextLines total and totalBytes", () => {
    const measured = skillTextLines();
    const readme = readFileSync(path.join(packageRoot(), "README.md"), "utf8");
    expect(readme).toContain(`**${measured.total} lines** / **${measured.totalBytes} UTF-8 bytes**`);
  });

  it("skillTextLines is deterministic for the same root", () => {
    const a = skillTextLines(packageRoot());
    const b = skillTextLines(packageRoot());
    expect(a).toEqual(b);
  });

  it("commandOutputBytes returns a positive size for lint on a fixture", () => {
    const root = minimalTsFixture();
    const { bytes, exitCode } = commandOutputBytes(["lint"], root);
    expect(exitCode).toBe(0);
    expect(bytes).toBeGreaterThan(0);
  });

  it("commandOutputBytes throws on nonzero exit instead of measuring error text", () => {
    expect(() =>
      commandOutputBytes(["lint", "--path", "/tmp/definitely-missing-ngrace-xyz"], packageRoot()),
    ).toThrow(/exited \d+/);
    expect(() => commandOutputBytes(["not-a-real-subcommand"], packageRoot())).toThrow(/exited \d+/);
  });

  it("selectionRatio is the fraction saved", () => {
    expect(selectionRatio(100, 40)).toBeCloseTo(0.6);
    expect(selectionRatio(100, 100)).toBe(0);
    expect(selectionRatio(0, 0)).toBe(0);
  });

  it("canonical SKILL.md D-numbers are immediately preceded by a plan id", () => {
    const skillsRoot = path.join(packageRoot(), "skills", "ngrace");
    const bare: string[] = [];
    const dNumber = /\bD\d+\b/g;
    for (const skill of readdirSync(skillsRoot).sort()) {
      const skillMd = path.join(skillsRoot, skill, "SKILL.md");
      if (!statSync(skillMd, { throwIfNoEntry: false })?.isFile()) continue;
      const text = readFileSync(skillMd, "utf8");
      for (const match of text.matchAll(dNumber)) {
        const before = text.slice(0, match.index);
        if (!/RM-[A-Z0-9-]+ $/.test(before)) {
          bare.push(`${skill}/SKILL.md:${match[0]}`);
        }
      }
    }
    expect(bare).toEqual([]);
  });

  it("selectionRatio rejects selected outside [0, full] and non-finite inputs", () => {
    expect(() => selectionRatio(10, 11)).toThrow(RangeError);
    expect(() => selectionRatio(10, -1)).toThrow(RangeError);
    // full === 0 still rejects selected > 0 (probe: short-circuit used to skip the range check)
    expect(() => selectionRatio(0, 1)).toThrow(RangeError);
    expect(() => selectionRatio(-1, 0)).toThrow(RangeError);
    expect(() => selectionRatio(Number.NaN, 0)).toThrow(RangeError);
    expect(() => selectionRatio(1, Number.NaN)).toThrow(RangeError);
  });
});
